import { Tree } from '@angular-devkit/schematics';
import { workspaces } from '@angular-devkit/core';
export declare function isImportedInMainModule(tree: Tree, project: workspaces.ProjectDefinition, moduleName: string): boolean;
export declare function getAppModulePath(host: Tree, mainPath: string): string;
