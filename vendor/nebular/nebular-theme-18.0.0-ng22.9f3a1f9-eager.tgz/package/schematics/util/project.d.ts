import { Tree } from '@angular-devkit/schematics';
import { workspaces } from '@angular-devkit/core';
/**
 * Gets project workspace from the specified tree by given project name
 * */
export declare function getProject(tree: Tree, projectName: string): Promise<workspaces.ProjectDefinition>;
