import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Inject, Injectable, InjectionToken, Injector, NgModule } from "@angular/core";
import * as i2 from "@angular/common";
import { CommonModule } from "@angular/common";
import * as i2$1 from "@angular/router";
import { RouterModule } from "@angular/router";
import * as i5 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import * as i3 from "@nebular/theme";
import { NB_WINDOW, NbAlertModule, NbButtonModule, NbCardModule, NbCheckboxModule, NbIconModule, NbInputModule, NbLayoutModule } from "@nebular/theme";
import { BehaviorSubject, Subject, of } from "rxjs";
import { catchError, delay, filter, map, share, switchMap, takeUntil } from "rxjs/operators";
import * as i1 from "@angular/common/http";
import { HttpErrorResponse, HttpHeaders, HttpResponse } from "@angular/common/http";
const socialLinks = [];
const defaultAuthOptions = {
	strategies: [],
	forms: {
		login: {
			redirectDelay: 500,
			strategy: "email",
			rememberMe: true,
			showMessages: {
				success: true,
				error: true
			},
			socialLinks
		},
		register: {
			redirectDelay: 500,
			strategy: "email",
			showMessages: {
				success: true,
				error: true
			},
			terms: true,
			socialLinks
		},
		requestPassword: {
			redirectDelay: 500,
			strategy: "email",
			showMessages: {
				success: true,
				error: true
			},
			socialLinks
		},
		resetPassword: {
			redirectDelay: 500,
			strategy: "email",
			showMessages: {
				success: true,
				error: true
			},
			socialLinks
		},
		logout: {
			redirectDelay: 500,
			strategy: "email"
		},
		validation: {
			password: {
				required: true,
				minLength: 4,
				maxLength: 50
			},
			email: { required: true },
			fullName: {
				required: false,
				minLength: 4,
				maxLength: 50
			}
		}
	}
};
const NB_AUTH_OPTIONS = new InjectionToken("Nebular Auth Options");
const NB_AUTH_USER_OPTIONS = new InjectionToken("Nebular User Auth Options");
const NB_AUTH_STRATEGIES = new InjectionToken("Nebular Auth Strategies");
const NB_AUTH_TOKENS = new InjectionToken("Nebular Auth Tokens");
const NB_AUTH_INTERCEPTOR_HEADER = new InjectionToken("Nebular Simple Interceptor Header");
const NB_AUTH_TOKEN_INTERCEPTOR_FILTER = new InjectionToken("Nebular Interceptor Filter");
const deepExtend = function(...objects) {
	if (arguments.length < 1 || typeof arguments[0] !== "object") return false;
	if (arguments.length < 2) return arguments[0];
	const target = arguments[0];
	const args = Array.prototype.slice.call(arguments, 1);
	let val, src;
	args.forEach(function(obj) {
		if (typeof obj !== "object" || Array.isArray(obj)) return;
		Object.keys(obj).forEach(function(key) {
			src = target[key];
			val = obj[key];
			if (val === target) return;
			else if (typeof val !== "object" || val === null) {
				target[key] = val;
				return;
			} else if (Array.isArray(val)) {
				target[key] = deepCloneArray(val);
				return;
			} else if (isSpecificValue(val)) {
				target[key] = cloneSpecificValue(val);
				return;
			} else if (typeof src !== "object" || src === null || Array.isArray(src)) {
				target[key] = deepExtend({}, val);
				return;
			} else {
				target[key] = deepExtend(src, val);
				return;
			}
		});
	});
	return target;
};
function isSpecificValue(val) {
	return val instanceof Date || val instanceof RegExp ? true : false;
}
function cloneSpecificValue(val) {
	if (val instanceof Date) return new Date(val.getTime());
	else if (val instanceof RegExp) return new RegExp(val);
	else throw new Error("cloneSpecificValue: Unexpected situation");
}
function deepCloneArray(arr) {
	const clone = [];
	arr.forEach(function(item, index) {
		if (typeof item === "object" && item !== null) if (Array.isArray(item)) clone[index] = deepCloneArray(item);
		else if (isSpecificValue(item)) clone[index] = cloneSpecificValue(item);
		else clone[index] = deepExtend({}, item);
		else clone[index] = item;
	});
	return clone;
}
function getDeepFromObject(object = {}, name, defaultValue) {
	const keys = name.split(".");
	let level = deepExtend({}, object || {});
	keys.forEach((k) => {
		if (level && typeof level[k] !== "undefined") level = level[k];
		else level = void 0;
	});
	return typeof level === "undefined" ? defaultValue : level;
}
function urlBase64Decode(str) {
	let output = str.replace(/-/g, "+").replace(/_/g, "/");
	switch (output.length % 4) {
		case 0: break;
		case 2:
			output += "==";
			break;
		case 3:
			output += "=";
			break;
		default: throw new Error("Illegal base64url string!");
	}
	return b64DecodeUnicode(output);
}
function b64decode(str) {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
	let output = "";
	str = String(str).replace(/=+$/, "");
	if (str.length % 4 === 1) throw new Error(`'atob' failed: The string to be decoded is not correctly encoded.`);
	for (let bc = 0, bs, buffer, idx = 0; buffer = str.charAt(idx++); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) && (output += String.fromCharCode(255 & bs >> (-2 * bc & 6)))) buffer = chars.indexOf(buffer);
	return output;
}
function b64DecodeUnicode(str) {
	return decodeURIComponent(Array.prototype.map.call(b64decode(str), (c) => {
		return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
	}).join(""));
}
var NbAuthToken = class {
	constructor() {
		this.payload = null;
	}
	getName() {
		return this.constructor.NAME;
	}
	getPayload() {
		return this.payload;
	}
};
var NbAuthTokenNotFoundError = class extends Error {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, new.target.prototype);
	}
};
var NbAuthIllegalTokenError = class extends Error {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, new.target.prototype);
	}
};
var NbAuthEmptyTokenError = class extends NbAuthIllegalTokenError {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, new.target.prototype);
	}
};
var NbAuthIllegalJWTTokenError = class extends NbAuthIllegalTokenError {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, new.target.prototype);
	}
};
function nbAuthCreateToken(tokenClass, token, ownerStrategyName, createdAt) {
	return new tokenClass(token, ownerStrategyName, createdAt);
}
function decodeJwtPayload(payload) {
	if (payload.length === 0) throw new NbAuthEmptyTokenError("Cannot extract from an empty payload.");
	const parts = payload.split(".");
	if (parts.length !== 3) throw new NbAuthIllegalJWTTokenError(`The payload ${payload} is not valid JWT payload and must consist of three parts.`);
	let decoded;
	try {
		decoded = urlBase64Decode(parts[1]);
	} catch (e) {
		throw new NbAuthIllegalJWTTokenError(`The payload ${payload} is not valid JWT payload and cannot be parsed.`);
	}
	if (!decoded) throw new NbAuthIllegalJWTTokenError(`The payload ${payload} is not valid JWT payload and cannot be decoded.`);
	return JSON.parse(decoded);
}
var NbAuthSimpleToken = class extends NbAuthToken {
	static {
		this.NAME = "nb:auth:simple:token";
	}
	constructor(token, ownerStrategyName, createdAt) {
		super();
		this.token = token;
		this.ownerStrategyName = ownerStrategyName;
		this.createdAt = createdAt;
		try {
			this.parsePayload();
		} catch (err) {
			if (!(err instanceof NbAuthTokenNotFoundError)) throw err;
		}
		this.createdAt = this.prepareCreatedAt(createdAt);
	}
	parsePayload() {
		this.payload = null;
	}
	prepareCreatedAt(date) {
		return date ? date : /* @__PURE__ */ new Date();
	}
	getCreatedAt() {
		return this.createdAt;
	}
	getValue() {
		return this.token;
	}
	getOwnerStrategyName() {
		return this.ownerStrategyName;
	}
	isValid() {
		return !!this.getValue();
	}
	toString() {
		return !!this.token ? this.token : "";
	}
};
var NbAuthJWTToken = class extends NbAuthSimpleToken {
	static {
		this.NAME = "nb:auth:jwt:token";
	}
	prepareCreatedAt(date) {
		const decoded = this.getPayload();
		return decoded && decoded.iat ? /* @__PURE__ */ new Date(Number(decoded.iat) * 1e3) : super.prepareCreatedAt(date);
	}
	parsePayload() {
		if (!this.token) throw new NbAuthTokenNotFoundError("Token not found. ");
		this.payload = decodeJwtPayload(this.token);
	}
	getTokenExpDate() {
		const decoded = this.getPayload();
		if (decoded && !decoded.hasOwnProperty("exp")) return null;
		const date = /* @__PURE__ */ new Date(0);
		date.setUTCSeconds(decoded.exp);
		return date;
	}
	isValid() {
		return super.isValid() && (!this.getTokenExpDate() || /* @__PURE__ */ new Date() < this.getTokenExpDate());
	}
};
const prepareOAuth2Token = (data) => {
	if (typeof data === "string") try {
		return JSON.parse(data);
	} catch (e) {}
	return data;
};
var NbAuthOAuth2Token = class extends NbAuthSimpleToken {
	static {
		this.NAME = "nb:auth:oauth2:token";
	}
	constructor(data = {}, ownerStrategyName, createdAt) {
		super(prepareOAuth2Token(data), ownerStrategyName, createdAt);
	}
	getValue() {
		return this.token.access_token;
	}
	getRefreshToken() {
		return this.token.refresh_token;
	}
	setRefreshToken(refreshToken) {
		this.token.refresh_token = refreshToken;
	}
	parsePayload() {
		if (!this.token) throw new NbAuthTokenNotFoundError("Token not found.");
		else if (!Object.keys(this.token).length) throw new NbAuthEmptyTokenError("Cannot extract payload from an empty token.");
		this.payload = this.token;
	}
	getType() {
		return this.token.token_type;
	}
	isValid() {
		return super.isValid() && (!this.getTokenExpDate() || /* @__PURE__ */ new Date() < this.getTokenExpDate());
	}
	getTokenExpDate() {
		if (!this.token.hasOwnProperty("expires_in")) return null;
		return new Date(this.createdAt.getTime() + Number(this.token.expires_in) * 1e3);
	}
	toString() {
		return JSON.stringify(this.token);
	}
};
var NbAuthOAuth2JWTToken = class extends NbAuthOAuth2Token {
	static {
		this.NAME = "nb:auth:oauth2:jwt:token";
	}
	parsePayload() {
		super.parsePayload();
		this.parseAccessTokenPayload();
	}
	parseAccessTokenPayload() {
		const accessToken = this.getValue();
		if (!accessToken) throw new NbAuthTokenNotFoundError("access_token key not found.");
		this.accessTokenPayload = decodeJwtPayload(accessToken);
	}
	getAccessTokenPayload() {
		return this.accessTokenPayload;
	}
	prepareCreatedAt(date) {
		const payload = this.accessTokenPayload;
		return payload && payload.iat ? /* @__PURE__ */ new Date(Number(payload.iat) * 1e3) : super.prepareCreatedAt(date);
	}
	isValid() {
		return this.accessTokenPayload && super.isValid();
	}
	getTokenExpDate() {
		if (this.accessTokenPayload && this.accessTokenPayload.hasOwnProperty("exp")) {
			const date = /* @__PURE__ */ new Date(0);
			date.setUTCSeconds(this.accessTokenPayload.exp);
			return date;
		} else return super.getTokenExpDate();
	}
};
const NB_AUTH_FALLBACK_TOKEN = new InjectionToken("Nebular Auth Options");
var NbAuthTokenParceler = class NbAuthTokenParceler {
	constructor(fallbackClass, tokenClasses) {
		this.fallbackClass = fallbackClass;
		this.tokenClasses = tokenClasses;
	}
	wrap(token) {
		return JSON.stringify({
			name: token.getName(),
			ownerStrategyName: token.getOwnerStrategyName(),
			createdAt: token.getCreatedAt().getTime(),
			value: token.toString()
		});
	}
	unwrap(value) {
		let tokenClass = this.fallbackClass;
		let tokenValue = "";
		let tokenOwnerStrategyName = "";
		let tokenCreatedAt = null;
		const tokenPack = this.parseTokenPack(value);
		if (tokenPack) {
			tokenClass = this.getClassByName(tokenPack.name) || this.fallbackClass;
			tokenValue = tokenPack.value;
			tokenOwnerStrategyName = tokenPack.ownerStrategyName;
			tokenCreatedAt = new Date(Number(tokenPack.createdAt));
		}
		return nbAuthCreateToken(tokenClass, tokenValue, tokenOwnerStrategyName, tokenCreatedAt);
	}
	getClassByName(name) {
		return this.tokenClasses.find((tokenClass) => tokenClass.NAME === name);
	}
	parseTokenPack(value) {
		try {
			return JSON.parse(value);
		} catch (e) {}
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthTokenParceler,
			deps: [{ token: NB_AUTH_FALLBACK_TOKEN }, { token: NB_AUTH_TOKENS }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthTokenParceler
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthTokenParceler,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_AUTH_FALLBACK_TOKEN]
		}]
	}, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_AUTH_TOKENS]
		}]
	}]
});
var NbTokenStorage = class {};
var NbTokenLocalStorage = class NbTokenLocalStorage extends NbTokenStorage {
	constructor(parceler) {
		super();
		this.parceler = parceler;
		this.key = "auth_app_token";
	}
	get() {
		const raw = localStorage.getItem(this.key);
		return this.parceler.unwrap(raw);
	}
	set(token) {
		const raw = this.parceler.wrap(token);
		localStorage.setItem(this.key, raw);
	}
	clear() {
		localStorage.removeItem(this.key);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTokenLocalStorage,
			deps: [{ token: NbAuthTokenParceler }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTokenLocalStorage
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTokenLocalStorage,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbAuthTokenParceler }]
});
var NbTokenService = class NbTokenService {
	constructor(tokenStorage) {
		this.tokenStorage = tokenStorage;
		this.token$ = new BehaviorSubject(null);
		this.publishStoredToken();
	}
	tokenChange() {
		return this.token$.pipe(filter((value) => !!value), share());
	}
	set(token) {
		this.tokenStorage.set(token);
		this.publishStoredToken();
		return of(null);
	}
	get() {
		return of(this.tokenStorage.get());
	}
	clear() {
		this.tokenStorage.clear();
		this.publishStoredToken();
		return of(null);
	}
	publishStoredToken() {
		this.token$.next(this.tokenStorage.get());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTokenService,
			deps: [{ token: NbTokenStorage }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTokenService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTokenService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbTokenStorage }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAuthService = class NbAuthService {
	constructor(tokenService, strategies) {
		this.tokenService = tokenService;
		this.strategies = strategies;
	}
	getToken() {
		return this.tokenService.get();
	}
	isAuthenticated() {
		return this.getToken().pipe(map((token) => token.isValid()));
	}
	isAuthenticatedOrRefresh() {
		return this.getToken().pipe(switchMap((token) => {
			if (token.getValue() && !token.isValid()) return this.refreshToken(token.getOwnerStrategyName(), token).pipe(switchMap((res) => {
				if (res.isSuccess()) return this.isAuthenticated();
				else return of(false);
			}));
			else return of(token.isValid());
		}));
	}
	onTokenChange() {
		return this.tokenService.tokenChange();
	}
	onAuthenticationChange() {
		return this.onTokenChange().pipe(map((token) => token.isValid()));
	}
	authenticate(strategyName, data) {
		return this.getStrategy(strategyName).authenticate(data).pipe(switchMap((result) => {
			return this.processResultToken(result);
		}));
	}
	register(strategyName, data) {
		return this.getStrategy(strategyName).register(data).pipe(switchMap((result) => {
			return this.processResultToken(result);
		}));
	}
	logout(strategyName) {
		return this.getStrategy(strategyName).logout().pipe(switchMap((result) => {
			if (result.isSuccess()) this.tokenService.clear().pipe(map(() => result));
			return of(result);
		}));
	}
	requestPassword(strategyName, data) {
		return this.getStrategy(strategyName).requestPassword(data);
	}
	resetPassword(strategyName, data) {
		return this.getStrategy(strategyName).resetPassword(data);
	}
	refreshToken(strategyName, data) {
		return this.getStrategy(strategyName).refreshToken(data).pipe(switchMap((result) => {
			return this.processResultToken(result);
		}));
	}
	getStrategy(strategyName) {
		const found = this.strategies.find((strategy) => strategy.getName() === strategyName);
		if (!found) throw new TypeError(`There is no Auth Strategy registered under '${strategyName}' name`);
		return found;
	}
	processResultToken(result) {
		if (result.isSuccess() && result.getToken()) return this.tokenService.set(result.getToken()).pipe(map((token) => {
			return result;
		}));
		return of(result);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthService,
			deps: [{ token: NbTokenService }, { token: NB_AUTH_STRATEGIES }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbTokenService }, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_AUTH_STRATEGIES]
		}]
	}]
});
var NbAuthStrategy = class {
	setOptions(options) {
		this.options = deepExtend({}, this.defaultOptions, options);
	}
	getOption(key) {
		return getDeepFromObject(this.options, key, null);
	}
	createToken(value, failWhenInvalidToken) {
		const token = nbAuthCreateToken(this.getOption("token.class"), value, this.getName());
		if (failWhenInvalidToken && !token.isValid()) throw new NbAuthIllegalTokenError("Token is empty or invalid.");
		return token;
	}
	getName() {
		return this.getOption("name");
	}
	createFailResponse(data) {
		return new HttpResponse({
			body: {},
			status: 401
		});
	}
	createSuccessResponse(data) {
		return new HttpResponse({
			body: {},
			status: 200
		});
	}
	getActionEndpoint(action) {
		const actionEndpoint = this.getOption(`${action}.endpoint`);
		const baseEndpoint = this.getOption("baseEndpoint");
		return actionEndpoint ? baseEndpoint + actionEndpoint : "";
	}
	getHeaders() {
		const customHeaders = this.getOption("headers") ?? {};
		if (customHeaders instanceof HttpHeaders) return customHeaders;
		let headers = new HttpHeaders();
		Object.entries(customHeaders).forEach(([key, value]) => {
			headers = headers.append(key, value);
		});
		return headers;
	}
};
var NbAuthResult = class {
	constructor(success, response, redirect, errors, messages, token = null) {
		this.success = success;
		this.response = response;
		this.redirect = redirect;
		this.errors = [];
		this.messages = [];
		this.errors = this.errors.concat([errors]);
		if (errors instanceof Array) this.errors = errors;
		this.messages = this.messages.concat([messages]);
		if (messages instanceof Array) this.messages = messages;
		this.token = token;
	}
	getResponse() {
		return this.response;
	}
	getToken() {
		return this.token;
	}
	getRedirect() {
		return this.redirect;
	}
	getErrors() {
		return this.errors.filter((val) => !!val);
	}
	getMessages() {
		return this.messages.filter((val) => !!val);
	}
	isSuccess() {
		return this.success;
	}
	isFailure() {
		return !this.success;
	}
};
var NbAuthStrategyOptions = class {};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDummyAuthStrategyOptions = class extends NbAuthStrategyOptions {
	constructor() {
		super(...arguments);
		this.token = { class: NbAuthSimpleToken };
		this.delay = 1e3;
		this.alwaysFail = false;
	}
};
const dummyStrategyOptions = new NbDummyAuthStrategyOptions();
var NbDummyAuthStrategy = class NbDummyAuthStrategy extends NbAuthStrategy {
	constructor() {
		super(...arguments);
		this.defaultOptions = dummyStrategyOptions;
	}
	static setup(options) {
		return [NbDummyAuthStrategy, options];
	}
	authenticate(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	register(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	requestPassword(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	resetPassword(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	logout(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	refreshToken(data) {
		return of(this.createDummyResult(data)).pipe(delay(this.getOption("delay")));
	}
	createDummyResult(data) {
		if (this.getOption("alwaysFail")) return new NbAuthResult(false, this.createFailResponse(data), null, ["Something went wrong."]);
		try {
			const token = this.createToken("test token", true);
			return new NbAuthResult(true, this.createSuccessResponse(data), "/", [], ["Successfully logged in."], token);
		} catch (err) {
			return new NbAuthResult(false, this.createFailResponse(data), null, [err.message]);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDummyAuthStrategy,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDummyAuthStrategy
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDummyAuthStrategy,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbOAuth2ResponseType;
(function(NbOAuth2ResponseType) {
	NbOAuth2ResponseType["CODE"] = "code";
	NbOAuth2ResponseType["TOKEN"] = "token";
})(NbOAuth2ResponseType || (NbOAuth2ResponseType = {}));
var NbOAuth2GrantType;
(function(NbOAuth2GrantType) {
	NbOAuth2GrantType["AUTHORIZATION_CODE"] = "authorization_code";
	NbOAuth2GrantType["PASSWORD"] = "password";
	NbOAuth2GrantType["REFRESH_TOKEN"] = "refresh_token";
})(NbOAuth2GrantType || (NbOAuth2GrantType = {}));
var NbOAuth2ClientAuthMethod;
(function(NbOAuth2ClientAuthMethod) {
	NbOAuth2ClientAuthMethod["NONE"] = "none";
	NbOAuth2ClientAuthMethod["BASIC"] = "basic";
	NbOAuth2ClientAuthMethod["REQUEST_BODY"] = "request-body";
})(NbOAuth2ClientAuthMethod || (NbOAuth2ClientAuthMethod = {}));
var NbOAuth2AuthStrategyOptions = class extends NbAuthStrategyOptions {
	constructor() {
		super(...arguments);
		this.baseEndpoint = "";
		this.clientId = "";
		this.clientSecret = "";
		this.clientAuthMethod = NbOAuth2ClientAuthMethod.NONE;
		this.redirect = {
			success: "/",
			failure: null
		};
		this.defaultErrors = ["Something went wrong, please try again."];
		this.defaultMessages = ["You have been successfully authenticated."];
		this.authorize = {
			endpoint: "authorize",
			responseType: NbOAuth2ResponseType.CODE,
			requireValidToken: true
		};
		this.token = {
			endpoint: "token",
			grantType: NbOAuth2GrantType.AUTHORIZATION_CODE,
			requireValidToken: true,
			class: NbAuthOAuth2Token
		};
		this.refresh = {
			endpoint: "token",
			grantType: NbOAuth2GrantType.REFRESH_TOKEN,
			requireValidToken: true
		};
	}
};
const auth2StrategyOptions = new NbOAuth2AuthStrategyOptions();
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbOAuth2AuthStrategy = class NbOAuth2AuthStrategy extends NbAuthStrategy {
	static setup(options) {
		return [NbOAuth2AuthStrategy, options];
	}
	get responseType() {
		return this.getOption("authorize.responseType");
	}
	get clientAuthMethod() {
		return this.getOption("clientAuthMethod");
	}
	constructor(http, route, window) {
		super();
		this.http = http;
		this.route = route;
		this.window = window;
		this.redirectResultHandlers = {
			[NbOAuth2ResponseType.CODE]: () => {
				return of(this.route.snapshot.queryParams).pipe(switchMap((params) => {
					if (params.code) return this.requestToken(params.code);
					return of(new NbAuthResult(false, params, this.getOption("redirect.failure"), this.getOption("defaultErrors"), []));
				}));
			},
			[NbOAuth2ResponseType.TOKEN]: () => {
				const requireValidToken = this.getOption(`authorize.requireValidToken`);
				return of(this.route.snapshot.fragment).pipe(map((fragment) => this.parseHashAsQueryParams(fragment)), map((params) => {
					if (!params.error) return new NbAuthResult(true, params, this.getOption("redirect.success"), [], this.getOption("defaultMessages"), this.createToken(params, requireValidToken));
					return new NbAuthResult(false, params, this.getOption("redirect.failure"), this.getOption("defaultErrors"), []);
				}), catchError((err) => {
					const errors = [];
					if (err instanceof NbAuthIllegalTokenError) errors.push(err.message);
					else errors.push("Something went wrong.");
					return of(new NbAuthResult(false, err, this.getOption("redirect.failure"), errors));
				}));
			}
		};
		this.redirectResults = {
			[NbOAuth2ResponseType.CODE]: () => {
				return of(this.route.snapshot.queryParams).pipe(map((params) => !!(params && (params.code || params.error))));
			},
			[NbOAuth2ResponseType.TOKEN]: () => {
				return of(this.route.snapshot.fragment).pipe(map((fragment) => this.parseHashAsQueryParams(fragment)), map((params) => !!(params && (params.access_token || params.error))));
			}
		};
		this.defaultOptions = auth2StrategyOptions;
	}
	authenticate(data) {
		if (this.getOption("token.grantType") === NbOAuth2GrantType.PASSWORD) return this.passwordToken(data.email, data.password);
		else return this.isRedirectResult().pipe(switchMap((result) => {
			if (!result) {
				this.authorizeRedirect();
				return of(new NbAuthResult(true));
			}
			return this.getAuthorizationResult();
		}));
	}
	getAuthorizationResult() {
		const redirectResultHandler = this.redirectResultHandlers[this.responseType];
		if (redirectResultHandler) return redirectResultHandler.call(this);
		throw new Error(`'${this.responseType}' responseType is not supported,
                      only 'token' and 'code' are supported now`);
	}
	refreshToken(token) {
		const module = "refresh";
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.post(url, this.buildRefreshRequestData(token), { headers: this.getHeaders() }).pipe(map((res) => {
			return new NbAuthResult(true, res, this.getOption("redirect.success"), [], this.getOption("defaultMessages"), this.createRefreshedToken(res, token, requireValidToken));
		}), catchError((res) => this.handleResponseError(res)));
	}
	passwordToken(username, password) {
		const module = "token";
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.post(url, this.buildPasswordRequestData(username, password), { headers: this.getHeaders() }).pipe(map((res) => {
			return new NbAuthResult(true, res, this.getOption("redirect.success"), [], this.getOption("defaultMessages"), this.createToken(res, requireValidToken));
		}), catchError((res) => this.handleResponseError(res)));
	}
	authorizeRedirect() {
		this.window.location.href = this.buildRedirectUrl();
	}
	isRedirectResult() {
		return this.redirectResults[this.responseType].call(this);
	}
	requestToken(code) {
		const module = "token";
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.post(url, this.buildCodeRequestData(code), { headers: this.getHeaders() }).pipe(map((res) => {
			return new NbAuthResult(true, res, this.getOption("redirect.success"), [], this.getOption("defaultMessages"), this.createToken(res, requireValidToken));
		}), catchError((res) => this.handleResponseError(res)));
	}
	buildCodeRequestData(code) {
		const params = {
			grant_type: this.getOption("token.grantType"),
			code,
			redirect_uri: this.getOption("token.redirectUri"),
			client_id: this.getOption("clientId")
		};
		return this.urlEncodeParameters(this.cleanParams(this.addCredentialsToParams(params)));
	}
	buildRefreshRequestData(token) {
		const params = {
			grant_type: this.getOption("refresh.grantType"),
			refresh_token: token.getRefreshToken(),
			scope: this.getOption("refresh.scope"),
			client_id: this.getOption("clientId")
		};
		return this.urlEncodeParameters(this.cleanParams(this.addCredentialsToParams(params)));
	}
	buildPasswordRequestData(username, password) {
		const params = {
			grant_type: this.getOption("token.grantType"),
			username,
			password,
			scope: this.getOption("token.scope")
		};
		return this.urlEncodeParameters(this.cleanParams(this.addCredentialsToParams(params)));
	}
	buildAuthHeader() {
		if (this.clientAuthMethod === NbOAuth2ClientAuthMethod.BASIC) if (this.getOption("clientId") && this.getOption("clientSecret")) return new HttpHeaders({ Authorization: "Basic " + btoa(this.getOption("clientId") + ":" + this.getOption("clientSecret")) });
		else throw Error("For basic client authentication method, please provide both clientId & clientSecret.");
	}
	getHeaders() {
		let headers = super.getHeaders();
		headers = headers.append("Content-Type", "application/x-www-form-urlencoded");
		const authHeaders = this.buildAuthHeader();
		if (authHeaders === void 0) return headers;
		for (const headerKey of authHeaders.keys()) for (const headerValue of authHeaders.getAll(headerKey)) headers = headers.append(headerKey, headerValue);
		return headers;
	}
	cleanParams(params) {
		Object.entries(params).forEach(([key, val]) => !val && delete params[key]);
		return params;
	}
	addCredentialsToParams(params) {
		if (this.clientAuthMethod === NbOAuth2ClientAuthMethod.REQUEST_BODY) if (this.getOption("clientId") && this.getOption("clientSecret")) return {
			...params,
			client_id: this.getOption("clientId"),
			client_secret: this.getOption("clientSecret")
		};
		else throw Error("For request body client authentication method, please provide both clientId & clientSecret.");
		return params;
	}
	handleResponseError(res) {
		let errors = [];
		if (res instanceof HttpErrorResponse) if (res.error.error_description) errors.push(res.error.error_description);
		else errors = this.getOption("defaultErrors");
		else if (res instanceof NbAuthIllegalTokenError) errors.push(res.message);
		else errors.push("Something went wrong.");
		return of(new NbAuthResult(false, res, this.getOption("redirect.failure"), errors, []));
	}
	buildRedirectUrl() {
		const params = {
			response_type: this.getOption("authorize.responseType"),
			client_id: this.getOption("clientId"),
			redirect_uri: this.getOption("authorize.redirectUri"),
			scope: this.getOption("authorize.scope"),
			state: this.getOption("authorize.state"),
			...this.getOption("authorize.params")
		};
		return `${this.getActionEndpoint("authorize")}?${this.urlEncodeParameters(this.cleanParams(params))}`;
	}
	parseHashAsQueryParams(hash) {
		return hash ? hash.split("&").reduce((acc, part) => {
			const item = part.split("=");
			acc[item[0]] = decodeURIComponent(item[1]);
			return acc;
		}, {}) : {};
	}
	urlEncodeParameters(params) {
		return Object.keys(params).map((k) => {
			return `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`;
		}).join("&");
	}
	createRefreshedToken(res, existingToken, requireValidToken) {
		const refreshedToken = this.createToken(res, requireValidToken);
		if (!refreshedToken.getRefreshToken() && existingToken.getRefreshToken()) refreshedToken.setRefreshToken(existingToken.getRefreshToken());
		return refreshedToken;
	}
	register(data) {
		throw new Error("`register` is not supported by `NbOAuth2AuthStrategy`, use `authenticate`.");
	}
	requestPassword(data) {
		throw new Error("`requestPassword` is not supported by `NbOAuth2AuthStrategy`, use `authenticate`.");
	}
	resetPassword(data = {}) {
		throw new Error("`resetPassword` is not supported by `NbOAuth2AuthStrategy`, use `authenticate`.");
	}
	logout() {
		return of(new NbAuthResult(true));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOAuth2AuthStrategy,
			deps: [
				{ token: i1.HttpClient },
				{ token: i2$1.ActivatedRoute },
				{ token: NB_WINDOW }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOAuth2AuthStrategy
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOAuth2AuthStrategy,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: i1.HttpClient },
		{ type: i2$1.ActivatedRoute },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW]
			}]
		}
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbPasswordAuthStrategyOptions = class extends NbAuthStrategyOptions {
	constructor() {
		super(...arguments);
		this.baseEndpoint = "/api/auth/";
		this.login = {
			alwaysFail: false,
			endpoint: "login",
			method: "post",
			requireValidToken: true,
			redirect: {
				success: "/",
				failure: null
			},
			defaultErrors: ["Login/Email combination is not correct, please try again."],
			defaultMessages: ["You have been successfully logged in."]
		};
		this.register = {
			alwaysFail: false,
			endpoint: "register",
			method: "post",
			requireValidToken: true,
			redirect: {
				success: "/",
				failure: null
			},
			defaultErrors: ["Something went wrong, please try again."],
			defaultMessages: ["You have been successfully registered."]
		};
		this.requestPass = {
			endpoint: "request-pass",
			method: "post",
			redirect: {
				success: "/",
				failure: null
			},
			defaultErrors: ["Something went wrong, please try again."],
			defaultMessages: ["Reset password instructions have been sent to your email."]
		};
		this.resetPass = {
			endpoint: "reset-pass",
			method: "put",
			redirect: {
				success: "/",
				failure: null
			},
			resetPasswordTokenKey: "reset_password_token",
			defaultErrors: ["Something went wrong, please try again."],
			defaultMessages: ["Your password has been successfully changed."]
		};
		this.logout = {
			alwaysFail: false,
			endpoint: "logout",
			method: "delete",
			redirect: {
				success: "/",
				failure: null
			},
			defaultErrors: ["Something went wrong, please try again."],
			defaultMessages: ["You have been successfully logged out."]
		};
		this.refreshToken = {
			endpoint: "refresh-token",
			method: "post",
			requireValidToken: true,
			redirect: {
				success: null,
				failure: null
			},
			defaultErrors: ["Something went wrong, please try again."],
			defaultMessages: ["Your token has been successfully refreshed."]
		};
		this.token = {
			class: NbAuthSimpleToken,
			key: "data.token",
			getter: (module, res, options) => getDeepFromObject(res.body, options.token.key)
		};
		this.errors = {
			key: "data.errors",
			getter: (module, res, options) => getDeepFromObject(res.error, options.errors.key, options[module].defaultErrors)
		};
		this.messages = {
			key: "data.messages",
			getter: (module, res, options) => getDeepFromObject(res.body, options.messages.key, options[module].defaultMessages)
		};
	}
};
const passwordStrategyOptions = new NbPasswordAuthStrategyOptions();
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbPasswordAuthStrategy = class NbPasswordAuthStrategy extends NbAuthStrategy {
	static setup(options) {
		return [NbPasswordAuthStrategy, options];
	}
	constructor(http, route) {
		super();
		this.http = http;
		this.route = route;
		this.defaultOptions = passwordStrategyOptions;
	}
	authenticate(data) {
		const module = "login";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.request(method, url, {
			body: data,
			observe: "response",
			headers: this.getHeaders()
		}).pipe(map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse(data);
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options), this.createToken(this.getOption("token.getter")(module, res, this.options), requireValidToken));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	register(data) {
		const module = "register";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.request(method, url, {
			body: data,
			observe: "response",
			headers: this.getHeaders()
		}).pipe(map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse(data);
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options), this.createToken(this.getOption("token.getter")("login", res, this.options), requireValidToken));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	requestPassword(data) {
		const module = "requestPass";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		return this.http.request(method, url, {
			body: data,
			observe: "response",
			headers: this.getHeaders()
		}).pipe(map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse();
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	resetPassword(data = {}) {
		const module = "resetPass";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		const tokenKey = this.getOption(`${module}.resetPasswordTokenKey`);
		data[tokenKey] = this.route.snapshot.queryParams[tokenKey];
		return this.http.request(method, url, {
			body: data,
			observe: "response",
			headers: this.getHeaders()
		}).pipe(map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse();
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	logout() {
		const module = "logout";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		return of({}).pipe(switchMap((res) => {
			if (!url) return of(res);
			return this.http.request(method, url, {
				observe: "response",
				headers: this.getHeaders()
			});
		}), map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse();
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	refreshToken(data) {
		const module = "refreshToken";
		const method = this.getOption(`${module}.method`);
		const url = this.getActionEndpoint(module);
		const requireValidToken = this.getOption(`${module}.requireValidToken`);
		return this.http.request(method, url, {
			body: data,
			observe: "response",
			headers: this.getHeaders()
		}).pipe(map((res) => {
			if (this.getOption(`${module}.alwaysFail`)) throw this.createFailResponse(data);
			return res;
		}), map((res) => {
			return new NbAuthResult(true, res, this.getOption(`${module}.redirect.success`), [], this.getOption("messages.getter")(module, res, this.options), this.createToken(this.getOption("token.getter")(module, res, this.options), requireValidToken));
		}), catchError((res) => {
			return this.handleResponseError(res, module);
		}));
	}
	handleResponseError(res, module) {
		let errors = [];
		if (res instanceof HttpErrorResponse) errors = this.getOption("errors.getter")(module, res, this.options);
		else if (res instanceof NbAuthIllegalTokenError) errors.push(res.message);
		else errors.push("Something went wrong.");
		return of(new NbAuthResult(false, res, this.getOption(`${module}.redirect.failure`), errors));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPasswordAuthStrategy,
			deps: [{ token: i1.HttpClient }, { token: i2$1.ActivatedRoute }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPasswordAuthStrategy
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPasswordAuthStrategy,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i1.HttpClient }, { type: i2$1.ActivatedRoute }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAuthBlockComponent = class NbAuthBlockComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthBlockComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAuthBlockComponent,
			isStandalone: false,
			selector: "nb-auth-block",
			ngImport: i0,
			template: `
    <ng-content></ng-content>
  `,
			isInline: true,
			styles: [":host{display:block;width:100%;max-width:35rem}:host ::ng-deep form{width:100%}:host ::ng-deep .label{display:block;margin-bottom:.5rem}:host ::ng-deep .forgot-password{text-decoration:none;margin-bottom:.5rem}:host ::ng-deep .caption{margin-top:.5rem}:host ::ng-deep .alert{text-align:center}:host ::ng-deep .title{margin-top:0;margin-bottom:.75rem;text-align:center}:host ::ng-deep .sub-title{margin-bottom:2rem;text-align:center}:host ::ng-deep .form-control-group{margin-bottom:2rem}:host ::ng-deep .form-control-group.accept-group{display:flex;justify-content:space-between;margin:2rem 0}:host ::ng-deep .label-with-link{display:flex;justify-content:space-between}:host ::ng-deep .links{text-align:center;margin-top:1.75rem}:host ::ng-deep .links .socials{margin-top:1.5rem}:host ::ng-deep .links .socials a{margin:0 1rem;text-decoration:none;vertical-align:middle}:host ::ng-deep .links .socials a.with-icon{font-size:2rem}:host ::ng-deep .another-action{margin-top:2rem;text-align:center}:host ::ng-deep .sign-in-or-up{margin-top:2rem;display:flex;justify-content:space-between}:host ::ng-deep nb-alert .alert-title,:host ::ng-deep nb-alert .alert-message{margin:0 0 .5rem}:host ::ng-deep nb-alert .alert-message-list{list-style-type:none;padding:0;margin:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthBlockComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-auth-block",
			template: `
    <ng-content></ng-content>
  `,
			standalone: false,
			styles: [":host{display:block;width:100%;max-width:35rem}:host ::ng-deep form{width:100%}:host ::ng-deep .label{display:block;margin-bottom:.5rem}:host ::ng-deep .forgot-password{text-decoration:none;margin-bottom:.5rem}:host ::ng-deep .caption{margin-top:.5rem}:host ::ng-deep .alert{text-align:center}:host ::ng-deep .title{margin-top:0;margin-bottom:.75rem;text-align:center}:host ::ng-deep .sub-title{margin-bottom:2rem;text-align:center}:host ::ng-deep .form-control-group{margin-bottom:2rem}:host ::ng-deep .form-control-group.accept-group{display:flex;justify-content:space-between;margin:2rem 0}:host ::ng-deep .label-with-link{display:flex;justify-content:space-between}:host ::ng-deep .links{text-align:center;margin-top:1.75rem}:host ::ng-deep .links .socials{margin-top:1.5rem}:host ::ng-deep .links .socials a{margin:0 1rem;text-decoration:none;vertical-align:middle}:host ::ng-deep .links .socials a.with-icon{font-size:2rem}:host ::ng-deep .another-action{margin-top:2rem;text-align:center}:host ::ng-deep .sign-in-or-up{margin-top:2rem;display:flex;justify-content:space-between}:host ::ng-deep nb-alert .alert-title,:host ::ng-deep nb-alert .alert-message{margin:0 0 .5rem}:host ::ng-deep nb-alert .alert-message-list{list-style-type:none;padding:0;margin:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAuthComponent = class NbAuthComponent {
	constructor(auth, location) {
		this.auth = auth;
		this.location = location;
		this.destroy$ = new Subject();
		this.authenticated = false;
		this.token = "";
		this.subscription = auth.onAuthenticationChange().pipe(takeUntil(this.destroy$)).subscribe((authenticated) => {
			this.authenticated = authenticated;
		});
	}
	back() {
		this.location.back();
		return false;
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthComponent,
			deps: [{ token: NbAuthService }, { token: i2.Location }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAuthComponent,
			isStandalone: false,
			selector: "nb-auth",
			ngImport: i0,
			template: `
    <nb-layout>
      <nb-layout-column>
        <nb-card>
          <nb-card-header>
            <nav class="navigation">
              <a href="#" (click)="back()" class="link back-link" aria-label="Back">
                <nb-icon icon="arrow-back"></nb-icon>
              </a>
            </nav>
          </nb-card-header>
          <nb-card-body>
            <nb-auth-block>
              <router-outlet></router-outlet>
            </nb-auth-block>
          </nb-card-body>
        </nb-card>
      </nb-layout-column>
    </nb-layout>
  `,
			isInline: true,
			styles: [".visually-hidden{position:absolute!important;height:1px;width:1px;overflow:hidden;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px)}.cdk-overlay-container,.cdk-global-overlay-wrapper{pointer-events:none;top:0;left:0;height:100%;width:100%}.cdk-overlay-container{position:fixed;z-index:1000}.cdk-overlay-container:empty{display:none}.cdk-global-overlay-wrapper{display:flex;position:absolute;z-index:1000}.cdk-overlay-pane{position:absolute;pointer-events:auto;box-sizing:border-box;display:flex;max-width:100%;max-height:100%;z-index:1000}.cdk-overlay-backdrop{position:absolute;inset:0;pointer-events:auto;-webkit-tap-highlight-color:transparent;opacity:0;touch-action:manipulation;z-index:1000;transition:opacity .4s cubic-bezier(.25,.8,.25,1)}@media(prefers-reduced-motion){.cdk-overlay-backdrop{transition-duration:1ms}}.cdk-overlay-backdrop-showing{opacity:1}@media(forced-colors:active){.cdk-overlay-backdrop-showing{opacity:.6}}.cdk-overlay-dark-backdrop{background:#00000052}.cdk-overlay-transparent-backdrop{transition:visibility 1ms linear,opacity 1ms linear;visibility:hidden;opacity:1}.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing,.cdk-high-contrast-active .cdk-overlay-transparent-backdrop{opacity:0;visibility:visible}.cdk-overlay-backdrop-noop-animation{transition:none}.cdk-overlay-connected-position-bounding-box{position:absolute;display:flex;flex-direction:column;min-width:1px;min-height:1px;z-index:1000}.cdk-global-scrollblock{position:fixed;width:100%;overflow-y:scroll}.cdk-overlay-popover{background:none;border:none;padding:0;outline:0;overflow:visible;position:fixed;pointer-events:none;white-space:normal;color:inherit;text-decoration:none;width:100%;height:100%;inset:0 auto auto 0}.cdk-overlay-popover::backdrop{display:none}.cdk-overlay-popover .cdk-overlay-backdrop{position:fixed;z-index:auto}.nb-global-scrollblock{position:static;width:auto;overflow:hidden}html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}html,body{margin:0;padding:0}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}h1{font-size:2em;margin:.67em 0}hr{box-sizing:content-box;height:0;overflow:visible}pre{font-family:monospace,monospace;font-size:1em}a{background-color:transparent}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,samp{font-family:monospace,monospace;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,input{overflow:visible}button,select{text-transform:none}button,[type=button],[type=reset],[type=submit]{-webkit-appearance:button}button::-moz-focus-inner,[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner{border-style:none;padding:0}button:-moz-focusring,[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{vertical-align:baseline}textarea{overflow:auto}[type=checkbox],[type=radio]{box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}details{display:block}summary{display:list-item}template{display:none}[hidden]{display:none}:host nb-card{margin:0;height:calc(100vh - 5rem)}:host .navigation .link{display:inline-block;text-decoration:none}:host .navigation .link nb-icon{font-size:2rem;vertical-align:middle}:host .links nb-icon{font-size:2.5rem}:host nb-card-body{display:flex;width:100%}:host nb-auth-block{margin:auto}@media(max-width:767.98px){:host nb-card{border-radius:0;height:100vh}}:host ::ng-deep nb-layout .layout .layout-container .content .columns nb-layout-column{padding:2.5rem}@media(max-width:767.98px){:host ::ng-deep nb-layout .layout .layout-container .content .columns nb-layout-column{padding:0}}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "component",
					type: i3.NbLayoutComponent,
					selector: "nb-layout",
					inputs: [
						"center",
						"windowMode",
						"withScroll",
						"restoreScrollTop"
					]
				},
				{
					kind: "component",
					type: i3.NbLayoutColumnComponent,
					selector: "nb-layout-column",
					inputs: ["left", "start"]
				},
				{
					kind: "component",
					type: i3.NbCardComponent,
					selector: "nb-card",
					inputs: [
						"size",
						"status",
						"accent"
					]
				},
				{
					kind: "component",
					type: i3.NbCardBodyComponent,
					selector: "nb-card-body"
				},
				{
					kind: "component",
					type: i3.NbCardHeaderComponent,
					selector: "nb-card-header"
				},
				{
					kind: "directive",
					type: i2$1.RouterOutlet,
					selector: "router-outlet",
					inputs: ["name", "routerOutletData"],
					outputs: [
						"activate",
						"deactivate",
						"attach",
						"detach"
					],
					exportAs: ["outlet"]
				},
				{
					kind: "component",
					type: i3.NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbAuthBlockComponent,
					selector: "nb-auth-block"
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-auth",
			template: `
    <nb-layout>
      <nb-layout-column>
        <nb-card>
          <nb-card-header>
            <nav class="navigation">
              <a href="#" (click)="back()" class="link back-link" aria-label="Back">
                <nb-icon icon="arrow-back"></nb-icon>
              </a>
            </nav>
          </nb-card-header>
          <nb-card-body>
            <nb-auth-block>
              <router-outlet></router-outlet>
            </nb-auth-block>
          </nb-card-body>
        </nb-card>
      </nb-layout-column>
    </nb-layout>
  `,
			standalone: false,
			styles: [".visually-hidden{position:absolute!important;height:1px;width:1px;overflow:hidden;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px)}.cdk-overlay-container,.cdk-global-overlay-wrapper{pointer-events:none;top:0;left:0;height:100%;width:100%}.cdk-overlay-container{position:fixed;z-index:1000}.cdk-overlay-container:empty{display:none}.cdk-global-overlay-wrapper{display:flex;position:absolute;z-index:1000}.cdk-overlay-pane{position:absolute;pointer-events:auto;box-sizing:border-box;display:flex;max-width:100%;max-height:100%;z-index:1000}.cdk-overlay-backdrop{position:absolute;inset:0;pointer-events:auto;-webkit-tap-highlight-color:transparent;opacity:0;touch-action:manipulation;z-index:1000;transition:opacity .4s cubic-bezier(.25,.8,.25,1)}@media(prefers-reduced-motion){.cdk-overlay-backdrop{transition-duration:1ms}}.cdk-overlay-backdrop-showing{opacity:1}@media(forced-colors:active){.cdk-overlay-backdrop-showing{opacity:.6}}.cdk-overlay-dark-backdrop{background:#00000052}.cdk-overlay-transparent-backdrop{transition:visibility 1ms linear,opacity 1ms linear;visibility:hidden;opacity:1}.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing,.cdk-high-contrast-active .cdk-overlay-transparent-backdrop{opacity:0;visibility:visible}.cdk-overlay-backdrop-noop-animation{transition:none}.cdk-overlay-connected-position-bounding-box{position:absolute;display:flex;flex-direction:column;min-width:1px;min-height:1px;z-index:1000}.cdk-global-scrollblock{position:fixed;width:100%;overflow-y:scroll}.cdk-overlay-popover{background:none;border:none;padding:0;outline:0;overflow:visible;position:fixed;pointer-events:none;white-space:normal;color:inherit;text-decoration:none;width:100%;height:100%;inset:0 auto auto 0}.cdk-overlay-popover::backdrop{display:none}.cdk-overlay-popover .cdk-overlay-backdrop{position:fixed;z-index:auto}.nb-global-scrollblock{position:static;width:auto;overflow:hidden}html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}html,body{margin:0;padding:0}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}h1{font-size:2em;margin:.67em 0}hr{box-sizing:content-box;height:0;overflow:visible}pre{font-family:monospace,monospace;font-size:1em}a{background-color:transparent}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,samp{font-family:monospace,monospace;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,input{overflow:visible}button,select{text-transform:none}button,[type=button],[type=reset],[type=submit]{-webkit-appearance:button}button::-moz-focus-inner,[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner{border-style:none;padding:0}button:-moz-focusring,[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{vertical-align:baseline}textarea{overflow:auto}[type=checkbox],[type=radio]{box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}details{display:block}summary{display:list-item}template{display:none}[hidden]{display:none}:host nb-card{margin:0;height:calc(100vh - 5rem)}:host .navigation .link{display:inline-block;text-decoration:none}:host .navigation .link nb-icon{font-size:2rem;vertical-align:middle}:host .links nb-icon{font-size:2.5rem}:host nb-card-body{display:flex;width:100%}:host nb-auth-block{margin:auto}@media(max-width:767.98px){:host nb-card{border-radius:0;height:100vh}}:host ::ng-deep nb-layout .layout .layout-container .content .columns nb-layout-column{padding:2.5rem}@media(max-width:767.98px){:host ::ng-deep nb-layout .layout .layout-container .content .columns nb-layout-column{padding:0}}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbAuthService }, { type: i2.Location }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbLoginComponent = class NbLoginComponent {
	constructor(service, options = {}, cd, router) {
		this.service = service;
		this.options = options;
		this.cd = cd;
		this.router = router;
		this.redirectDelay = 0;
		this.showMessages = {};
		this.strategy = "";
		this.errors = [];
		this.messages = [];
		this.user = {};
		this.submitted = false;
		this.socialLinks = [];
		this.rememberMe = false;
		this.redirectDelay = this.getConfigValue("forms.login.redirectDelay");
		this.showMessages = this.getConfigValue("forms.login.showMessages");
		this.strategy = this.getConfigValue("forms.login.strategy");
		this.socialLinks = this.getConfigValue("forms.login.socialLinks");
		this.rememberMe = this.getConfigValue("forms.login.rememberMe");
	}
	login() {
		this.errors = [];
		this.messages = [];
		this.submitted = true;
		this.service.authenticate(this.strategy, this.user).subscribe((result) => {
			this.submitted = false;
			if (result.isSuccess()) this.messages = result.getMessages();
			else this.errors = result.getErrors();
			const redirect = result.getRedirect();
			if (redirect) setTimeout(() => {
				return this.router.navigateByUrl(redirect);
			}, this.redirectDelay);
			this.cd.detectChanges();
		});
	}
	getConfigValue(key) {
		return getDeepFromObject(this.options, key, null);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLoginComponent,
			deps: [
				{ token: NbAuthService },
				{ token: NB_AUTH_OPTIONS },
				{ token: i0.ChangeDetectorRef },
				{ token: i2$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLoginComponent,
			isStandalone: false,
			selector: "nb-login",
			ngImport: i0,
			template: "<h1 id=\"title\" class=\"title\">Login</h1>\n<p class=\"sub-title\">Hello! Log in with your email.</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"login()\" #form=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Email address:</label>\n    <input nbInput\n           fullWidth\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           name=\"email\"\n           id=\"input-email\"\n           pattern=\".+@.+\\..+\"\n           placeholder=\"Email address\"\n           fieldSize=\"large\"\n           autofocus\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <span class=\"label-with-link\">\n      <label class=\"label\" for=\"input-password\">Password:</label>\n      <a class=\"forgot-password caption-2\" routerLink=\"../request-password\">Forgot Password?</a>\n    </span>\n    <input nbInput\n           fullWidth\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           name=\"password\"\n           type=\"password\"\n           id=\"input-password\"\n           placeholder=\"Password\"\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched \">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contain\n        from {{ getConfigValue('forms.validation.password.minLength') }}\n        to {{ getConfigValue('forms.validation.password.maxLength') }}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group accept-group\">\n    <nb-checkbox name=\"rememberMe\" [(ngModel)]=\"user.rememberMe\" *ngIf=\"rememberMe\">Remember me</nb-checkbox>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !form.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Log In\n  </button>\n</form>\n\n<section *ngIf=\"socialLinks && socialLinks.length > 0\" class=\"links\" aria-label=\"Social sign in\">\n  or enter with:\n  <div class=\"socials\">\n    <ng-container *ngFor=\"let socialLink of socialLinks\">\n      <a *ngIf=\"socialLink.link\"\n         [routerLink]=\"socialLink.link\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n      <a *ngIf=\"socialLink.url\"\n         [attr.href]=\"socialLink.url\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n    </ng-container>\n  </div>\n</section>\n\n<section class=\"another-action\" aria-label=\"Register\">\n  Don't have an account? <a class=\"text-link\" routerLink=\"../register\">Register</a>\n</section>\n",
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: i3.NbCheckboxComponent,
					selector: "nb-checkbox",
					inputs: [
						"checked",
						"disabled",
						"status",
						"indeterminate"
					],
					outputs: ["checkedChange"]
				},
				{
					kind: "component",
					type: i3.NbAlertComponent,
					selector: "nb-alert",
					inputs: [
						"size",
						"status",
						"accent",
						"outline",
						"closable"
					],
					outputs: ["close"]
				},
				{
					kind: "directive",
					type: i3.NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: i3.NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				},
				{
					kind: "directive",
					type: i2$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: i5.ɵNgNoValidate,
					selector: "form:not([ngNoForm]):not([ngNativeValidate])"
				},
				{
					kind: "directive",
					type: i5.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatusGroup,
					selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
				},
				{
					kind: "directive",
					type: i5.RequiredValidator,
					selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
					inputs: ["required"]
				},
				{
					kind: "directive",
					type: i5.MinLengthValidator,
					selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]",
					inputs: ["minlength"]
				},
				{
					kind: "directive",
					type: i5.MaxLengthValidator,
					selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]",
					inputs: ["maxlength"]
				},
				{
					kind: "directive",
					type: i5.PatternValidator,
					selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]",
					inputs: ["pattern"]
				},
				{
					kind: "directive",
					type: i5.NgModel,
					selector: "[ngModel]:not([formControlName]):not([formControl])",
					inputs: [
						"name",
						"disabled",
						"ngModel",
						"ngModelOptions"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngModel"]
				},
				{
					kind: "directive",
					type: i5.NgForm,
					selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
					inputs: ["ngFormOptions"],
					outputs: ["ngSubmit"],
					exportAs: ["ngForm"]
				},
				{
					kind: "component",
					type: i3.NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLoginComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-login",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<h1 id=\"title\" class=\"title\">Login</h1>\n<p class=\"sub-title\">Hello! Log in with your email.</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"login()\" #form=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Email address:</label>\n    <input nbInput\n           fullWidth\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           name=\"email\"\n           id=\"input-email\"\n           pattern=\".+@.+\\..+\"\n           placeholder=\"Email address\"\n           fieldSize=\"large\"\n           autofocus\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <span class=\"label-with-link\">\n      <label class=\"label\" for=\"input-password\">Password:</label>\n      <a class=\"forgot-password caption-2\" routerLink=\"../request-password\">Forgot Password?</a>\n    </span>\n    <input nbInput\n           fullWidth\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           name=\"password\"\n           type=\"password\"\n           id=\"input-password\"\n           placeholder=\"Password\"\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched \">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contain\n        from {{ getConfigValue('forms.validation.password.minLength') }}\n        to {{ getConfigValue('forms.validation.password.maxLength') }}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group accept-group\">\n    <nb-checkbox name=\"rememberMe\" [(ngModel)]=\"user.rememberMe\" *ngIf=\"rememberMe\">Remember me</nb-checkbox>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !form.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Log In\n  </button>\n</form>\n\n<section *ngIf=\"socialLinks && socialLinks.length > 0\" class=\"links\" aria-label=\"Social sign in\">\n  or enter with:\n  <div class=\"socials\">\n    <ng-container *ngFor=\"let socialLink of socialLinks\">\n      <a *ngIf=\"socialLink.link\"\n         [routerLink]=\"socialLink.link\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n      <a *ngIf=\"socialLink.url\"\n         [attr.href]=\"socialLink.url\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n    </ng-container>\n  </div>\n</section>\n\n<section class=\"another-action\" aria-label=\"Register\">\n  Don't have an account? <a class=\"text-link\" routerLink=\"../register\">Register</a>\n</section>\n"
		}]
	}],
	ctorParameters: () => [
		{ type: NbAuthService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_AUTH_OPTIONS]
			}]
		},
		{ type: i0.ChangeDetectorRef },
		{ type: i2$1.Router }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRegisterComponent = class NbRegisterComponent {
	constructor(service, options = {}, cd, router) {
		this.service = service;
		this.options = options;
		this.cd = cd;
		this.router = router;
		this.redirectDelay = 0;
		this.showMessages = {};
		this.strategy = "";
		this.submitted = false;
		this.errors = [];
		this.messages = [];
		this.user = {};
		this.socialLinks = [];
		this.redirectDelay = this.getConfigValue("forms.register.redirectDelay");
		this.showMessages = this.getConfigValue("forms.register.showMessages");
		this.strategy = this.getConfigValue("forms.register.strategy");
		this.socialLinks = this.getConfigValue("forms.login.socialLinks");
	}
	register() {
		this.errors = this.messages = [];
		this.submitted = true;
		this.service.register(this.strategy, this.user).subscribe((result) => {
			this.submitted = false;
			if (result.isSuccess()) this.messages = result.getMessages();
			else this.errors = result.getErrors();
			const redirect = result.getRedirect();
			if (redirect) setTimeout(() => {
				return this.router.navigateByUrl(redirect);
			}, this.redirectDelay);
			this.cd.detectChanges();
		});
	}
	getConfigValue(key) {
		return getDeepFromObject(this.options, key, null);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRegisterComponent,
			deps: [
				{ token: NbAuthService },
				{ token: NB_AUTH_OPTIONS },
				{ token: i0.ChangeDetectorRef },
				{ token: i2$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRegisterComponent,
			isStandalone: false,
			selector: "nb-register",
			ngImport: i0,
			template: "<h1 id=\"title\" class=\"title\">Register</h1>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"register()\" #form=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-name\">Full name:</label>\n    <input nbInput\n           [(ngModel)]=\"user.fullName\"\n           #fullName=\"ngModel\"\n           id=\"input-name\"\n           name=\"fullName\"\n           placeholder=\"Full name\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"fullName.dirty ? (fullName.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.fullName.required')\"\n           [minlength]=\"getConfigValue('forms.validation.fullName.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.fullName.maxLength')\"\n           [attr.aria-invalid]=\"fullName.invalid && fullName.touched ? true : null\">\n    <ng-container *ngIf=\"fullName.invalid && fullName.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"fullName.errors?.required\">\n        Full name is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"fullName.errors?.minlength || fullName.errors?.maxlength\">\n        Full name should contains\n        from {{getConfigValue('forms.validation.fullName.minLength')}}\n        to {{getConfigValue('forms.validation.fullName.maxLength')}}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Email address:</label>\n    <input nbInput\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           id=\"input-email\"\n           name=\"email\"\n           pattern=\".+@.+..+\"\n           placeholder=\"Email address\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-password\">Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           type=\"password\"\n           id=\"input-password\"\n           name=\"password\"\n           placeholder=\"Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contain\n        from {{ getConfigValue('forms.validation.password.minLength') }}\n        to {{ getConfigValue('forms.validation.password.maxLength') }}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-re-password\">Repeat password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.confirmPassword\"\n           #rePass=\"ngModel\"\n           type=\"password\"\n           id=\"input-re-password\"\n           name=\"rePass\"\n           placeholder=\"Confirm Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"rePass.dirty ? (rePass.invalid || password.value != rePass.value  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [attr.aria-invalid]=\"rePass.invalid && rePass.touched ? true : null\">\n    <ng-container *ngIf=\"rePass.invalid && rePass.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"rePass.errors?.required\">\n        Password confirmation is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.value != rePass.value && !rePass.errors?.required\">\n        Password does not match the confirm password.\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group accept-group\" *ngIf=\"getConfigValue('forms.register.terms')\">\n    <nb-checkbox name=\"terms\" [(ngModel)]=\"user.terms\" [required]=\"getConfigValue('forms.register.terms')\">\n      Agree to <a href=\"#\" target=\"_blank\"><strong>Terms & Conditions</strong></a>\n    </nb-checkbox>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !form.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Register\n  </button>\n</form>\n\n<section *ngIf=\"socialLinks && socialLinks.length > 0\" class=\"links\" aria-label=\"Social sign in\">\n  or enter with:\n  <div class=\"socials\">\n    <ng-container *ngFor=\"let socialLink of socialLinks\">\n      <a *ngIf=\"socialLink.link\"\n         [routerLink]=\"socialLink.link\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n      <a *ngIf=\"socialLink.url\"\n         [attr.href]=\"socialLink.url\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n    </ng-container>\n  </div>\n</section>\n\n<section class=\"another-action\" aria-label=\"Sign in\">\n  Already have an account? <a class=\"text-link\" routerLink=\"../login\">Log in</a>\n</section>\n",
			styles: [":host .title{margin-bottom:2rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: i3.NbCheckboxComponent,
					selector: "nb-checkbox",
					inputs: [
						"checked",
						"disabled",
						"status",
						"indeterminate"
					],
					outputs: ["checkedChange"]
				},
				{
					kind: "component",
					type: i3.NbAlertComponent,
					selector: "nb-alert",
					inputs: [
						"size",
						"status",
						"accent",
						"outline",
						"closable"
					],
					outputs: ["close"]
				},
				{
					kind: "directive",
					type: i3.NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: i3.NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				},
				{
					kind: "directive",
					type: i2$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: i5.ɵNgNoValidate,
					selector: "form:not([ngNoForm]):not([ngNativeValidate])"
				},
				{
					kind: "directive",
					type: i5.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatusGroup,
					selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
				},
				{
					kind: "directive",
					type: i5.RequiredValidator,
					selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
					inputs: ["required"]
				},
				{
					kind: "directive",
					type: i5.MinLengthValidator,
					selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]",
					inputs: ["minlength"]
				},
				{
					kind: "directive",
					type: i5.MaxLengthValidator,
					selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]",
					inputs: ["maxlength"]
				},
				{
					kind: "directive",
					type: i5.PatternValidator,
					selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]",
					inputs: ["pattern"]
				},
				{
					kind: "directive",
					type: i5.NgModel,
					selector: "[ngModel]:not([formControlName]):not([formControl])",
					inputs: [
						"name",
						"disabled",
						"ngModel",
						"ngModelOptions"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngModel"]
				},
				{
					kind: "directive",
					type: i5.NgForm,
					selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
					inputs: ["ngFormOptions"],
					outputs: ["ngSubmit"],
					exportAs: ["ngForm"]
				},
				{
					kind: "component",
					type: i3.NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRegisterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-register",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<h1 id=\"title\" class=\"title\">Register</h1>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"register()\" #form=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-name\">Full name:</label>\n    <input nbInput\n           [(ngModel)]=\"user.fullName\"\n           #fullName=\"ngModel\"\n           id=\"input-name\"\n           name=\"fullName\"\n           placeholder=\"Full name\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"fullName.dirty ? (fullName.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.fullName.required')\"\n           [minlength]=\"getConfigValue('forms.validation.fullName.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.fullName.maxLength')\"\n           [attr.aria-invalid]=\"fullName.invalid && fullName.touched ? true : null\">\n    <ng-container *ngIf=\"fullName.invalid && fullName.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"fullName.errors?.required\">\n        Full name is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"fullName.errors?.minlength || fullName.errors?.maxlength\">\n        Full name should contains\n        from {{getConfigValue('forms.validation.fullName.minLength')}}\n        to {{getConfigValue('forms.validation.fullName.maxLength')}}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Email address:</label>\n    <input nbInput\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           id=\"input-email\"\n           name=\"email\"\n           pattern=\".+@.+..+\"\n           placeholder=\"Email address\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-password\">Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           type=\"password\"\n           id=\"input-password\"\n           name=\"password\"\n           placeholder=\"Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contain\n        from {{ getConfigValue('forms.validation.password.minLength') }}\n        to {{ getConfigValue('forms.validation.password.maxLength') }}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-re-password\">Repeat password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.confirmPassword\"\n           #rePass=\"ngModel\"\n           type=\"password\"\n           id=\"input-re-password\"\n           name=\"rePass\"\n           placeholder=\"Confirm Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"rePass.dirty ? (rePass.invalid || password.value != rePass.value  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [attr.aria-invalid]=\"rePass.invalid && rePass.touched ? true : null\">\n    <ng-container *ngIf=\"rePass.invalid && rePass.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"rePass.errors?.required\">\n        Password confirmation is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.value != rePass.value && !rePass.errors?.required\">\n        Password does not match the confirm password.\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-control-group accept-group\" *ngIf=\"getConfigValue('forms.register.terms')\">\n    <nb-checkbox name=\"terms\" [(ngModel)]=\"user.terms\" [required]=\"getConfigValue('forms.register.terms')\">\n      Agree to <a href=\"#\" target=\"_blank\"><strong>Terms & Conditions</strong></a>\n    </nb-checkbox>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !form.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Register\n  </button>\n</form>\n\n<section *ngIf=\"socialLinks && socialLinks.length > 0\" class=\"links\" aria-label=\"Social sign in\">\n  or enter with:\n  <div class=\"socials\">\n    <ng-container *ngFor=\"let socialLink of socialLinks\">\n      <a *ngIf=\"socialLink.link\"\n         [routerLink]=\"socialLink.link\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n      <a *ngIf=\"socialLink.url\"\n         [attr.href]=\"socialLink.url\"\n         [attr.target]=\"socialLink.target\"\n         [attr.class]=\"socialLink.icon\"\n         [class.with-icon]=\"socialLink.icon\">\n        <nb-icon *ngIf=\"socialLink.icon; else title\" [icon]=\"socialLink.icon\"></nb-icon>\n        <ng-template #title>{{ socialLink.title }}</ng-template>\n      </a>\n    </ng-container>\n  </div>\n</section>\n\n<section class=\"another-action\" aria-label=\"Sign in\">\n  Already have an account? <a class=\"text-link\" routerLink=\"../login\">Log in</a>\n</section>\n",
			styles: [":host .title{margin-bottom:2rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbAuthService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_AUTH_OPTIONS]
			}]
		},
		{ type: i0.ChangeDetectorRef },
		{ type: i2$1.Router }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbLogoutComponent = class NbLogoutComponent {
	constructor(service, options = {}, router) {
		this.service = service;
		this.options = options;
		this.router = router;
		this.redirectDelay = 0;
		this.strategy = "";
		this.redirectDelay = this.getConfigValue("forms.logout.redirectDelay");
		this.strategy = this.getConfigValue("forms.logout.strategy");
	}
	ngOnInit() {
		this.logout(this.strategy);
	}
	logout(strategy) {
		this.service.logout(strategy).subscribe((result) => {
			const redirect = result.getRedirect();
			if (redirect) setTimeout(() => {
				return this.router.navigateByUrl(redirect);
			}, this.redirectDelay);
		});
	}
	getConfigValue(key) {
		return getDeepFromObject(this.options, key, null);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLogoutComponent,
			deps: [
				{ token: NbAuthService },
				{ token: NB_AUTH_OPTIONS },
				{ token: i2$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLogoutComponent,
			isStandalone: false,
			selector: "nb-logout",
			ngImport: i0,
			template: "<div>Logging out, please wait...</div>\n"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLogoutComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-logout",
			standalone: false,
			template: "<div>Logging out, please wait...</div>\n"
		}]
	}],
	ctorParameters: () => [
		{ type: NbAuthService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_AUTH_OPTIONS]
			}]
		},
		{ type: i2$1.Router }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRequestPasswordComponent = class NbRequestPasswordComponent {
	constructor(service, options = {}, cd, router) {
		this.service = service;
		this.options = options;
		this.cd = cd;
		this.router = router;
		this.redirectDelay = 0;
		this.showMessages = {};
		this.strategy = "";
		this.submitted = false;
		this.errors = [];
		this.messages = [];
		this.user = {};
		this.redirectDelay = this.getConfigValue("forms.requestPassword.redirectDelay");
		this.showMessages = this.getConfigValue("forms.requestPassword.showMessages");
		this.strategy = this.getConfigValue("forms.requestPassword.strategy");
	}
	requestPass() {
		this.errors = this.messages = [];
		this.submitted = true;
		this.service.requestPassword(this.strategy, this.user).subscribe((result) => {
			this.submitted = false;
			if (result.isSuccess()) this.messages = result.getMessages();
			else this.errors = result.getErrors();
			const redirect = result.getRedirect();
			if (redirect) setTimeout(() => {
				return this.router.navigateByUrl(redirect);
			}, this.redirectDelay);
			this.cd.detectChanges();
		});
	}
	getConfigValue(key) {
		return getDeepFromObject(this.options, key, null);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRequestPasswordComponent,
			deps: [
				{ token: NbAuthService },
				{ token: NB_AUTH_OPTIONS },
				{ token: i0.ChangeDetectorRef },
				{ token: i2$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRequestPasswordComponent,
			isStandalone: false,
			selector: "nb-request-password-page",
			ngImport: i0,
			template: "<h1 id=\"title\" class=\"title\">Forgot Password</h1>\n<p class=\"sub-title\">Enter your email address and we’ll send a link to reset your password</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"requestPass()\" #requestPassForm=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Enter your email address:</label>\n    <input nbInput\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           id=\"input-email\"\n           name=\"email\"\n           pattern=\".+@.+\\..+\"\n           placeholder=\"Email address\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !requestPassForm.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Request password\n  </button>\n</form>\n\n<section class=\"sign-in-or-up\" aria-label=\"Sign in or sign up\">\n  <p><a class=\"text-link\" routerLink=\"../login\">Back to Log In</a></p>\n  <p><a routerLink=\"../register\" class=\"text-link\">Register</a></p>\n</section>\n",
			styles: [":host .form-group:last-of-type{margin-bottom:3rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: i3.NbAlertComponent,
					selector: "nb-alert",
					inputs: [
						"size",
						"status",
						"accent",
						"outline",
						"closable"
					],
					outputs: ["close"]
				},
				{
					kind: "directive",
					type: i3.NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: i3.NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				},
				{
					kind: "directive",
					type: i2$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: i5.ɵNgNoValidate,
					selector: "form:not([ngNoForm]):not([ngNativeValidate])"
				},
				{
					kind: "directive",
					type: i5.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatusGroup,
					selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
				},
				{
					kind: "directive",
					type: i5.RequiredValidator,
					selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
					inputs: ["required"]
				},
				{
					kind: "directive",
					type: i5.PatternValidator,
					selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]",
					inputs: ["pattern"]
				},
				{
					kind: "directive",
					type: i5.NgModel,
					selector: "[ngModel]:not([formControlName]):not([formControl])",
					inputs: [
						"name",
						"disabled",
						"ngModel",
						"ngModelOptions"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngModel"]
				},
				{
					kind: "directive",
					type: i5.NgForm,
					selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
					inputs: ["ngFormOptions"],
					outputs: ["ngSubmit"],
					exportAs: ["ngForm"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRequestPasswordComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-request-password-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<h1 id=\"title\" class=\"title\">Forgot Password</h1>\n<p class=\"sub-title\">Enter your email address and we’ll send a link to reset your password</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"requestPass()\" #requestPassForm=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-email\">Enter your email address:</label>\n    <input nbInput\n           [(ngModel)]=\"user.email\"\n           #email=\"ngModel\"\n           id=\"input-email\"\n           name=\"email\"\n           pattern=\".+@.+\\..+\"\n           placeholder=\"Email address\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"email.dirty ? (email.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.email.required')\"\n           [attr.aria-invalid]=\"email.invalid && email.touched ? true : null\">\n    <ng-container *ngIf=\"email.invalid && email.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.required\">\n        Email is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"email.errors?.pattern\">\n        Email should be the real one!\n      </p>\n    </ng-container>\n  </div>\n\n  <button nbButton\n          fullWidth\n          status=\"primary\"\n          size=\"large\"\n          [disabled]=\"submitted || !requestPassForm.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Request password\n  </button>\n</form>\n\n<section class=\"sign-in-or-up\" aria-label=\"Sign in or sign up\">\n  <p><a class=\"text-link\" routerLink=\"../login\">Back to Log In</a></p>\n  <p><a routerLink=\"../register\" class=\"text-link\">Register</a></p>\n</section>\n",
			styles: [":host .form-group:last-of-type{margin-bottom:3rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbAuthService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_AUTH_OPTIONS]
			}]
		},
		{ type: i0.ChangeDetectorRef },
		{ type: i2$1.Router }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbResetPasswordComponent = class NbResetPasswordComponent {
	constructor(service, options = {}, cd, router) {
		this.service = service;
		this.options = options;
		this.cd = cd;
		this.router = router;
		this.redirectDelay = 0;
		this.showMessages = {};
		this.strategy = "";
		this.submitted = false;
		this.errors = [];
		this.messages = [];
		this.user = {};
		this.redirectDelay = this.getConfigValue("forms.resetPassword.redirectDelay");
		this.showMessages = this.getConfigValue("forms.resetPassword.showMessages");
		this.strategy = this.getConfigValue("forms.resetPassword.strategy");
	}
	resetPass() {
		this.errors = this.messages = [];
		this.submitted = true;
		this.service.resetPassword(this.strategy, this.user).subscribe((result) => {
			this.submitted = false;
			if (result.isSuccess()) this.messages = result.getMessages();
			else this.errors = result.getErrors();
			const redirect = result.getRedirect();
			if (redirect) setTimeout(() => {
				return this.router.navigateByUrl(redirect);
			}, this.redirectDelay);
			this.cd.detectChanges();
		});
	}
	getConfigValue(key) {
		return getDeepFromObject(this.options, key, null);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbResetPasswordComponent,
			deps: [
				{ token: NbAuthService },
				{ token: NB_AUTH_OPTIONS },
				{ token: i0.ChangeDetectorRef },
				{ token: i2$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbResetPasswordComponent,
			isStandalone: false,
			selector: "nb-reset-password-page",
			ngImport: i0,
			template: "<h1 id=\"title\" class=\"title\">Change password</h1>\n<p class=\"sub-title\">Please set a new password</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"resetPass()\" #resetPassForm=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-password\">New Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           type=\"password\"\n           id=\"input-password\"\n           name=\"password\"\n           class=\"first\"\n           placeholder=\"New Password\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contains\n        from {{getConfigValue('forms.validation.password.minLength')}}\n        to {{getConfigValue('forms.validation.password.maxLength')}}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-group\">\n    <label class=\"label\" for=\"input-re-password\">Confirm Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.confirmPassword\"\n           #rePass=\"ngModel\"\n           id=\"input-re-password\"\n           name=\"rePass\"\n           type=\"password\"\n           class=\"last\"\n           placeholder=\"Confirm Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"rePass.touched\n               ? (rePass.invalid || password.value != rePass.value ? 'danger' : 'success')\n               : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [attr.aria-invalid]=\"rePass.invalid && rePass.touched ? true : null\">\n    <ng-container *ngIf=\"rePass.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"rePass.invalid && rePass.errors?.required\">\n        Password confirmation is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.value != rePass.value && !rePass.errors?.required\">\n        Password does not match the confirm password.\n      </p>\n    </ng-container>\n  </div>\n\n  <button nbButton\n          status=\"primary\"\n          fullWidth\n          size=\"large\"\n          [disabled]=\"submitted || !resetPassForm.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Change password\n  </button>\n</form>\n\n<section class=\"sign-in-or-up\" aria-label=\"Sign in or sign up\">\n  <p><a class=\"text-link\" routerLink=\"../login\">Back to Log In</a></p>\n  <p><a class=\"text-link\" routerLink=\"../register\">Register</a></p>\n</section>\n",
			styles: [":host .form-group:last-of-type{margin-bottom:3rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: i3.NbAlertComponent,
					selector: "nb-alert",
					inputs: [
						"size",
						"status",
						"accent",
						"outline",
						"closable"
					],
					outputs: ["close"]
				},
				{
					kind: "directive",
					type: i3.NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: i3.NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				},
				{
					kind: "directive",
					type: i2$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: i5.ɵNgNoValidate,
					selector: "form:not([ngNoForm]):not([ngNativeValidate])"
				},
				{
					kind: "directive",
					type: i5.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i5.NgControlStatusGroup,
					selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
				},
				{
					kind: "directive",
					type: i5.RequiredValidator,
					selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
					inputs: ["required"]
				},
				{
					kind: "directive",
					type: i5.MinLengthValidator,
					selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]",
					inputs: ["minlength"]
				},
				{
					kind: "directive",
					type: i5.MaxLengthValidator,
					selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]",
					inputs: ["maxlength"]
				},
				{
					kind: "directive",
					type: i5.NgModel,
					selector: "[ngModel]:not([formControlName]):not([formControl])",
					inputs: [
						"name",
						"disabled",
						"ngModel",
						"ngModelOptions"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngModel"]
				},
				{
					kind: "directive",
					type: i5.NgForm,
					selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
					inputs: ["ngFormOptions"],
					outputs: ["ngSubmit"],
					exportAs: ["ngForm"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbResetPasswordComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-reset-password-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<h1 id=\"title\" class=\"title\">Change password</h1>\n<p class=\"sub-title\">Please set a new password</p>\n\n<nb-alert *ngIf=\"showMessages.error && errors?.length && !submitted\" outline=\"danger\" role=\"alert\">\n  <p class=\"alert-title\"><b>Oh snap!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let error of errors\" class=\"alert-message\">{{ error }}</li>\n  </ul>\n</nb-alert>\n\n<nb-alert *ngIf=\"showMessages.success && messages?.length && !submitted\" outline=\"success\" role=\"alert\">\n  <p class=\"alert-title\"><b>Hooray!</b></p>\n  <ul class=\"alert-message-list\">\n    <li *ngFor=\"let message of messages\" class=\"alert-message\">{{ message }}</li>\n  </ul>\n</nb-alert>\n\n<form (ngSubmit)=\"resetPass()\" #resetPassForm=\"ngForm\" aria-labelledby=\"title\">\n\n  <div class=\"form-control-group\">\n    <label class=\"label\" for=\"input-password\">New Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.password\"\n           #password=\"ngModel\"\n           type=\"password\"\n           id=\"input-password\"\n           name=\"password\"\n           class=\"first\"\n           placeholder=\"New Password\"\n           autofocus\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"password.dirty ? (password.invalid  ? 'danger' : 'success') : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\n           [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"\n           [attr.aria-invalid]=\"password.invalid && password.touched ? true : null\">\n    <ng-container *ngIf=\"password.invalid && password.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.required\">\n        Password is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.errors?.minlength || password.errors?.maxlength\">\n        Password should contains\n        from {{getConfigValue('forms.validation.password.minLength')}}\n        to {{getConfigValue('forms.validation.password.maxLength')}}\n        characters\n      </p>\n    </ng-container>\n  </div>\n\n  <div class=\"form-group\">\n    <label class=\"label\" for=\"input-re-password\">Confirm Password:</label>\n    <input nbInput\n           [(ngModel)]=\"user.confirmPassword\"\n           #rePass=\"ngModel\"\n           id=\"input-re-password\"\n           name=\"rePass\"\n           type=\"password\"\n           class=\"last\"\n           placeholder=\"Confirm Password\"\n           fullWidth\n           fieldSize=\"large\"\n           [status]=\"rePass.touched\n               ? (rePass.invalid || password.value != rePass.value ? 'danger' : 'success')\n               : 'basic'\"\n           [required]=\"getConfigValue('forms.validation.password.required')\"\n           [attr.aria-invalid]=\"rePass.invalid && rePass.touched ? true : null\">\n    <ng-container *ngIf=\"rePass.touched\">\n      <p class=\"caption status-danger\" *ngIf=\"rePass.invalid && rePass.errors?.required\">\n        Password confirmation is required!\n      </p>\n      <p class=\"caption status-danger\" *ngIf=\"password.value != rePass.value && !rePass.errors?.required\">\n        Password does not match the confirm password.\n      </p>\n    </ng-container>\n  </div>\n\n  <button nbButton\n          status=\"primary\"\n          fullWidth\n          size=\"large\"\n          [disabled]=\"submitted || !resetPassForm.valid\"\n          [class.btn-pulse]=\"submitted\">\n    Change password\n  </button>\n</form>\n\n<section class=\"sign-in-or-up\" aria-label=\"Sign in or sign up\">\n  <p><a class=\"text-link\" routerLink=\"../login\">Back to Log In</a></p>\n  <p><a class=\"text-link\" routerLink=\"../register\">Register</a></p>\n</section>\n",
			styles: [":host .form-group:last-of-type{margin-bottom:3rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbAuthService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_AUTH_OPTIONS]
			}]
		},
		{ type: i0.ChangeDetectorRef },
		{ type: i2$1.Router }
	]
});
function nbStrategiesFactory(options, injector) {
	const strategies = [];
	options.strategies.forEach(([strategyClass, strategyOptions]) => {
		const strategy = injector.get(strategyClass);
		strategy.setOptions(strategyOptions);
		strategies.push(strategy);
	});
	return strategies;
}
function nbTokensFactory(strategies) {
	const tokens = [];
	strategies.forEach((strategy) => {
		tokens.push(strategy.getOption("token.class"));
	});
	return tokens;
}
function nbOptionsFactory(options) {
	return deepExtend(defaultAuthOptions, options);
}
function nbNoOpInterceptorFilter(req) {
	return true;
}
var NbAuthModule = class NbAuthModule {
	static forRoot(nbAuthOptions) {
		return {
			ngModule: NbAuthModule,
			providers: [
				{
					provide: NB_AUTH_USER_OPTIONS,
					useValue: nbAuthOptions
				},
				{
					provide: NB_AUTH_OPTIONS,
					useFactory: nbOptionsFactory,
					deps: [NB_AUTH_USER_OPTIONS]
				},
				{
					provide: NB_AUTH_STRATEGIES,
					useFactory: nbStrategiesFactory,
					deps: [NB_AUTH_OPTIONS, Injector]
				},
				{
					provide: NB_AUTH_TOKENS,
					useFactory: nbTokensFactory,
					deps: [NB_AUTH_STRATEGIES]
				},
				{
					provide: NB_AUTH_FALLBACK_TOKEN,
					useValue: NbAuthSimpleToken
				},
				{
					provide: NB_AUTH_INTERCEPTOR_HEADER,
					useValue: "Authorization"
				},
				{
					provide: NB_AUTH_TOKEN_INTERCEPTOR_FILTER,
					useValue: nbNoOpInterceptorFilter
				},
				{
					provide: NbTokenStorage,
					useClass: NbTokenLocalStorage
				},
				NbAuthTokenParceler,
				NbAuthService,
				NbTokenService,
				NbDummyAuthStrategy,
				NbPasswordAuthStrategy,
				NbOAuth2AuthStrategy
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthModule,
			declarations: [
				NbAuthComponent,
				NbAuthBlockComponent,
				NbLoginComponent,
				NbRegisterComponent,
				NbRequestPasswordComponent,
				NbResetPasswordComponent,
				NbLogoutComponent
			],
			imports: [
				CommonModule,
				NbLayoutModule,
				NbCardModule,
				NbCheckboxModule,
				NbAlertModule,
				NbInputModule,
				NbButtonModule,
				RouterModule,
				FormsModule,
				NbIconModule
			],
			exports: [
				NbAuthComponent,
				NbAuthBlockComponent,
				NbLoginComponent,
				NbRegisterComponent,
				NbRequestPasswordComponent,
				NbResetPasswordComponent,
				NbLogoutComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthModule,
			imports: [
				CommonModule,
				NbLayoutModule,
				NbCardModule,
				NbCheckboxModule,
				NbAlertModule,
				NbInputModule,
				NbButtonModule,
				RouterModule,
				FormsModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				NbLayoutModule,
				NbCardModule,
				NbCheckboxModule,
				NbAlertModule,
				NbInputModule,
				NbButtonModule,
				RouterModule,
				FormsModule,
				NbIconModule
			],
			declarations: [
				NbAuthComponent,
				NbAuthBlockComponent,
				NbLoginComponent,
				NbRegisterComponent,
				NbRequestPasswordComponent,
				NbResetPasswordComponent,
				NbLogoutComponent
			],
			exports: [
				NbAuthComponent,
				NbAuthBlockComponent,
				NbLoginComponent,
				NbRegisterComponent,
				NbRequestPasswordComponent,
				NbResetPasswordComponent,
				NbLogoutComponent
			]
		}]
	}]
});
const routes = [{
	path: "auth",
	component: NbAuthComponent,
	children: [
		{
			path: "",
			component: NbLoginComponent
		},
		{
			path: "login",
			component: NbLoginComponent
		},
		{
			path: "register",
			component: NbRegisterComponent
		},
		{
			path: "logout",
			component: NbLogoutComponent
		},
		{
			path: "request-password",
			component: NbRequestPasswordComponent
		},
		{
			path: "reset-password",
			component: NbResetPasswordComponent
		}
	]
}];
var NbAuthJWTInterceptor = class NbAuthJWTInterceptor {
	constructor(injector, filter) {
		this.injector = injector;
		this.filter = filter;
	}
	intercept(req, next) {
		if (!this.filter(req)) return this.authService.isAuthenticatedOrRefresh().pipe(switchMap((authenticated) => {
			if (authenticated) return this.authService.getToken().pipe(switchMap((token) => {
				const JWT = `Bearer ${token.getValue()}`;
				req = req.clone({ setHeaders: { Authorization: JWT } });
				return next.handle(req);
			}));
			else return next.handle(req);
		}));
		else return next.handle(req);
	}
	get authService() {
		return this.injector.get(NbAuthService);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthJWTInterceptor,
			deps: [{ token: i0.Injector }, { token: NB_AUTH_TOKEN_INTERCEPTOR_FILTER }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthJWTInterceptor
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthJWTInterceptor,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i0.Injector }, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_AUTH_TOKEN_INTERCEPTOR_FILTER]
		}]
	}]
});
var NbAuthSimpleInterceptor = class NbAuthSimpleInterceptor {
	constructor(injector, headerName = "Authorization") {
		this.injector = injector;
		this.headerName = headerName;
	}
	intercept(req, next) {
		return this.authService.getToken().pipe(switchMap((token) => {
			if (token && token.getValue()) req = req.clone({ setHeaders: { [this.headerName]: token.getValue() } });
			return next.handle(req);
		}));
	}
	get authService() {
		return this.injector.get(NbAuthService);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthSimpleInterceptor,
			deps: [{ token: i0.Injector }, { token: NB_AUTH_INTERCEPTOR_HEADER }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAuthSimpleInterceptor
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAuthSimpleInterceptor,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i0.Injector }, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_AUTH_INTERCEPTOR_HEADER]
		}]
	}]
});
var NbUser = class {
	constructor(id, email, password, rememberMe, terms, confirmPassword, fullName) {
		this.id = id;
		this.email = email;
		this.password = password;
		this.rememberMe = rememberMe;
		this.terms = terms;
		this.confirmPassword = confirmPassword;
		this.fullName = fullName;
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
export { NB_AUTH_FALLBACK_TOKEN, NB_AUTH_INTERCEPTOR_HEADER, NB_AUTH_OPTIONS, NB_AUTH_STRATEGIES, NB_AUTH_TOKENS, NB_AUTH_TOKEN_INTERCEPTOR_FILTER, NB_AUTH_USER_OPTIONS, NbAuthBlockComponent, NbAuthComponent, NbAuthEmptyTokenError, NbAuthIllegalJWTTokenError, NbAuthIllegalTokenError, NbAuthJWTInterceptor, NbAuthJWTToken, NbAuthModule, NbAuthOAuth2JWTToken, NbAuthOAuth2Token, NbAuthResult, NbAuthService, NbAuthSimpleInterceptor, NbAuthSimpleToken, NbAuthStrategy, NbAuthStrategyOptions, NbAuthToken, NbAuthTokenNotFoundError, NbAuthTokenParceler, NbDummyAuthStrategy, NbDummyAuthStrategyOptions, NbLoginComponent, NbLogoutComponent, NbOAuth2AuthStrategy, NbOAuth2AuthStrategyOptions, NbOAuth2ClientAuthMethod, NbOAuth2GrantType, NbOAuth2ResponseType, NbPasswordAuthStrategy, NbPasswordAuthStrategyOptions, NbRegisterComponent, NbRequestPasswordComponent, NbResetPasswordComponent, NbTokenLocalStorage, NbTokenService, NbTokenStorage, NbUser, auth2StrategyOptions, b64DecodeUnicode, b64decode, decodeJwtPayload, deepExtend, defaultAuthOptions, dummyStrategyOptions, getDeepFromObject, nbAuthCreateToken, nbNoOpInterceptorFilter, nbOptionsFactory, nbStrategiesFactory, nbTokensFactory, passwordStrategyOptions, routes, urlBase64Decode };

//# sourceMappingURL=nebular-auth.mjs.map