import * as i0 from "@angular/core";
import { Attribute, ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChild, ContentChildren, DOCUMENT, Directive, ElementRef, EventEmitter, Host, HostBinding, HostListener, Inject, Injectable, InjectionToken, Injector, Input, LOCALE_ID, NgModule, Optional, Output, PLATFORM_ID, Pipe, SimpleChange, TemplateRef, Type, ViewChild, ViewChildren, ViewContainerRef, forwardRef, inject, isDevMode, signal } from "@angular/core";
import * as i2 from "@angular/common";
import { CommonModule, DatePipe, FormStyle, FormatWidth, TranslationWidth, getLocaleDayNames, getLocaleFirstDayOfWeek, getLocaleMonthNames, getLocaleTimeFormat, isPlatformBrowser } from "@angular/common";
import { BehaviorSubject, EMPTY, Observable, ReplaySubject, Subject, animationFrameScheduler, combineLatest, forkJoin, from, fromEvent, interval, merge, of, timer } from "rxjs";
import { debounceTime, delay, distinctUntilChanged, filter, finalize, map, observeOn, pairwise, publish, refCount, repeat, share, skip, startWith, switchMap, take, takeUntil, takeWhile, tap, throttle } from "rxjs/operators";
import * as i1 from "@angular/forms";
import { FormsModule, NG_VALIDATORS, NG_VALUE_ACCESSOR, Validators } from "@angular/forms";
import * as i1$1 from "@angular/router";
import { NavigationEnd, RouterModule } from "@angular/router";
import * as i1$3 from "@angular/cdk/a11y";
import { ActiveDescendantKeyManager, FocusKeyManager, FocusMonitor, FocusTrap, FocusTrapFactory } from "@angular/cdk/a11y";
import { CdkPortal, CdkPortalOutlet, ComponentPortal, PortalModule, TemplatePortal } from "@angular/cdk/portal";
import * as i3 from "@angular/cdk/overlay";
import { BlockScrollStrategy, FlexibleConnectedPositionStrategy, GlobalPositionStrategy, Overlay, OverlayContainer, OverlayModule, OverlayPositionBuilder, ScrollDispatcher, ScrollStrategyOptions, ViewportRuler } from "@angular/cdk/overlay";
import { Platform } from "@angular/cdk/platform";
import * as i1$2 from "@angular/platform-browser";
import { animate, state, style, transition, trigger } from "@angular/animations";
import { BidiModule, Directionality } from "@angular/cdk/bidi";
import { CDK_TABLE, CdkCell, CdkCellDef, CdkCellOutlet, CdkColumnDef, CdkFooterCell, CdkFooterCellDef, CdkFooterRow, CdkFooterRowDef, CdkHeaderCell, CdkHeaderCellDef, CdkHeaderRow, CdkHeaderRowDef, CdkRow, CdkRowDef, CdkTable, CdkTableModule, DataRowOutlet, DataSource, FooterRowOutlet, HeaderRowOutlet, NoDataRowOutlet } from "@angular/cdk/table";
import { coerceBooleanProperty } from "@angular/cdk/coercion";
import { ViewportRuler as ViewportRuler$1 } from "@angular/cdk/scrolling";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_THEME_OPTIONS = new InjectionToken("Nebular Theme Options");
const NB_MEDIA_BREAKPOINTS = new InjectionToken("Nebular Media Breakpoints");
const NB_BUILT_IN_JS_THEMES = new InjectionToken("Nebular Built-in JS Themes");
const NB_JS_THEMES = new InjectionToken("Nebular JS Themes");
const NB_WINDOW = new InjectionToken("Window");
const NB_DOCUMENT = new InjectionToken("Document");
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const DEFAULT_MEDIA_BREAKPOINTS = [
	{
		name: "xs",
		width: 0
	},
	{
		name: "is",
		width: 400
	},
	{
		name: "sm",
		width: 576
	},
	{
		name: "md",
		width: 768
	},
	{
		name: "lg",
		width: 992
	},
	{
		name: "xl",
		width: 1200
	},
	{
		name: "xxl",
		width: 1400
	},
	{
		name: "xxxl",
		width: 1600
	}
];
var NbMediaBreakpointsService = class NbMediaBreakpointsService {
	constructor(breakpoints) {
		this.breakpoints = breakpoints;
		this.breakpointsMap = this.breakpoints.reduce((res, b) => {
			res[b.name] = b.width;
			return res;
		}, {});
	}
	getByWidth(width) {
		const unknown = {
			name: "unknown",
			width
		};
		const breakpoints = this.getBreakpoints();
		return breakpoints.find((point, index) => {
			const next = breakpoints[index + 1];
			return width >= point.width && (!next || width < next.width);
		}) || unknown;
	}
	getByName(name) {
		return this.getBreakpoints().find((point) => name === point.name) || {
			name: "unknown",
			width: NaN
		};
	}
	getBreakpoints() {
		return this.breakpoints;
	}
	getBreakpointsMap() {
		return this.breakpointsMap;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMediaBreakpointsService,
			deps: [{ token: NB_MEDIA_BREAKPOINTS }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMediaBreakpointsService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMediaBreakpointsService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_MEDIA_BREAKPOINTS]
		}]
	}]
});
const palette$3 = {
	primary: "#3366ff",
	success: "#00d68f",
	info: "#0095ff",
	warning: "#ffaa00",
	danger: "#ff3d71"
};
const DEFAULT_THEME = {
	name: "default",
	variables: {
		fontMain: "Open Sans, sans-serif",
		fontSecondary: "Raleway, sans-serif",
		bg: "#ffffff",
		bg2: "#f7f9fc",
		bg3: "#edf1f7",
		bg4: "#e4e9f2",
		border: "#ffffff",
		border2: "#f7f9fc",
		border3: "#edf1f7",
		border4: "#e4e9f2",
		border5: "#c5cee0",
		fg: "#8f9bb3",
		fgHeading: "#1a2138",
		fgText: "#1a2138",
		fgHighlight: palette$3.primary,
		layoutBg: "#f7f9fc",
		separator: "#edf1f7",
		primary: palette$3.primary,
		success: palette$3.success,
		info: palette$3.info,
		warning: palette$3.warning,
		danger: palette$3.danger,
		primaryLight: "#598bff",
		successLight: "#2ce69b",
		infoLight: "#42aaff",
		warningLight: "#ffc94d",
		dangerLight: "#ff708d"
	}
};
const palette$2 = {
	primary: "#a16eff",
	success: "#00d68f",
	info: "#0095ff",
	warning: "#ffaa00",
	danger: "#ff3d71"
};
const COSMIC_THEME = {
	name: "cosmic",
	variables: {
		fontMain: "Open Sans, sans-serif",
		fontSecondary: "Raleway, sans-serif",
		bg: "#323259",
		bg2: "#252547",
		bg3: "#1b1b38",
		bg4: "#13132b",
		border: "#323259",
		border2: "#252547",
		border3: "#1b1b38",
		border4: "#13132b",
		border5: "#13132b",
		fg: "#b4b4db",
		fgHeading: "#ffffff",
		fgText: "#ffffff",
		fgHighlight: palette$2.primary,
		layoutBg: "#151a30",
		separator: "#151a30",
		primary: palette$2.primary,
		success: palette$2.success,
		info: palette$2.info,
		warning: palette$2.warning,
		danger: palette$2.danger,
		primaryLight: "#b18aff",
		successLight: "#2ce69b",
		infoLight: "#42aaff",
		warningLight: "#ffc94d",
		dangerLight: "#ff708d"
	}
};
const palette$1 = {
	primary: "#73a1ff",
	success: "#5dcfe3",
	info: "#ba7fec",
	warning: "#ffa36b",
	danger: "#ff6b83"
};
const CORPORATE_THEME = {
	name: "corporate",
	base: "default",
	variables: {
		fontMain: "Open Sans, sans-serif",
		fontSecondary: "Raleway, sans-serif",
		bg: "#ffffff",
		bg2: "#f7f9fc",
		bg3: "#edf1f7",
		bg4: "#e4e9f2",
		border: "#ffffff",
		border2: "#f7f9fc",
		border3: "#edf1f7",
		border4: "#e4e9f2",
		border5: "#c5cee0",
		fg: "#8f9bb3",
		fgHeading: "#1a2138",
		fgText: "#1a2138",
		fgHighlight: palette$1.primary,
		layoutBg: "#f7f9fc",
		separator: "#edf1f7",
		primary: palette$1.primary,
		success: palette$1.success,
		info: palette$1.info,
		warning: palette$1.warning,
		danger: palette$1.danger,
		primaryLight: "#598bff",
		successLight: "#2ce69b",
		infoLight: "#42aaff",
		warningLight: "#ffc94d",
		dangerLight: "#ff708d"
	}
};
const palette = {
	primary: "#3366ff",
	success: "#00d68f",
	info: "#0095ff",
	warning: "#ffaa00",
	danger: "#ff3d71"
};
const DARK_THEME = {
	name: "dark",
	variables: {
		fontMain: "Open Sans, sans-serif",
		fontSecondary: "Raleway, sans-serif",
		bg: "#222b45",
		bg2: "#1a2138",
		bg3: "#151a30",
		bg4: "#101426",
		border: "#222b45",
		border2: "#1a2138",
		border3: "#151a30",
		border4: "#101426",
		border5: "#101426",
		fg: "#8f9bb3",
		fgHeading: "#ffffff",
		fgText: "#ffffff",
		fgHighlight: palette.primary,
		layoutBg: "#1b1b38",
		separator: "#1b1b38",
		primary: palette.primary,
		success: palette.success,
		info: palette.info,
		warning: palette.warning,
		danger: palette.danger,
		primaryLight: "#598bff",
		successLight: "#2ce69b",
		infoLight: "#42aaff",
		warningLight: "#ffc94d",
		dangerLight: "#ff708d"
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const BUILT_IN_THEMES = [
	DEFAULT_THEME,
	COSMIC_THEME,
	CORPORATE_THEME,
	DARK_THEME
];
var NbJSThemesRegistry = class NbJSThemesRegistry {
	constructor(builtInThemes, newThemes = []) {
		this.themes = {};
		this.combineByNames(newThemes, builtInThemes).forEach((theme) => {
			this.register(theme, theme.name, theme.base);
		});
	}
	register(config, themeName, baseTheme) {
		const base = this.has(baseTheme) ? this.get(baseTheme) : {};
		this.themes[themeName] = this.mergeDeep({}, base, config);
	}
	has(themeName) {
		return !!this.themes[themeName];
	}
	get(themeName) {
		if (!this.themes[themeName]) throw Error(`NbThemeConfig: no theme '${themeName}' found registered.`);
		return JSON.parse(JSON.stringify(this.themes[themeName]));
	}
	combineByNames(newThemes, oldThemes) {
		if (newThemes) {
			const mergedThemes = [];
			newThemes.forEach((theme) => {
				const sameOld = oldThemes.find((tm) => tm.name === theme.name) || {};
				const mergedTheme = this.mergeDeep({}, sameOld, theme);
				mergedThemes.push(mergedTheme);
			});
			oldThemes.forEach((theme) => {
				if (!mergedThemes.find((tm) => tm.name === theme.name)) mergedThemes.push(theme);
			});
			return mergedThemes;
		}
		return oldThemes;
	}
	isObject(item) {
		return item && typeof item === "object" && !Array.isArray(item);
	}
	mergeDeep(target, ...sources) {
		if (!sources.length) return target;
		const source = sources.shift();
		if (this.isObject(target) && this.isObject(source)) for (const key in source) if (this.isObject(source[key])) {
			if (!target[key]) Object.assign(target, { [key]: {} });
			this.mergeDeep(target[key], source[key]);
		} else Object.assign(target, { [key]: source[key] });
		return this.mergeDeep(target, ...sources);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbJSThemesRegistry,
			deps: [{ token: NB_BUILT_IN_JS_THEMES }, { token: NB_JS_THEMES }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbJSThemesRegistry
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbJSThemesRegistry,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_BUILT_IN_JS_THEMES]
		}]
	}, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_JS_THEMES]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbThemeService = class NbThemeService {
	constructor(options, breakpointService, jsThemesRegistry) {
		this.options = options;
		this.breakpointService = breakpointService;
		this.jsThemesRegistry = jsThemesRegistry;
		this.themeChanges$ = new ReplaySubject(1);
		this.appendLayoutClass$ = new Subject();
		this.removeLayoutClass$ = new Subject();
		this.changeWindowWidth$ = new ReplaySubject(2);
		if (options && options.name) this.changeTheme(options.name);
	}
	changeTheme(name) {
		this.themeChanges$.next({
			name,
			previous: this.currentTheme
		});
		this.currentTheme = name;
	}
	changeWindowWidth(width) {
		this.changeWindowWidth$.next(width);
	}
	getJsTheme() {
		return this.onThemeChange().pipe(map((theme) => {
			return this.jsThemesRegistry.get(theme.name);
		}));
	}
	onMediaQueryChange() {
		return this.changeWindowWidth$.pipe(startWith(void 0), pairwise(), map(([prevWidth, width]) => {
			return [this.breakpointService.getByWidth(prevWidth), this.breakpointService.getByWidth(width)];
		}), filter(([prevPoint, point]) => {
			return prevPoint.name !== point.name;
		}), distinctUntilChanged(null, (params) => params[0].name + params[1].name), share());
	}
	onThemeChange() {
		return this.themeChanges$.pipe(share());
	}
	appendLayoutClass(className) {
		this.appendLayoutClass$.next(className);
	}
	onAppendLayoutClass() {
		return this.appendLayoutClass$.pipe(share());
	}
	removeLayoutClass(className) {
		this.removeLayoutClass$.next(className);
	}
	onRemoveLayoutClass() {
		return this.removeLayoutClass$.pipe(share());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbThemeService,
			deps: [
				{ token: NB_THEME_OPTIONS },
				{ token: NbMediaBreakpointsService },
				{ token: NbJSThemesRegistry }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbThemeService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbThemeService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_THEME_OPTIONS]
			}]
		},
		{ type: NbMediaBreakpointsService },
		{ type: NbJSThemesRegistry }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSpinnerService = class NbSpinnerService {
	constructor(document) {
		this.document = document;
		this.loaders = [];
		this.selector = "nb-global-spinner";
	}
	registerLoader(method) {
		this.loaders.push(method);
	}
	clear() {
		this.loaders = [];
	}
	load() {
		this.showSpinner();
		this.executeAll();
	}
	executeAll(done = (values) => {}) {
		Promise.all(this.loaders).then((values) => {
			this.hideSpinner();
			done.call(null, values);
		}).catch((error) => {
			console.error(error);
		});
	}
	showSpinner() {
		const el = this.getSpinnerElement();
		if (el) el.style["display"] = "block";
	}
	hideSpinner() {
		const el = this.getSpinnerElement();
		if (el) el.style["display"] = "none";
	}
	getSpinnerElement() {
		return this.document.getElementById(this.selector);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerService,
			deps: [{ token: NB_DOCUMENT }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSpinnerService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_DOCUMENT]
		}]
	}]
});
var NbLayoutDirection;
(function(NbLayoutDirection) {
	NbLayoutDirection["LTR"] = "ltr";
	NbLayoutDirection["RTL"] = "rtl";
})(NbLayoutDirection || (NbLayoutDirection = {}));
const NB_LAYOUT_DIRECTION = new InjectionToken("Layout direction");
var NbLayoutDirectionService = class NbLayoutDirectionService {
	constructor(direction = NbLayoutDirection.LTR) {
		this.direction = direction;
		this.$directionChange = new ReplaySubject(1);
		this.setDirection(direction);
	}
	isLtr() {
		return this.direction === NbLayoutDirection.LTR;
	}
	isRtl() {
		return this.direction === NbLayoutDirection.RTL;
	}
	getDirection() {
		return this.direction;
	}
	setDirection(direction) {
		this.direction = direction;
		this.$directionChange.next(direction);
	}
	onDirectionChange() {
		return this.$directionChange.pipe(share());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutDirectionService,
			deps: [{
				token: NB_LAYOUT_DIRECTION,
				optional: true
			}],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutDirectionService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutDirectionService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [NB_LAYOUT_DIRECTION]
		}]
	}]
});
var NbLayoutScrollService = class NbLayoutScrollService {
	constructor() {
		this.scrollPositionReq$ = new Subject();
		this.manualScroll$ = new Subject();
		this.scroll$ = new Subject();
		this.scrollable$ = new Subject();
	}
	getPosition() {
		return new Observable((observer) => {
			const listener = new Subject();
			listener.subscribe(observer);
			this.scrollPositionReq$.next({ listener });
			return () => listener.complete();
		});
	}
	scrollTo(x = null, y = null) {
		this.manualScroll$.next({
			x,
			y
		});
	}
	onScroll() {
		return this.scroll$.pipe(share());
	}
	onManualScroll() {
		return this.manualScroll$.pipe(share());
	}
	onGetPosition() {
		return this.scrollPositionReq$;
	}
	onScrollableChange() {
		return this.scrollable$.pipe(share());
	}
	fireScrollChange(event) {
		this.scroll$.next(event);
	}
	scrollable(scrollable) {
		this.scrollable$.next(scrollable);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutScrollService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutScrollService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutScrollService,
	decorators: [{ type: Injectable }]
});
var NbLayoutRulerService = class NbLayoutRulerService {
	constructor() {
		this.contentDimensionsReq$ = new Subject();
	}
	getDimensions() {
		return new Observable((observer) => {
			const listener = new Subject();
			listener.subscribe(observer);
			this.contentDimensionsReq$.next({ listener });
			return () => listener.complete();
		});
	}
	onGetDimensions() {
		return this.contentDimensionsReq$;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutRulerService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutRulerService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutRulerService,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSharedModule = class NbSharedModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSharedModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSharedModule,
			exports: [
				CommonModule,
				FormsModule,
				RouterModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSharedModule,
			imports: [
				CommonModule,
				FormsModule,
				RouterModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSharedModule,
	decorators: [{
		type: NgModule,
		args: [{ exports: [
			CommonModule,
			FormsModule,
			RouterModule
		] }]
	}]
});
var NbFocusTrap = class extends FocusTrap {
	constructor(element, checker, ngZone, document, deferAnchors, injector) {
		super(element, checker, ngZone, document, deferAnchors, injector);
		this.element = element;
		this.checker = checker;
		this.ngZone = ngZone;
		this.document = document;
		this.savePreviouslyFocusedElement();
	}
	restoreFocus() {
		this.previouslyFocusedElement.focus();
		this.destroy();
	}
	blurPreviouslyFocusedElement() {
		this.previouslyFocusedElement.blur();
	}
	savePreviouslyFocusedElement() {
		this.previouslyFocusedElement = this.document.activeElement;
	}
};
var NbFocusTrapFactoryService = class NbFocusTrapFactoryService extends FocusTrapFactory {
	constructor(checker, ngZone, document, injector) {
		super();
		this.checker = checker;
		this.ngZone = ngZone;
		this.document = document;
		this.injector = injector;
	}
	create(element, deferCaptureElements) {
		return new NbFocusTrap(element, this.checker, this.ngZone, this.document, deferCaptureElements, this.injector);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFocusTrapFactoryService,
			deps: [
				{ token: i1$3.InteractivityChecker },
				{ token: i0.NgZone },
				{ token: NB_DOCUMENT },
				{ token: i0.Injector }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFocusTrapFactoryService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFocusTrapFactoryService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: i1$3.InteractivityChecker },
		{ type: i0.NgZone },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: i0.Injector }
	]
});
var NbFocusKeyManager = class extends FocusKeyManager {};
var NbFocusKeyManagerFactoryService = class {
	create(items) {
		return new NbFocusKeyManager(items);
	}
};
var NbActiveDescendantKeyManager = class extends ActiveDescendantKeyManager {};
var NbActiveDescendantKeyManagerFactoryService = class {
	create(items) {
		return new NbActiveDescendantKeyManager(items);
	}
};
var NbKeyManagerActiveItemMode;
(function(NbKeyManagerActiveItemMode) {
	NbKeyManagerActiveItemMode[NbKeyManagerActiveItemMode["RESET_ACTIVE"] = -1] = "RESET_ACTIVE";
	NbKeyManagerActiveItemMode[NbKeyManagerActiveItemMode["FIRST_ACTIVE"] = 0] = "FIRST_ACTIVE";
})(NbKeyManagerActiveItemMode || (NbKeyManagerActiveItemMode = {}));
var NbFocusMonitor = class NbFocusMonitor extends FocusMonitor {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFocusMonitor,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFocusMonitor
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFocusMonitor,
	decorators: [{ type: Injectable }]
});
var NbA11yModule = class NbA11yModule {
	static forRoot() {
		return {
			ngModule: NbA11yModule,
			providers: [
				NbFocusTrapFactoryService,
				NbFocusKeyManagerFactoryService,
				NbActiveDescendantKeyManagerFactoryService,
				{
					provide: NbFocusMonitor,
					useClass: FocusMonitor
				}
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbA11yModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbA11yModule
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbA11yModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbA11yModule,
	decorators: [{
		type: NgModule,
		args: [{}]
	}]
});
var NbPortalDirective = class NbPortalDirective extends CdkPortal {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPortalDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPortalDirective,
			isStandalone: false,
			selector: "[nbPortal]",
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPortalDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbPortal]",
			standalone: false
		}]
	}]
});
var NbPortalOutletDirective = class NbPortalOutletDirective extends CdkPortalOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPortalOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPortalOutletDirective,
			isStandalone: false,
			selector: "[nbPortalOutlet]",
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPortalOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbPortalOutlet]",
			standalone: false
		}]
	}]
});
var NbComponentPortal = class extends ComponentPortal {};
var NbOverlay = class NbOverlay extends Overlay {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlay,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlay
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlay,
	decorators: [{ type: Injectable }]
});
var NbOverlayPositionBuilder = class NbOverlayPositionBuilder extends OverlayPositionBuilder {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayPositionBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayPositionBuilder
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayPositionBuilder,
	decorators: [{ type: Injectable }]
});
var NbTemplatePortal = class extends TemplatePortal {
	constructor(template, viewContainerRef, context) {
		super(template, viewContainerRef, context);
	}
};
var NbOverlayContainer = class NbOverlayContainer extends OverlayContainer {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayContainer,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayContainer
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayContainer,
	decorators: [{ type: Injectable }]
});
var NbFlexibleConnectedPositionStrategy = class extends FlexibleConnectedPositionStrategy {};
const CDK_MODULES = [OverlayModule, PortalModule];
var NbCdkMappingModule = class NbCdkMappingModule {
	static forRoot() {
		return {
			ngModule: NbCdkMappingModule,
			providers: [NbOverlay, NbOverlayPositionBuilder]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkMappingModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkMappingModule,
			declarations: [NbPortalDirective, NbPortalOutletDirective],
			imports: [OverlayModule, PortalModule],
			exports: [
				OverlayModule,
				PortalModule,
				NbPortalDirective,
				NbPortalOutletDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkMappingModule,
			imports: [
				CDK_MODULES,
				OverlayModule,
				PortalModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCdkMappingModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [...CDK_MODULES],
			exports: [
				...CDK_MODULES,
				NbPortalDirective,
				NbPortalOutletDirective
			],
			declarations: [NbPortalDirective, NbPortalOutletDirective]
		}]
	}]
});
var NbGlobalLogicalPosition;
(function(NbGlobalLogicalPosition) {
	NbGlobalLogicalPosition["TOP_START"] = "top-start";
	NbGlobalLogicalPosition["TOP_END"] = "top-end";
	NbGlobalLogicalPosition["BOTTOM_START"] = "bottom-start";
	NbGlobalLogicalPosition["BOTTOM_END"] = "bottom-end";
})(NbGlobalLogicalPosition || (NbGlobalLogicalPosition = {}));
var NbGlobalPhysicalPosition;
(function(NbGlobalPhysicalPosition) {
	NbGlobalPhysicalPosition["TOP_RIGHT"] = "top-right";
	NbGlobalPhysicalPosition["TOP_LEFT"] = "top-left";
	NbGlobalPhysicalPosition["BOTTOM_RIGHT"] = "bottom-right";
	NbGlobalPhysicalPosition["BOTTOM_LEFT"] = "bottom-left";
})(NbGlobalPhysicalPosition || (NbGlobalPhysicalPosition = {}));
var NbPositionHelper = class NbPositionHelper {
	constructor(layoutDirection) {
		this.layoutDirection = layoutDirection;
	}
	toLogicalPosition(position) {
		if (Object.values(NbGlobalLogicalPosition).includes(position)) return position;
		if (this.layoutDirection.isLtr()) return this.toLogicalPositionWhenLtr(position);
		else return this.toLogicalPositionWhenRtl(position);
	}
	toPhysicalPosition(position) {
		if (Object.values(NbGlobalPhysicalPosition).includes(position)) return position;
		if (this.layoutDirection.isLtr()) return this.toPhysicalPositionWhenLtr(position);
		else return this.toPhysicalPositionWhenRtl(position);
	}
	isTopPosition(position) {
		const logicalPosition = this.toLogicalPosition(position);
		return logicalPosition === NbGlobalLogicalPosition.TOP_END || logicalPosition === NbGlobalLogicalPosition.TOP_START;
	}
	isRightPosition(position) {
		const physicalPosition = this.toPhysicalPosition(position);
		return physicalPosition === NbGlobalPhysicalPosition.TOP_RIGHT || physicalPosition === NbGlobalPhysicalPosition.BOTTOM_RIGHT;
	}
	toLogicalPositionWhenLtr(position) {
		switch (position) {
			case NbGlobalPhysicalPosition.TOP_RIGHT: return NbGlobalLogicalPosition.TOP_END;
			case NbGlobalPhysicalPosition.TOP_LEFT: return NbGlobalLogicalPosition.TOP_START;
			case NbGlobalPhysicalPosition.BOTTOM_RIGHT: return NbGlobalLogicalPosition.BOTTOM_END;
			case NbGlobalPhysicalPosition.BOTTOM_LEFT: return NbGlobalLogicalPosition.BOTTOM_START;
		}
	}
	toLogicalPositionWhenRtl(position) {
		switch (position) {
			case NbGlobalPhysicalPosition.TOP_RIGHT: return NbGlobalLogicalPosition.TOP_START;
			case NbGlobalPhysicalPosition.TOP_LEFT: return NbGlobalLogicalPosition.TOP_END;
			case NbGlobalPhysicalPosition.BOTTOM_RIGHT: return NbGlobalLogicalPosition.BOTTOM_START;
			case NbGlobalPhysicalPosition.BOTTOM_LEFT: return NbGlobalLogicalPosition.BOTTOM_END;
		}
	}
	toPhysicalPositionWhenLtr(position) {
		switch (position) {
			case NbGlobalLogicalPosition.TOP_START: return NbGlobalPhysicalPosition.TOP_LEFT;
			case NbGlobalLogicalPosition.TOP_END: return NbGlobalPhysicalPosition.TOP_RIGHT;
			case NbGlobalLogicalPosition.BOTTOM_START: return NbGlobalPhysicalPosition.BOTTOM_LEFT;
			case NbGlobalLogicalPosition.BOTTOM_END: return NbGlobalPhysicalPosition.BOTTOM_RIGHT;
		}
	}
	toPhysicalPositionWhenRtl(position) {
		switch (position) {
			case NbGlobalLogicalPosition.TOP_START: return NbGlobalPhysicalPosition.TOP_RIGHT;
			case NbGlobalLogicalPosition.TOP_END: return NbGlobalPhysicalPosition.TOP_LEFT;
			case NbGlobalLogicalPosition.BOTTOM_START: return NbGlobalPhysicalPosition.BOTTOM_RIGHT;
			case NbGlobalLogicalPosition.BOTTOM_END: return NbGlobalPhysicalPosition.BOTTOM_LEFT;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPositionHelper,
			deps: [{ token: NbLayoutDirectionService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPositionHelper
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPositionHelper,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbLayoutDirectionService }]
});
var NbPlatform = class NbPlatform extends Platform {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPlatform,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPlatform,
			providedIn: "root",
			useClass: Platform
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPlatform,
	decorators: [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useClass: Platform
		}]
	}]
});
var NbViewportRulerAdapter = class NbViewportRulerAdapter extends ViewportRuler {
	constructor(platform, ngZone, ruler, scroll, document) {
		super();
		this.ruler = ruler;
		this.scroll = scroll;
	}
	getViewportSize() {
		let res = super.getViewportSize();
		this.ruler.getDimensions().pipe(map((dimensions) => ({
			width: dimensions.clientWidth,
			height: dimensions.clientHeight
		}))).subscribe((rect) => res = rect).unsubscribe();
		return res;
	}
	getViewportScrollPosition() {
		let res = super.getViewportScrollPosition();
		this.scroll.getPosition().pipe(map((position) => ({
			top: position.y,
			left: position.x
		}))).subscribe((position) => res = position).unsubscribe();
		return res;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbViewportRulerAdapter,
			deps: [
				{ token: NbPlatform },
				{ token: i0.NgZone },
				{ token: NbLayoutRulerService },
				{ token: NbLayoutScrollService },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbViewportRulerAdapter
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbViewportRulerAdapter,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbPlatform },
		{ type: i0.NgZone },
		{ type: NbLayoutRulerService },
		{ type: NbLayoutScrollService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	]
});
function throwLayoutNotFoundError() {
	throw new Error(`[NbOverlayContainerAdapter]: Layout not found.
  When using Nebular '<nb-layout>' is required and should wrap other nebular components.`);
}
var NbOverlayContainerAdapter = class NbOverlayContainerAdapter extends NbOverlayContainer {
	setContainer(container) {
		this.container = container;
	}
	clearContainer() {
		this.container = null;
		this._containerElement = null;
	}
	_createContainer() {
		this.checkContainer();
		const container = this._document.createElement("div");
		container.classList.add("cdk-overlay-container");
		this.container.appendChild(container);
		this._containerElement = container;
	}
	checkContainer() {
		if (!this.container) throwLayoutNotFoundError();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayContainerAdapter,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayContainerAdapter
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayContainerAdapter,
	decorators: [{ type: Injectable }]
});
var NbAdjustment;
(function(NbAdjustment) {
	NbAdjustment["NOOP"] = "noop";
	NbAdjustment["CLOCKWISE"] = "clockwise";
	NbAdjustment["COUNTERCLOCKWISE"] = "counterclockwise";
	NbAdjustment["VERTICAL"] = "vertical";
	NbAdjustment["HORIZONTAL"] = "horizontal";
})(NbAdjustment || (NbAdjustment = {}));
var NbPosition;
(function(NbPosition) {
	NbPosition["TOP"] = "top";
	NbPosition["BOTTOM"] = "bottom";
	NbPosition["LEFT"] = "left";
	NbPosition["RIGHT"] = "right";
	NbPosition["START"] = "start";
	NbPosition["END"] = "end";
	NbPosition["TOP_END"] = "top-end";
	NbPosition["TOP_START"] = "top-start";
	NbPosition["BOTTOM_END"] = "bottom-end";
	NbPosition["BOTTOM_START"] = "bottom-start";
	NbPosition["END_TOP"] = "end-top";
	NbPosition["END_BOTTOM"] = "end-bottom";
	NbPosition["START_TOP"] = "start-top";
	NbPosition["START_BOTTOM"] = "start-bottom";
})(NbPosition || (NbPosition = {}));
const POSITIONS = {
	[NbPosition.RIGHT](offset) {
		return {
			originX: "end",
			originY: "center",
			overlayX: "start",
			overlayY: "center",
			offsetX: offset
		};
	},
	[NbPosition.BOTTOM](offset) {
		return {
			originX: "center",
			originY: "bottom",
			overlayX: "center",
			overlayY: "top",
			offsetY: offset
		};
	},
	[NbPosition.LEFT](offset) {
		return {
			originX: "start",
			originY: "center",
			overlayX: "end",
			overlayY: "center",
			offsetX: -offset
		};
	},
	[NbPosition.TOP](offset) {
		return {
			originX: "center",
			originY: "top",
			overlayX: "center",
			overlayY: "bottom",
			offsetY: -offset
		};
	},
	[NbPosition.START](offset) {
		return this[NbPosition.LEFT](offset);
	},
	[NbPosition.END](offset) {
		return this[NbPosition.RIGHT](offset);
	},
	[NbPosition.END_TOP](offset) {
		return {
			originX: "end",
			originY: "bottom",
			overlayX: "start",
			overlayY: "bottom",
			offsetX: offset
		};
	},
	[NbPosition.END_BOTTOM](offset) {
		return {
			originX: "end",
			originY: "top",
			overlayX: "start",
			overlayY: "top",
			offsetX: offset
		};
	},
	[NbPosition.BOTTOM_START](offset) {
		return {
			originX: "end",
			originY: "bottom",
			overlayX: "end",
			overlayY: "top",
			offsetY: offset
		};
	},
	[NbPosition.BOTTOM_END](offset) {
		return {
			originX: "start",
			originY: "bottom",
			overlayX: "start",
			overlayY: "top",
			offsetY: offset
		};
	},
	[NbPosition.START_TOP](offset) {
		return {
			originX: "start",
			originY: "bottom",
			overlayX: "end",
			overlayY: "bottom",
			offsetX: -offset
		};
	},
	[NbPosition.START_BOTTOM](offset) {
		return {
			originX: "start",
			originY: "top",
			overlayX: "end",
			overlayY: "top",
			offsetX: -offset
		};
	},
	[NbPosition.TOP_START](offset) {
		return {
			originX: "end",
			originY: "top",
			overlayX: "end",
			overlayY: "bottom",
			offsetY: -offset
		};
	},
	[NbPosition.TOP_END](offset) {
		return {
			originX: "start",
			originY: "top",
			overlayX: "start",
			overlayY: "bottom",
			offsetY: -offset
		};
	}
};
const RTL_PHYSICAL_POSITIONS = {
	...POSITIONS,
	[NbPosition.RIGHT](offset) {
		return {
			originX: "start",
			originY: "center",
			overlayX: "end",
			overlayY: "center",
			offsetX: offset
		};
	},
	[NbPosition.LEFT](offset) {
		return {
			originX: "end",
			originY: "center",
			overlayX: "start",
			overlayY: "center",
			offsetX: -offset
		};
	},
	[NbPosition.START](offset) {
		return this[NbPosition.RIGHT](offset);
	},
	[NbPosition.END](offset) {
		return this[NbPosition.LEFT](offset);
	}
};
const COUNTER_CLOCKWISE_POSITIONS = [
	NbPosition.TOP,
	NbPosition.TOP_END,
	NbPosition.TOP_START,
	NbPosition.START,
	NbPosition.START_TOP,
	NbPosition.START_BOTTOM,
	NbPosition.BOTTOM,
	NbPosition.BOTTOM_START,
	NbPosition.BOTTOM_END,
	NbPosition.END,
	NbPosition.END_BOTTOM,
	NbPosition.END_TOP
];
const CLOCKWISE_POSITIONS = [
	NbPosition.TOP,
	NbPosition.TOP_START,
	NbPosition.TOP_END,
	NbPosition.END,
	NbPosition.END_TOP,
	NbPosition.END_BOTTOM,
	NbPosition.BOTTOM,
	NbPosition.BOTTOM_END,
	NbPosition.BOTTOM_START,
	NbPosition.START,
	NbPosition.START_BOTTOM,
	NbPosition.START_TOP
];
const VERTICAL_POSITIONS = [NbPosition.BOTTOM, NbPosition.TOP];
const HORIZONTAL_POSITIONS = [NbPosition.START, NbPosition.END];
function comparePositions(p1, p2) {
	return p1.originX === p2.originX && p1.originY === p2.originY && p1.overlayX === p2.overlayX && p1.overlayY === p2.overlayY;
}
var NbAdjustableConnectedPositionStrategy = class extends NbFlexibleConnectedPositionStrategy {
	constructor() {
		super(...arguments);
		this._offset = 15;
		this.positionChange = this.positionChanges.pipe(map((positionChange) => positionChange.connectionPair), map((connectionPair) => {
			return this.appliedPositions.find(({ connectedPosition }) => {
				return comparePositions(connectedPosition, connectionPair);
			}).key;
		}));
	}
	attach(overlayRef) {
		this.applyPositions();
		super.attach(overlayRef);
	}
	direction(direction) {
		this._direction = direction;
		return this;
	}
	apply() {
		this.applyPositions();
		super.apply();
	}
	position(position) {
		this._position = position;
		return this;
	}
	adjustment(adjustment) {
		this._adjustment = adjustment;
		return this;
	}
	offset(offset) {
		this._offset = offset;
		return this;
	}
	applyPositions() {
		const positions = this.createPositions();
		this.persistChosenPositions(positions);
		this.withPositions(this.appliedPositions.map(({ connectedPosition }) => connectedPosition));
	}
	createPositions() {
		switch (this._adjustment) {
			case NbAdjustment.NOOP: return [this._position];
			case NbAdjustment.CLOCKWISE: return this.reorderPreferredPositions(CLOCKWISE_POSITIONS);
			case NbAdjustment.COUNTERCLOCKWISE: return this.reorderPreferredPositions(COUNTER_CLOCKWISE_POSITIONS);
			case NbAdjustment.HORIZONTAL: return this.reorderPreferredPositions(HORIZONTAL_POSITIONS);
			case NbAdjustment.VERTICAL: return this.reorderPreferredPositions(VERTICAL_POSITIONS);
		}
	}
	mapToLogicalPosition(position) {
		if (position === NbPosition.LEFT) return this._direction === NbLayoutDirection.LTR ? NbPosition.START : NbPosition.END;
		if (position === NbPosition.RIGHT) return this._direction === NbLayoutDirection.LTR ? NbPosition.END : NbPosition.START;
		return position;
	}
	persistChosenPositions(positions) {
		const positionGrid = this._direction === NbLayoutDirection.RTL ? RTL_PHYSICAL_POSITIONS : POSITIONS;
		this.appliedPositions = positions.map((position) => ({
			key: position,
			connectedPosition: positionGrid[position](this._offset)
		}));
	}
	reorderPreferredPositions(positions) {
		const startPosition = this.mapToLogicalPosition(this._position);
		const startPositionIndex = positions.indexOf(startPosition);
		const firstPart = positions.slice(startPositionIndex);
		const secondPart = positions.slice(0, startPositionIndex);
		return firstPart.concat(secondPart);
	}
};
var NbGlobalPositionStrategy = class extends GlobalPositionStrategy {
	position(position) {
		switch (position) {
			case NbGlobalLogicalPosition.TOP_START: return this.top().left();
			case NbGlobalLogicalPosition.TOP_END: return this.top().right();
			case NbGlobalLogicalPosition.BOTTOM_START: return this.bottom().left();
			case NbGlobalLogicalPosition.BOTTOM_END: return this.bottom().right();
		}
	}
};
var NbPositionBuilderService = class NbPositionBuilderService {
	constructor(document, viewportRuler, platform, positionBuilder, overlayContainer) {
		this.document = document;
		this.viewportRuler = viewportRuler;
		this.platform = platform;
		this.positionBuilder = positionBuilder;
		this.overlayContainer = overlayContainer;
	}
	global() {
		return new NbGlobalPositionStrategy();
	}
	connectedTo(elementRef) {
		return new NbAdjustableConnectedPositionStrategy(elementRef, this.viewportRuler, this.document, this.platform, this.overlayContainer).withFlexibleDimensions(false).withPush(false);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPositionBuilderService,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbViewportRulerAdapter },
				{ token: NbPlatform },
				{ token: NbOverlayPositionBuilder },
				{ token: NbOverlayContainerAdapter }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPositionBuilderService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPositionBuilderService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbViewportRulerAdapter },
		{ type: NbPlatform },
		{ type: NbOverlayPositionBuilder },
		{ type: NbOverlayContainerAdapter }
	]
});
var NbPositionedContainerComponent = class NbPositionedContainerComponent {
	get top() {
		return this.position === NbPosition.TOP;
	}
	get topStart() {
		return this.position === NbPosition.TOP_START;
	}
	get topEnd() {
		return this.position === NbPosition.TOP_END;
	}
	get right() {
		return this.position === NbPosition.RIGHT || this.position === NbPosition.END;
	}
	get endTop() {
		return this.position === NbPosition.END_TOP;
	}
	get endBottom() {
		return this.position === NbPosition.END_BOTTOM;
	}
	get bottom() {
		return this.position === NbPosition.BOTTOM;
	}
	get bottomStart() {
		return this.position === NbPosition.BOTTOM_START;
	}
	get bottomEnd() {
		return this.position === NbPosition.BOTTOM_END;
	}
	get left() {
		return this.position === NbPosition.LEFT || this.position === NbPosition.START;
	}
	get startTop() {
		return this.position === NbPosition.START_TOP;
	}
	get startBottom() {
		return this.position === NbPosition.START_BOTTOM;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPositionedContainerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPositionedContainerComponent,
			isStandalone: false,
			selector: "ng-component",
			inputs: { position: "position" },
			host: { properties: {
				"class.nb-overlay-top": "this.top",
				"class.nb-overlay-top-start": "this.topStart",
				"class.nb-overlay-top-end": "this.topEnd",
				"class.nb-overlay-right": "this.right",
				"class.nb-overlay-end-top": "this.endTop",
				"class.nb-overlay-end-bottom": "this.endBottom",
				"class.nb-overlay-bottom": "this.bottom",
				"class.nb-overlay-bottom-start": "this.bottomStart",
				"class.nb-overlay-bottom-end": "this.bottomEnd",
				"class.nb-overlay-left": "this.left",
				"class.nb-overlay-start-top": "this.startTop",
				"class.nb-overlay-start-bottom": "this.startBottom"
			} },
			ngImport: i0,
			template: "",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPositionedContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			template: "",
			standalone: false
		}]
	}],
	propDecorators: {
		position: [{ type: Input }],
		top: [{
			type: HostBinding,
			args: ["class.nb-overlay-top"]
		}],
		topStart: [{
			type: HostBinding,
			args: ["class.nb-overlay-top-start"]
		}],
		topEnd: [{
			type: HostBinding,
			args: ["class.nb-overlay-top-end"]
		}],
		right: [{
			type: HostBinding,
			args: ["class.nb-overlay-right"]
		}],
		endTop: [{
			type: HostBinding,
			args: ["class.nb-overlay-end-top"]
		}],
		endBottom: [{
			type: HostBinding,
			args: ["class.nb-overlay-end-bottom"]
		}],
		bottom: [{
			type: HostBinding,
			args: ["class.nb-overlay-bottom"]
		}],
		bottomStart: [{
			type: HostBinding,
			args: ["class.nb-overlay-bottom-start"]
		}],
		bottomEnd: [{
			type: HostBinding,
			args: ["class.nb-overlay-bottom-end"]
		}],
		left: [{
			type: HostBinding,
			args: ["class.nb-overlay-left"]
		}],
		startTop: [{
			type: HostBinding,
			args: ["class.nb-overlay-start-top"]
		}],
		startBottom: [{
			type: HostBinding,
			args: ["class.nb-overlay-start-bottom"]
		}]
	}
});
var NbOverlayContainerComponent = class NbOverlayContainerComponent {
	constructor(vcr, injector, changeDetectorRef) {
		this.vcr = vcr;
		this.injector = injector;
		this.changeDetectorRef = changeDetectorRef;
		this.isAttached = false;
	}
	get isStringContent() {
		return !!this.content;
	}
	attachComponentPortal(portal, context) {
		portal.injector = this.createChildInjector();
		const componentRef = this.portalOutlet.attachComponentPortal(portal);
		if (context) Object.assign(componentRef.instance, context);
		componentRef.changeDetectorRef.markForCheck();
		componentRef.changeDetectorRef.detectChanges();
		this.isAttached = true;
		return componentRef;
	}
	attachTemplatePortal(portal) {
		const templateRef = this.portalOutlet.attachTemplatePortal(portal);
		templateRef.detectChanges();
		this.isAttached = true;
		return templateRef;
	}
	attachStringContent(content) {
		this.content = content;
		this.changeDetectorRef.markForCheck();
		this.changeDetectorRef.detectChanges();
		this.isAttached = true;
	}
	detach() {
		if (this.portalOutlet.hasAttached()) this.portalOutlet.detach();
		this.attachStringContent(null);
		this.isAttached = false;
	}
	createChildInjector() {
		return Injector.create({
			parent: this.injector,
			providers: []
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayContainerComponent,
			deps: [
				{ token: i0.ViewContainerRef },
				{ token: i0.Injector },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbOverlayContainerComponent,
			isStandalone: false,
			selector: "nb-overlay-container",
			viewQueries: [{
				propertyName: "portalOutlet",
				first: true,
				predicate: NbPortalOutletDirective,
				descendants: true,
				static: true
			}],
			ngImport: i0,
			template: `
    <div *ngIf="isStringContent" class="primitive-overlay">{{ content }}</div>
    <ng-template nbPortalOutlet></ng-template>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbPortalOutletDirective,
				selector: "[nbPortalOutlet]"
			}, {
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-overlay-container",
			template: `
    <div *ngIf="isStringContent" class="primitive-overlay">{{ content }}</div>
    <ng-template nbPortalOutlet></ng-template>
  `,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ViewContainerRef },
		{ type: i0.Injector },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: { portalOutlet: [{
		type: ViewChild,
		args: [NbPortalOutletDirective, { static: true }]
	}] }
});
function patch(container, containerContext) {
	Object.assign(container.instance, containerContext);
	container.changeDetectorRef.detectChanges();
	return container;
}
function createContainer(ref, container, context) {
	const containerRef = ref.attach(new NbComponentPortal(container, null, null));
	patch(containerRef, context);
	return containerRef;
}
var NbOverlayService = class NbOverlayService {
	constructor(overlay, layoutDirection) {
		this.overlay = overlay;
		this.layoutDirection = layoutDirection;
	}
	get scrollStrategies() {
		return this.overlay.scrollStrategies;
	}
	create(config) {
		const overlayRef = this.overlay.create(config);
		this.layoutDirection.onDirectionChange().subscribe((dir) => overlayRef.setDirection(dir));
		return overlayRef;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayService,
			deps: [{ token: NbOverlay }, { token: NbLayoutDirectionService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbOverlay }, { type: NbLayoutDirectionService }]
});
var NbScrollDispatcherAdapter = class NbScrollDispatcherAdapter extends ScrollDispatcher {
	constructor(ngZone, platform, scrollService, document) {
		super();
		this.scrollService = scrollService;
	}
	scrolled(auditTimeInMs) {
		return merge(super.scrolled(auditTimeInMs), this.scrollService.onScroll());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbScrollDispatcherAdapter,
			deps: [
				{ token: i0.NgZone },
				{ token: NbPlatform },
				{ token: NbLayoutScrollService },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbScrollDispatcherAdapter
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbScrollDispatcherAdapter,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: i0.NgZone },
		{ type: NbPlatform },
		{ type: NbLayoutScrollService },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	]
});
var NbBlockScrollStrategyAdapter = class NbBlockScrollStrategyAdapter extends BlockScrollStrategy {
	constructor(document, viewportRuler, scrollService) {
		super(viewportRuler, document);
		this.scrollService = scrollService;
	}
	enable() {
		super.enable();
		this.scrollService.scrollable(false);
	}
	disable() {
		super.disable();
		this.scrollService.scrollable(true);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBlockScrollStrategyAdapter,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbViewportRulerAdapter },
				{ token: NbLayoutScrollService }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBlockScrollStrategyAdapter
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBlockScrollStrategyAdapter,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbViewportRulerAdapter },
		{ type: NbLayoutScrollService }
	]
});
var NbScrollStrategyOptions = class NbScrollStrategyOptions extends ScrollStrategyOptions {
	constructor(scrollService, scrollDispatcher, viewportRuler, ngZone, document) {
		super();
		this.scrollService = scrollService;
		this.scrollDispatcher = scrollDispatcher;
		this.viewportRuler = viewportRuler;
		this.ngZone = ngZone;
		this.document = document;
		this.block = () => new NbBlockScrollStrategyAdapter(this.document, this.viewportRuler, this.scrollService);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbScrollStrategyOptions,
			deps: [
				{ token: NbLayoutScrollService },
				{ token: i3.ScrollDispatcher },
				{ token: NbViewportRulerAdapter },
				{ token: i0.NgZone },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbScrollStrategyOptions
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbScrollStrategyOptions,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbLayoutScrollService },
		{ type: i3.ScrollDispatcher },
		{ type: NbViewportRulerAdapter },
		{ type: i0.NgZone },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	]
});
var NbCdkAdapterModule = class NbCdkAdapterModule {
	static forRoot() {
		return {
			ngModule: NbCdkAdapterModule,
			providers: [
				NbViewportRulerAdapter,
				NbOverlayContainerAdapter,
				NbBlockScrollStrategyAdapter,
				NbScrollDispatcherAdapter,
				NbScrollStrategyOptions,
				{
					provide: OverlayContainer,
					useExisting: NbOverlayContainerAdapter
				},
				{
					provide: NbOverlayContainer,
					useExisting: NbOverlayContainerAdapter
				},
				{
					provide: ScrollDispatcher,
					useExisting: NbScrollDispatcherAdapter
				},
				{
					provide: ScrollStrategyOptions,
					useExisting: NbScrollStrategyOptions
				}
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkAdapterModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkAdapterModule
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCdkAdapterModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCdkAdapterModule,
	decorators: [{
		type: NgModule,
		args: [{}]
	}]
});
var NbTrigger;
(function(NbTrigger) {
	NbTrigger["NOOP"] = "noop";
	NbTrigger["CLICK"] = "click";
	NbTrigger["HOVER"] = "hover";
	NbTrigger["HINT"] = "hint";
	NbTrigger["FOCUS"] = "focus";
})(NbTrigger || (NbTrigger = {}));
var NbTriggerStrategyBase = class {
	destroy() {
		this.destroyed$.next();
	}
	isNotOnHostOrContainer(element) {
		return !this.isOnHost(element) && !this.isOnContainer(element);
	}
	isOnHostOrContainer(element) {
		return this.isOnHost(element) || this.isOnContainer(element);
	}
	isOnHost(element) {
		return this.host.contains(element);
	}
	isOnContainer(element) {
		return this.container() && this.container().location.nativeElement.contains(element);
	}
	constructor(document, host, container) {
		this.document = document;
		this.host = host;
		this.container = container;
		this.destroyed$ = new Subject();
	}
};
var NbClickTriggerStrategy = class extends NbTriggerStrategyBase {
	constructor() {
		super(...arguments);
		this.click$ = fromEvent(this.document, "click").pipe(map((event) => [!this.container() && this.isOnHost(event.target), event]), share(), takeUntil(this.destroyed$));
		this.show$ = this.click$.pipe(filter(([shouldShow]) => shouldShow), map(([, event]) => event), takeUntil(this.destroyed$));
		this.hide$ = this.click$.pipe(filter(([shouldShow, event]) => !shouldShow && !this.isOnContainer(event.target)), map(([, event]) => event), takeUntil(this.destroyed$));
	}
};
var NbHoverTriggerStrategy = class extends NbTriggerStrategyBase {
	constructor() {
		super(...arguments);
		this.show$ = fromEvent(this.host, "mouseenter").pipe(filter(() => !this.container()), delay(100), takeUntil(fromEvent(this.host, "mouseleave")), repeat(), takeUntil(this.destroyed$));
		this.hide$ = fromEvent(this.host, "mouseleave").pipe(switchMap(() => fromEvent(this.document, "mousemove").pipe(debounceTime(100), takeWhile(() => !!this.container()), filter((event) => this.isNotOnHostOrContainer(event.target)))), takeUntil(this.destroyed$));
	}
};
var NbHintTriggerStrategy = class extends NbTriggerStrategyBase {
	constructor() {
		super(...arguments);
		this.show$ = fromEvent(this.host, "mouseenter").pipe(delay(100), takeUntil(fromEvent(this.host, "mouseleave")), repeat(), takeUntil(this.destroyed$));
		this.hide$ = fromEvent(this.host, "mouseleave").pipe(takeUntil(this.destroyed$));
	}
};
var NbFocusTriggerStrategy = class extends NbTriggerStrategyBase {
	constructor() {
		super(...arguments);
		this.focusOut$ = fromEvent(this.host, "focusout").pipe(switchMap(() => fromEvent(this.document, "focusin").pipe(takeWhile(() => !!this.container()), filter((event) => this.isNotOnHostOrContainer(event.target)))), takeUntil(this.destroyed$));
		this.clickIn$ = fromEvent(this.host, "click").pipe(filter(() => !this.container()), takeUntil(this.destroyed$));
		this.clickOut$ = fromEvent(this.document, "click").pipe(filter(() => !!this.container()), filter((event) => {
			if (this.isNotOnHostOrContainer(event.target)) return this.isNotOnHostOrContainer(this.document.activeElement);
			return false;
		}), takeUntil(this.destroyed$));
		this.tabKeyPress$ = fromEvent(this.document, "keydown").pipe(filter((event) => event.keyCode === 9), filter(() => !!this.container()), takeUntil(this.destroyed$));
		this.show$ = merge(fromEvent(this.host, "focusin"), this.clickIn$).pipe(filter(() => !this.container()), debounceTime(100), takeUntil(fromEvent(this.host, "focusout")), repeat(), takeUntil(this.destroyed$));
		this.hide$ = merge(this.focusOut$, this.tabKeyPress$, this.clickOut$).pipe(takeUntil(this.destroyed$));
	}
};
var NbNoopTriggerStrategy = class extends NbTriggerStrategyBase {
	constructor() {
		super(...arguments);
		this.show$ = EMPTY;
		this.hide$ = EMPTY;
	}
};
var NbTriggerStrategyBuilderService = class NbTriggerStrategyBuilderService {
	constructor(_document) {
		this._document = _document;
	}
	trigger(trigger) {
		this._trigger = trigger;
		return this;
	}
	host(host) {
		this._host = host;
		return this;
	}
	container(container) {
		this._container = container;
		return this;
	}
	build() {
		switch (this._trigger) {
			case NbTrigger.CLICK: return new NbClickTriggerStrategy(this._document, this._host, this._container);
			case NbTrigger.HINT: return new NbHintTriggerStrategy(this._document, this._host, this._container);
			case NbTrigger.HOVER: return new NbHoverTriggerStrategy(this._document, this._host, this._container);
			case NbTrigger.FOCUS: return new NbFocusTriggerStrategy(this._document, this._host, this._container);
			case NbTrigger.NOOP: return new NbNoopTriggerStrategy(this._document, this._host, this._container);
			default: throw new Error("Trigger have to be provided");
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTriggerStrategyBuilderService,
			deps: [{ token: NB_DOCUMENT }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTriggerStrategyBuilderService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTriggerStrategyBuilderService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_DOCUMENT]
		}]
	}]
});
var NbOverlayModule = class NbOverlayModule {
	static forRoot() {
		return {
			ngModule: NbOverlayModule,
			providers: [
				NbPositionBuilderService,
				NbTriggerStrategyBuilderService,
				NbOverlayService,
				NbPositionHelper,
				...NbCdkMappingModule.forRoot().providers,
				...NbCdkAdapterModule.forRoot().providers,
				...NbA11yModule.forRoot().providers
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayModule,
			declarations: [NbPositionedContainerComponent, NbOverlayContainerComponent],
			imports: [NbCdkMappingModule, NbSharedModule],
			exports: [
				NbCdkMappingModule,
				NbCdkAdapterModule,
				NbOverlayContainerComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOverlayModule,
			imports: [
				NbCdkMappingModule,
				NbSharedModule,
				NbCdkMappingModule,
				NbCdkAdapterModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOverlayModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbCdkMappingModule, NbSharedModule],
			declarations: [NbPositionedContainerComponent, NbOverlayContainerComponent],
			exports: [
				NbCdkMappingModule,
				NbCdkAdapterModule,
				NbOverlayContainerComponent
			]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbStatusService = class NbStatusService {
	constructor() {
		this.coreStatuses = [
			"basic",
			"primary",
			"info",
			"warning",
			"danger",
			"control"
		];
	}
	isCoreStatus(status) {
		return this.coreStatuses.includes(status);
	}
	isCustomStatus(status) {
		if (this.isValidStatusString(status)) return !this.isCoreStatus(status);
		return false;
	}
	getStatusClass(status) {
		if (this.isValidStatusString(status)) return `status-${status}`;
	}
	isValidStatusString(status) {
		return typeof status === "string" && status.length > 0;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStatusService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStatusService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStatusService,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
function windowFactory(platformId) {
	if (isPlatformBrowser(platformId)) return window;
}
var NbThemeModule = class NbThemeModule {
	static forRoot(nbThemeOptions = { name: "default" }, nbJSThemes, nbMediaBreakpoints, layoutDirection) {
		return {
			ngModule: NbThemeModule,
			providers: [
				{
					provide: NB_THEME_OPTIONS,
					useValue: nbThemeOptions || {}
				},
				{
					provide: NB_BUILT_IN_JS_THEMES,
					useValue: BUILT_IN_THEMES
				},
				{
					provide: NB_JS_THEMES,
					useValue: nbJSThemes || []
				},
				{
					provide: NB_MEDIA_BREAKPOINTS,
					useValue: nbMediaBreakpoints || DEFAULT_MEDIA_BREAKPOINTS
				},
				{
					provide: NB_DOCUMENT,
					useExisting: DOCUMENT
				},
				{
					provide: NB_WINDOW,
					useFactory: windowFactory,
					deps: [PLATFORM_ID]
				},
				NbJSThemesRegistry,
				NbThemeService,
				NbMediaBreakpointsService,
				NbSpinnerService,
				{
					provide: NB_LAYOUT_DIRECTION,
					useValue: layoutDirection || NbLayoutDirection.LTR
				},
				NbLayoutDirectionService,
				NbLayoutScrollService,
				NbLayoutRulerService,
				...NbOverlayModule.forRoot().providers,
				NbStatusService
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbThemeModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbThemeModule,
			imports: [CommonModule]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbThemeModule,
			imports: [CommonModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbThemeModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule],
			exports: []
		}]
	}]
});
var NbColorHelper = class NbColorHelper {
	static shade(color, weight) {
		return NbColorHelper.mix("#000000", color, weight);
	}
	static tint(color, weight) {
		return NbColorHelper.mix("#ffffff", color, weight);
	}
	static mix(color1, color2, weight) {
		const d2h = (d) => d.toString(16);
		const h2d = (h) => parseInt(h, 16);
		let result = "#";
		for (let i = 1; i < 7; i += 2) {
			const firstPart = h2d(color1.substr(i, 2));
			const secondPart = h2d(color2.substr(i, 2));
			const resultPart = d2h(Math.floor(secondPart + (firstPart - secondPart) * (weight / 100)));
			result += ("0" + resultPart).slice(-2);
		}
		return result;
	}
	static hexToRgbA(hex, alpha) {
		let c;
		if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
			c = hex.substring(1).split("");
			if (c.length === 3) c = [
				c[0],
				c[0],
				c[1],
				c[1],
				c[2],
				c[2]
			];
			c = "0x" + c.join("");
			return "rgba(" + [
				c >> 16 & 255,
				c >> 8 & 255,
				c & 255
			].join(",") + "," + alpha + ")";
		}
		throw new Error("Bad Hex");
	}
};
var NbIconPackType;
(function(NbIconPackType) {
	NbIconPackType["SVG"] = "svg";
	NbIconPackType["FONT"] = "font";
})(NbIconPackType || (NbIconPackType = {}));
var NbFontIcon = class {
	constructor(name, content, params = {}) {
		this.name = name;
		this.content = content;
		this.params = params;
	}
	getClasses(options) {
		const classes = [];
		if (this.params.packClass) classes.push(this.params.packClass);
		const name = this.params.iconClassPrefix ? `${this.params.iconClassPrefix}-${this.name}` : this.name;
		classes.push(name);
		return classes;
	}
	getContent(options) {
		return this.content;
	}
};
var NbSvgIcon = class {
	constructor(name, content, params = {}) {
		this.name = name;
		this.content = content;
		this.params = params;
	}
	getClasses(options) {
		const classes = [];
		if (this.params.packClass) classes.push(this.params.packClass);
		return classes;
	}
	getContent(options) {
		return this.content;
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbIconDefinition = class {};
function throwPackNotFoundError(name) {
	throw Error(`Icon Pack '${name}' is not registered`);
}
function throwNoDefaultPackError() {
	throw Error("Default pack is not registered.");
}
function throwWrongPackTypeError(name, type, desiredType) {
	throw Error(`Pack '${name}' is not an '${desiredType}' Pack and its type is '${type}'`);
}
var NbIconLibraries = class NbIconLibraries {
	constructor() {
		this.packs = /* @__PURE__ */ new Map();
	}
	registerSvgPack(name, icons, params = {}) {
		this.packs.set(name, {
			name,
			icons: new Map(Object.entries(icons)),
			params,
			type: NbIconPackType.SVG
		});
	}
	registerFontPack(name, params = {}) {
		this.packs.set(name, {
			name,
			params,
			icons: /* @__PURE__ */ new Map(),
			type: NbIconPackType.FONT
		});
	}
	getPack(name) {
		return this.packs.get(name);
	}
	setDefaultPack(name) {
		if (!this.packs.has(name)) throwPackNotFoundError(name);
		this.defaultPack = this.packs.get(name);
	}
	getSvgIcon(name, pack) {
		const iconsPack = pack ? this.getPackOrThrow(pack) : this.getDefaultPackOrThrow();
		if (iconsPack.type !== NbIconPackType.SVG) throwWrongPackTypeError(iconsPack.name, iconsPack.type, "SVG");
		const icon = this.getIconFromPack(name, iconsPack);
		if (!icon) return null;
		return {
			name,
			pack: iconsPack.name,
			type: NbIconPackType.SVG,
			icon: this.createSvgIcon(name, icon, iconsPack.params)
		};
	}
	getFontIcon(name, pack) {
		const iconsPack = pack ? this.getPackOrThrow(pack) : this.getDefaultPackOrThrow();
		if (iconsPack.type !== NbIconPackType.FONT) throwWrongPackTypeError(iconsPack.name, iconsPack.type, "Font");
		const icon = this.getIconFromPack(name, iconsPack) ?? "";
		const iconContent = iconsPack.params.ligature ? name : icon;
		return {
			name,
			pack: iconsPack.name,
			type: NbIconPackType.FONT,
			icon: this.createFontIcon(name, iconContent, iconsPack.params)
		};
	}
	getIcon(name, pack) {
		if ((pack ? this.getPackOrThrow(pack) : this.getDefaultPackOrThrow()).type === NbIconPackType.SVG) return this.getSvgIcon(name, pack);
		return this.getFontIcon(name, pack);
	}
	createSvgIcon(name, content, params) {
		return content instanceof NbSvgIcon ? content : new NbSvgIcon(name, content, params);
	}
	createFontIcon(name, content, params) {
		return content instanceof NbFontIcon ? content : new NbFontIcon(name, content, params);
	}
	getPackOrThrow(name) {
		const pack = this.packs.get(name);
		if (!pack) throwPackNotFoundError(name);
		return pack;
	}
	getDefaultPackOrThrow() {
		if (!this.defaultPack) throwNoDefaultPackError();
		return this.defaultPack;
	}
	getIconFromPack(name, pack) {
		if (pack.icons.has(name)) return pack.icons.get(name);
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconLibraries,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconLibraries,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbIconLibraries,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbIconComponent = class NbIconComponent {
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	get config() {
		return this._config;
	}
	set config(value) {
		if (!value) return;
		this._config = value;
		if (typeof value === "string") this.icon = value;
		else {
			this.icon = value.icon;
			this.pack = value.pack;
			this.status = value.status;
			this.options = value.options;
		}
	}
	constructor(sanitizer, iconLibrary, el, renderer, statusService) {
		this.sanitizer = sanitizer;
		this.iconLibrary = iconLibrary;
		this.el = el;
		this.renderer = renderer;
		this.statusService = statusService;
		this.prevClasses = [];
		this.html = "";
	}
	ngOnInit() {
		this.iconDef = this.renderIcon(this.icon, this.pack, this.options);
	}
	ngOnChanges() {
		if (this.iconLibrary.getIcon(this.icon, this.pack)) this.renderIcon(this.icon, this.pack, this.options);
		else this.clearIcon();
	}
	renderIcon(name, pack, options) {
		const iconDefinition = this.iconLibrary.getIcon(name, pack);
		if (!iconDefinition) return;
		const content = iconDefinition.icon.getContent(options);
		if (content) this.html = this.sanitizer.bypassSecurityTrustHtml(content);
		this.assignClasses(iconDefinition.icon.getClasses(options));
		return iconDefinition;
	}
	clearIcon() {
		this.html = "";
		this.assignClasses([]);
	}
	assignClasses(classes) {
		this.prevClasses.forEach((className) => {
			this.renderer.removeClass(this.el.nativeElement, className);
		});
		classes.forEach((className) => {
			this.renderer.addClass(this.el.nativeElement, className);
		});
		this.prevClasses = classes;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconComponent,
			deps: [
				{ token: i1$2.DomSanitizer },
				{ token: NbIconLibraries },
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbIconComponent,
			isStandalone: false,
			selector: "nb-icon",
			inputs: {
				icon: "icon",
				pack: "pack",
				options: "options",
				status: "status",
				config: "config"
			},
			host: { properties: {
				"innerHtml": "this.html",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses"
			} },
			usesOnChanges: true,
			ngImport: i0,
			template: "",
			isInline: true,
			styles: [":host{display:inline-block}\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbIconComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-icon",
			template: "",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:inline-block}\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i1$2.DomSanitizer },
		{ type: NbIconLibraries },
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: NbStatusService }
	],
	propDecorators: {
		html: [{
			type: HostBinding,
			args: ["innerHtml"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		icon: [{ type: Input }],
		pack: [{ type: Input }],
		options: [{ type: Input }],
		status: [{ type: Input }],
		config: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbIconModule = class NbIconModule {
	constructor(iconsLibrary) {
		this.iconsLibrary = iconsLibrary;
		this.essentialsPackName = "nebular-essentials";
		if (this.iconsLibrary.getPack(this.essentialsPackName)) return;
		this.iconsLibrary.registerSvgPack(this.essentialsPackName, {
			"chevron-down-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"chevron-down\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M12 15.5a1 1 0 0 1-.71-.29l-4-4a1 1 0 1 1 1.42-1.42L12 13.1l3.3-3.18a1 1 0 1 1 1.38 1.44l-4 3.86a1 1 0 0 1-.68.28z\"/></g></g></svg>",
			"chevron-up-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"chevron-up\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M16 14.5a1 1 0 0 1-.71-.29L12 10.9l-3.3 3.18a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.42l4-3.86a1 1 0 0 1 1.4 0l4 4a1 1 0 0 1 0 1.42 1 1 0 0 1-.69.28z\"/></g></g></svg>",
			"chevron-left-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"chevron-left\"><rect width=\"24\" height=\"24\" transform=\"rotate(90 12 12)\" opacity=\"0\"/><path d=\"M13.36 17a1 1 0 0 1-.72-.31l-3.86-4a1 1 0 0 1 0-1.4l4-4a1 1 0 1 1 1.42 1.42L10.9 12l3.18 3.3a1 1 0 0 1 0 1.41 1 1 0 0 1-.72.29z\"/></g></g></svg>",
			"chevron-right-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"chevron-right\"><rect width=\"24\" height=\"24\" transform=\"rotate(-90 12 12)\" opacity=\"0\"/><path d=\"M10.5 17a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42L13.1 12 9.92 8.69a1 1 0 0 1 0-1.41 1 1 0 0 1 1.42 0l3.86 4a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-.7.32z\"/></g></g></svg>",
			"checkmark-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"checkmark\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M9.86 18a1 1 0 0 1-.73-.32l-4.86-5.17a1 1 0 1 1 1.46-1.37l4.12 4.39 8.41-9.2a1 1 0 1 1 1.48 1.34l-9.14 10a1 1 0 0 1-.73.33z\"/></g></g></svg>",
			"paper-plane-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"paper-plane\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M21 4a1.31 1.31 0 0 0-.06-.27v-.09a1 1 0 0 0-.2-.3 1 1 0 0 0-.29-.19h-.09a.86.86 0 0 0-.31-.15H20a1 1 0 0 0-.3 0l-18 6a1 1 0 0 0 0 1.9l8.53 2.84 2.84 8.53a1 1 0 0 0 1.9 0l6-18A1 1 0 0 0 21 4zm-4.7 2.29l-5.57 5.57L5.16 10zM14 18.84l-1.86-5.57 5.57-5.57z\"/></g></g></svg>",
			"file-text-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"file-text\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M15 16H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z\"/><path d=\"M9 14h3a1 1 0 0 0 0-2H9a1 1 0 0 0 0 2z\"/><path d=\"M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM14 5l2.74 3h-2a.79.79 0 0 1-.74-.85zm3.44 15H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H12v3.15A2.79 2.79 0 0 0 14.71 10H18v9.5a.53.53 0 0 1-.56.5z\"/></g></g></svg>",
			"alert-triangle-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"alert-triangle\"><rect width=\"24\" height=\"24\" transform=\"rotate(90 12 12)\" opacity=\"0\"/><path d=\"M22.56 16.3L14.89 3.58a3.43 3.43 0 0 0-5.78 0L1.44 16.3a3 3 0 0 0-.05 3A3.37 3.37 0 0 0 4.33 21h15.34a3.37 3.37 0 0 0 2.94-1.66 3 3 0 0 0-.05-3.04zm-1.7 2.05a1.31 1.31 0 0 1-1.19.65H4.33a1.31 1.31 0 0 1-1.19-.65 1 1 0 0 1 0-1l7.68-12.73a1.48 1.48 0 0 1 2.36 0l7.67 12.72a1 1 0 0 1 .01 1.01z\"/><circle cx=\"12\" cy=\"16\" r=\"1\"/><path d=\"M12 8a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z\"/></g></g></svg>",
			"question-mark-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"question-mark\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M17 9A5 5 0 0 0 7 9a1 1 0 0 0 2 0 3 3 0 1 1 3 3 1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-1.1A5 5 0 0 0 17 9z\"/><circle cx=\"12\" cy=\"19\" r=\"1\"/></g></g></svg>",
			"email-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"email\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M19 4H5a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zm-.67 2L12 10.75 5.67 6zM19 18H5a1 1 0 0 1-1-1V7.25l7.4 5.55a1 1 0 0 0 .6.2 1 1 0 0 0 .6-.2L20 7.25V17a1 1 0 0 1-1 1z\"/></g></g></svg>",
			"flash-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"flash\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M11.11 23a1 1 0 0 1-.34-.06 1 1 0 0 1-.65-1.05l.77-7.09H5a1 1 0 0 1-.83-1.56l7.89-11.8a1 1 0 0 1 1.17-.38 1 1 0 0 1 .65 1l-.77 7.14H19a1 1 0 0 1 .83 1.56l-7.89 11.8a1 1 0 0 1-.83.44zM6.87 12.8H12a1 1 0 0 1 .74.33 1 1 0 0 1 .25.78l-.45 4.15 4.59-6.86H12a1 1 0 0 1-1-1.11l.45-4.15z\"/></g></g></svg>",
			"search-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"search\"><rect width=\"24\" height=\"24\" opacity=\"0\"/><path d=\"M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z\"/></g></g></svg>",
			"close-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"close\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z\"/></g></g></svg>",
			"collapse-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"collapse\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M19 9h-2.58l3.29-3.29a1 1 0 1 0-1.42-1.42L15 7.57V5a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2z\"/><path d=\"M10 13H5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L9 16.42V19a1 1 0 0 0 1 1 1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1z\"/></g></g></svg>",
			"expand-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"expand\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M20 5a1 1 0 0 0-1-1h-5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42V10a1 1 0 0 0 1 1 1 1 0 0 0 1-1z\"/><path d=\"M10.71 13.29a1 1 0 0 0-1.42 0L6 16.57V14a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2H7.42l3.29-3.29a1 1 0 0 0 0-1.42z\"/></g></g></svg>",
			"minus-outline": "<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" width=\"100%\" height=\"100%\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"minus\"><rect width=\"24\" height=\"24\" transform=\"rotate(180 12 12)\" opacity=\"0\"/><path d=\"M19 13H5a1 1 0 0 1 0-2h14a1 1 0 0 1 0 2z\"/></g></g></svg>",
			"minus-bold-outline": "<svg xmlns:xlink=\"http://www.w3.org/1999/xlink\" fill=\"currentColor\" viewBox=\"0 0 8 2\" width=\"100%\" height=\"100%\"><defs><rect id=\"nb-mbo\" y=\"3\" width=\"8\" height=\"2\" rx=\"1\"/></defs><use xlink:href=\"#nb-mbo\" transform=\"translate(0 -3)\" fill-rule=\"evenodd\"/></svg>",
			"checkmark-bold-outline": "<svg xmlns:xlink=\"http://www.w3.org/1999/xlink\" fill=\"currentColor\" viewBox=\"0 0 8 7\" width=\"100%\" height=\"100%\"><defs><path id=\"nb-cbo\" d=\"M6.039 1.43a1.11 1.11 0 0 1 1.517-.228c.483.342.588.998.234 1.466L4.431 7.1a1 1 0 0 1-1.492.115L.317 4.677a1.023 1.023 0 0 1 .002-1.483 1.113 1.113 0 0 1 1.535.002l1.641 1.59L6.04 1.428z\"/></defs><use xlink:href=\"#nb-cbo\" transform=\"translate(0 -1)\" fill-rule=\"evenodd\"/></svg>",
			"arrow-back": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><g data-name=\"Layer 2\"><g data-name=\"arrow-back\"><rect width=\"24\" height=\"24\" transform=\"rotate(90 12 12)\" opacity=\"0\"/><path d=\"M19 11H7.14l3.63-4.36a1 1 0 1 0-1.54-1.28l-5 6a1.19 1.19 0 0 0-.09.15c0 .05 0 .08-.07.13A1 1 0 0 0 4 12a1 1 0 0 0 .07.36c0 .05 0 .08.07.13a1.19 1.19 0 0 0 .09.15l5 6A1 1 0 0 0 10 19a1 1 0 0 0 .64-.23 1 1 0 0 0 .13-1.41L7.14 13H19a1 1 0 0 0 0-2z\"/></g></g></svg>"
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconModule,
			deps: [{ token: NbIconLibraries }],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconModule,
			declarations: [NbIconComponent],
			imports: [CommonModule],
			exports: [NbIconComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbIconModule,
			imports: [CommonModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbIconModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule],
			declarations: [NbIconComponent],
			exports: [NbIconComponent]
		}]
	}],
	ctorParameters: () => [{ type: NbIconLibraries }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCardHeaderComponent = class NbCardHeaderComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardHeaderComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardHeaderComponent,
			isStandalone: false,
			selector: "nb-card-header",
			ngImport: i0,
			template: `<ng-content></ng-content>`,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card-header",
			template: `<ng-content></ng-content>`,
			standalone: false
		}]
	}]
});
var NbCardBodyComponent = class NbCardBodyComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardBodyComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardBodyComponent,
			isStandalone: false,
			selector: "nb-card-body",
			ngImport: i0,
			template: `<ng-content></ng-content>`,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardBodyComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card-body",
			template: `<ng-content></ng-content>`,
			standalone: false
		}]
	}]
});
var NbCardFooterComponent = class NbCardFooterComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardFooterComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardFooterComponent,
			isStandalone: false,
			selector: "nb-card-footer",
			ngImport: i0,
			template: `<ng-content></ng-content>`,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card-footer",
			template: `<ng-content></ng-content>`,
			standalone: false
		}]
	}]
});
var NbCardComponent = class NbCardComponent {
	get size() {
		return this._size;
	}
	set size(value) {
		this._size = value;
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get hasAccent() {
		return this.accent;
	}
	get primaryAccent() {
		return this.accent === "primary";
	}
	get infoAccent() {
		return this.accent === "info";
	}
	get successAccent() {
		return this.accent === "success";
	}
	get warningAccent() {
		return this.accent === "warning";
	}
	get dangerAccent() {
		return this.accent === "danger";
	}
	get basicAccent() {
		return this.accent === "basic";
	}
	get controlAccent() {
		return this.accent === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(statusService) {
		this.statusService = statusService;
		this._size = "";
		this.status = "";
		this.accent = "";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardComponent,
			isStandalone: false,
			selector: "nb-card",
			inputs: {
				size: "size",
				status: "status",
				accent: "accent"
			},
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.accent": "this.hasAccent",
				"class.accent-primary": "this.primaryAccent",
				"class.accent-info": "this.infoAccent",
				"class.accent-success": "this.successAccent",
				"class.accent-warning": "this.warningAccent",
				"class.accent-danger": "this.dangerAccent",
				"class.accent-basic": "this.basicAccent",
				"class.accent-control": "this.controlAccent",
				"class": "this.additionalClasses"
			} },
			ngImport: i0,
			template: `
    <ng-content select="nb-card-header"></ng-content>
    <ng-content select="nb-card-body"></ng-content>
    <ng-content></ng-content>
    <ng-content select="nb-card-footer"></ng-content>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card",
			template: `
    <ng-content select="nb-card-header"></ng-content>
    <ng-content select="nb-card-body"></ng-content>
    <ng-content></ng-content>
    <ng-content select="nb-card-footer"></ng-content>
  `,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		size: [{ type: Input }],
		status: [{ type: Input }],
		accent: [{ type: Input }],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		hasAccent: [{
			type: HostBinding,
			args: ["class.accent"]
		}],
		primaryAccent: [{
			type: HostBinding,
			args: ["class.accent-primary"]
		}],
		infoAccent: [{
			type: HostBinding,
			args: ["class.accent-info"]
		}],
		successAccent: [{
			type: HostBinding,
			args: ["class.accent-success"]
		}],
		warningAccent: [{
			type: HostBinding,
			args: ["class.accent-warning"]
		}],
		dangerAccent: [{
			type: HostBinding,
			args: ["class.accent-danger"]
		}],
		basicAccent: [{
			type: HostBinding,
			args: ["class.accent-basic"]
		}],
		controlAccent: [{
			type: HostBinding,
			args: ["class.accent-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var NbRevealCardComponent = class NbRevealCardComponent {
	constructor() {
		this.revealed = false;
		this.showToggleButton = true;
	}
	toggle() {
		this.revealed = !this.revealed;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRevealCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRevealCardComponent,
			isStandalone: false,
			selector: "nb-reveal-card",
			inputs: {
				revealed: "revealed",
				showToggleButton: "showToggleButton"
			},
			host: { properties: { "class.revealed": "this.revealed" } },
			ngImport: i0,
			template: `
    <ng-content select="nb-card-front"></ng-content>
    <div class="second-card-container">
      <ng-content select="nb-card-back"></ng-content>
    </div>
    <a *ngIf="showToggleButton" class="reveal-button" (click)="toggle()">
      <nb-icon icon="chevron-down-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
    </a>
  `,
			isInline: true,
			styles: [":host{display:block;position:relative;overflow:hidden}:host .second-card-container{position:absolute;top:100%;right:0;left:0;overflow:hidden;transition:top 0s .5s}:host ::ng-deep nb-card-front nb-card,:host ::ng-deep nb-card-back nb-card{box-shadow:none;margin:0}:host ::ng-deep nb-card-front{display:block;height:100%}:host ::ng-deep nb-card-back{position:absolute;left:0;top:100%;width:100%;transition:top .5s}:host .reveal-button{cursor:pointer;position:absolute;right:0;bottom:0;transform:rotate(180deg);transition:transform .3s}:host(.revealed) .second-card-container{top:0;transition:none}:host(.revealed) .second-card-container ::ng-deep nb-card-back{top:0}:host(.revealed) .reveal-button{transform:none}\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRevealCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-reveal-card",
			template: `
    <ng-content select="nb-card-front"></ng-content>
    <div class="second-card-container">
      <ng-content select="nb-card-back"></ng-content>
    </div>
    <a *ngIf="showToggleButton" class="reveal-button" (click)="toggle()">
      <nb-icon icon="chevron-down-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
    </a>
  `,
			standalone: false,
			styles: [":host{display:block;position:relative;overflow:hidden}:host .second-card-container{position:absolute;top:100%;right:0;left:0;overflow:hidden;transition:top 0s .5s}:host ::ng-deep nb-card-front nb-card,:host ::ng-deep nb-card-back nb-card{box-shadow:none;margin:0}:host ::ng-deep nb-card-front{display:block;height:100%}:host ::ng-deep nb-card-back{position:absolute;left:0;top:100%;width:100%;transition:top .5s}:host .reveal-button{cursor:pointer;position:absolute;right:0;bottom:0;transform:rotate(180deg);transition:transform .3s}:host(.revealed) .second-card-container{top:0;transition:none}:host(.revealed) .second-card-container ::ng-deep nb-card-back{top:0}:host(.revealed) .reveal-button{transform:none}\n"]
		}]
	}],
	propDecorators: {
		revealed: [{ type: Input }, {
			type: HostBinding,
			args: ["class.revealed"]
		}],
		showToggleButton: [{ type: Input }]
	}
});
var NbFlipCardComponent = class NbFlipCardComponent {
	constructor() {
		this.flipped = false;
		this.showToggleButton = true;
	}
	toggle() {
		this.flipped = !this.flipped;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFlipCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFlipCardComponent,
			isStandalone: false,
			selector: "nb-flip-card",
			inputs: {
				flipped: "flipped",
				showToggleButton: "showToggleButton"
			},
			host: { properties: { "class.flipped": "this.flipped" } },
			ngImport: i0,
			template: `
    <div class="flipcard-body">
      <div class="front-container">
        <ng-content select="nb-card-front"></ng-content>
        <a *ngIf="showToggleButton" class="flip-button" (click)="toggle()">
          <nb-icon icon="chevron-left-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
        </a>
      </div>
      <div class="back-container">
        <ng-content select="nb-card-back"></ng-content>
        <a *ngIf="showToggleButton" class="flip-button" (click)="toggle()">
          <nb-icon icon="chevron-left-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
        </a>
      </div>
    </div>
  `,
			isInline: true,
			styles: [":host{display:block;min-width:0;perspective:1200px;position:relative}:host-context(.flipped) .flipcard-body{transform:rotateY(-180deg)}:host-context(.flipped) .flipcard-body .front-container{opacity:0;transition:opacity 0s .25s;backface-visibility:hidden;-webkit-backface-visibility:hidden}:host-context(.flipped) .flipcard-body .front-container .flip-button{opacity:0;z-index:-1}:host-context(.flipped) .flipcard-body .back-container{backface-visibility:visible;-webkit-backface-visibility:visible}.flipcard-body{display:flex;transition:transform .5s;transform-style:preserve-3d}.flipcard-body .front-container,.flipcard-body .back-container{flex:1;height:fit-content;overflow:auto}.flipcard-body .front-container .flip-button,.flipcard-body .back-container .flip-button{cursor:pointer;position:absolute;right:0;bottom:0;opacity:1;transition:opacity 0s .15s}.flipcard-body .front-container{backface-visibility:visible;-webkit-backface-visibility:visible;transition:opacity 0s .2s}.flipcard-body .back-container{backface-visibility:hidden;-webkit-backface-visibility:hidden;transform:rotateY(180deg)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFlipCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-flip-card",
			template: `
    <div class="flipcard-body">
      <div class="front-container">
        <ng-content select="nb-card-front"></ng-content>
        <a *ngIf="showToggleButton" class="flip-button" (click)="toggle()">
          <nb-icon icon="chevron-left-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
        </a>
      </div>
      <div class="back-container">
        <ng-content select="nb-card-back"></ng-content>
        <a *ngIf="showToggleButton" class="flip-button" (click)="toggle()">
          <nb-icon icon="chevron-left-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
        </a>
      </div>
    </div>
  `,
			standalone: false,
			styles: [":host{display:block;min-width:0;perspective:1200px;position:relative}:host-context(.flipped) .flipcard-body{transform:rotateY(-180deg)}:host-context(.flipped) .flipcard-body .front-container{opacity:0;transition:opacity 0s .25s;backface-visibility:hidden;-webkit-backface-visibility:hidden}:host-context(.flipped) .flipcard-body .front-container .flip-button{opacity:0;z-index:-1}:host-context(.flipped) .flipcard-body .back-container{backface-visibility:visible;-webkit-backface-visibility:visible}.flipcard-body{display:flex;transition:transform .5s;transform-style:preserve-3d}.flipcard-body .front-container,.flipcard-body .back-container{flex:1;height:fit-content;overflow:auto}.flipcard-body .front-container .flip-button,.flipcard-body .back-container .flip-button{cursor:pointer;position:absolute;right:0;bottom:0;opacity:1;transition:opacity 0s .15s}.flipcard-body .front-container{backface-visibility:visible;-webkit-backface-visibility:visible;transition:opacity 0s .2s}.flipcard-body .back-container{backface-visibility:hidden;-webkit-backface-visibility:hidden;transform:rotateY(180deg)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		flipped: [{ type: Input }, {
			type: HostBinding,
			args: ["class.flipped"]
		}],
		showToggleButton: [{ type: Input }]
	}
});
var NbCardFrontComponent = class NbCardFrontComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardFrontComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardFrontComponent,
			isStandalone: false,
			selector: "nb-card-front",
			ngImport: i0,
			template: "<ng-content select=\"nb-card\"></ng-content>",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardFrontComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card-front",
			template: "<ng-content select=\"nb-card\"></ng-content>",
			standalone: false
		}]
	}]
});
var NbCardBackComponent = class NbCardBackComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardBackComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCardBackComponent,
			isStandalone: false,
			selector: "nb-card-back",
			ngImport: i0,
			template: "<ng-content select=\"nb-card\"></ng-content>",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardBackComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-card-back",
			template: "<ng-content select=\"nb-card\"></ng-content>",
			standalone: false
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_CARD_COMPONENTS = [
	NbCardComponent,
	NbCardBodyComponent,
	NbCardFooterComponent,
	NbCardHeaderComponent,
	NbRevealCardComponent,
	NbFlipCardComponent,
	NbCardFrontComponent,
	NbCardBackComponent
];
var NbCardModule = class NbCardModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardModule,
			declarations: [
				NbCardComponent,
				NbCardBodyComponent,
				NbCardFooterComponent,
				NbCardHeaderComponent,
				NbRevealCardComponent,
				NbFlipCardComponent,
				NbCardFrontComponent,
				NbCardBackComponent
			],
			imports: [NbSharedModule, NbIconModule],
			exports: [
				NbCardComponent,
				NbCardBodyComponent,
				NbCardFooterComponent,
				NbCardHeaderComponent,
				NbRevealCardComponent,
				NbFlipCardComponent,
				NbCardFrontComponent,
				NbCardBackComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCardModule,
			imports: [NbSharedModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCardModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbIconModule],
			declarations: [...NB_CARD_COMPONENTS],
			exports: [...NB_CARD_COMPONENTS]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarViewMode;
(function(NbCalendarViewMode) {
	NbCalendarViewMode["YEAR"] = "year";
	NbCalendarViewMode["MONTH"] = "month";
	NbCalendarViewMode["DATE"] = "date";
})(NbCalendarViewMode || (NbCalendarViewMode = {}));
var NbCalendarSize;
(function(NbCalendarSize) {
	NbCalendarSize["MEDIUM"] = "medium";
	NbCalendarSize["LARGE"] = "large";
})(NbCalendarSize || (NbCalendarSize = {}));
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
function convertToBoolProperty(val) {
	if (typeof val === "string") {
		val = val.toLowerCase().trim();
		return val === "true" || val === "";
	}
	return !!val;
}
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDateService = class {
	constructor() {
		this.DAYS_IN_WEEK = 7;
		this.HOURS_IN_DAY_PERIOD = 12;
	}
	setLocale(locale) {
		this.locale = locale;
	}
	isBetween(date, start, end) {
		return this.compareDates(date, start) > 0 && this.compareDates(date, end) < 0;
	}
	isSameDaySafe(date1, date2) {
		return date1 && date2 && this.isSameDay(date1, date2);
	}
	isSameMonthSafe(date1, date2) {
		return date1 && date2 && this.isSameMonth(date1, date2);
	}
	isSameYearSafe(date1, date2) {
		return date1 && date2 && this.isSameYear(date1, date2);
	}
	isSameHourAndMinute(date1, date2) {
		return this.isSameHour(date1, date2) && this.isSameMinute(date1, date2);
	}
	isSameHour(date1, date2) {
		return this.getHours(date1) === this.getHours(date2);
	}
	isSameMinute(date1, date2) {
		return this.getMinutes(date1) === this.getMinutes(date2);
	}
	getTwentyFourHoursFormat() {
		return "HH:mm";
	}
	getTwentyFourHoursFormatWithSeconds() {
		return "HH:mm:ss";
	}
	getTwelveHoursFormatWithSeconds() {
		return "hh:mm:ss a";
	}
	getDayPeriod(date) {
		if (this.getHours(date) < this.HOURS_IN_DAY_PERIOD) return "AM";
		else return "PM";
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const batch = (target, batchSize, offset = 0) => {
	return target.reduce((res, item, index) => {
		const chunkIndex = Math.floor((index + offset) / batchSize);
		if (!res[chunkIndex]) res[chunkIndex] = [];
		res[chunkIndex].push(item);
		return res;
	}, []);
};
const rangeFromTo = (from, to = 0, producer = (i) => i) => {
	const arr = [];
	for (let i = from; i < to; i++) arr.push(producer(i));
	return arr;
};
const range = (bound, producer = (i) => i) => {
	return rangeFromTo(0, bound, producer);
};
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarYearModelService = class NbCalendarYearModelService {
	constructor(dateService) {
		this.dateService = dateService;
		this.yearsInView = 12;
		this.yearsInRow = 4;
	}
	getYearsInView() {
		return this.yearsInView;
	}
	getYearsInRow() {
		return this.yearsInRow;
	}
	getViewYears(viewYear) {
		const year = this.dateService.getYear(viewYear);
		let viewStartYear;
		if (year >= 0) viewStartYear = year - year % this.yearsInView;
		else viewStartYear = year - (year % this.yearsInView + this.yearsInView);
		const years = range(this.yearsInView).map((i) => this.copyWithYear(viewStartYear + i, viewYear));
		return batch(years, this.yearsInRow);
	}
	copyWithYear(year, date) {
		return this.dateService.createDate(year, this.dateService.getMonth(date), this.dateService.getDate(date));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarYearModelService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarYearModelService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarYearModelService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
var NbButton = class NbButton {
	get filled() {
		return this.appearance === "filled";
	}
	set filled(value) {
		if (convertToBoolProperty(value)) this.appearance = "filled";
	}
	get outline() {
		return this.appearance === "outline";
	}
	set outline(value) {
		if (convertToBoolProperty(value)) this.appearance = "outline";
	}
	get ghost() {
		return this.appearance === "ghost";
	}
	set ghost(value) {
		if (convertToBoolProperty(value)) this.appearance = "ghost";
	}
	get fullWidth() {
		return this._fullWidth;
	}
	set fullWidth(value) {
		this._fullWidth = convertToBoolProperty(value);
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		if (this.disabled !== convertToBoolProperty(value)) {
			this._disabled = !this.disabled;
			this.renderer.setProperty(this.hostElement.nativeElement, "disabled", this.disabled);
		}
	}
	get tabbable() {
		if (this.disabled) return "-1";
		if (this.tabIndex == null) return "0";
		return this.tabIndex.toString();
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get rectangle() {
		return this.shape === "rectangle";
	}
	get round() {
		return this.shape === "round";
	}
	get semiRound() {
		return this.shape === "semi-round";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(renderer, hostElement, cd, zone, statusService) {
		this.renderer = renderer;
		this.hostElement = hostElement;
		this.cd = cd;
		this.zone = zone;
		this.statusService = statusService;
		this.size = "medium";
		this.status = "basic";
		this.shape = "rectangle";
		this.appearance = "filled";
		this._fullWidth = false;
		this._disabled = false;
		this.iconLeft = false;
		this.iconRight = false;
	}
	ngAfterContentChecked() {
		const firstNode = this.nodes[0];
		const lastNode = this.nodes[this.nodes.length - 1];
		this.iconLeft = this.isIconExist(firstNode);
		this.iconRight = this.isIconExist(lastNode);
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostElement.nativeElement, "nb-transition");
		}));
	}
	updateProperties(config) {
		let isPropertyChanged = false;
		for (const key in config) if (config.hasOwnProperty(key) && this[key] !== config[key]) {
			this[key] = config[key];
			isPropertyChanged = true;
		}
		if (isPropertyChanged) this.cd.markForCheck();
	}
	get iconElement() {
		return this.hostElement.nativeElement.querySelector("nb-icon");
	}
	get nodes() {
		return this.cd.rootNodes.filter((child) => child.nodeType !== Node.COMMENT_NODE);
	}
	isIconExist(node) {
		return this.icons.some((item) => item.nativeElement === node);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButton,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbButton,
			isStandalone: true,
			inputs: {
				size: "size",
				status: "status",
				shape: "shape",
				appearance: "appearance",
				filled: "filled",
				outline: "outline",
				ghost: "ghost",
				fullWidth: "fullWidth",
				disabled: "disabled",
				tabIndex: "tabIndex"
			},
			host: { properties: {
				"class.appearance-filled": "this.filled",
				"class.appearance-outline": "this.outline",
				"class.appearance-ghost": "this.ghost",
				"class.full-width": "this.fullWidth",
				"attr.aria-disabled": "this.disabled",
				"class.btn-disabled": "this.disabled",
				"attr.tabindex": "this.tabbable",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.shape-rectangle": "this.rectangle",
				"class.shape-round": "this.round",
				"class.shape-semi-round": "this.semiRound",
				"class.icon-start": "this.iconLeft",
				"class.icon-end": "this.iconRight",
				"class": "this.additionalClasses"
			} },
			queries: [{
				propertyName: "icons",
				predicate: NbIconComponent,
				read: ElementRef
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButton,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		size: [{ type: Input }],
		status: [{ type: Input }],
		shape: [{ type: Input }],
		appearance: [{ type: Input }],
		filled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-filled"]
		}],
		outline: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-outline"]
		}],
		ghost: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-ghost"]
		}],
		fullWidth: [{ type: Input }, {
			type: HostBinding,
			args: ["class.full-width"]
		}],
		disabled: [
			{ type: Input },
			{
				type: HostBinding,
				args: ["attr.aria-disabled"]
			},
			{
				type: HostBinding,
				args: ["class.btn-disabled"]
			}
		],
		tabIndex: [{ type: Input }],
		tabbable: [{
			type: HostBinding,
			args: ["attr.tabindex"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		rectangle: [{
			type: HostBinding,
			args: ["class.shape-rectangle"]
		}],
		round: [{
			type: HostBinding,
			args: ["class.shape-round"]
		}],
		semiRound: [{
			type: HostBinding,
			args: ["class.shape-semi-round"]
		}],
		iconLeft: [{
			type: HostBinding,
			args: ["class.icon-start"]
		}],
		iconRight: [{
			type: HostBinding,
			args: ["class.icon-end"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		icons: [{
			type: ContentChildren,
			args: [NbIconComponent, { read: ElementRef }]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbButtonComponent = class NbButtonComponent extends NbButton {
	get hero() {
		return this.appearance === "hero";
	}
	set hero(value) {
		if (convertToBoolProperty(value)) this.appearance = "hero";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	onClick(event) {
		if (this.disabled) {
			event.preventDefault();
			event.stopImmediatePropagation();
		}
	}
	constructor(renderer, hostElement, cd, zone, statusService) {
		super(renderer, hostElement, cd, zone, statusService);
		this.renderer = renderer;
		this.hostElement = hostElement;
		this.cd = cd;
		this.zone = zone;
		this.statusService = statusService;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonComponent,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbButtonComponent,
			isStandalone: false,
			selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
			inputs: { hero: "hero" },
			host: {
				listeners: { "click": "onClick($event)" },
				properties: {
					"class.appearance-hero": "this.hero",
					"class.status-primary": "this.primary",
					"class.status-info": "this.info",
					"class.status-success": "this.success",
					"class.status-warning": "this.warning",
					"class.status-danger": "this.danger",
					"class.status-basic": "this.basic",
					"class.status-control": "this.control"
				}
			},
			providers: [{
				provide: NbButton,
				useExisting: NbButtonComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: `
    <ng-content></ng-content>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
			template: `
    <ng-content></ng-content>
  `,
			providers: [{
				provide: NbButton,
				useExisting: NbButtonComponent
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		hero: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-hero"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarViewModeComponent = class NbCalendarViewModeComponent {
	constructor(dateService, yearModelService) {
		this.dateService = dateService;
		this.yearModelService = yearModelService;
		this.viewMode = NbCalendarViewMode.DATE;
		this.changeMode = new EventEmitter(true);
	}
	getText() {
		if (!this.date) return "";
		switch (this.viewMode) {
			case NbCalendarViewMode.DATE: return `${this.dateService.getMonthName(this.date, TranslationWidth.Wide)} ${this.dateService.getYear(this.date)}`;
			case NbCalendarViewMode.MONTH: return `${this.dateService.getYear(this.date)}`;
			case NbCalendarViewMode.YEAR: return `${this.getFirstYear()} - ${this.getLastYear()}`;
		}
	}
	getIcon() {
		if (this.viewMode === NbCalendarViewMode.DATE) return "chevron-down-outline";
		return "chevron-up-outline";
	}
	getFirstYear() {
		const years = this.yearModelService.getViewYears(this.date);
		return this.dateService.getYear(years[0][0]).toString();
	}
	getLastYear() {
		const years = this.yearModelService.getViewYears(this.date);
		const lastRow = years[years.length - 1];
		const lastYear = lastRow[lastRow.length - 1];
		return this.dateService.getYear(lastYear).toString();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarViewModeComponent,
			deps: [{ token: NbDateService }, { token: NbCalendarYearModelService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarViewModeComponent,
			isStandalone: false,
			selector: "nb-calendar-view-mode",
			inputs: {
				date: "date",
				viewMode: "viewMode"
			},
			outputs: { changeMode: "changeMode" },
			ngImport: i0,
			template: `
    <button nbButton (click)="changeMode.emit()" ghost status="basic">
      {{ getText() }}
      <nb-icon [icon]="getIcon()" pack="nebular-essentials"></nb-icon>
    </button>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbButtonComponent,
				selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
				inputs: ["hero"]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarViewModeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-view-mode",
			template: `
    <button nbButton (click)="changeMode.emit()" ghost status="basic">
      {{ getText() }}
      <nb-icon [icon]="getIcon()" pack="nebular-essentials"></nb-icon>
    </button>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }, { type: NbCalendarYearModelService }],
	propDecorators: {
		date: [{ type: Input }],
		viewMode: [{ type: Input }],
		changeMode: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarPageableNavigationComponent = class NbCalendarPageableNavigationComponent {
	constructor(directionService) {
		this.directionService = directionService;
		this.next = new EventEmitter();
		this.prev = new EventEmitter();
	}
	get isLtr() {
		return this.directionService.isLtr();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarPageableNavigationComponent,
			deps: [{ token: NbLayoutDirectionService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarPageableNavigationComponent,
			isStandalone: false,
			selector: "nb-calendar-pageable-navigation",
			outputs: {
				next: "next",
				prev: "prev"
			},
			ngImport: i0,
			template: `
    <button nbButton (click)="prev.emit()" ghost status="basic" class="prev-month">
      <nb-icon [icon]="isLtr ? 'chevron-left-outline' : 'chevron-right-outline'" pack="nebular-essentials"></nb-icon>
    </button>
    <button nbButton (click)="next.emit()" ghost status="basic" class="next-month">
      <nb-icon [icon]="isLtr ? 'chevron-right-outline' : 'chevron-left-outline'" pack="nebular-essentials"></nb-icon>
    </button>
  `,
			isInline: true,
			styles: [":host{display:flex;align-items:center;justify-content:flex-start}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "component",
				type: NbButtonComponent,
				selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
				inputs: ["hero"]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarPageableNavigationComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-pageable-navigation",
			template: `
    <button nbButton (click)="prev.emit()" ghost status="basic" class="prev-month">
      <nb-icon [icon]="isLtr ? 'chevron-left-outline' : 'chevron-right-outline'" pack="nebular-essentials"></nb-icon>
    </button>
    <button nbButton (click)="next.emit()" ghost status="basic" class="next-month">
      <nb-icon [icon]="isLtr ? 'chevron-right-outline' : 'chevron-left-outline'" pack="nebular-essentials"></nb-icon>
    </button>
  `,
			standalone: false,
			styles: [":host{display:flex;align-items:center;justify-content:flex-start}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbLayoutDirectionService }],
	propDecorators: {
		next: [{ type: Output }],
		prev: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarYearCellComponent = class NbCalendarYearCellComponent {
	constructor(dateService) {
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.yearCellClass = true;
	}
	get selected() {
		return this.dateService.isSameYearSafe(this.date, this.selectedValue);
	}
	get today() {
		return this.dateService.isSameYearSafe(this.date, this.dateService.today());
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	get year() {
		return this.dateService.getYear(this.date);
	}
	onClick() {
		if (this.disabled) return;
		this.select.emit(this.date);
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.yearEnd(), this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.yearStart(), this.max) > 0;
	}
	yearStart() {
		return this.dateService.getYearStart(this.date);
	}
	yearEnd() {
		return this.dateService.getYearEnd(this.date);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarYearCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarYearCellComponent,
			isStandalone: false,
			selector: "nb-calendar-year-cell",
			inputs: {
				date: "date",
				min: "min",
				max: "max",
				selectedValue: "selectedValue",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.selected": "this.selected",
					"class.today": "this.today",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge",
					"class.year-cell": "this.yearCellClass"
				}
			},
			ngImport: i0,
			template: `
    <div class="cell-content">
      {{ year }}
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarYearCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-year-cell",
			template: `
    <div class="cell-content">
      {{ year }}
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		selectedValue: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		yearCellClass: [{
			type: HostBinding,
			args: ["class.year-cell"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarPickerRowComponent = class NbCalendarPickerRowComponent {
	constructor() {
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter();
	}
	ngOnChanges() {
		this.containerRef.clear();
		this.row.forEach((date) => {
			const component = this.containerRef.createComponent(this.component, { index: this.containerRef.length });
			this.patchWithContext(component.instance, date);
			component.changeDetectorRef.detectChanges();
		});
	}
	patchWithContext(component, date) {
		component.visibleDate = this.visibleDate;
		component.selectedValue = this.selectedValue;
		component.date = date;
		component.min = this.min;
		component.max = this.max;
		component.filter = this.filter;
		component.size = this.size;
		component.select.subscribe(this.select.emit.bind(this.select));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarPickerRowComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarPickerRowComponent,
			isStandalone: false,
			selector: "nb-calendar-picker-row",
			inputs: {
				row: "row",
				selectedValue: "selectedValue",
				visibleDate: "visibleDate",
				component: "component",
				min: "min",
				max: "max",
				filter: "filter",
				size: "size"
			},
			outputs: { select: "select" },
			viewQueries: [{
				propertyName: "containerRef",
				first: true,
				predicate: TemplateRef,
				descendants: true,
				read: ViewContainerRef,
				static: true
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: "<ng-template></ng-template>",
			isInline: true,
			styles: [":host{display:flex;justify-content:space-between}\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarPickerRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-picker-row",
			template: "<ng-template></ng-template>",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;justify-content:space-between}\n"]
		}]
	}],
	propDecorators: {
		row: [{ type: Input }],
		selectedValue: [{ type: Input }],
		visibleDate: [{ type: Input }],
		component: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		containerRef: [{
			type: ViewChild,
			args: [TemplateRef, {
				read: ViewContainerRef,
				static: true
			}]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarPickerComponent = class NbCalendarPickerComponent {
	constructor() {
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarPickerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarPickerComponent,
			isStandalone: false,
			selector: "nb-calendar-picker",
			inputs: {
				data: "data",
				visibleDate: "visibleDate",
				selectedValue: "selectedValue",
				cellComponent: "cellComponent",
				min: "min",
				max: "max",
				filter: "filter",
				size: "size"
			},
			outputs: { select: "select" },
			host: { properties: { "class.size-large": "this.isLarge" } },
			ngImport: i0,
			template: `
    <nb-calendar-picker-row
      *ngFor="let row of data"
      [row]="row"
      [visibleDate]="visibleDate"
      [selectedValue]="selectedValue"
      [component]="cellComponent"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [size]="size"
      (select)="select.emit($event)">
    </nb-calendar-picker-row>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgForOf,
				selector: "[ngFor][ngForOf]",
				inputs: [
					"ngForOf",
					"ngForTrackBy",
					"ngForTemplate"
				]
			}, {
				kind: "component",
				type: NbCalendarPickerRowComponent,
				selector: "nb-calendar-picker-row",
				inputs: [
					"row",
					"selectedValue",
					"visibleDate",
					"component",
					"min",
					"max",
					"filter",
					"size"
				],
				outputs: ["select"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-picker",
			template: `
    <nb-calendar-picker-row
      *ngFor="let row of data"
      [row]="row"
      [visibleDate]="visibleDate"
      [selectedValue]="selectedValue"
      [component]="cellComponent"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [size]="size"
      (select)="select.emit($event)">
    </nb-calendar-picker-row>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: {
		data: [{ type: Input }],
		visibleDate: [{ type: Input }],
		selectedValue: [{ type: Input }],
		cellComponent: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarYearPickerComponent = class NbCalendarYearPickerComponent {
	set _cellComponent(cellComponent) {
		if (cellComponent) this.cellComponent = cellComponent;
	}
	get large() {
		return this.size === NbCalendarSize.LARGE;
	}
	constructor(dateService, yearModelService) {
		this.dateService = dateService;
		this.yearModelService = yearModelService;
		this.cellComponent = NbCalendarYearCellComponent;
		this.size = NbCalendarSize.MEDIUM;
		this.yearChange = new EventEmitter();
	}
	ngOnChanges() {
		this.years = this.yearModelService.getViewYears(this.year);
	}
	onSelect(year) {
		this.yearChange.emit(year);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarYearPickerComponent,
			deps: [{ token: NbDateService }, { token: NbCalendarYearModelService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarYearPickerComponent,
			isStandalone: false,
			selector: "nb-calendar-year-picker",
			inputs: {
				date: "date",
				min: "min",
				max: "max",
				filter: "filter",
				_cellComponent: ["cellComponent", "_cellComponent"],
				size: "size",
				year: "year"
			},
			outputs: { yearChange: "yearChange" },
			host: { properties: { "class.size-large": "this.large" } },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <nb-calendar-picker
      [data]="years"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [selectedValue]="date"
      [visibleDate]="year"
      [cellComponent]="cellComponent"
      [size]="size"
      (select)="onSelect($event)">
    </nb-calendar-picker>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbCalendarPickerComponent,
				selector: "nb-calendar-picker",
				inputs: [
					"data",
					"visibleDate",
					"selectedValue",
					"cellComponent",
					"min",
					"max",
					"filter",
					"size"
				],
				outputs: ["select"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarYearPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-year-picker",
			template: `
    <nb-calendar-picker
      [data]="years"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [selectedValue]="date"
      [visibleDate]="year"
      [cellComponent]="cellComponent"
      [size]="size"
      (select)="onSelect($event)">
    </nb-calendar-picker>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }, { type: NbCalendarYearModelService }],
	propDecorators: {
		date: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		_cellComponent: [{
			type: Input,
			args: ["cellComponent"]
		}],
		size: [{ type: Input }],
		year: [{ type: Input }],
		yearChange: [{ type: Output }],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarMonthCellComponent = class NbCalendarMonthCellComponent {
	constructor(dateService) {
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.monthCellClass = true;
	}
	get selected() {
		return this.dateService.isSameMonthSafe(this.date, this.selectedValue);
	}
	get today() {
		return this.dateService.isSameMonthSafe(this.date, this.dateService.today());
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	get month() {
		return this.dateService.getMonthName(this.date);
	}
	onClick() {
		if (this.disabled) return;
		this.select.emit(this.date);
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.monthEnd(), this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.monthStart(), this.max) > 0;
	}
	monthStart() {
		return this.dateService.getMonthStart(this.date);
	}
	monthEnd() {
		return this.dateService.getMonthEnd(this.date);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarMonthCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarMonthCellComponent,
			isStandalone: false,
			selector: "nb-calendar-month-cell",
			inputs: {
				date: "date",
				selectedValue: "selectedValue",
				min: "min",
				max: "max",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.selected": "this.selected",
					"class.today": "this.today",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge",
					"class.month-cell": "this.monthCellClass"
				}
			},
			ngImport: i0,
			template: `
    <div class="cell-content">
      {{ month }}
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarMonthCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-month-cell",
			template: `
    <div class="cell-content">
      {{ month }}
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		selectedValue: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		monthCellClass: [{
			type: HostBinding,
			args: ["class.month-cell"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const MONTHS_IN_VIEW = 12;
const MONTHS_IN_COLUMN = 4;
var NbCalendarMonthPickerComponent = class NbCalendarMonthPickerComponent {
	constructor(dateService) {
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.monthChange = new EventEmitter();
		this.cellComponent = NbCalendarMonthCellComponent;
	}
	set _cellComponent(cellComponent) {
		if (cellComponent) this.cellComponent = cellComponent;
	}
	get large() {
		return this.size === NbCalendarSize.LARGE;
	}
	ngOnChanges(changes) {
		if (changes.month) this.initMonths();
	}
	initMonths() {
		const date = this.dateService.getDate(this.month);
		const year = this.dateService.getYear(this.month);
		const firstMonth = this.dateService.createDate(year, 0, date);
		const months = [firstMonth];
		for (let monthIndex = 1; monthIndex < 12; monthIndex++) months.push(this.dateService.addMonth(firstMonth, monthIndex));
		this.months = batch(months, 4);
	}
	onSelect(month) {
		this.monthChange.emit(month);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarMonthPickerComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarMonthPickerComponent,
			isStandalone: false,
			selector: "nb-calendar-month-picker",
			inputs: {
				min: "min",
				max: "max",
				filter: "filter",
				size: "size",
				month: "month",
				date: "date",
				_cellComponent: ["cellComponent", "_cellComponent"]
			},
			outputs: { monthChange: "monthChange" },
			host: { properties: { "class.size-large": "this.large" } },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <nb-calendar-picker
      [data]="months"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [selectedValue]="date"
      [visibleDate]="month"
      [cellComponent]="cellComponent"
      [size]="size"
      (select)="onSelect($event)">
    </nb-calendar-picker>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbCalendarPickerComponent,
				selector: "nb-calendar-picker",
				inputs: [
					"data",
					"visibleDate",
					"selectedValue",
					"cellComponent",
					"min",
					"max",
					"filter",
					"size"
				],
				outputs: ["select"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarMonthPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-month-picker",
			template: `
    <nb-calendar-picker
      [data]="months"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [selectedValue]="date"
      [visibleDate]="month"
      [cellComponent]="cellComponent"
      [size]="size"
      (select)="onSelect($event)">
    </nb-calendar-picker>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		size: [{ type: Input }],
		month: [{ type: Input }],
		date: [{ type: Input }],
		monthChange: [{ type: Output }],
		_cellComponent: [{
			type: Input,
			args: ["cellComponent"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarDayCellComponent = class NbCalendarDayCellComponent {
	constructor(dateService) {
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.dayCellClass = true;
	}
	get today() {
		return this.dateService.isSameDaySafe(this.date, this.dateService.today());
	}
	get boundingMonth() {
		return !this.dateService.isSameMonthSafe(this.date, this.visibleDate);
	}
	get selected() {
		return this.dateService.isSameDaySafe(this.date, this.selectedValue);
	}
	get empty() {
		return !this.date;
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax() || this.dontFitFilter();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	get day() {
		return this.date && this.dateService.getDate(this.date);
	}
	onClick() {
		if (this.disabled || this.empty) return;
		this.select.emit(this.date);
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.date, this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.date, this.max) > 0;
	}
	dontFitFilter() {
		return this.date && this.filter && !this.filter(this.date);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarDayCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarDayCellComponent,
			isStandalone: false,
			selector: "nb-calendar-day-cell",
			inputs: {
				date: "date",
				selectedValue: "selectedValue",
				visibleDate: "visibleDate",
				min: "min",
				max: "max",
				filter: "filter",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.today": "this.today",
					"class.bounding-month": "this.boundingMonth",
					"class.selected": "this.selected",
					"class.empty": "this.empty",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge",
					"class.day-cell": "this.dayCellClass"
				}
			},
			ngImport: i0,
			template: `
    <div class="cell-content">
      {{ day }}
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarDayCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-day-cell",
			template: `
    <div class="cell-content">
      {{ day }}
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		selectedValue: [{ type: Input }],
		visibleDate: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		boundingMonth: [{
			type: HostBinding,
			args: ["class.bounding-month"]
		}],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		empty: [{
			type: HostBinding,
			args: ["class.empty"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		dayCellClass: [{
			type: HostBinding,
			args: ["class.day-cell"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarMonthModelService = class NbCalendarMonthModelService {
	constructor(dateService) {
		this.dateService = dateService;
	}
	createDaysGrid(activeMonth, boundingMonth = true, firstDayOfWeek) {
		const weeks = this.createDates(activeMonth, firstDayOfWeek);
		return this.withBoundingMonths(weeks, activeMonth, boundingMonth);
	}
	createDates(activeMonth, firstDayOfWeek) {
		const days = this.createDateRangeForMonth(activeMonth);
		const startOfWeekDayDiff = this.getStartOfWeekDayDiff(activeMonth, firstDayOfWeek);
		return batch(days, this.dateService.DAYS_IN_WEEK, startOfWeekDayDiff);
	}
	withBoundingMonths(weeks, activeMonth, boundingMonth) {
		let withBoundingMonths = weeks;
		if (this.isShouldAddPrevBoundingMonth(withBoundingMonths)) withBoundingMonths = this.addPrevBoundingMonth(withBoundingMonths, activeMonth, boundingMonth);
		if (this.isShouldAddNextBoundingMonth(withBoundingMonths)) withBoundingMonths = this.addNextBoundingMonth(withBoundingMonths, activeMonth, boundingMonth);
		return withBoundingMonths;
	}
	addPrevBoundingMonth(weeks, activeMonth, boundingMonth) {
		const firstWeek = weeks.shift();
		const requiredItems = this.dateService.DAYS_IN_WEEK - firstWeek.length;
		firstWeek.unshift(...this.createPrevBoundingDays(activeMonth, boundingMonth, requiredItems));
		return [firstWeek, ...weeks];
	}
	addNextBoundingMonth(weeks, activeMonth, boundingMonth) {
		const lastWeek = weeks.pop();
		const requiredItems = this.dateService.DAYS_IN_WEEK - lastWeek.length;
		lastWeek.push(...this.createNextBoundingDays(activeMonth, boundingMonth, requiredItems));
		return [...weeks, lastWeek];
	}
	createPrevBoundingDays(activeMonth, boundingMonth, requiredItems) {
		const month = this.dateService.addMonth(activeMonth, -1);
		const daysInMonth = this.dateService.getNumberOfDaysInMonth(month);
		return this.createDateRangeForMonth(month).slice(daysInMonth - requiredItems).map((date) => boundingMonth ? date : null);
	}
	createNextBoundingDays(activeMonth, boundingMonth, requiredItems) {
		const month = this.dateService.addMonth(activeMonth, 1);
		return this.createDateRangeForMonth(month).slice(0, requiredItems).map((date) => boundingMonth ? date : null);
	}
	getStartOfWeekDayDiff(date, firstDayOfWeek) {
		const startOfMonth = this.dateService.getMonthStart(date);
		return this.getWeekStartDiff(startOfMonth, firstDayOfWeek);
	}
	getWeekStartDiff(date, firstDayOfWeek) {
		return (7 - (firstDayOfWeek ?? this.dateService.getFirstDayOfWeek()) + this.dateService.getDayOfWeek(date)) % 7;
	}
	isShouldAddPrevBoundingMonth(weeks) {
		return weeks[0].length < this.dateService.DAYS_IN_WEEK;
	}
	isShouldAddNextBoundingMonth(weeks) {
		return weeks[weeks.length - 1].length < this.dateService.DAYS_IN_WEEK;
	}
	createDateRangeForMonth(date) {
		const daysInMonth = this.dateService.getNumberOfDaysInMonth(date);
		return range(daysInMonth, (i) => {
			const year = this.dateService.getYear(date);
			const month = this.dateService.getMonth(date);
			return this.dateService.createDate(year, month, i + 1);
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarMonthModelService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarMonthModelService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarMonthModelService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarDaysNamesComponent = class NbCalendarDaysNamesComponent {
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	constructor(dateService) {
		this.dateService = dateService;
	}
	ngOnInit() {
		const days = this.createDaysNames();
		this.days = this.shiftStartOfWeek(days);
	}
	ngOnChanges({ firstDayOfWeek }) {
		if (firstDayOfWeek) {
			const days = this.createDaysNames();
			this.days = this.shiftStartOfWeek(days);
		}
	}
	createDaysNames() {
		return this.dateService.getDayOfWeekNames().map(this.markIfHoliday);
	}
	shiftStartOfWeek(days) {
		const firstDayOfWeek = this.firstDayOfWeek ?? this.dateService.getFirstDayOfWeek();
		for (let i = 0; i < firstDayOfWeek; i++) days.push(days.shift());
		return days;
	}
	markIfHoliday(name, i) {
		return {
			name,
			isHoliday: i % 6 === 0
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarDaysNamesComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarDaysNamesComponent,
			isStandalone: false,
			selector: "nb-calendar-days-names",
			inputs: {
				size: "size",
				firstDayOfWeek: "firstDayOfWeek"
			},
			host: { properties: { "class.size-large": "this.isLarge" } },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <div class="day" *ngFor="let day of days" [class.holiday]="day.isHoliday">{{ day.name }}</div>
  `,
			isInline: true,
			styles: [":host{display:flex;justify-content:space-between}:host .day{display:flex;align-items:center;justify-content:center}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgForOf,
				selector: "[ngFor][ngForOf]",
				inputs: [
					"ngForOf",
					"ngForTrackBy",
					"ngForTemplate"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarDaysNamesComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-days-names",
			template: `
    <div class="day" *ngFor="let day of days" [class.holiday]="day.isHoliday">{{ day.name }}</div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;justify-content:space-between}:host .day{display:flex;align-items:center;justify-content:center}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		size: [{ type: Input }],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		firstDayOfWeek: [{ type: Input }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarWeekNumberComponent = class NbCalendarWeekNumberComponent {
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	constructor(dateService) {
		this.dateService = dateService;
	}
	ngOnChanges(changes) {
		if (changes.weeks) this.weekNumbers = this.getWeeks();
	}
	getWeeks() {
		return this.weeks.map((week) => {
			const lastDay = [...week].reverse().find((day) => !!day);
			return this.dateService.getWeekNumber(lastDay);
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarWeekNumberComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarWeekNumberComponent,
			isStandalone: false,
			selector: "nb-calendar-week-numbers",
			inputs: {
				weeks: "weeks",
				size: "size",
				weekNumberSymbol: "weekNumberSymbol"
			},
			host: { properties: { "class.size-large": "this.isLarge" } },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <div class="sign-container">
      <div class="sign">{{ weekNumberSymbol }}</div>
    </div>
    <div class="week-number" *ngFor="let weekNumber of weekNumbers">{{ weekNumber }}</div>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgForOf,
				selector: "[ngFor][ngForOf]",
				inputs: [
					"ngForOf",
					"ngForTrackBy",
					"ngForTemplate"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarWeekNumberComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-week-numbers",
			template: `
    <div class="sign-container">
      <div class="sign">{{ weekNumberSymbol }}</div>
    </div>
    <div class="week-number" *ngFor="let weekNumber of weekNumbers">{{ weekNumber }}</div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		weeks: [{ type: Input }],
		size: [{ type: Input }],
		weekNumberSymbol: [{ type: Input }],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarDayPickerComponent = class NbCalendarDayPickerComponent {
	set setCellComponent(cellComponent) {
		if (cellComponent) this.cellComponent = cellComponent;
	}
	get showWeekNumber() {
		return this._showWeekNumber;
	}
	set showWeekNumber(value) {
		this._showWeekNumber = convertToBoolProperty(value);
	}
	get large() {
		return this.size === NbCalendarSize.LARGE;
	}
	constructor(monthModel) {
		this.monthModel = monthModel;
		this.boundingMonths = true;
		this.cellComponent = NbCalendarDayCellComponent;
		this.size = NbCalendarSize.MEDIUM;
		this._showWeekNumber = false;
		this.dateChange = new EventEmitter();
	}
	ngOnChanges({ visibleDate, boundingMonths, firstDayOfWeek }) {
		if (visibleDate || boundingMonths || firstDayOfWeek) this.weeks = this.monthModel.createDaysGrid(this.visibleDate, this.boundingMonths, this.firstDayOfWeek);
	}
	onSelect(day) {
		this.dateChange.emit(day);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarDayPickerComponent,
			deps: [{ token: NbCalendarMonthModelService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarDayPickerComponent,
			isStandalone: false,
			selector: "nb-calendar-day-picker",
			inputs: {
				visibleDate: "visibleDate",
				boundingMonths: "boundingMonths",
				min: "min",
				max: "max",
				filter: "filter",
				setCellComponent: ["cellComponent", "setCellComponent"],
				size: "size",
				date: "date",
				showWeekNumber: "showWeekNumber",
				weekNumberSymbol: "weekNumberSymbol",
				firstDayOfWeek: "firstDayOfWeek"
			},
			outputs: { dateChange: "dateChange" },
			host: { properties: { "class.size-large": "this.large" } },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <nb-calendar-week-numbers *ngIf="showWeekNumber"
                              [weeks]="weeks"
                              [size]="size"
                              [weekNumberSymbol]="weekNumberSymbol">
    </nb-calendar-week-numbers>
    <div class="days-container">
      <nb-calendar-days-names [size]="size" [firstDayOfWeek]="firstDayOfWeek"></nb-calendar-days-names>
      <nb-calendar-picker
          [data]="weeks"
          [visibleDate]="visibleDate"
          [selectedValue]="date"
          [cellComponent]="cellComponent"
          [min]="min"
          [max]="max"
          [filter]="filter"
          [size]="size"
          (select)="onSelect($event)">
      </nb-calendar-picker>
    </div>
  `,
			isInline: true,
			styles: [":host{display:flex}.days-container{width:100%}\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: NbCalendarDaysNamesComponent,
					selector: "nb-calendar-days-names",
					inputs: ["size", "firstDayOfWeek"]
				},
				{
					kind: "component",
					type: NbCalendarPickerComponent,
					selector: "nb-calendar-picker",
					inputs: [
						"data",
						"visibleDate",
						"selectedValue",
						"cellComponent",
						"min",
						"max",
						"filter",
						"size"
					],
					outputs: ["select"]
				},
				{
					kind: "component",
					type: NbCalendarWeekNumberComponent,
					selector: "nb-calendar-week-numbers",
					inputs: [
						"weeks",
						"size",
						"weekNumberSymbol"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarDayPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-day-picker",
			template: `
    <nb-calendar-week-numbers *ngIf="showWeekNumber"
                              [weeks]="weeks"
                              [size]="size"
                              [weekNumberSymbol]="weekNumberSymbol">
    </nb-calendar-week-numbers>
    <div class="days-container">
      <nb-calendar-days-names [size]="size" [firstDayOfWeek]="firstDayOfWeek"></nb-calendar-days-names>
      <nb-calendar-picker
          [data]="weeks"
          [visibleDate]="visibleDate"
          [selectedValue]="date"
          [cellComponent]="cellComponent"
          [min]="min"
          [max]="max"
          [filter]="filter"
          [size]="size"
          (select)="onSelect($event)">
      </nb-calendar-picker>
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex}.days-container{width:100%}\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbCalendarMonthModelService }],
	propDecorators: {
		visibleDate: [{ type: Input }],
		boundingMonths: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		setCellComponent: [{
			type: Input,
			args: ["cellComponent"]
		}],
		size: [{ type: Input }],
		date: [{ type: Input }],
		showWeekNumber: [{ type: Input }],
		weekNumberSymbol: [{ type: Input }],
		firstDayOfWeek: [{ type: Input }],
		dateChange: [{ type: Output }],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBaseCalendarComponent = class NbBaseCalendarComponent {
	get showWeekNumber() {
		return this._showWeekNumber;
	}
	set showWeekNumber(value) {
		this._showWeekNumber = convertToBoolProperty(value);
	}
	constructor(dateService, yearModelService) {
		this.dateService = dateService;
		this.yearModelService = yearModelService;
		this.boundingMonth = true;
		this.activeViewMode = NbCalendarViewMode.DATE;
		this.size = NbCalendarSize.MEDIUM;
		this.showNavigation = true;
		this._showWeekNumber = false;
		this.dateChange = new EventEmitter();
		this.ViewMode = NbCalendarViewMode;
	}
	ngOnInit() {
		if (!this.visibleDate) this.visibleDate = this.dateService.today();
	}
	get large() {
		return this.size === NbCalendarSize.LARGE;
	}
	setViewMode(viewMode) {
		this.activeViewMode = viewMode;
	}
	setVisibleDate(visibleDate) {
		this.visibleDate = visibleDate;
	}
	prevMonth() {
		this.changeVisibleMonth(-1);
	}
	nextMonth() {
		this.changeVisibleMonth(1);
	}
	prevYear() {
		this.changeVisibleYear(-1);
	}
	nextYear() {
		this.changeVisibleYear(1);
	}
	prevYears() {
		this.changeVisibleYears(-1);
	}
	nextYears() {
		this.changeVisibleYears(1);
	}
	navigatePrev() {
		switch (this.activeViewMode) {
			case NbCalendarViewMode.DATE: return this.prevMonth();
			case NbCalendarViewMode.MONTH: return this.prevYear();
			case NbCalendarViewMode.YEAR: return this.prevYears();
		}
	}
	navigateNext() {
		switch (this.activeViewMode) {
			case NbCalendarViewMode.DATE: return this.nextMonth();
			case NbCalendarViewMode.MONTH: return this.nextYear();
			case NbCalendarViewMode.YEAR: return this.nextYears();
		}
	}
	onChangeViewMode() {
		if (this.activeViewMode === NbCalendarViewMode.DATE) return this.setViewMode(NbCalendarViewMode.YEAR);
		this.setViewMode(NbCalendarViewMode.DATE);
	}
	changeVisibleMonth(direction) {
		this.visibleDate = this.dateService.addMonth(this.visibleDate, direction);
	}
	changeVisibleYear(direction) {
		this.visibleDate = this.dateService.addYear(this.visibleDate, direction);
	}
	changeVisibleYears(direction) {
		this.visibleDate = this.dateService.addYear(this.visibleDate, direction * this.yearModelService.getYearsInView());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBaseCalendarComponent,
			deps: [{ token: NbDateService }, { token: NbCalendarYearModelService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbBaseCalendarComponent,
			isStandalone: false,
			selector: "nb-base-calendar",
			inputs: {
				boundingMonth: "boundingMonth",
				activeViewMode: ["startView", "activeViewMode"],
				min: "min",
				max: "max",
				filter: "filter",
				dayCellComponent: "dayCellComponent",
				monthCellComponent: "monthCellComponent",
				yearCellComponent: "yearCellComponent",
				size: "size",
				visibleDate: "visibleDate",
				showNavigation: "showNavigation",
				date: "date",
				showWeekNumber: "showWeekNumber",
				weekNumberSymbol: "weekNumberSymbol",
				firstDayOfWeek: "firstDayOfWeek"
			},
			outputs: { dateChange: "dateChange" },
			host: { properties: {
				"class.has-navigation": "this.showNavigation",
				"class.has-week-number": "this.showWeekNumber",
				"class.size-large": "this.large"
			} },
			ngImport: i0,
			template: "<nb-card>\n  <nb-card-header *ngIf=\"showNavigation\" class=\"calendar-navigation\">\n    <nb-calendar-view-mode [date]=\"visibleDate\"\n                           [viewMode]=\"activeViewMode\"\n                           (changeMode)=\"onChangeViewMode()\">\n    </nb-calendar-view-mode>\n\n    <nb-calendar-pageable-navigation (prev)=\"navigatePrev()\" (next)=\"navigateNext()\">\n    </nb-calendar-pageable-navigation>\n  </nb-card-header>\n\n  <nb-card-body [ngSwitch]=\"activeViewMode\">\n\n    <nb-calendar-day-picker *ngSwitchCase=\"ViewMode.DATE\"\n                            [boundingMonths]=\"boundingMonth\"\n                            [cellComponent]=\"dayCellComponent\"\n                            [min]=\"min\"\n                            [max]=\"max\"\n                            [filter]=\"filter\"\n                            [visibleDate]=\"visibleDate\"\n                            [size]=\"size\"\n                            [date]=\"date\"\n                            [showWeekNumber]=\"showWeekNumber\"\n                            [firstDayOfWeek]=\"firstDayOfWeek\"\n                            (dateChange)=\"dateChange.emit($any($event))\"\n                            [weekNumberSymbol]=\"weekNumberSymbol\">\n    </nb-calendar-day-picker>\n\n    <nb-calendar-year-picker *ngSwitchCase=\"ViewMode.YEAR\"\n                             [cellComponent]=\"yearCellComponent\"\n                             [date]=\"$any(date)\"\n                             [min]=\"min\"\n                             [max]=\"max\"\n                             [filter]=\"filter\"\n                             [size]=\"size\"\n                             [year]=\"visibleDate\"\n                             (yearChange)=\"setVisibleDate($event); setViewMode(ViewMode.MONTH)\">\n    </nb-calendar-year-picker>\n\n    <nb-calendar-month-picker *ngSwitchCase=\"ViewMode.MONTH\"\n                              [cellComponent]=\"monthCellComponent\"\n                              [min]=\"min\"\n                              [max]=\"max\"\n                              [filter]=\"filter\"\n                              [size]=\"size\"\n                              [month]=\"visibleDate\"\n                              [date]=\"$any(date)\"\n                              (monthChange)=\"setVisibleDate($event); setViewMode(ViewMode.DATE)\">\n    </nb-calendar-month-picker>\n\n  </nb-card-body>\n\n</nb-card>\n",
			dependencies: [
				{
					kind: "component",
					type: NbCalendarViewModeComponent,
					selector: "nb-calendar-view-mode",
					inputs: ["date", "viewMode"],
					outputs: ["changeMode"]
				},
				{
					kind: "component",
					type: NbCalendarPageableNavigationComponent,
					selector: "nb-calendar-pageable-navigation",
					outputs: ["next", "prev"]
				},
				{
					kind: "component",
					type: NbCalendarYearPickerComponent,
					selector: "nb-calendar-year-picker",
					inputs: [
						"date",
						"min",
						"max",
						"filter",
						"cellComponent",
						"size",
						"year"
					],
					outputs: ["yearChange"]
				},
				{
					kind: "component",
					type: NbCalendarMonthPickerComponent,
					selector: "nb-calendar-month-picker",
					inputs: [
						"min",
						"max",
						"filter",
						"size",
						"month",
						"date",
						"cellComponent"
					],
					outputs: ["monthChange"]
				},
				{
					kind: "component",
					type: NbCalendarDayPickerComponent,
					selector: "nb-calendar-day-picker",
					inputs: [
						"visibleDate",
						"boundingMonths",
						"min",
						"max",
						"filter",
						"cellComponent",
						"size",
						"date",
						"showWeekNumber",
						"weekNumberSymbol",
						"firstDayOfWeek"
					],
					outputs: ["dateChange"]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgSwitch,
					selector: "[ngSwitch]",
					inputs: ["ngSwitch"]
				},
				{
					kind: "directive",
					type: i2.NgSwitchCase,
					selector: "[ngSwitchCase]",
					inputs: ["ngSwitchCase"]
				},
				{
					kind: "component",
					type: NbCardComponent,
					selector: "nb-card",
					inputs: [
						"size",
						"status",
						"accent"
					]
				},
				{
					kind: "component",
					type: NbCardBodyComponent,
					selector: "nb-card-body"
				},
				{
					kind: "component",
					type: NbCardHeaderComponent,
					selector: "nb-card-header"
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBaseCalendarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-base-calendar",
			standalone: false,
			template: "<nb-card>\n  <nb-card-header *ngIf=\"showNavigation\" class=\"calendar-navigation\">\n    <nb-calendar-view-mode [date]=\"visibleDate\"\n                           [viewMode]=\"activeViewMode\"\n                           (changeMode)=\"onChangeViewMode()\">\n    </nb-calendar-view-mode>\n\n    <nb-calendar-pageable-navigation (prev)=\"navigatePrev()\" (next)=\"navigateNext()\">\n    </nb-calendar-pageable-navigation>\n  </nb-card-header>\n\n  <nb-card-body [ngSwitch]=\"activeViewMode\">\n\n    <nb-calendar-day-picker *ngSwitchCase=\"ViewMode.DATE\"\n                            [boundingMonths]=\"boundingMonth\"\n                            [cellComponent]=\"dayCellComponent\"\n                            [min]=\"min\"\n                            [max]=\"max\"\n                            [filter]=\"filter\"\n                            [visibleDate]=\"visibleDate\"\n                            [size]=\"size\"\n                            [date]=\"date\"\n                            [showWeekNumber]=\"showWeekNumber\"\n                            [firstDayOfWeek]=\"firstDayOfWeek\"\n                            (dateChange)=\"dateChange.emit($any($event))\"\n                            [weekNumberSymbol]=\"weekNumberSymbol\">\n    </nb-calendar-day-picker>\n\n    <nb-calendar-year-picker *ngSwitchCase=\"ViewMode.YEAR\"\n                             [cellComponent]=\"yearCellComponent\"\n                             [date]=\"$any(date)\"\n                             [min]=\"min\"\n                             [max]=\"max\"\n                             [filter]=\"filter\"\n                             [size]=\"size\"\n                             [year]=\"visibleDate\"\n                             (yearChange)=\"setVisibleDate($event); setViewMode(ViewMode.MONTH)\">\n    </nb-calendar-year-picker>\n\n    <nb-calendar-month-picker *ngSwitchCase=\"ViewMode.MONTH\"\n                              [cellComponent]=\"monthCellComponent\"\n                              [min]=\"min\"\n                              [max]=\"max\"\n                              [filter]=\"filter\"\n                              [size]=\"size\"\n                              [month]=\"visibleDate\"\n                              [date]=\"$any(date)\"\n                              (monthChange)=\"setVisibleDate($event); setViewMode(ViewMode.DATE)\">\n    </nb-calendar-month-picker>\n\n  </nb-card-body>\n\n</nb-card>\n"
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }, { type: NbCalendarYearModelService }],
	propDecorators: {
		boundingMonth: [{ type: Input }],
		activeViewMode: [{
			type: Input,
			args: ["startView"]
		}],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		dayCellComponent: [{ type: Input }],
		monthCellComponent: [{ type: Input }],
		yearCellComponent: [{ type: Input }],
		size: [{ type: Input }],
		visibleDate: [{ type: Input }],
		showNavigation: [{ type: Input }, {
			type: HostBinding,
			args: ["class.has-navigation"]
		}],
		date: [{ type: Input }],
		showWeekNumber: [{ type: Input }, {
			type: HostBinding,
			args: ["class.has-week-number"]
		}],
		weekNumberSymbol: [{ type: Input }],
		firstDayOfWeek: [{ type: Input }],
		dateChange: [{ type: Output }],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarComponent = class NbCalendarComponent {
	constructor() {
		this.boundingMonth = true;
		this.startView = NbCalendarViewMode.DATE;
		this.size = NbCalendarSize.MEDIUM;
		this.showNavigation = true;
		this._showWeekNumber = false;
		this.weekNumberSymbol = "#";
		this.dateChange = new EventEmitter();
	}
	get showWeekNumber() {
		return this._showWeekNumber;
	}
	set showWeekNumber(value) {
		this._showWeekNumber = convertToBoolProperty(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarComponent,
			isStandalone: false,
			selector: "nb-calendar",
			inputs: {
				boundingMonth: "boundingMonth",
				startView: "startView",
				min: "min",
				max: "max",
				filter: "filter",
				dayCellComponent: "dayCellComponent",
				monthCellComponent: "monthCellComponent",
				yearCellComponent: "yearCellComponent",
				size: "size",
				visibleDate: "visibleDate",
				showNavigation: "showNavigation",
				date: "date",
				showWeekNumber: "showWeekNumber",
				weekNumberSymbol: "weekNumberSymbol",
				firstDayOfWeek: "firstDayOfWeek"
			},
			outputs: { dateChange: "dateChange" },
			ngImport: i0,
			template: `
    <nb-base-calendar
      [boundingMonth]="boundingMonth"
      [startView]="startView"
      [date]="date"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [dayCellComponent]="dayCellComponent"
      [monthCellComponent]="monthCellComponent"
      [yearCellComponent]="yearCellComponent"
      [size]="size"
      [visibleDate]="visibleDate"
      [showNavigation]="showNavigation"
      [showWeekNumber]="showWeekNumber"
      [weekNumberSymbol]="weekNumberSymbol"
      [firstDayOfWeek]="firstDayOfWeek"
      (dateChange)="dateChange.emit($event)"
    ></nb-base-calendar>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbBaseCalendarComponent,
				selector: "nb-base-calendar",
				inputs: [
					"boundingMonth",
					"startView",
					"min",
					"max",
					"filter",
					"dayCellComponent",
					"monthCellComponent",
					"yearCellComponent",
					"size",
					"visibleDate",
					"showNavigation",
					"date",
					"showWeekNumber",
					"weekNumberSymbol",
					"firstDayOfWeek"
				],
				outputs: ["dateChange"]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar",
			template: `
    <nb-base-calendar
      [boundingMonth]="boundingMonth"
      [startView]="startView"
      [date]="date"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [dayCellComponent]="dayCellComponent"
      [monthCellComponent]="monthCellComponent"
      [yearCellComponent]="yearCellComponent"
      [size]="size"
      [visibleDate]="visibleDate"
      [showNavigation]="showNavigation"
      [showWeekNumber]="showWeekNumber"
      [weekNumberSymbol]="weekNumberSymbol"
      [firstDayOfWeek]="firstDayOfWeek"
      (dateChange)="dateChange.emit($event)"
    ></nb-base-calendar>
  `,
			standalone: false
		}]
	}],
	propDecorators: {
		boundingMonth: [{ type: Input }],
		startView: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		dayCellComponent: [{ type: Input }],
		monthCellComponent: [{ type: Input }],
		yearCellComponent: [{ type: Input }],
		size: [{ type: Input }],
		visibleDate: [{ type: Input }],
		showNavigation: [{ type: Input }],
		date: [{ type: Input }],
		showWeekNumber: [{ type: Input }],
		weekNumberSymbol: [{ type: Input }],
		firstDayOfWeek: [{ type: Input }],
		dateChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_BUTTON_COMPONENTS = [NbButtonComponent];
var NbButtonModule = class NbButtonModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonModule,
			declarations: [NbButtonComponent],
			imports: [NbSharedModule],
			exports: [NbButtonComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButtonModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: [...NB_BUTTON_COMPONENTS],
			exports: [...NB_BUTTON_COMPONENTS]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbNativeDateService = class NbNativeDateService extends NbDateService {
	constructor(locale) {
		super();
		this.setLocale(locale);
	}
	setLocale(locale) {
		super.setLocale(locale);
		this.datePipe = new DatePipe(locale);
	}
	setHours(date, hour) {
		const result = this.clone(date);
		result.setHours(hour);
		return result;
	}
	setMinutes(date, minute) {
		const result = this.clone(date);
		result.setMinutes(minute);
		return result;
	}
	setSeconds(date, second) {
		const result = this.clone(date);
		result.setSeconds(second);
		return result;
	}
	setMilliseconds(date, second) {
		const result = this.clone(date);
		result.setMilliseconds(second);
		return result;
	}
	isValidDateString(date, format) {
		return !isNaN(this.parse(date, format).getTime());
	}
	isValidTimeString(date, format) {
		return this.isValidDateString(date, format);
	}
	today() {
		return /* @__PURE__ */ new Date();
	}
	getLocaleTimeFormat() {
		return getLocaleTimeFormat(this.locale, FormatWidth.Short);
	}
	getDate(date) {
		return date.getDate();
	}
	getMonth(date) {
		return date.getMonth();
	}
	getYear(date) {
		return date.getFullYear();
	}
	getDayOfWeek(date) {
		return date.getDay();
	}
	getFirstDayOfWeek() {
		return getLocaleFirstDayOfWeek(this.locale);
	}
	getMonthName(date, style = TranslationWidth.Abbreviated) {
		const index = date.getMonth();
		return this.getMonthNameByIndex(index, style);
	}
	getMonthNameByIndex(index, style = TranslationWidth.Abbreviated) {
		return getLocaleMonthNames(this.locale, FormStyle.Format, style)[index];
	}
	getDayOfWeekNames() {
		return [...getLocaleDayNames(this.locale, FormStyle.Format, TranslationWidth.Short)];
	}
	format(date, format) {
		return this.datePipe.transform(date, format);
	}
	parse(date, format) {
		return new Date(Date.parse(date));
	}
	addDay(date, num) {
		return this.createDate(date.getFullYear(), date.getMonth(), date.getDate() + num);
	}
	addMonth(date, num) {
		const month = this.createDate(date.getFullYear(), date.getMonth() + num, 1);
		month.setDate(Math.min(date.getDate(), this.getMonthEnd(month).getDate()));
		return month;
	}
	addMinutes(date, minute) {
		const result = new Date(date);
		result.setMinutes(date.getMinutes() + minute);
		return result;
	}
	addHours(date, hour) {
		const result = new Date(date);
		result.setHours(date.getHours() + hour);
		return result;
	}
	getHours(date) {
		return date.getHours();
	}
	getMinutes(date) {
		return date.getMinutes();
	}
	getSeconds(date) {
		return date.getSeconds();
	}
	getMilliseconds(date) {
		return date.getMilliseconds();
	}
	addYear(date, num) {
		return this.createDate(date.getFullYear() + num, date.getMonth(), date.getDate());
	}
	clone(date) {
		return new Date(date.getTime());
	}
	compareDates(date1, date2) {
		return date1.getTime() - date2.getTime();
	}
	createDate(year, month, date) {
		const result = new Date(year, month, date);
		if (year >= 0 && year < 100) result.setFullYear(result.getFullYear() - 1900);
		return result;
	}
	getMonthEnd(date) {
		return this.createDate(date.getFullYear(), date.getMonth() + 1, 0);
	}
	getMonthStart(date) {
		return this.createDate(date.getFullYear(), date.getMonth(), 1);
	}
	getNumberOfDaysInMonth(date) {
		return this.getMonthEnd(date).getDate();
	}
	getYearEnd(date) {
		return this.createDate(date.getFullYear(), 11, 31);
	}
	getYearStart(date) {
		return this.createDate(date.getFullYear(), 0, 1);
	}
	valueOf(date) {
		return date.valueOf();
	}
	isSameDay(date1, date2) {
		return this.isSameMonth(date1, date2) && date1.getDate() === date2.getDate();
	}
	isSameMonth(date1, date2) {
		return this.isSameYear(date1, date2) && date1.getMonth() === date2.getMonth();
	}
	isSameYear(date1, date2) {
		return date1.getFullYear() === date2.getFullYear();
	}
	getId() {
		return "native";
	}
	getWeekNumber(date) {
		return parseInt(this.datePipe.transform(date, "w"), 10);
	}
	getDateFormat() {
		return "yyyy-MM-dd";
	}
	getTwelveHoursFormat() {
		return "hh:mm a";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbNativeDateService,
			deps: [{ token: LOCALE_ID }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbNativeDateService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbNativeDateService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LOCALE_ID]
		}]
	}]
});
var NbCalendarTimeModelService = class NbCalendarTimeModelService {
	constructor(dateService) {
		this.dateService = dateService;
		this.MINUTES_AND_SECONDS = 60;
	}
	getHoursRange(step = this.MINUTES_AND_SECONDS) {
		let date = this.getResetTime();
		const endDate = this.dateService.addDay(date, 1);
		const result = [];
		while (this.dateService.compareDates(date, endDate) < 0) {
			result.push(date);
			date = this.dateService.addMinutes(date, step);
		}
		return result;
	}
	getResetTime() {
		let today = this.dateService.today();
		today = this.dateService.setHours(today, 0);
		today = this.dateService.setMinutes(today, 0);
		today = this.dateService.setSeconds(today, 0);
		today = this.dateService.setMilliseconds(today, 0);
		return today;
	}
	paddToTwoSymbols(n) {
		if (n < 10) return "0" + n;
		return n.toString();
	}
	buildDateFormat(twelveHoursFormat, withSeconds = false) {
		if (twelveHoursFormat) return `${this.dateService.getDateFormat()} ${this.dateService.getTwelveHoursFormat()}`;
		if (withSeconds) return `${this.dateService.getDateFormat()} ${this.dateService.getTwentyFourHoursFormatWithSeconds()}`;
		return `${this.dateService.getDateFormat()} ${this.dateService.getTwentyFourHoursFormat()}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarTimeModelService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarTimeModelService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarTimeModelService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
var NbCalendarActionsComponent = class NbCalendarActionsComponent {
	constructor() {
		this._applyButtonText = "ok";
		this._currentTimeButtonText = "now";
		this.setCurrentTime = new EventEmitter();
		this.saveValue = new EventEmitter();
	}
	set applyButtonText(value) {
		if (value) this._applyButtonText = value;
	}
	get applyText() {
		return this._applyButtonText;
	}
	set currentTimeButtonText(value) {
		if (value) this._currentTimeButtonText = value;
	}
	get currentTimeText() {
		return this._currentTimeButtonText;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarActionsComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarActionsComponent,
			isStandalone: false,
			selector: "nb-calendar-actions",
			inputs: {
				applyButtonText: "applyButtonText",
				currentTimeButtonText: "currentTimeButtonText",
				showCurrentTimeButton: "showCurrentTimeButton"
			},
			outputs: {
				setCurrentTime: "setCurrentTime",
				saveValue: "saveValue"
			},
			ngImport: i0,
			template: `
    <button
      *ngIf="showCurrentTimeButton"
      nbButton
      ghost
      status="primary"
      size="small"
      (click)="setCurrentTime.emit()">
      {{ currentTimeText }}</button>
    <button
      class="apply-text-button"
      nbButton
      status="primary"
      size="small"
      (click)="saveValue.emit()">
      {{ applyText }}</button>
  `,
			isInline: true,
			styles: [":host{display:flex;justify-content:space-between}[dir=ltr] :host .apply-text-button{margin-left:auto}[dir=rtl] :host .apply-text-button{margin-right:auto}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbButtonComponent,
				selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
				inputs: ["hero"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarActionsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-actions",
			template: `
    <button
      *ngIf="showCurrentTimeButton"
      nbButton
      ghost
      status="primary"
      size="small"
      (click)="setCurrentTime.emit()">
      {{ currentTimeText }}</button>
    <button
      class="apply-text-button"
      nbButton
      status="primary"
      size="small"
      (click)="saveValue.emit()">
      {{ applyText }}</button>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;justify-content:space-between}[dir=ltr] :host .apply-text-button{margin-left:auto}[dir=rtl] :host .apply-text-button{margin-right:auto}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		applyButtonText: [{ type: Input }],
		currentTimeButtonText: [{ type: Input }],
		showCurrentTimeButton: [{ type: Input }],
		setCurrentTime: [{ type: Output }],
		saveValue: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const SERVICES = [
	{
		provide: NbDateService,
		useClass: NbNativeDateService
	},
	DatePipe,
	NbCalendarMonthModelService,
	NbCalendarYearModelService,
	NbCalendarTimeModelService
];
const COMPONENTS$3 = [
	NbCalendarViewModeComponent,
	NbCalendarPageableNavigationComponent,
	NbCalendarDaysNamesComponent,
	NbCalendarYearPickerComponent,
	NbCalendarMonthPickerComponent,
	NbCalendarDayPickerComponent,
	NbCalendarDayCellComponent,
	NbCalendarActionsComponent,
	NbCalendarMonthCellComponent,
	NbCalendarYearCellComponent,
	NbCalendarPickerRowComponent,
	NbCalendarPickerComponent,
	NbCalendarWeekNumberComponent
];
var NbCalendarKitModule = class NbCalendarKitModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarKitModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarKitModule,
			declarations: [
				NbCalendarViewModeComponent,
				NbCalendarPageableNavigationComponent,
				NbCalendarDaysNamesComponent,
				NbCalendarYearPickerComponent,
				NbCalendarMonthPickerComponent,
				NbCalendarDayPickerComponent,
				NbCalendarDayCellComponent,
				NbCalendarActionsComponent,
				NbCalendarMonthCellComponent,
				NbCalendarYearCellComponent,
				NbCalendarPickerRowComponent,
				NbCalendarPickerComponent,
				NbCalendarWeekNumberComponent
			],
			imports: [
				NbSharedModule,
				NbButtonModule,
				NbIconModule
			],
			exports: [
				NbCalendarViewModeComponent,
				NbCalendarPageableNavigationComponent,
				NbCalendarDaysNamesComponent,
				NbCalendarYearPickerComponent,
				NbCalendarMonthPickerComponent,
				NbCalendarDayPickerComponent,
				NbCalendarDayCellComponent,
				NbCalendarActionsComponent,
				NbCalendarMonthCellComponent,
				NbCalendarYearCellComponent,
				NbCalendarPickerRowComponent,
				NbCalendarPickerComponent,
				NbCalendarWeekNumberComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarKitModule,
			providers: [...SERVICES],
			imports: [
				NbSharedModule,
				NbButtonModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarKitModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbButtonModule,
				NbIconModule
			],
			exports: [...COMPONENTS$3],
			declarations: [...COMPONENTS$3],
			providers: [...SERVICES]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBaseCalendarModule = class NbBaseCalendarModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBaseCalendarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBaseCalendarModule,
			declarations: [NbBaseCalendarComponent],
			imports: [
				NbCalendarKitModule,
				NbSharedModule,
				NbCardModule
			],
			exports: [NbBaseCalendarComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBaseCalendarModule,
			imports: [
				NbCalendarKitModule,
				NbSharedModule,
				NbCardModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBaseCalendarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbCalendarKitModule,
				NbSharedModule,
				NbCardModule
			],
			exports: [NbBaseCalendarComponent],
			declarations: [NbBaseCalendarComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarModule = class NbCalendarModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarModule,
			declarations: [NbCalendarComponent],
			imports: [NbBaseCalendarModule],
			exports: [NbCalendarComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarModule,
			imports: [NbBaseCalendarModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbBaseCalendarModule],
			exports: [NbCalendarComponent],
			declarations: [NbCalendarComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBaseCalendarRangeCell = class {
	get hasRange() {
		return !!(this.selectedValue && this.selectedValue.start && this.selectedValue.end);
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarRangeDayCellComponent = class NbCalendarRangeDayCellComponent extends NbBaseCalendarRangeCell {
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.rangeCellClass = true;
		this.dayCellClass = true;
	}
	get inRange() {
		if (this.date && this.hasRange) return this.isInRange(this.date, this.selectedValue);
		return false;
	}
	get start() {
		return this.date && this.hasRange && this.dateService.isSameDay(this.date, this.selectedValue.start);
	}
	get end() {
		return this.date && this.hasRange && this.dateService.isSameDay(this.date, this.selectedValue.end);
	}
	get today() {
		return this.date && this.dateService.isSameDay(this.date, this.dateService.today());
	}
	get boundingMonth() {
		return !this.dateService.isSameMonthSafe(this.date, this.visibleDate);
	}
	get selected() {
		if (this.inRange) return true;
		if (this.selectedValue) return this.dateService.isSameDaySafe(this.date, this.selectedValue.start);
		return false;
	}
	get empty() {
		return !this.date;
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax() || this.dontFitFilter();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	get day() {
		return this.date && this.dateService.getDate(this.date);
	}
	onClick() {
		if (this.disabled || this.empty) return;
		this.select.emit(this.date);
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.date, this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.date, this.max) > 0;
	}
	dontFitFilter() {
		return this.date && this.filter && !this.filter(this.date);
	}
	isInRange(date, { start, end }) {
		const isGreaterThanStart = this.dateService.compareDates(this.date, start) >= 0;
		const isLessThanEnd = this.dateService.compareDates(this.date, end) <= 0;
		return isGreaterThanStart && isLessThanEnd;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeDayCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarRangeDayCellComponent,
			isStandalone: false,
			selector: "nb-calendar-range-day-cell",
			inputs: {
				date: "date",
				selectedValue: "selectedValue",
				visibleDate: "visibleDate",
				min: "min",
				max: "max",
				filter: "filter",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.in-range": "this.inRange",
					"class.start": "this.start",
					"class.end": "this.end",
					"class.range-cell": "this.rangeCellClass",
					"class.day-cell": "this.dayCellClass",
					"class.today": "this.today",
					"class.bounding-month": "this.boundingMonth",
					"class.selected": "this.selected",
					"class.empty": "this.empty",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge"
				}
			},
			usesInheritance: true,
			ngImport: i0,
			template: `
    <div class="cell-content">{{ day }}</div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarRangeDayCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-range-day-cell",
			template: `
    <div class="cell-content">{{ day }}</div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		selectedValue: [{ type: Input }],
		visibleDate: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		inRange: [{
			type: HostBinding,
			args: ["class.in-range"]
		}],
		start: [{
			type: HostBinding,
			args: ["class.start"]
		}],
		end: [{
			type: HostBinding,
			args: ["class.end"]
		}],
		rangeCellClass: [{
			type: HostBinding,
			args: ["class.range-cell"]
		}],
		dayCellClass: [{
			type: HostBinding,
			args: ["class.day-cell"]
		}],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		boundingMonth: [{
			type: HostBinding,
			args: ["class.bounding-month"]
		}],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		empty: [{
			type: HostBinding,
			args: ["class.empty"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarRangeYearCellComponent = class NbCalendarRangeYearCellComponent extends NbBaseCalendarRangeCell {
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.yearCellClass = true;
		this.rangeCellClass = true;
	}
	get inRange() {
		return this.hasRange && this.isInRange(this.date, this.selectedValue);
	}
	get rangeStart() {
		return this.hasRange && this.dateService.isSameYear(this.date, this.selectedValue.start);
	}
	get rangeEnd() {
		return this.hasRange && this.dateService.isSameYear(this.date, this.selectedValue.end);
	}
	get selected() {
		if (this.inRange) return true;
		if (this.selectedValue) return this.dateService.isSameYearSafe(this.date, this.selectedValue.start);
		return false;
	}
	get today() {
		return this.dateService.isSameYear(this.date, this.dateService.today());
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	get year() {
		return this.dateService.getYear(this.date);
	}
	onClick() {
		if (this.disabled) return;
		this.select.emit(this.date);
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.yearEnd(), this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.yearStart(), this.max) > 0;
	}
	yearStart() {
		return this.dateService.getYearStart(this.date);
	}
	yearEnd() {
		return this.dateService.getYearEnd(this.date);
	}
	isInRange(date, { start, end }) {
		if (start && end) {
			const cellYear = this.dateService.getYear(date);
			const startYear = this.dateService.getYear(start);
			const endYear = this.dateService.getYear(end);
			return cellYear >= startYear && cellYear <= endYear;
		}
		return this.dateService.isSameYear(date, start);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeYearCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarRangeYearCellComponent,
			isStandalone: false,
			selector: "nb-calendar-range-year-cell",
			inputs: {
				date: "date",
				min: "min",
				max: "max",
				selectedValue: "selectedValue",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.in-range": "this.inRange",
					"class.start": "this.rangeStart",
					"class.end": "this.rangeEnd",
					"class.selected": "this.selected",
					"class.today": "this.today",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge",
					"class.year-cell": "this.yearCellClass",
					"class.range-cell": "this.rangeCellClass"
				}
			},
			usesInheritance: true,
			ngImport: i0,
			template: `
    <div class="cell-content">
      {{ year }}
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarRangeYearCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-range-year-cell",
			template: `
    <div class="cell-content">
      {{ year }}
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		selectedValue: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		inRange: [{
			type: HostBinding,
			args: ["class.in-range"]
		}],
		rangeStart: [{
			type: HostBinding,
			args: ["class.start"]
		}],
		rangeEnd: [{
			type: HostBinding,
			args: ["class.end"]
		}],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		yearCellClass: [{
			type: HostBinding,
			args: ["class.year-cell"]
		}],
		rangeCellClass: [{
			type: HostBinding,
			args: ["class.range-cell"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarRangeMonthCellComponent = class NbCalendarRangeMonthCellComponent extends NbBaseCalendarRangeCell {
	get month() {
		return this.dateService.getMonthName(this.date);
	}
	get selected() {
		if (this.inRange) return true;
		if (this.selectedValue) return this.dateService.isSameMonthSafe(this.date, this.selectedValue.start);
		return false;
	}
	get inRange() {
		if (this.hasRange) return this.isInRage(this.date, this.selectedValue);
		return false;
	}
	get rangeStart() {
		if (this.hasRange) return this.dateService.isSameMonth(this.date, this.selectedValue.start);
		return false;
	}
	get rangeEnd() {
		if (this.hasRange) return this.dateService.isSameMonth(this.date, this.selectedValue.end);
		return false;
	}
	get today() {
		return this.dateService.isSameMonthSafe(this.date, this.dateService.today());
	}
	get disabled() {
		return this.smallerThanMin() || this.greaterThanMax();
	}
	get isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	onClick() {
		if (this.disabled) return;
		this.select.emit(this.date);
	}
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.size = NbCalendarSize.MEDIUM;
		this.select = new EventEmitter(true);
		this.monthCellClass = true;
		this.rangeCellClass = true;
	}
	smallerThanMin() {
		return this.date && this.min && this.dateService.compareDates(this.monthEnd(), this.min) < 0;
	}
	greaterThanMax() {
		return this.date && this.max && this.dateService.compareDates(this.monthStart(), this.max) > 0;
	}
	monthStart() {
		return this.dateService.getMonthStart(this.date);
	}
	monthEnd() {
		return this.dateService.getMonthEnd(this.date);
	}
	isInRage(date, range) {
		if (range.start && range.end) {
			const cellDate = this.dateService.getMonthStart(date);
			const start = this.dateService.getMonthStart(range.start);
			const end = this.dateService.getMonthStart(range.end);
			const isGreaterThanStart = this.dateService.compareDates(cellDate, start) >= 0;
			const isLessThanEnd = this.dateService.compareDates(cellDate, end) <= 0;
			return isGreaterThanStart && isLessThanEnd;
		}
		return this.dateService.isSameMonth(date, range.start);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeMonthCellComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarRangeMonthCellComponent,
			isStandalone: false,
			selector: "nb-calendar-range-month-cell",
			inputs: {
				date: "date",
				visibleDate: "visibleDate",
				selectedValue: "selectedValue",
				min: "min",
				max: "max",
				size: "size"
			},
			outputs: { select: "select" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.month-cell": "this.monthCellClass",
					"class.range-cell": "this.rangeCellClass",
					"class.selected": "this.selected",
					"class.in-range": "this.inRange",
					"class.start": "this.rangeStart",
					"class.end": "this.rangeEnd",
					"class.today": "this.today",
					"class.disabled": "this.disabled",
					"class.size-large": "this.isLarge"
				}
			},
			usesInheritance: true,
			ngImport: i0,
			template: `
    <div class="cell-content">
      {{ month }}
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarRangeMonthCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-range-month-cell",
			template: `
    <div class="cell-content">
      {{ month }}
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		date: [{ type: Input }],
		visibleDate: [{ type: Input }],
		selectedValue: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		size: [{ type: Input }],
		select: [{ type: Output }],
		monthCellClass: [{
			type: HostBinding,
			args: ["class.month-cell"]
		}],
		rangeCellClass: [{
			type: HostBinding,
			args: ["class.range-cell"]
		}],
		selected: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		inRange: [{
			type: HostBinding,
			args: ["class.in-range"]
		}],
		rangeStart: [{
			type: HostBinding,
			args: ["class.start"]
		}],
		rangeEnd: [{
			type: HostBinding,
			args: ["class.end"]
		}],
		today: [{
			type: HostBinding,
			args: ["class.today"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["class.disabled"]
		}],
		isLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarRangeComponent = class NbCalendarRangeComponent {
	set _cellComponent(cellComponent) {
		if (cellComponent) this.dayCellComponent = cellComponent;
	}
	set _monthCellComponent(cellComponent) {
		if (cellComponent) this.monthCellComponent = cellComponent;
	}
	set _yearCellComponent(cellComponent) {
		if (cellComponent) this.yearCellComponent = cellComponent;
	}
	get showWeekNumber() {
		return this._showWeekNumber;
	}
	set showWeekNumber(value) {
		this._showWeekNumber = convertToBoolProperty(value);
	}
	constructor(dateService) {
		this.dateService = dateService;
		this.boundingMonth = true;
		this.startView = NbCalendarViewMode.DATE;
		this.dayCellComponent = NbCalendarRangeDayCellComponent;
		this.monthCellComponent = NbCalendarRangeMonthCellComponent;
		this.yearCellComponent = NbCalendarRangeYearCellComponent;
		this.size = NbCalendarSize.MEDIUM;
		this.showNavigation = true;
		this._showWeekNumber = false;
		this.weekNumberSymbol = "#";
		this.rangeChange = new EventEmitter();
	}
	onChange(date) {
		this.initDateIfNull();
		this.handleSelected(date);
	}
	initDateIfNull() {
		if (!this.range) this.range = {
			start: null,
			end: null
		};
	}
	handleSelected(date) {
		if (this.selectionStarted()) this.selectEnd(date);
		else this.selectStart(date);
	}
	selectionStarted() {
		const { start, end } = this.range;
		return start && !end;
	}
	selectStart(start) {
		this.selectRange({ start });
	}
	selectEnd(date) {
		const { start } = this.range;
		if (this.dateService.compareDates(date, start) > 0) this.selectRange({
			start,
			end: date
		});
		else this.selectRange({
			start: date,
			end: start
		});
	}
	selectRange(range) {
		this.range = range;
		this.rangeChange.emit(range);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeComponent,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarRangeComponent,
			isStandalone: false,
			selector: "nb-calendar-range",
			inputs: {
				boundingMonth: "boundingMonth",
				startView: "startView",
				min: "min",
				max: "max",
				filter: "filter",
				_cellComponent: ["dayCellComponent", "_cellComponent"],
				_monthCellComponent: ["monthCellComponent", "_monthCellComponent"],
				_yearCellComponent: ["yearCellComponent", "_yearCellComponent"],
				size: "size",
				visibleDate: "visibleDate",
				showNavigation: "showNavigation",
				range: "range",
				showWeekNumber: "showWeekNumber",
				weekNumberSymbol: "weekNumberSymbol",
				firstDayOfWeek: "firstDayOfWeek"
			},
			outputs: { rangeChange: "rangeChange" },
			ngImport: i0,
			template: `
    <nb-base-calendar
      [date]="range"
      (dateChange)="onChange($any($event))"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [startView]="startView"
      [boundingMonth]="boundingMonth"
      [dayCellComponent]="dayCellComponent"
      [monthCellComponent]="monthCellComponent"
      [yearCellComponent]="yearCellComponent"
      [visibleDate]="visibleDate"
      [showNavigation]="showNavigation"
      [size]="size"
      [showWeekNumber]="showWeekNumber"
      [weekNumberSymbol]="weekNumberSymbol"
      [firstDayOfWeek]="firstDayOfWeek"
    ></nb-base-calendar>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbBaseCalendarComponent,
				selector: "nb-base-calendar",
				inputs: [
					"boundingMonth",
					"startView",
					"min",
					"max",
					"filter",
					"dayCellComponent",
					"monthCellComponent",
					"yearCellComponent",
					"size",
					"visibleDate",
					"showNavigation",
					"date",
					"showWeekNumber",
					"weekNumberSymbol",
					"firstDayOfWeek"
				],
				outputs: ["dateChange"]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarRangeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-range",
			template: `
    <nb-base-calendar
      [date]="range"
      (dateChange)="onChange($any($event))"
      [min]="min"
      [max]="max"
      [filter]="filter"
      [startView]="startView"
      [boundingMonth]="boundingMonth"
      [dayCellComponent]="dayCellComponent"
      [monthCellComponent]="monthCellComponent"
      [yearCellComponent]="yearCellComponent"
      [visibleDate]="visibleDate"
      [showNavigation]="showNavigation"
      [size]="size"
      [showWeekNumber]="showWeekNumber"
      [weekNumberSymbol]="weekNumberSymbol"
      [firstDayOfWeek]="firstDayOfWeek"
    ></nb-base-calendar>
  `,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbDateService }],
	propDecorators: {
		boundingMonth: [{ type: Input }],
		startView: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		_cellComponent: [{
			type: Input,
			args: ["dayCellComponent"]
		}],
		_monthCellComponent: [{
			type: Input,
			args: ["monthCellComponent"]
		}],
		_yearCellComponent: [{
			type: Input,
			args: ["yearCellComponent"]
		}],
		size: [{ type: Input }],
		visibleDate: [{ type: Input }],
		showNavigation: [{ type: Input }],
		range: [{ type: Input }],
		showWeekNumber: [{ type: Input }],
		weekNumberSymbol: [{ type: Input }],
		firstDayOfWeek: [{ type: Input }],
		rangeChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCalendarRangeModule = class NbCalendarRangeModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeModule,
			declarations: [
				NbCalendarRangeComponent,
				NbCalendarRangeDayCellComponent,
				NbCalendarRangeYearCellComponent,
				NbCalendarRangeMonthCellComponent
			],
			imports: [NbBaseCalendarModule],
			exports: [NbCalendarRangeComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarRangeModule,
			imports: [NbBaseCalendarModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarRangeModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbBaseCalendarModule],
			exports: [NbCalendarRangeComponent],
			declarations: [
				NbCalendarRangeComponent,
				NbCalendarRangeDayCellComponent,
				NbCalendarRangeYearCellComponent,
				NbCalendarRangeMonthCellComponent
			]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_TIME_PICKER_CONFIG = new InjectionToken("NB_TIME_PICKER_CONFIG");
const NB_DEFAULT_TIMEPICKER_LOCALIZATION_CONFIG = {
	hoursText: "Hr",
	minutesText: "Min",
	secondsText: "Sec",
	ampmText: "Am/Pm"
};
var NbListComponent = class NbListComponent {
	constructor() {
		this.role = "list";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbListComponent,
			isStandalone: false,
			selector: "nb-list",
			inputs: { role: "role" },
			host: { properties: { "attr.role": "this.role" } },
			ngImport: i0,
			template: `<ng-content select="nb-list-item"></ng-content>`,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-list",
			template: `<ng-content select="nb-list-item"></ng-content>`,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}\n"]
		}]
	}],
	propDecorators: { role: [{ type: Input }, {
		type: HostBinding,
		args: ["attr.role"]
	}] }
});
var NbListItemComponent = class NbListItemComponent {
	constructor() {
		this.role = "listitem";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbListItemComponent,
			isStandalone: false,
			selector: "nb-list-item",
			inputs: { role: "role" },
			host: { properties: { "attr.role": "this.role" } },
			ngImport: i0,
			template: `<ng-content></ng-content>`,
			isInline: true,
			styles: [":host{display:flex;align-items:center;flex-shrink:0}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbListItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-list-item",
			template: `<ng-content></ng-content>`,
			standalone: false,
			styles: [":host{display:flex;align-items:center;flex-shrink:0}\n"]
		}]
	}],
	propDecorators: { role: [{ type: Input }, {
		type: HostBinding,
		args: ["attr.role"]
	}] }
});
var NbTimePickerCellComponent = class NbTimePickerCellComponent {
	set selected(selected) {
		if (selected) {
			this._selected = selected;
			this.scrollToElement();
		}
		this.selectedChange$.next(selected);
	}
	get selected() {
		return this._selected;
	}
	constructor(ngZone, platformService) {
		this.ngZone = ngZone;
		this.platformService = platformService;
		this.selectedChange$ = new Subject();
		this.unselected$ = this.selectedChange$.pipe(filter((selected) => !selected));
		this.destroy$ = new Subject();
		this.select = new EventEmitter();
	}
	onClick() {
		this.select.emit({ value: this.value });
	}
	ngAfterViewInit() {
		if (this.selected) this.ngZone.onStable.pipe(take(1), takeUntil(merge(this.unselected$, this.destroy$))).subscribe(() => this.scrollToElement());
	}
	scrollToElement() {
		if (this.valueContainerElement && this.platformService.isBrowser) this.ngZone.runOutsideAngular(() => this.valueContainerElement.nativeElement.scrollIntoView({ block: "center" }));
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimePickerCellComponent,
			deps: [{ token: i0.NgZone }, { token: NbPlatform }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTimePickerCellComponent,
			isStandalone: false,
			selector: "nb-timepicker-cell",
			inputs: {
				selected: "selected",
				value: "value"
			},
			outputs: { select: "select" },
			host: { listeners: { "click": "onClick()" } },
			viewQueries: [{
				propertyName: "valueContainerElement",
				first: true,
				predicate: ["valueContainer"],
				descendants: true
			}],
			ngImport: i0,
			template: `
    <div #valueContainer>{{ value }}</div>
  `,
			isInline: true,
			styles: [":host{width:100%;height:100%;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTimePickerCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-timepicker-cell",
			template: `
    <div #valueContainer>{{ value }}</div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{width:100%;height:100%;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: i0.NgZone }, { type: NbPlatform }],
	propDecorators: {
		selected: [{ type: Input }],
		value: [{ type: Input }],
		select: [{ type: Output }],
		valueContainerElement: [{
			type: ViewChild,
			args: ["valueContainer"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
var NbTimePickerComponent = class NbTimePickerComponent {
	get blur() {
		return this.blur$.asObservable();
	}
	get timeFormat() {
		return this._timeFormat;
	}
	set timeFormat(timeFormat) {
		this._timeFormat = timeFormat;
	}
	get twelveHoursFormat() {
		return this._twelveHoursFormat;
	}
	set twelveHoursFormat(value) {
		this._twelveHoursFormat = convertToBoolProperty(value);
	}
	get showAmPmLabel() {
		return this._showAmPmLabel;
	}
	set showAmPmLabel(value) {
		this._showAmPmLabel = convertToBoolProperty(value);
	}
	get withSeconds() {
		return this._withSeconds;
	}
	set withSeconds(value) {
		this._withSeconds = convertToBoolProperty(value);
	}
	get singleColumn() {
		return this._singleColumn;
	}
	set singleColumn(value) {
		this._singleColumn = convertToBoolProperty(value);
	}
	set step(step) {
		this._step = step;
	}
	get step() {
		return this._step;
	}
	set date(date) {
		this._date = date;
		this.isAM = this.dateService.getDayPeriod(this.date) === "AM";
		this.buildColumnOptions();
		this.cd.markForCheck();
	}
	get date() {
		return this._date;
	}
	constructor(config, platformService, locale, cd, calendarTimeModelService, dateService) {
		this.config = config;
		this.platformService = platformService;
		this.cd = cd;
		this.calendarTimeModelService = calendarTimeModelService;
		this.dateService = dateService;
		this.blur$ = new Subject();
		this.dayPeriodColumnOptions = ["AM", "PM"];
		this.isAM = true;
		this.timepickerFormatChange$ = new Subject();
		this.computedTimeFormat = this.setupTimeFormat();
		this._showAmPmLabel = true;
		this.showFooter = true;
		this.onSelectTime = new EventEmitter();
		this.initFromConfig(this.config);
	}
	ngOnChanges({ step, twelveHoursFormat, withSeconds, singleColumn }) {
		const nextTimeFormat = this.setupTimeFormat();
		if (nextTimeFormat !== this.computedTimeFormat) {
			this.computedTimeFormat = nextTimeFormat;
			this.timepickerFormatChange$.next();
		}
		if (step || twelveHoursFormat || withSeconds || singleColumn || !this.fullTimeOptions) this.buildColumnOptions();
	}
	setHost(hostRef) {
		this.hostRef = hostRef;
	}
	attach(hostRef) {
		this.hostRef = hostRef;
	}
	setCurrentTime() {
		this.date = this.dateService.today();
		this.onSelectTime.emit({
			time: this.date,
			save: true
		});
	}
	setHour(value) {
		this.updateValue(this.dateService.setHours(this.date, value));
	}
	setMinute(value) {
		this.updateValue(this.dateService.setMinutes(this.date, value));
	}
	setSecond(value) {
		this.updateValue(this.dateService.setSeconds(this.date, value));
	}
	selectFullTime(value) {
		this.updateValue(value);
	}
	changeDayPeriod(dayPeriodToSet) {
		if (this.dateService.getDayPeriod(this.date) === dayPeriodToSet) return;
		const increment = (dayPeriodToSet === "AM" ? -1 : 1) * this.dateService.HOURS_IN_DAY_PERIOD;
		this.updateValue(this.dateService.addHours(this.date, increment));
	}
	updateValue(date) {
		this.onSelectTime.emit({ time: date });
	}
	saveValue() {
		this.onSelectTime.emit({
			time: this.date,
			save: true
		});
	}
	trackByTimeValues(index, item) {
		return item.value;
	}
	trackBySingleColumnValue(index, item) {
		return this.dateService.valueOf(item);
	}
	trackByDayPeriod(index, item) {
		return item;
	}
	showSeconds() {
		return this.withSeconds && !this.singleColumn;
	}
	isSelectedHour(val) {
		if (this.date) return this.dateService.getHours(this.date) === val;
		return false;
	}
	isSelectedMinute(val) {
		if (this.date) return this.dateService.getMinutes(this.date) === val;
		return false;
	}
	isSelectedSecond(val) {
		if (this.date) return this.dateService.getSeconds(this.date) === val;
		return false;
	}
	isSelectedDayPeriod(dayPeriod) {
		if (this.date) return dayPeriod === this.dateService.getDayPeriod(this.date);
		return false;
	}
	getFullTimeString(item) {
		return this.dateService.format(item, this.computedTimeFormat).toUpperCase();
	}
	isSelectedFullTimeValue(value) {
		if (this.date) return this.dateService.isSameHourAndMinute(value, this.date);
		return false;
	}
	buildColumnOptions() {
		this.fullTimeOptions = this.singleColumn ? this.calendarTimeModelService.getHoursRange(this.step) : [];
		this.hoursColumnOptions = this.generateHours();
		this.minutesColumnOptions = this.generateMinutesOrSeconds();
		this.secondsColumnOptions = this.showSeconds() ? this.generateMinutesOrSeconds() : [];
	}
	isFirefox() {
		return this.platformService.FIREFOX;
	}
	generateHours() {
		if (!this.twelveHoursFormat) return range(24, (v) => {
			return {
				value: v,
				text: this.calendarTimeModelService.paddToTwoSymbols(v)
			};
		});
		if (this.isAM) return range(12, (v) => {
			const text = v === 0 ? 12 : v;
			return {
				value: v,
				text: this.calendarTimeModelService.paddToTwoSymbols(text)
			};
		});
		return rangeFromTo(12, 24, (v) => {
			const text = v === 12 ? 12 : v - 12;
			return {
				value: v,
				text: this.calendarTimeModelService.paddToTwoSymbols(text)
			};
		});
	}
	generateMinutesOrSeconds() {
		return range(60, (v) => {
			return {
				value: v,
				text: this.calendarTimeModelService.paddToTwoSymbols(v)
			};
		});
	}
	setupTimeFormat() {
		if (!this.timeFormat) return this.config.format || this.buildTimeFormat();
		return this.timeFormat;
	}
	buildTimeFormat() {
		if (this.twelveHoursFormat) return `${this.withSeconds && !this.singleColumn ? this.dateService.getTwelveHoursFormatWithSeconds() : this.dateService.getTwelveHoursFormat()}`;
		else return `${this.withSeconds && !this.singleColumn ? this.dateService.getTwentyFourHoursFormatWithSeconds() : this.dateService.getTwentyFourHoursFormat()}`;
	}
	initFromConfig(config) {
		if (config) this.twelveHoursFormat = config.twelveHoursFormat;
		else this.twelveHoursFormat = this.dateService.getLocaleTimeFormat().includes("h");
		const localeConfig = {
			...NB_DEFAULT_TIMEPICKER_LOCALIZATION_CONFIG,
			...config?.localization ?? {}
		};
		this.hoursText = localeConfig.hoursText;
		this.minutesText = localeConfig.minutesText;
		this.secondsText = localeConfig.secondsText;
		this.ampmText = localeConfig.ampmText;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimePickerComponent,
			deps: [
				{ token: NB_TIME_PICKER_CONFIG },
				{ token: NbPlatform },
				{ token: LOCALE_ID },
				{ token: i0.ChangeDetectorRef },
				{ token: NbCalendarTimeModelService },
				{ token: NbDateService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTimePickerComponent,
			isStandalone: false,
			selector: "nb-timepicker",
			inputs: {
				timeFormat: "timeFormat",
				twelveHoursFormat: "twelveHoursFormat",
				showAmPmLabel: "showAmPmLabel",
				withSeconds: "withSeconds",
				singleColumn: "singleColumn",
				step: "step",
				date: "date",
				showFooter: "showFooter",
				applyButtonText: "applyButtonText",
				hoursText: "hoursText",
				minutesText: "minutesText",
				secondsText: "secondsText",
				ampmText: "ampmText",
				currentTimeButtonText: "currentTimeButtonText"
			},
			outputs: { onSelectTime: "onSelectTime" },
			viewQueries: [{
				propertyName: "portal",
				first: true,
				predicate: NbPortalDirective,
				descendants: true,
				static: true
			}],
			exportAs: ["nbTimepicker"],
			usesOnChanges: true,
			ngImport: i0,
			template: "<nb-card *nbPortal [class.supports-scrollbar-theming]=\"!isFirefox()\" class=\"nb-timepicker-container\">\n  <nb-card-header class=\"column-header\">\n    <ng-container *ngIf=\"singleColumn; else fullTimeHeadersBlock\">\n      <div class=\"header-cell\">Time</div>\n    </ng-container>\n    <ng-template #fullTimeHeadersBlock>\n      <div class=\"header-cell\">{{ hoursText }}</div>\n      <div class=\"header-cell\">{{ minutesText }}</div>\n      <div *ngIf=\"withSeconds\" class=\"header-cell\">{{ secondsText }}</div>\n      <div *ngIf=\"twelveHoursFormat\" class=\"header-cell\">\n        <ng-template [ngIf]=\"showAmPmLabel\">{{ ampmText }}</ng-template>\n      </div>\n    </ng-template>\n  </nb-card-header>\n\n  <div class=\"picker-body\">\n    <ng-container *ngIf=\"singleColumn; else fullTimeColumnBlock\">\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedFullTimeValue(item)\"\n          *ngFor=\"let item of fullTimeOptions; trackBy: trackBySingleColumnValue.bind(this)\"\n        >\n          <nb-timepicker-cell\n            [value]=\"getFullTimeString(item)\"\n            [selected]=\"isSelectedFullTimeValue(item)\"\n            (select)=\"selectFullTime(item)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n    </ng-container>\n\n    <ng-template #fullTimeColumnBlock>\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedHour(item.value)\"\n          *ngFor=\"let item of hoursColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedHour(item.value)\"\n            (select)=\"setHour(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedMinute(item.value)\"\n          *ngFor=\"let item of minutesColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedMinute(item.value)\"\n            (select)=\"setMinute(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list *ngIf=\"showSeconds()\" class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedSecond(item.value)\"\n          *ngFor=\"let item of secondsColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedSecond(item.value)\"\n            (select)=\"setSecond(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list *ngIf=\"twelveHoursFormat\" class=\"values-list\">\n        <nb-list-item\n          class=\"list-item am-pm-item\"\n          [class.selected]=\"isSelectedDayPeriod(dayPeriod)\"\n          *ngFor=\"let dayPeriod of dayPeriodColumnOptions; trackBy: trackByDayPeriod\"\n        >\n          <nb-timepicker-cell\n            [value]=\"dayPeriod\"\n            [selected]=\"isSelectedDayPeriod(dayPeriod)\"\n            (select)=\"changeDayPeriod(dayPeriod)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n    </ng-template>\n  </div>\n\n  <nb-card-footer *ngIf=\"showFooter\" class=\"actions-footer\">\n    <nb-calendar-actions\n      [applyButtonText]=\"applyButtonText\"\n      [currentTimeButtonText]=\"currentTimeButtonText\"\n      (setCurrentTime)=\"setCurrentTime()\"\n      (saveValue)=\"saveValue()\"\n    ></nb-calendar-actions>\n  </nb-card-footer>\n</nb-card>\n",
			styles: [".nb-timepicker-container{overflow:hidden;margin-bottom:0}.values-list{width:100%;overflow:hidden}.values-list:hover{overflow-y:auto}.values-list{scroll-snap-type:y proximity}.list-item{border:0;padding:0;cursor:pointer}.picker-body{display:flex;width:100%;flex:1 0 0;overflow:hidden}.column-header{width:100%;display:flex;justify-content:space-between;padding:0}.header-cell{width:100%;display:flex;align-items:center;justify-content:center}.actions-footer{width:100%}nb-card-header,nb-card-footer{flex:0 0 auto}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: NbPortalDirective,
					selector: "[nbPortal]"
				},
				{
					kind: "component",
					type: NbListComponent,
					selector: "nb-list",
					inputs: ["role"]
				},
				{
					kind: "component",
					type: NbListItemComponent,
					selector: "nb-list-item",
					inputs: ["role"]
				},
				{
					kind: "component",
					type: NbCardComponent,
					selector: "nb-card",
					inputs: [
						"size",
						"status",
						"accent"
					]
				},
				{
					kind: "component",
					type: NbCardFooterComponent,
					selector: "nb-card-footer"
				},
				{
					kind: "component",
					type: NbCardHeaderComponent,
					selector: "nb-card-header"
				},
				{
					kind: "component",
					type: NbCalendarActionsComponent,
					selector: "nb-calendar-actions",
					inputs: [
						"applyButtonText",
						"currentTimeButtonText",
						"showCurrentTimeButton"
					],
					outputs: ["setCurrentTime", "saveValue"]
				},
				{
					kind: "component",
					type: NbTimePickerCellComponent,
					selector: "nb-timepicker-cell",
					inputs: ["selected", "value"],
					outputs: ["select"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTimePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-timepicker",
			exportAs: "nbTimepicker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<nb-card *nbPortal [class.supports-scrollbar-theming]=\"!isFirefox()\" class=\"nb-timepicker-container\">\n  <nb-card-header class=\"column-header\">\n    <ng-container *ngIf=\"singleColumn; else fullTimeHeadersBlock\">\n      <div class=\"header-cell\">Time</div>\n    </ng-container>\n    <ng-template #fullTimeHeadersBlock>\n      <div class=\"header-cell\">{{ hoursText }}</div>\n      <div class=\"header-cell\">{{ minutesText }}</div>\n      <div *ngIf=\"withSeconds\" class=\"header-cell\">{{ secondsText }}</div>\n      <div *ngIf=\"twelveHoursFormat\" class=\"header-cell\">\n        <ng-template [ngIf]=\"showAmPmLabel\">{{ ampmText }}</ng-template>\n      </div>\n    </ng-template>\n  </nb-card-header>\n\n  <div class=\"picker-body\">\n    <ng-container *ngIf=\"singleColumn; else fullTimeColumnBlock\">\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedFullTimeValue(item)\"\n          *ngFor=\"let item of fullTimeOptions; trackBy: trackBySingleColumnValue.bind(this)\"\n        >\n          <nb-timepicker-cell\n            [value]=\"getFullTimeString(item)\"\n            [selected]=\"isSelectedFullTimeValue(item)\"\n            (select)=\"selectFullTime(item)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n    </ng-container>\n\n    <ng-template #fullTimeColumnBlock>\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedHour(item.value)\"\n          *ngFor=\"let item of hoursColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedHour(item.value)\"\n            (select)=\"setHour(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedMinute(item.value)\"\n          *ngFor=\"let item of minutesColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedMinute(item.value)\"\n            (select)=\"setMinute(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list *ngIf=\"showSeconds()\" class=\"values-list\">\n        <nb-list-item\n          class=\"list-item\"\n          [class.selected]=\"isSelectedSecond(item.value)\"\n          *ngFor=\"let item of secondsColumnOptions; trackBy: trackByTimeValues\"\n        >\n          <nb-timepicker-cell\n            [value]=\"item.text\"\n            [selected]=\"isSelectedSecond(item.value)\"\n            (select)=\"setSecond(item.value)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n      <nb-list *ngIf=\"twelveHoursFormat\" class=\"values-list\">\n        <nb-list-item\n          class=\"list-item am-pm-item\"\n          [class.selected]=\"isSelectedDayPeriod(dayPeriod)\"\n          *ngFor=\"let dayPeriod of dayPeriodColumnOptions; trackBy: trackByDayPeriod\"\n        >\n          <nb-timepicker-cell\n            [value]=\"dayPeriod\"\n            [selected]=\"isSelectedDayPeriod(dayPeriod)\"\n            (select)=\"changeDayPeriod(dayPeriod)\"\n          >\n          </nb-timepicker-cell>\n        </nb-list-item>\n      </nb-list>\n    </ng-template>\n  </div>\n\n  <nb-card-footer *ngIf=\"showFooter\" class=\"actions-footer\">\n    <nb-calendar-actions\n      [applyButtonText]=\"applyButtonText\"\n      [currentTimeButtonText]=\"currentTimeButtonText\"\n      (setCurrentTime)=\"setCurrentTime()\"\n      (saveValue)=\"saveValue()\"\n    ></nb-calendar-actions>\n  </nb-card-footer>\n</nb-card>\n",
			styles: [".nb-timepicker-container{overflow:hidden;margin-bottom:0}.values-list{width:100%;overflow:hidden}.values-list:hover{overflow-y:auto}.values-list{scroll-snap-type:y proximity}.list-item{border:0;padding:0;cursor:pointer}.picker-body{display:flex;width:100%;flex:1 0 0;overflow:hidden}.column-header{width:100%;display:flex;justify-content:space-between;padding:0}.header-cell{width:100%;display:flex;align-items:center;justify-content:center}.actions-footer{width:100%}nb-card-header,nb-card-footer{flex:0 0 auto}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_TIME_PICKER_CONFIG]
			}]
		},
		{ type: NbPlatform },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LOCALE_ID]
			}]
		},
		{ type: i0.ChangeDetectorRef },
		{ type: NbCalendarTimeModelService },
		{ type: NbDateService }
	],
	propDecorators: {
		timeFormat: [{ type: Input }],
		twelveHoursFormat: [{ type: Input }],
		showAmPmLabel: [{ type: Input }],
		withSeconds: [{ type: Input }],
		singleColumn: [{ type: Input }],
		step: [{ type: Input }],
		date: [{ type: Input }],
		showFooter: [{ type: Input }],
		applyButtonText: [{ type: Input }],
		hoursText: [{ type: Input }],
		minutesText: [{ type: Input }],
		secondsText: [{ type: Input }],
		ampmText: [{ type: Input }],
		currentTimeButtonText: [{ type: Input }],
		onSelectTime: [{ type: Output }],
		portal: [{
			type: ViewChild,
			args: [NbPortalDirective, { static: true }]
		}]
	}
});
var NbCalendarWithTimeComponent = class NbCalendarWithTimeComponent extends NbCalendarComponent {
	constructor(dateService, cd, calendarTimeModelService) {
		super();
		this.dateService = dateService;
		this.cd = cd;
		this.calendarTimeModelService = calendarTimeModelService;
	}
	ngOnInit() {
		if (!this.date) this.date = this.calendarTimeModelService.getResetTime();
	}
	ngAfterViewInit() {
		this.portalOutlet.attachTemplatePortal(this.timepicker.portal);
	}
	onDateValueChange(date) {
		const hours = this.dateService.getHours(this.date);
		const minutes = this.dateService.getMinutes(this.date);
		const seconds = this.dateService.getSeconds(this.date);
		const milliseconds = this.dateService.getMilliseconds(this.date);
		let newDate = this.dateService.setHours(date, hours);
		newDate = this.dateService.setMinutes(newDate, minutes);
		newDate = this.dateService.setMinutes(newDate, minutes);
		newDate = this.dateService.setSeconds(newDate, seconds);
		newDate = this.dateService.setMilliseconds(newDate, milliseconds);
		this.date = newDate;
	}
	onTimeChange(selectedTime) {
		let newDate = this.dateService.clone(this.date);
		newDate = this.dateService.setHours(newDate, this.dateService.getHours(selectedTime.time));
		newDate = this.dateService.setMinutes(newDate, this.dateService.getMinutes(selectedTime.time));
		newDate = this.dateService.setSeconds(newDate, this.dateService.getSeconds(selectedTime.time));
		newDate = this.dateService.setMilliseconds(newDate, this.dateService.getMilliseconds(selectedTime.time));
		this.date = newDate;
	}
	saveValue() {
		this.dateChange.emit(this.date);
	}
	saveCurrentTime() {
		this.dateChange.emit(this.dateService.today());
	}
	showSeconds() {
		return this.withSeconds && !this.singleColumn;
	}
	isLarge() {
		return this.size === NbCalendarSize.LARGE;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCalendarWithTimeComponent,
			deps: [
				{ token: NbDateService },
				{ token: i0.ChangeDetectorRef },
				{ token: NbCalendarTimeModelService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCalendarWithTimeComponent,
			isStandalone: false,
			selector: "nb-calendar-with-time",
			inputs: {
				visibleDate: "visibleDate",
				twelveHoursFormat: "twelveHoursFormat",
				showAmPmLabel: "showAmPmLabel",
				withSeconds: "withSeconds",
				singleColumn: "singleColumn",
				step: "step",
				timeFormat: "timeFormat",
				title: "title",
				applyButtonText: "applyButtonText",
				currentTimeButtonText: "currentTimeButtonText",
				showCurrentTimeButton: "showCurrentTimeButton"
			},
			viewQueries: [{
				propertyName: "portalOutlet",
				first: true,
				predicate: NbPortalOutletDirective,
				descendants: true
			}, {
				propertyName: "timepicker",
				first: true,
				predicate: NbTimePickerComponent,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: `
    <nb-card class="calendar-with-time">
      <nb-card-body class="picker-body">
        <nb-base-calendar
          [boundingMonth]="boundingMonth"
          [startView]="startView"
          [date]="date"
          [min]="min"
          [max]="max"
          [filter]="filter"
          [dayCellComponent]="dayCellComponent"
          [monthCellComponent]="monthCellComponent"
          [yearCellComponent]="yearCellComponent"
          [size]="size"
          [visibleDate]="visibleDate"
          [showNavigation]="showNavigation"
          [showWeekNumber]="showWeekNumber"
          [weekNumberSymbol]="weekNumberSymbol"
          [firstDayOfWeek]="firstDayOfWeek"
          (dateChange)="onDateValueChange($event)"
        >
        </nb-base-calendar>
        <div
          class="timepicker-section"
          [class.size-large]="isLarge()"
          [class.timepicker-single-column-width]="singleColumn"
          [class.timepicker-multiple-column-width]="!singleColumn"
        >
          <div class="picker-title">{{ title }}</div>
          <nb-timepicker
            (onSelectTime)="onTimeChange($event)"
            [date]="date"
            [twelveHoursFormat]="twelveHoursFormat"
            [showAmPmLabel]="showAmPmLabel"
            [withSeconds]="showSeconds()"
            [showFooter]="false"
            [singleColumn]="singleColumn"
            [step]="step"
          >
          </nb-timepicker>
          <ng-container nbPortalOutlet></ng-container>
        </div>
      </nb-card-body>
      <nb-card-footer class="picker-footer">
        <nb-calendar-actions
          [applyButtonText]="applyButtonText"
          [currentTimeButtonText]="currentTimeButtonText"
          [showCurrentTimeButton]="showCurrentTimeButton"
          (setCurrentTime)="saveCurrentTime()"
          (saveValue)="saveValue()"
        ></nb-calendar-actions>
      </nb-card-footer>
    </nb-card>
  `,
			isInline: true,
			styles: [":host ::ng-deep nb-card.nb-timepicker-container{flex:1 0 0;border-radius:0;width:auto;border-right:0;border-bottom:0}[dir=ltr] :host .picker-footer{padding-left:.625rem}[dir=rtl] :host .picker-footer{padding-right:.625rem}.picker-body{align-items:stretch;display:flex;padding:0}.picker-body nb-base-calendar ::ng-deep nb-card{border-radius:0}.calendar-with-time{overflow:hidden}.timepicker-section{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: NbPortalOutletDirective,
					selector: "[nbPortalOutlet]"
				},
				{
					kind: "component",
					type: NbCardComponent,
					selector: "nb-card",
					inputs: [
						"size",
						"status",
						"accent"
					]
				},
				{
					kind: "component",
					type: NbCardBodyComponent,
					selector: "nb-card-body"
				},
				{
					kind: "component",
					type: NbCardFooterComponent,
					selector: "nb-card-footer"
				},
				{
					kind: "component",
					type: NbBaseCalendarComponent,
					selector: "nb-base-calendar",
					inputs: [
						"boundingMonth",
						"startView",
						"min",
						"max",
						"filter",
						"dayCellComponent",
						"monthCellComponent",
						"yearCellComponent",
						"size",
						"visibleDate",
						"showNavigation",
						"date",
						"showWeekNumber",
						"weekNumberSymbol",
						"firstDayOfWeek"
					],
					outputs: ["dateChange"]
				},
				{
					kind: "component",
					type: NbTimePickerComponent,
					selector: "nb-timepicker",
					inputs: [
						"timeFormat",
						"twelveHoursFormat",
						"showAmPmLabel",
						"withSeconds",
						"singleColumn",
						"step",
						"date",
						"showFooter",
						"applyButtonText",
						"hoursText",
						"minutesText",
						"secondsText",
						"ampmText",
						"currentTimeButtonText"
					],
					outputs: ["onSelectTime"],
					exportAs: ["nbTimepicker"]
				},
				{
					kind: "component",
					type: NbCalendarActionsComponent,
					selector: "nb-calendar-actions",
					inputs: [
						"applyButtonText",
						"currentTimeButtonText",
						"showCurrentTimeButton"
					],
					outputs: ["setCurrentTime", "saveValue"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCalendarWithTimeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-calendar-with-time",
			template: `
    <nb-card class="calendar-with-time">
      <nb-card-body class="picker-body">
        <nb-base-calendar
          [boundingMonth]="boundingMonth"
          [startView]="startView"
          [date]="date"
          [min]="min"
          [max]="max"
          [filter]="filter"
          [dayCellComponent]="dayCellComponent"
          [monthCellComponent]="monthCellComponent"
          [yearCellComponent]="yearCellComponent"
          [size]="size"
          [visibleDate]="visibleDate"
          [showNavigation]="showNavigation"
          [showWeekNumber]="showWeekNumber"
          [weekNumberSymbol]="weekNumberSymbol"
          [firstDayOfWeek]="firstDayOfWeek"
          (dateChange)="onDateValueChange($event)"
        >
        </nb-base-calendar>
        <div
          class="timepicker-section"
          [class.size-large]="isLarge()"
          [class.timepicker-single-column-width]="singleColumn"
          [class.timepicker-multiple-column-width]="!singleColumn"
        >
          <div class="picker-title">{{ title }}</div>
          <nb-timepicker
            (onSelectTime)="onTimeChange($event)"
            [date]="date"
            [twelveHoursFormat]="twelveHoursFormat"
            [showAmPmLabel]="showAmPmLabel"
            [withSeconds]="showSeconds()"
            [showFooter]="false"
            [singleColumn]="singleColumn"
            [step]="step"
          >
          </nb-timepicker>
          <ng-container nbPortalOutlet></ng-container>
        </div>
      </nb-card-body>
      <nb-card-footer class="picker-footer">
        <nb-calendar-actions
          [applyButtonText]="applyButtonText"
          [currentTimeButtonText]="currentTimeButtonText"
          [showCurrentTimeButton]="showCurrentTimeButton"
          (setCurrentTime)="saveCurrentTime()"
          (saveValue)="saveValue()"
        ></nb-calendar-actions>
      </nb-card-footer>
    </nb-card>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host ::ng-deep nb-card.nb-timepicker-container{flex:1 0 0;border-radius:0;width:auto;border-right:0;border-bottom:0}[dir=ltr] :host .picker-footer{padding-left:.625rem}[dir=rtl] :host .picker-footer{padding-right:.625rem}.picker-body{align-items:stretch;display:flex;padding:0}.picker-body nb-base-calendar ::ng-deep nb-card{border-radius:0}.calendar-with-time{overflow:hidden}.timepicker-section{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbDateService },
		{ type: i0.ChangeDetectorRef },
		{ type: NbCalendarTimeModelService }
	],
	propDecorators: {
		visibleDate: [{ type: Input }],
		twelveHoursFormat: [{ type: Input }],
		showAmPmLabel: [{ type: Input }],
		withSeconds: [{ type: Input }],
		singleColumn: [{ type: Input }],
		step: [{ type: Input }],
		timeFormat: [{ type: Input }],
		title: [{ type: Input }],
		applyButtonText: [{ type: Input }],
		currentTimeButtonText: [{ type: Input }],
		showCurrentTimeButton: [{ type: Input }],
		portalOutlet: [{
			type: ViewChild,
			args: [NbPortalOutletDirective]
		}],
		timepicker: [{
			type: ViewChild,
			args: [NbTimePickerComponent]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDatepickerContainerComponent = class NbDatepickerContainerComponent extends NbPositionedContainerComponent {
	attach(portal) {
		return this.overlayContainer.attachComponentPortal(portal);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerContainerComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDatepickerContainerComponent,
			isStandalone: false,
			selector: "nb-datepicker-container",
			viewQueries: [{
				propertyName: "overlayContainer",
				first: true,
				predicate: NbOverlayContainerComponent,
				descendants: true,
				static: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: `
    <nb-overlay-container></nb-overlay-container>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbOverlayContainerComponent,
				selector: "nb-overlay-container"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDatepickerContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-datepicker-container",
			template: `
    <nb-overlay-container></nb-overlay-container>
  `,
			standalone: false
		}]
	}],
	propDecorators: { overlayContainer: [{
		type: ViewChild,
		args: [NbOverlayContainerComponent, { static: true }]
	}] }
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDatepickerAdapter = class {};
var NbDatepicker = class {};
const NB_DATE_ADAPTER = new InjectionToken("Datepicker Adapter");
const NB_DATE_SERVICE_OPTIONS = new InjectionToken("Date service options");
var NbDatepickerDirective = class NbDatepickerDirective {
	set setPicker(picker) {
		this.picker = picker;
		this.setupPicker();
	}
	constructor(document, datepickerAdapters, hostRef, dateService, changeDetector) {
		this.document = document;
		this.datepickerAdapters = datepickerAdapters;
		this.hostRef = hostRef;
		this.dateService = dateService;
		this.changeDetector = changeDetector;
		this.destroy$ = new Subject();
		this.isDatepickerReady = false;
		this.onChange = () => {};
		this.onTouched = () => {};
		this.validator = Validators.compose([
			this.parseValidator,
			this.minValidator,
			this.maxValidator,
			this.filterValidator
		].map((fn) => fn.bind(this)));
		this.subscribeOnInputChange();
	}
	get input() {
		return this.hostRef.nativeElement;
	}
	get inputValue() {
		return this.input.value;
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	writeValue(value) {
		if (this.isDatepickerReady) {
			this.writePicker(value);
			this.writeInput(value);
		} else this.queue = value;
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.input.disabled = isDisabled;
	}
	validate() {
		return this.validator(null);
	}
	hidePicker() {
		this.input.focus();
		this.picker.hide();
	}
	parseValidator() {
		if (this.inputValue === "") return null;
		return this.datepickerAdapter.isValid(this.inputValue, this.picker.format) ? null : { nbDatepickerParse: { value: this.inputValue } };
	}
	minValidator() {
		const config = this.picker.getValidatorConfig();
		const date = this.datepickerAdapter.parse(this.inputValue, this.picker.format);
		return !config.min || !date || this.dateService.compareDates(config.min, date) <= 0 ? null : { nbDatepickerMin: {
			min: config.min,
			actual: date
		} };
	}
	maxValidator() {
		const config = this.picker.getValidatorConfig();
		const date = this.datepickerAdapter.parse(this.inputValue, this.picker.format);
		return !config.max || !date || this.dateService.compareDates(config.max, date) >= 0 ? null : { nbDatepickerMax: {
			max: config.max,
			actual: date
		} };
	}
	filterValidator() {
		const config = this.picker.getValidatorConfig();
		const date = this.datepickerAdapter.parse(this.inputValue, this.picker.format);
		return !config.filter || !date || config.filter(date) ? null : { nbDatepickerFilter: true };
	}
	chooseDatepickerAdapter() {
		this.datepickerAdapter = this.datepickerAdapters.find(({ picker }) => this.picker instanceof picker);
		if (this.noDatepickerAdapterProvided()) throw new Error("No datepickerAdapter provided for picker");
	}
	setupPicker() {
		this.chooseDatepickerAdapter();
		this.picker.attach(this.hostRef);
		if (this.inputValue) this.picker.value = this.datepickerAdapter.parse(this.inputValue, this.picker.format);
		this.pickerInputsChangedSubscription?.unsubscribe();
		this.pickerInputsChangedSubscription = this.picker.formatChanged$.pipe(map(() => this.picker.format), startWith(this.picker.format), distinctUntilChanged(), pairwise(), takeUntil(this.destroy$)).subscribe(([prevFormat, nextFormat]) => {
			if (this.inputValue) {
				const date = this.datepickerAdapter.parse(this.inputValue, prevFormat);
				this.writeInput(date);
			}
		});
		if (!this.isDatepickerReady) this.picker.init.pipe(take(1), tap(() => this.isDatepickerReady = true), filter(() => !!this.queue), takeUntil(this.destroy$)).subscribe(() => {
			this.writeValue(this.queue);
			this.changeDetector.detectChanges();
			this.queue = void 0;
		});
		this.picker.valueChange.pipe(takeUntil(this.destroy$)).subscribe((value) => {
			this.writePicker(value);
			this.writeInput(value);
			this.onChange(value);
			if (this.picker.shouldHide()) this.hidePicker();
		});
		merge(this.picker.blur, fromEvent(this.input, "blur").pipe(filter(() => !this.picker.isShown && this.document.activeElement !== this.input))).pipe(takeUntil(this.destroy$)).subscribe(() => this.onTouched());
	}
	writePicker(value) {
		this.picker.value = value;
	}
	writeInput(value) {
		this.hostRef.nativeElement.value = this.datepickerAdapter.format(value, this.picker.format);
	}
	noDatepickerAdapterProvided() {
		return !this.datepickerAdapter || !(this.datepickerAdapter instanceof NbDatepickerAdapter);
	}
	subscribeOnInputChange() {
		fromEvent(this.input, "input").pipe(map(() => this.inputValue), takeUntil(this.destroy$)).subscribe((value) => this.handleInputChange(value));
	}
	handleInputChange(value) {
		const date = this.parseInputValue(value);
		this.onChange(date);
		this.writePicker(date);
	}
	parseInputValue(value) {
		if (this.datepickerAdapter.isValid(value, this.picker.format)) return this.datepickerAdapter.parse(value, this.picker.format);
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerDirective,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NB_DATE_ADAPTER },
				{ token: i0.ElementRef },
				{ token: NbDateService },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDatepickerDirective,
			isStandalone: false,
			selector: "input[nbDatepicker]",
			inputs: { setPicker: ["nbDatepicker", "setPicker"] },
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbDatepickerDirective),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => NbDatepickerDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDatepickerDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[nbDatepicker]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbDatepickerDirective),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => NbDatepickerDirective),
				multi: true
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DATE_ADAPTER]
			}]
		},
		{ type: i0.ElementRef },
		{ type: NbDateService },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: { setPicker: [{
		type: Input,
		args: ["nbDatepicker"]
	}] }
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBasePicker = class extends NbDatepicker {
	constructor(overlay, positionBuilder, triggerStrategyBuilder, dateService, dateServiceOptions) {
		super();
		this.overlay = overlay;
		this.positionBuilder = positionBuilder;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.dateService = dateService;
		this.dateServiceOptions = dateServiceOptions;
		this.formatChanged$ = new Subject();
		this.init$ = new ReplaySubject();
		this.onChange$ = new Subject();
		this.overlayOffset = 8;
		this.adjustment = NbAdjustment.COUNTERCLOCKWISE;
		this.destroy$ = new Subject();
		this.blur$ = new Subject();
	}
	get picker() {
		return this.pickerRef && this.pickerRef.instance;
	}
	get valueChange() {
		return this.onChange$.asObservable();
	}
	get isShown() {
		return this.ref && this.ref.hasAttached();
	}
	get init() {
		return this.init$.asObservable();
	}
	get blur() {
		return this.blur$.asObservable();
	}
	attach(hostRef) {
		this.hostRef = hostRef;
		this.subscribeOnTriggers();
	}
	getValidatorConfig() {
		return {
			min: this.min,
			max: this.max,
			filter: this.filter
		};
	}
	show() {
		if (!this.ref) this.createOverlay();
		this.openDatepicker();
	}
	shouldHide() {
		return this.hideOnSelect && !!this.value;
	}
	hide() {
		if (this.ref) this.ref.detach();
		if (this.picker) {
			this.queue = this.value;
			this.pickerRef.destroy();
			this.pickerRef = null;
			this.container = null;
		}
	}
	createOverlay() {
		this.positionStrategy = this.createPositionStrategy();
		this.ref = this.overlay.create({
			positionStrategy: this.positionStrategy,
			scrollStrategy: this.overlay.scrollStrategies.reposition()
		});
		this.subscribeOnPositionChange();
	}
	openDatepicker() {
		this.container = this.ref.attach(new NbComponentPortal(NbDatepickerContainerComponent, null, null));
		this.instantiatePicker();
		this.subscribeOnValueChange();
		this.writeQueue();
		this.patchWithInputs();
		this.pickerRef.changeDetectorRef.markForCheck();
	}
	createPositionStrategy() {
		return this.positionBuilder.connectedTo(this.hostRef).position(NbPosition.BOTTOM).offset(this.overlayOffset).adjustment(this.adjustment);
	}
	subscribeOnPositionChange() {
		this.positionStrategy.positionChange.pipe(takeUntil(this.destroy$)).subscribe((position) => patch(this.container, { position }));
	}
	createTriggerStrategy() {
		return this.triggerStrategyBuilder.trigger(NbTrigger.FOCUS).host(this.hostRef.nativeElement).container(() => this.container).build();
	}
	subscribeOnTriggers() {
		this.triggerStrategy = this.createTriggerStrategy();
		this.triggerStrategy.show$.subscribe(() => this.show());
		this.triggerStrategy.hide$.subscribe(() => {
			this.blur$.next();
			this.hide();
		});
	}
	instantiatePicker() {
		this.pickerRef = this.container.instance.attach(new NbComponentPortal(this.pickerClass, null, null));
	}
	subscribeOnValueChange() {
		this.pickerValueChange.subscribe((date) => {
			this.onChange$.next(date);
		});
	}
	patchWithInputs() {
		this.pickerRef.setInput("boundingMonth", this.boundingMonth);
		this.pickerRef.setInput("startView", this.startView);
		this.pickerRef.setInput("min", this.min);
		this.pickerRef.setInput("max", this.max);
		this.pickerRef.setInput("filter", this.filter);
		this.pickerRef.setInput("dayCellComponent", this.dayCellComponent);
		this.pickerRef.setInput("monthCellComponent", this.monthCellComponent);
		this.pickerRef.setInput("yearCellComponent", this.yearCellComponent);
		this.pickerRef.setInput("size", this.size);
		this.pickerRef.setInput("showNavigation", this.showNavigation);
		this.pickerRef.setInput("visibleDate", this.visibleDate);
		this.pickerRef.setInput("showWeekNumber", this.showWeekNumber);
		this.pickerRef.setInput("weekNumberSymbol", this.weekNumberSymbol);
		this.pickerRef.setInput("firstDayOfWeek", this.firstDayOfWeek);
	}
	checkFormat() {
		if (this.dateService.getId() === "native" && this.format) throw new Error("Can't format native date. To use custom formatting you have to install @nebular/moment or @nebular/date-fns package and import NbMomentDateModule or NbDateFnsDateModule accordingly.More information at \"Formatting issue\" https://akveo.github.io/nebular/docs/components/datepicker/overview#nbdatepickercomponent");
		const isFormatSet = this.format || this.dateServiceOptions && this.dateServiceOptions.format;
		if (this.dateService.getId() === "date-fns" && !isFormatSet) throw new Error("format is required when using NbDateFnsDateModule");
	}
};
var NbBasePickerComponent = class NbBasePickerComponent extends NbBasePicker {
	get showWeekNumber() {
		return this._showWeekNumber;
	}
	set showWeekNumber(value) {
		this._showWeekNumber = convertToBoolProperty(value);
	}
	constructor(document, positionBuilder, triggerStrategyBuilder, overlay, dateService, dateServiceOptions) {
		super(overlay, positionBuilder, triggerStrategyBuilder, dateService, dateServiceOptions);
		this.boundingMonth = true;
		this.startView = NbCalendarViewMode.DATE;
		this.size = NbCalendarSize.MEDIUM;
		this.hideOnSelect = true;
		this.showNavigation = true;
		this.weekNumberSymbol = "#";
		this._showWeekNumber = false;
		this.overlayOffset = 8;
		this.adjustment = NbAdjustment.COUNTERCLOCKWISE;
	}
	ngOnInit() {
		this.checkFormat();
		this.init$.next();
	}
	ngOnChanges(changes) {
		if (changes.format) {
			if (!changes.format.isFirstChange()) this.checkFormat();
			this.formatChanged$.next();
		}
		if (this.picker) this.patchWithInputs();
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
		this.hide();
		this.init$.complete();
		if (this.ref) this.ref.dispose();
		if (this.triggerStrategy) this.triggerStrategy.destroy();
	}
	get pickerValueChange() {}
	get value() {}
	set value(value) {}
	writeQueue() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBasePickerComponent,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbPositionBuilderService },
				{ token: NbTriggerStrategyBuilderService },
				{ token: NbOverlayService },
				{ token: NbDateService },
				{
					token: NB_DATE_SERVICE_OPTIONS,
					optional: true
				}
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbBasePickerComponent,
			isStandalone: false,
			selector: "ng-component",
			inputs: {
				format: "format",
				boundingMonth: "boundingMonth",
				startView: "startView",
				min: "min",
				max: "max",
				filter: "filter",
				dayCellComponent: "dayCellComponent",
				monthCellComponent: "monthCellComponent",
				yearCellComponent: "yearCellComponent",
				size: "size",
				visibleDate: "visibleDate",
				hideOnSelect: "hideOnSelect",
				showNavigation: "showNavigation",
				weekNumberSymbol: "weekNumberSymbol",
				showWeekNumber: "showWeekNumber",
				firstDayOfWeek: "firstDayOfWeek",
				overlayOffset: "overlayOffset",
				adjustment: "adjustment"
			},
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBasePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			template: "",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbPositionBuilderService },
		{ type: NbTriggerStrategyBuilderService },
		{ type: NbOverlayService },
		{ type: NbDateService },
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NB_DATE_SERVICE_OPTIONS]
			}]
		}
	],
	propDecorators: {
		format: [{ type: Input }],
		boundingMonth: [{ type: Input }],
		startView: [{ type: Input }],
		min: [{ type: Input }],
		max: [{ type: Input }],
		filter: [{ type: Input }],
		dayCellComponent: [{ type: Input }],
		monthCellComponent: [{ type: Input }],
		yearCellComponent: [{ type: Input }],
		size: [{ type: Input }],
		visibleDate: [{ type: Input }],
		hideOnSelect: [{ type: Input }],
		showNavigation: [{ type: Input }],
		weekNumberSymbol: [{ type: Input }],
		showWeekNumber: [{ type: Input }],
		firstDayOfWeek: [{ type: Input }],
		overlayOffset: [{ type: Input }],
		adjustment: [{ type: Input }]
	}
});
var NbDatepickerComponent = class NbDatepickerComponent extends NbBasePickerComponent {
	constructor() {
		super(...arguments);
		this.pickerClass = NbCalendarComponent;
	}
	set date(date) {
		this.value = date;
	}
	get dateChange() {
		return this.valueChange;
	}
	get value() {
		return this.picker ? this.picker.date : void 0;
	}
	set value(date) {
		if (!this.picker) {
			this.queue = date;
			return;
		}
		if (date) {
			this.visibleDate = date;
			this.pickerRef.setInput("visibleDate", date);
			this.pickerRef.setInput("date", date);
		}
	}
	get pickerValueChange() {
		return this.picker.dateChange;
	}
	writeQueue() {
		if (this.queue) {
			const date = this.queue;
			this.queue = null;
			this.value = date;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDatepickerComponent,
			isStandalone: false,
			selector: "nb-datepicker",
			inputs: { date: "date" },
			outputs: { dateChange: "dateChange" },
			usesInheritance: true,
			ngImport: i0,
			template: "",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDatepickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-datepicker",
			template: "",
			standalone: false
		}]
	}],
	propDecorators: {
		date: [{ type: Input }],
		dateChange: [{ type: Output }]
	}
});
var NbRangepickerComponent = class NbRangepickerComponent extends NbBasePickerComponent {
	constructor() {
		super(...arguments);
		this.pickerClass = NbCalendarRangeComponent;
	}
	set range(range) {
		this.value = range;
	}
	get rangeChange() {
		return this.valueChange;
	}
	get value() {
		return this.picker ? this.picker.range : void 0;
	}
	set value(range) {
		if (!this.picker) {
			this.queue = range;
			return;
		}
		if (range) {
			const visibleDate = range && range.start;
			this.visibleDate = visibleDate;
			this.picker.visibleDate = visibleDate;
			this.picker.range = range;
		}
	}
	get pickerValueChange() {
		return this.picker.rangeChange;
	}
	shouldHide() {
		return super.shouldHide() && !!(this.value && this.value.start && this.value.end);
	}
	writeQueue() {
		if (this.queue) {
			const range = this.queue;
			this.queue = null;
			this.value = range;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRangepickerComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRangepickerComponent,
			isStandalone: false,
			selector: "nb-rangepicker",
			inputs: { range: "range" },
			outputs: { rangeChange: "rangeChange" },
			usesInheritance: true,
			ngImport: i0,
			template: "",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRangepickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-rangepicker",
			template: "",
			standalone: false
		}]
	}],
	propDecorators: {
		range: [{ type: Input }],
		rangeChange: [{ type: Output }]
	}
});
var NbDateTimePickerComponent = class NbDateTimePickerComponent extends NbBasePickerComponent {
	get value() {
		return this.picker ? this.picker.date : void 0;
	}
	set value(date) {
		if (!this.picker) {
			this.queue = date;
			return;
		}
		if (date) {
			this.visibleDate = date;
			this.picker.visibleDate = date;
			this.picker.date = date;
			this.picker.cd.markForCheck();
		}
	}
	get twelveHoursFormat() {
		return this._twelveHoursFormat;
	}
	set twelveHoursFormat(value) {
		this._twelveHoursFormat = convertToBoolProperty(value);
	}
	get showAmPmLabel() {
		return this._showAmPmLabel;
	}
	set showAmPmLabel(value) {
		this._showAmPmLabel = convertToBoolProperty(value);
	}
	get withSeconds() {
		return this._withSeconds;
	}
	set withSeconds(value) {
		this._withSeconds = convertToBoolProperty(value);
	}
	get singleColumn() {
		return this._singleColumn;
	}
	set singleColumn(value) {
		this._singleColumn = convertToBoolProperty(value);
	}
	get dateTimeChange() {
		return this.valueChange;
	}
	constructor(document, positionBuilder, triggerStrategyBuilder, overlay, dateService, dateServiceOptions, calendarWithTimeModelService) {
		super(document, positionBuilder, triggerStrategyBuilder, overlay, dateService, dateServiceOptions);
		this.calendarWithTimeModelService = calendarWithTimeModelService;
		this.pickerClass = NbCalendarWithTimeComponent;
		this.showCurrentTimeButton = true;
		this._showAmPmLabel = true;
	}
	ngOnInit() {
		this.format = this.format || this.buildTimeFormat();
		this.init$.next();
	}
	patchWithInputs() {
		this.picker.singleColumn = this.singleColumn;
		this.picker.twelveHoursFormat = this.twelveHoursFormat;
		this.picker.showAmPmLabel = this.showAmPmLabel;
		this.picker.withSeconds = this.withSeconds;
		this.picker.step = this.step;
		this.picker.title = this.title;
		this.picker.applyButtonText = this.applyButtonText;
		this.picker.currentTimeButtonText = this.currentTimeButtonText;
		this.picker.showCurrentTimeButton = this.showCurrentTimeButton;
		if (this.twelveHoursFormat) this.picker.timeFormat = this.dateService.getTwelveHoursFormat();
		else this.picker.timeFormat = this.withSeconds && !this.singleColumn ? this.dateService.getTwentyFourHoursFormatWithSeconds() : this.dateService.getTwentyFourHoursFormat();
		super.patchWithInputs();
		this.picker.cd.markForCheck();
	}
	get pickerValueChange() {
		return this.picker.dateChange;
	}
	writeQueue() {
		if (this.queue) {
			const date = this.queue;
			this.queue = null;
			this.value = date;
		}
	}
	buildTimeFormat() {
		if (this.singleColumn) return this.calendarWithTimeModelService.buildDateFormat(this.twelveHoursFormat);
		else return this.calendarWithTimeModelService.buildDateFormat(this.twelveHoursFormat, this.withSeconds);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDateTimePickerComponent,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbPositionBuilderService },
				{ token: NbTriggerStrategyBuilderService },
				{ token: NbOverlayService },
				{ token: NbDateService },
				{
					token: NB_DATE_SERVICE_OPTIONS,
					optional: true
				},
				{ token: NbCalendarTimeModelService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDateTimePickerComponent,
			isStandalone: false,
			selector: "nb-date-timepicker",
			inputs: {
				step: "step",
				title: "title",
				applyButtonText: "applyButtonText",
				currentTimeButtonText: "currentTimeButtonText",
				showCurrentTimeButton: "showCurrentTimeButton",
				twelveHoursFormat: "twelveHoursFormat",
				showAmPmLabel: "showAmPmLabel",
				withSeconds: "withSeconds",
				singleColumn: "singleColumn"
			},
			outputs: { dateTimeChange: "dateTimeChange" },
			usesInheritance: true,
			ngImport: i0,
			template: "",
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDateTimePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-date-timepicker",
			template: "",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbPositionBuilderService },
		{ type: NbTriggerStrategyBuilderService },
		{ type: NbOverlayService },
		{ type: NbDateService },
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NB_DATE_SERVICE_OPTIONS]
			}]
		},
		{ type: NbCalendarTimeModelService }
	],
	propDecorators: {
		step: [{ type: Input }],
		title: [{ type: Input }],
		applyButtonText: [{ type: Input }],
		currentTimeButtonText: [{ type: Input }],
		showCurrentTimeButton: [{ type: Input }],
		twelveHoursFormat: [{ type: Input }],
		showAmPmLabel: [{ type: Input }],
		withSeconds: [{ type: Input }],
		singleColumn: [{ type: Input }],
		dateTimeChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
function isUrlPathEqual(path, link) {
	return link === getPathPartOfUrl(path);
}
function isUrlPathContain(path, link) {
	const locationPath = getPathPartOfUrl(path);
	return locationPath.startsWith(link) && locationPath.slice(link.length).charAt(0).search(/\/|^$/) !== -1;
}
function getPathPartOfUrl(url) {
	return url.match(/.*?(?=[?;#]|$)/)[0];
}
function getFragmentPartOfUrl(url) {
	const matched = url.match(/#(.+)/);
	return matched ? matched[1] : "";
}
function isFragmentEqual(path, fragment) {
	return getFragmentPartOfUrl(path) === fragment;
}
function isFragmentContain(path, fragment) {
	return getFragmentPartOfUrl(path).includes(fragment);
}
var NbRestoreScrollTopHelper = class NbRestoreScrollTopHelper {
	constructor(router) {
		this.router = router;
	}
	shouldRestore() {
		return this.router.events.pipe(startWith(null), filter((event) => event === null || event instanceof NavigationEnd), pairwise(), map(([prev, current]) => this.pageChanged(prev, current)), filter((res) => !!res));
	}
	pageChanged(prev, current) {
		return !prev || getPathPartOfUrl(prev.url) !== getPathPartOfUrl(current.url);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRestoreScrollTopHelper,
			deps: [{ token: i1$1.Router }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRestoreScrollTopHelper
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRestoreScrollTopHelper,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i1$1.Router }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbLayoutComponent = class NbLayoutComponent {
	set center(val) {
		this.centerValue = convertToBoolProperty(val);
	}
	set windowMode(val) {
		this.windowModeValue = convertToBoolProperty(val);
		this.withScroll = this.windowModeValue;
	}
	set withScroll(val) {
		this.withScrollValue = convertToBoolProperty(val);
		const body = this.document.getElementsByTagName("body")[0];
		if (this.withScrollValue) this.renderer.setStyle(body, "overflow", "hidden");
		else this.renderer.setStyle(body, "overflow", "initial");
	}
	set restoreScrollTop(val) {
		this.restoreScrollTopValue = convertToBoolProperty(val);
	}
	constructor(themeService, spinnerService, elementRef, renderer, window, document, platformId, layoutDirectionService, scrollService, rulerService, scrollTop, overlayContainer) {
		this.themeService = themeService;
		this.spinnerService = spinnerService;
		this.elementRef = elementRef;
		this.renderer = renderer;
		this.window = window;
		this.document = document;
		this.platformId = platformId;
		this.layoutDirectionService = layoutDirectionService;
		this.scrollService = scrollService;
		this.rulerService = rulerService;
		this.scrollTop = scrollTop;
		this.overlayContainer = overlayContainer;
		this.scrollBlockClass = "nb-global-scrollblock";
		this.isScrollBlocked = false;
		this.centerValue = false;
		this.restoreScrollTopValue = true;
		this.windowModeValue = false;
		this.withScrollValue = false;
		this.withSubheader = false;
		this.afterViewInit$ = new BehaviorSubject(null);
		this.destroy$ = new Subject();
		this.registerAsOverlayContainer();
		this.themeService.onThemeChange().pipe(takeUntil(this.destroy$)).subscribe((theme) => {
			const body = this.document.getElementsByTagName("body")[0];
			if (theme.previous) this.renderer.removeClass(body, `nb-theme-${theme.previous}`);
			this.renderer.addClass(body, `nb-theme-${theme.name}`);
		});
		this.themeService.onAppendLayoutClass().pipe(takeUntil(this.destroy$)).subscribe((className) => {
			this.renderer.addClass(this.elementRef.nativeElement, className);
		});
		this.themeService.onRemoveLayoutClass().pipe(takeUntil(this.destroy$)).subscribe((className) => {
			this.renderer.removeClass(this.elementRef.nativeElement, className);
		});
		this.spinnerService.registerLoader(new Promise((resolve) => {
			this.afterViewInit$.pipe(takeUntil(this.destroy$)).subscribe((_) => resolve());
		}));
		this.spinnerService.load();
		this.rulerService.onGetDimensions().pipe(takeUntil(this.destroy$)).subscribe(({ listener }) => {
			listener.next(this.getDimensions());
			listener.complete();
		});
		this.scrollService.onGetPosition().pipe(takeUntil(this.destroy$)).subscribe(({ listener }) => {
			listener.next(this.getScrollPosition());
			listener.complete();
		});
		this.scrollTop.shouldRestore().pipe(filter(() => this.restoreScrollTopValue), takeUntil(this.destroy$)).subscribe(() => {
			this.scroll(0, 0);
		});
		this.scrollService.onScrollableChange().pipe(filter(() => this.withScrollValue), takeUntil(this.destroy$)).subscribe((scrollable) => {
			if (scrollable) this.enableScroll();
			else this.blockScroll();
		});
		if (isPlatformBrowser(this.platformId)) this.themeService.changeWindowWidth(this.window.innerWidth);
	}
	ngAfterViewInit() {
		this.layoutDirectionService.onDirectionChange().pipe(takeUntil(this.destroy$)).subscribe((direction) => this.document.dir = direction);
		this.scrollService.onManualScroll().pipe(takeUntil(this.destroy$)).subscribe(({ x, y }) => this.scroll(x, y));
		this.afterViewInit$.next(true);
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
		this.unregisterAsOverlayContainer();
	}
	onScroll($event) {
		this.scrollService.fireScrollChange($event);
	}
	onResize(event) {
		this.themeService.changeWindowWidth(event.target.innerWidth);
	}
	getDimensions() {
		let clientWidth, clientHeight, scrollWidth, scrollHeight = 0;
		if (this.withScrollValue) {
			const container = this.scrollableContainerRef.nativeElement;
			clientWidth = container.clientWidth;
			clientHeight = container.clientHeight;
			scrollWidth = container.scrollWidth;
			scrollHeight = container.scrollHeight;
		} else {
			const { documentElement, body } = this.document;
			clientWidth = documentElement.clientWidth || body.clientWidth;
			clientHeight = documentElement.clientHeight || body.clientHeight;
			scrollWidth = documentElement.scrollWidth || body.scrollWidth;
			scrollHeight = documentElement.scrollHeight || body.scrollHeight;
		}
		return {
			clientWidth,
			clientHeight,
			scrollWidth,
			scrollHeight
		};
	}
	getScrollPosition() {
		if (!isPlatformBrowser(this.platformId)) return {
			x: 0,
			y: 0
		};
		if (this.withScrollValue) {
			const container = this.scrollableContainerRef.nativeElement;
			return {
				x: container.scrollLeft,
				y: container.scrollTop
			};
		}
		const documentRect = this.document.documentElement.getBoundingClientRect();
		return {
			x: -documentRect.left || this.document.body.scrollLeft || this.window.scrollX || this.document.documentElement.scrollLeft || 0,
			y: -documentRect.top || this.document.body.scrollTop || this.window.scrollY || this.document.documentElement.scrollTop || 0
		};
	}
	registerAsOverlayContainer() {
		if (this.overlayContainer.setContainer) this.overlayContainer.setContainer(this.elementRef.nativeElement);
	}
	unregisterAsOverlayContainer() {
		if (this.overlayContainer.clearContainer) this.overlayContainer.clearContainer();
	}
	scroll(x = null, y = null) {
		const { x: currentX, y: currentY } = this.getScrollPosition();
		x = x == null ? currentX : x;
		y = y == null ? currentY : y;
		if (!isPlatformBrowser(this.platformId)) return;
		if (this.withScrollValue) {
			const scrollable = this.scrollableContainerRef.nativeElement;
			if (scrollable.scrollTo) scrollable.scrollTo(x, y);
			else {
				scrollable.scrollLeft = x;
				scrollable.scrollTop = y;
			}
		} else this.window.scrollTo(x, y);
	}
	blockScroll() {
		if (this.isScrollBlocked) return;
		this.isScrollBlocked = true;
		this.renderer.addClass(this.document.documentElement, this.scrollBlockClass);
		const scrollableContainerElement = this.scrollableContainerRef.nativeElement;
		const layoutElement = this.layoutContainerRef.nativeElement;
		const layoutWithScrollWidth = layoutElement.clientWidth;
		this.scrollableContainerOverflowOldValue = scrollableContainerElement.style.overflow;
		scrollableContainerElement.style.overflow = "hidden";
		const scrollWidth = layoutElement.clientWidth - layoutWithScrollWidth;
		if (!scrollWidth) return;
		this.layoutPaddingOldValue = {
			left: layoutElement.style.paddingLeft,
			right: layoutElement.style.paddingRight
		};
		if (this.layoutDirectionService.isLtr()) layoutElement.style.paddingRight = `${scrollWidth}px`;
		else layoutElement.style.paddingLeft = `${scrollWidth}px`;
	}
	enableScroll() {
		if (this.isScrollBlocked) {
			this.isScrollBlocked = false;
			this.renderer.removeClass(this.document.documentElement, this.scrollBlockClass);
			this.scrollableContainerRef.nativeElement.style.overflow = this.scrollableContainerOverflowOldValue;
			if (this.layoutPaddingOldValue) {
				const layoutElement = this.layoutContainerRef.nativeElement;
				layoutElement.style.paddingLeft = this.layoutPaddingOldValue.left;
				layoutElement.style.paddingRight = this.layoutPaddingOldValue.right;
				this.layoutPaddingOldValue = null;
			}
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutComponent,
			deps: [
				{ token: NbThemeService },
				{ token: NbSpinnerService },
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: NB_WINDOW },
				{ token: NB_DOCUMENT },
				{ token: PLATFORM_ID },
				{ token: NbLayoutDirectionService },
				{ token: NbLayoutScrollService },
				{ token: NbLayoutRulerService },
				{ token: NbRestoreScrollTopHelper },
				{ token: NbOverlayContainerAdapter }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLayoutComponent,
			isStandalone: false,
			selector: "nb-layout",
			inputs: {
				center: "center",
				windowMode: "windowMode",
				withScroll: "withScroll",
				restoreScrollTop: "restoreScrollTop"
			},
			host: {
				listeners: {
					"window:scroll": "onScroll($event)",
					"window:resize": "onResize($event)"
				},
				properties: {
					"class.window-mode": "this.windowModeValue",
					"class.with-scroll": "this.withScrollValue",
					"class.with-subheader": "this.withSubheader"
				}
			},
			viewQueries: [
				{
					propertyName: "veryTopRef",
					first: true,
					predicate: ["layoutTopDynamicArea"],
					descendants: true,
					read: ViewContainerRef
				},
				{
					propertyName: "scrollableContainerRef",
					first: true,
					predicate: ["scrollableContainer"],
					descendants: true,
					read: ElementRef,
					static: true
				},
				{
					propertyName: "layoutContainerRef",
					first: true,
					predicate: ["layoutContainer"],
					descendants: true,
					read: ElementRef
				}
			],
			ngImport: i0,
			template: `
    <div class="scrollable-container" #scrollableContainer (scroll)="onScroll($event)">
      <div class="layout" #layoutContainer>
        <ng-content select="nb-layout-header:not([subheader])"></ng-content>
        <div class="layout-container">
          <ng-content select="nb-sidebar"></ng-content>
          <div class="content" [class.center]="centerValue">
            <ng-content select="nb-layout-header[subheader]"></ng-content>
            <div class="columns">
              <ng-content select="nb-layout-column"></ng-content>
            </div>
            <ng-content select="nb-layout-footer"></ng-content>
          </div>
        </div>
      </div>
    </div>
  `,
			isInline: true,
			styles: ["[dir=ltr] :host{text-align:left}[dir=rtl] :host{text-align:right}:host{-webkit-font-smoothing:antialiased}:host .layout{display:flex;flex-direction:column}:host ::ng-deep nb-layout-header{display:block}:host ::ng-deep nb-layout-header nav{align-items:center;justify-content:flex-start;display:flex}:host ::ng-deep nb-layout-header.fixed{position:fixed;top:0;left:0;right:0;z-index:1040}:host .layout-container{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:row}[dir=ltr] :host .layout-container ::ng-deep nb-sidebar.left{order:0}[dir=rtl] :host .layout-container ::ng-deep nb-sidebar.left{order:2}[dir=ltr] :host .layout-container ::ng-deep nb-sidebar.right{order:2}[dir=rtl] :host .layout-container ::ng-deep nb-sidebar.right{order:0}:host .layout-container ::ng-deep nb-sidebar.end{order:2}:host .layout-container ::ng-deep nb-sidebar .fixed{position:fixed;width:100%;overflow-y:auto;height:100%}:host .layout-container .content{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:column;min-width:0}:host .layout-container .content.center{max-width:100%;position:relative;margin-left:auto;margin-right:auto}:host .layout-container .content .columns{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:row;width:100%}:host .layout-container .content .columns ::ng-deep nb-layout-column{order:1;flex:1 0;min-width:0}[dir=ltr] :host .layout-container .content .columns ::ng-deep nb-layout-column.left{order:0}[dir=rtl] :host .layout-container .content .columns ::ng-deep nb-layout-column.left{order:2}:host .layout-container .content .columns ::ng-deep nb-layout-column.start{order:0}:host .layout-container .content ::ng-deep nb-layout-footer{display:block;margin-top:auto}:host .layout-container .content ::ng-deep nb-layout-footer nav{justify-content:center;display:flex}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-layout",
			template: `
    <div class="scrollable-container" #scrollableContainer (scroll)="onScroll($event)">
      <div class="layout" #layoutContainer>
        <ng-content select="nb-layout-header:not([subheader])"></ng-content>
        <div class="layout-container">
          <ng-content select="nb-sidebar"></ng-content>
          <div class="content" [class.center]="centerValue">
            <ng-content select="nb-layout-header[subheader]"></ng-content>
            <div class="columns">
              <ng-content select="nb-layout-column"></ng-content>
            </div>
            <ng-content select="nb-layout-footer"></ng-content>
          </div>
        </div>
      </div>
    </div>
  `,
			standalone: false,
			styles: ["[dir=ltr] :host{text-align:left}[dir=rtl] :host{text-align:right}:host{-webkit-font-smoothing:antialiased}:host .layout{display:flex;flex-direction:column}:host ::ng-deep nb-layout-header{display:block}:host ::ng-deep nb-layout-header nav{align-items:center;justify-content:flex-start;display:flex}:host ::ng-deep nb-layout-header.fixed{position:fixed;top:0;left:0;right:0;z-index:1040}:host .layout-container{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:row}[dir=ltr] :host .layout-container ::ng-deep nb-sidebar.left{order:0}[dir=rtl] :host .layout-container ::ng-deep nb-sidebar.left{order:2}[dir=ltr] :host .layout-container ::ng-deep nb-sidebar.right{order:2}[dir=rtl] :host .layout-container ::ng-deep nb-sidebar.right{order:0}:host .layout-container ::ng-deep nb-sidebar.end{order:2}:host .layout-container ::ng-deep nb-sidebar .fixed{position:fixed;width:100%;overflow-y:auto;height:100%}:host .layout-container .content{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:column;min-width:0}:host .layout-container .content.center{max-width:100%;position:relative;margin-left:auto;margin-right:auto}:host .layout-container .content .columns{display:flex;flex:1;-ms-flex:1 1 auto;flex-direction:row;width:100%}:host .layout-container .content .columns ::ng-deep nb-layout-column{order:1;flex:1 0;min-width:0}[dir=ltr] :host .layout-container .content .columns ::ng-deep nb-layout-column.left{order:0}[dir=rtl] :host .layout-container .content .columns ::ng-deep nb-layout-column.left{order:2}:host .layout-container .content .columns ::ng-deep nb-layout-column.start{order:0}:host .layout-container .content ::ng-deep nb-layout-footer{display:block;margin-top:auto}:host .layout-container .content ::ng-deep nb-layout-footer nav{justify-content:center;display:flex}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbThemeService },
		{ type: NbSpinnerService },
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{ type: NbLayoutDirectionService },
		{ type: NbLayoutScrollService },
		{ type: NbLayoutRulerService },
		{ type: NbRestoreScrollTopHelper },
		{ type: NbOverlayContainerAdapter }
	],
	propDecorators: {
		windowModeValue: [{
			type: HostBinding,
			args: ["class.window-mode"]
		}],
		withScrollValue: [{
			type: HostBinding,
			args: ["class.with-scroll"]
		}],
		withSubheader: [{
			type: HostBinding,
			args: ["class.with-subheader"]
		}],
		center: [{ type: Input }],
		windowMode: [{ type: Input }],
		withScroll: [{ type: Input }],
		restoreScrollTop: [{ type: Input }],
		veryTopRef: [{
			type: ViewChild,
			args: ["layoutTopDynamicArea", { read: ViewContainerRef }]
		}],
		scrollableContainerRef: [{
			type: ViewChild,
			args: ["scrollableContainer", {
				read: ElementRef,
				static: true
			}]
		}],
		layoutContainerRef: [{
			type: ViewChild,
			args: ["layoutContainer", { read: ElementRef }]
		}],
		onScroll: [{
			type: HostListener,
			args: ["window:scroll", ["$event"]]
		}],
		onResize: [{
			type: HostListener,
			args: ["window:resize", ["$event"]]
		}]
	}
});
var NbLayoutColumnComponent = class NbLayoutColumnComponent {
	set left(val) {
		this.leftValue = convertToBoolProperty(val);
		this.startValue = false;
	}
	set start(val) {
		this.startValue = convertToBoolProperty(val);
		this.leftValue = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutColumnComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLayoutColumnComponent,
			isStandalone: false,
			selector: "nb-layout-column",
			inputs: {
				left: "left",
				start: "start"
			},
			host: { properties: {
				"class.left": "this.leftValue",
				"class.start": "this.startValue"
			} },
			ngImport: i0,
			template: `<ng-content></ng-content>`,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutColumnComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-layout-column",
			template: `<ng-content></ng-content>`,
			standalone: false
		}]
	}],
	propDecorators: {
		leftValue: [{
			type: HostBinding,
			args: ["class.left"]
		}],
		startValue: [{
			type: HostBinding,
			args: ["class.start"]
		}],
		left: [{ type: Input }],
		start: [{ type: Input }]
	}
});
var NbLayoutHeaderComponent = class NbLayoutHeaderComponent {
	constructor(layout) {
		this.layout = layout;
	}
	set fixed(val) {
		this.fixedValue = convertToBoolProperty(val);
	}
	set subheader(val) {
		this.subheaderValue = convertToBoolProperty(val);
		this.fixedValue = false;
		this.layout.withSubheader = this.subheaderValue;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutHeaderComponent,
			deps: [{ token: NbLayoutComponent }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLayoutHeaderComponent,
			isStandalone: false,
			selector: "nb-layout-header",
			inputs: {
				fixed: "fixed",
				subheader: "subheader"
			},
			host: { properties: {
				"class.fixed": "this.fixedValue",
				"class.subheader": "this.subheaderValue"
			} },
			ngImport: i0,
			template: `
    <nav [class.fixed]="fixedValue">
      <ng-content></ng-content>
    </nav>
  `,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-layout-header",
			template: `
    <nav [class.fixed]="fixedValue">
      <ng-content></ng-content>
    </nav>
  `,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbLayoutComponent }],
	propDecorators: {
		fixedValue: [{
			type: HostBinding,
			args: ["class.fixed"]
		}],
		subheaderValue: [{
			type: HostBinding,
			args: ["class.subheader"]
		}],
		fixed: [{ type: Input }],
		subheader: [{ type: Input }]
	}
});
var NbLayoutFooterComponent = class NbLayoutFooterComponent {
	set fixed(val) {
		this.fixedValue = convertToBoolProperty(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutFooterComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLayoutFooterComponent,
			isStandalone: false,
			selector: "nb-layout-footer",
			inputs: { fixed: "fixed" },
			host: { properties: { "class.fixed": "this.fixedValue" } },
			ngImport: i0,
			template: `
    <nav [class.fixed]="fixedValue">
      <ng-content></ng-content>
    </nav>
  `,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-layout-footer",
			template: `
    <nav [class.fixed]="fixedValue">
      <ng-content></ng-content>
    </nav>
  `,
			standalone: false
		}]
	}],
	propDecorators: {
		fixedValue: [{
			type: HostBinding,
			args: ["class.fixed"]
		}],
		fixed: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBaseLayoutDirectionDirective = class NbBaseLayoutDirectionDirective {
	constructor(templateRef, viewContainer, cd, directionService, directionToShow) {
		this.templateRef = templateRef;
		this.viewContainer = viewContainer;
		this.cd = cd;
		this.directionService = directionService;
		this.directionToShow = directionToShow;
		this.destroy$ = new Subject();
	}
	ngOnInit() {
		this.directionService.onDirectionChange().pipe(map((layoutDirection) => layoutDirection === this.directionToShow), distinctUntilChanged(), takeUntil(this.destroy$)).subscribe((shouldShow) => this.updateView(shouldShow));
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	updateView(shouldShow) {
		if (shouldShow && !this.viewContainer.length) {
			this.viewContainer.createEmbeddedView(this.templateRef);
			this.cd.markForCheck();
		} else if (!shouldShow && this.viewContainer.length) this.viewContainer.clear();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBaseLayoutDirectionDirective,
			deps: [
				{ token: i0.TemplateRef },
				{ token: i0.ViewContainerRef },
				{ token: i0.ChangeDetectorRef },
				{ token: NbLayoutDirectionService },
				{ token: NbLayoutDirection }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbBaseLayoutDirectionDirective,
			isStandalone: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBaseLayoutDirectionDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.TemplateRef },
		{ type: i0.ViewContainerRef },
		{ type: i0.ChangeDetectorRef },
		{ type: NbLayoutDirectionService },
		{ type: NbLayoutDirection }
	]
});
var NbLtrDirective = class NbLtrDirective extends NbBaseLayoutDirectionDirective {
	constructor(templateRef, viewContainer, cd, directionService) {
		super(templateRef, viewContainer, cd, directionService, NbLayoutDirection.LTR);
		this.templateRef = templateRef;
		this.viewContainer = viewContainer;
		this.cd = cd;
		this.directionService = directionService;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLtrDirective,
			deps: [
				{ token: i0.TemplateRef },
				{ token: i0.ViewContainerRef },
				{ token: i0.ChangeDetectorRef },
				{ token: NbLayoutDirectionService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbLtrDirective,
			isStandalone: false,
			selector: "[nbLtr]",
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLtrDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbLtr]",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.TemplateRef },
		{ type: i0.ViewContainerRef },
		{ type: i0.ChangeDetectorRef },
		{ type: NbLayoutDirectionService }
	]
});
var NbRtlDirective = class NbRtlDirective extends NbBaseLayoutDirectionDirective {
	constructor(templateRef, viewContainer, cd, directionService) {
		super(templateRef, viewContainer, cd, directionService, NbLayoutDirection.RTL);
		this.templateRef = templateRef;
		this.viewContainer = viewContainer;
		this.cd = cd;
		this.directionService = directionService;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRtlDirective,
			deps: [
				{ token: i0.TemplateRef },
				{ token: i0.ViewContainerRef },
				{ token: i0.ChangeDetectorRef },
				{ token: NbLayoutDirectionService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRtlDirective,
			isStandalone: false,
			selector: "[nbRtl]",
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRtlDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbRtl]",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.TemplateRef },
		{ type: i0.ViewContainerRef },
		{ type: i0.ChangeDetectorRef },
		{ type: NbLayoutDirectionService }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_LAYOUT_COMPONENTS = [
	NbLayoutComponent,
	NbLayoutColumnComponent,
	NbLayoutFooterComponent,
	NbLayoutHeaderComponent
];
const NB_LAYOUT_DIRECTIVES = [NbLtrDirective, NbRtlDirective];
var NbLayoutModule = class NbLayoutModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutModule,
			declarations: [
				NbLayoutComponent,
				NbLayoutColumnComponent,
				NbLayoutFooterComponent,
				NbLayoutHeaderComponent,
				NbLtrDirective,
				NbRtlDirective
			],
			imports: [NbSharedModule],
			exports: [
				NbLayoutComponent,
				NbLayoutColumnComponent,
				NbLayoutFooterComponent,
				NbLayoutHeaderComponent,
				NbLtrDirective,
				NbRtlDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbLayoutModule,
			providers: [NbRestoreScrollTopHelper],
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbLayoutModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: [...NB_LAYOUT_COMPONENTS, ...NB_LAYOUT_DIRECTIVES],
			providers: [NbRestoreScrollTopHelper],
			exports: [...NB_LAYOUT_COMPONENTS, ...NB_LAYOUT_DIRECTIVES]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const itemClick$ = new Subject();
const addItems$ = new ReplaySubject(1);
const navigateHome$ = new ReplaySubject(1);
const getSelectedItem$ = new ReplaySubject(1);
const itemSelect$ = new ReplaySubject(1);
const itemHover$ = new ReplaySubject(1);
const submenuToggle$ = new ReplaySubject(1);
const collapseAll$ = new ReplaySubject(1);
var NbMenuItem = class {
	constructor() {
		this.pathMatch = "full";
	}
	static getParents(item) {
		const parents = [];
		let parent = item.parent;
		while (parent) {
			parents.unshift(parent);
			parent = parent.parent;
		}
		return parents;
	}
	static isParent(item, possibleChild) {
		return possibleChild.parent ? possibleChild.parent === item || this.isParent(item, possibleChild.parent) : false;
	}
};
var NbMenuService = class NbMenuService {
	addItems(items, tag) {
		addItems$.next({
			tag,
			items
		});
	}
	collapseAll(tag) {
		collapseAll$.next({ tag });
	}
	navigateHome(tag) {
		navigateHome$.next({ tag });
	}
	getSelectedItem(tag) {
		const listener = new BehaviorSubject(null);
		getSelectedItem$.next({
			tag,
			listener
		});
		return listener.asObservable();
	}
	onItemClick() {
		return itemClick$.pipe(share());
	}
	onItemSelect() {
		return itemSelect$.pipe(share());
	}
	onItemHover() {
		return itemHover$.pipe(share());
	}
	onSubmenuToggle() {
		return submenuToggle$.pipe(share());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMenuService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var NbMenuInternalService = class NbMenuInternalService {
	constructor(location) {
		this.location = location;
	}
	prepareItems(items) {
		const defaultItem = new NbMenuItem();
		items.forEach((i) => {
			this.applyDefaults(i, defaultItem);
			this.setParent(i);
		});
	}
	selectFromUrl(items, tag, collapseOther = false) {
		const selectedItem = this.findItemByUrl(items);
		if (selectedItem) this.selectItem(selectedItem, items, collapseOther, tag);
	}
	selectItem(item, items, collapseOther = false, tag) {
		const unselectedItems = this.resetSelection(items);
		const collapsedItems = collapseOther ? this.collapseItems(items) : [];
		for (const parent of NbMenuItem.getParents(item)) {
			parent.selected = true;
			if (!unselectedItems.includes(parent)) this.itemSelect(parent, tag);
			const wasNotExpanded = !parent.expanded;
			parent.expanded = true;
			const i = collapsedItems.indexOf(parent);
			if (i === -1 && wasNotExpanded) this.submenuToggle(parent, tag);
			else collapsedItems.splice(i, 1);
		}
		item.selected = true;
		if (!unselectedItems.includes(item)) this.itemSelect(item, tag);
		for (const collapsedItem of collapsedItems) this.submenuToggle(collapsedItem, tag);
	}
	collapseAll(items, tag, except) {
		const collapsedItems = this.collapseItems(items, except);
		for (const item of collapsedItems) this.submenuToggle(item, tag);
	}
	onAddItem() {
		return addItems$.pipe(share());
	}
	onNavigateHome() {
		return navigateHome$.pipe(share());
	}
	onCollapseAll() {
		return collapseAll$.pipe(share());
	}
	onGetSelectedItem() {
		return getSelectedItem$.pipe(share());
	}
	itemHover(item, tag) {
		itemHover$.next({
			tag,
			item
		});
	}
	submenuToggle(item, tag) {
		submenuToggle$.next({
			tag,
			item
		});
	}
	itemSelect(item, tag) {
		itemSelect$.next({
			tag,
			item
		});
	}
	itemClick(item, tag) {
		itemClick$.next({
			tag,
			item
		});
	}
	resetSelection(items) {
		const unselectedItems = [];
		for (const item of items) {
			if (item.selected) unselectedItems.push(item);
			item.selected = false;
			if (item.children) unselectedItems.push(...this.resetSelection(item.children));
		}
		return unselectedItems;
	}
	collapseItems(items, except) {
		const collapsedItems = [];
		for (const item of items) {
			if (except && (item === except || NbMenuItem.isParent(item, except))) continue;
			if (item.expanded) collapsedItems.push(item);
			item.expanded = false;
			if (item.children) collapsedItems.push(...this.collapseItems(item.children));
		}
		return collapsedItems;
	}
	applyDefaults(item, defaultItem) {
		const menuItem = { ...item };
		Object.assign(item, defaultItem, menuItem);
		item.children && item.children.forEach((child) => {
			this.applyDefaults(child, defaultItem);
		});
	}
	setParent(item) {
		item.children && item.children.forEach((child) => {
			child.parent = item;
			this.setParent(child);
		});
	}
	findItemByUrl(items) {
		let selectedItem;
		items.some((item) => {
			if (item.children) selectedItem = this.findItemByUrl(item.children);
			if (!selectedItem && this.isSelectedInUrl(item)) selectedItem = item;
			return selectedItem;
		});
		return selectedItem;
	}
	isSelectedInUrl(item) {
		const exact = item.pathMatch === "full";
		const link = item.link;
		const isSelectedInPath = exact ? isUrlPathEqual(this.location.path(), link) : isUrlPathContain(this.location.path(), link);
		if (isSelectedInPath && item.fragment != null) return exact ? isFragmentEqual(this.location.path(true), item.fragment) : isFragmentContain(this.location.path(true), item.fragment);
		return isSelectedInPath;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuInternalService,
			deps: [{ token: i2.Location }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuInternalService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMenuInternalService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [{ type: i2.Location }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBadgeComponent = class NbBadgeComponent {
	get position() {
		return this._position;
	}
	set position(value) {
		this._position = value || this._defaultPosition;
	}
	get dotMode() {
		return this._dotMode;
	}
	set dotMode(value) {
		this._dotMode = convertToBoolProperty(value);
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get info() {
		return this.status === "info";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get top() {
		return this.position.includes("top");
	}
	get right() {
		return this.position.includes("right");
	}
	get bottom() {
		return this.position.includes("bottom");
	}
	get left() {
		return this.position.includes("left");
	}
	get start() {
		return this.position.includes("start");
	}
	get end() {
		return this.position.includes("end");
	}
	get center() {
		return this.position.includes("center");
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.text = "";
		this._defaultPosition = "top right";
		this._position = this._defaultPosition;
		this.status = "basic";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBadgeComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbBadgeComponent,
			isStandalone: false,
			selector: "nb-badge",
			inputs: {
				text: "text",
				position: "position",
				dotMode: "dotMode",
				status: "status"
			},
			host: { properties: {
				"class.dot-mode": "this.dotMode",
				"class": "this.additionalClasses",
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-info": "this.info",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.position-top": "this.top",
				"class.position-right": "this.right",
				"class.position-bottom": "this.bottom",
				"class.position-left": "this.left",
				"class.position-start": "this.start",
				"class.position-end": "this.end",
				"class.position-center": "this.center"
			} },
			ngImport: i0,
			template: `{{dotMode ? '' : text}}`,
			isInline: true,
			styles: [":host{position:absolute;text-align:center;white-space:nowrap;vertical-align:baseline}:host(.position-top){top:0}:host(.position-right){right:0}:host(.position-bottom){bottom:0}:host(.position-left){left:0}:host(.position-center){top:50%;transform:translateY(-50%)}[dir=ltr] :host(.position-start){left:0}[dir=rtl] :host(.position-start){right:0}[dir=ltr] :host(.position-end){right:0}[dir=rtl] :host(.position-end){left:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBadgeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-badge",
			template: `{{dotMode ? '' : text}}`,
			standalone: false,
			styles: [":host{position:absolute;text-align:center;white-space:nowrap;vertical-align:baseline}:host(.position-top){top:0}:host(.position-right){right:0}:host(.position-bottom){bottom:0}:host(.position-left){left:0}:host(.position-center){top:50%;transform:translateY(-50%)}[dir=ltr] :host(.position-start){left:0}[dir=rtl] :host(.position-start){right:0}[dir=ltr] :host(.position-end){right:0}[dir=rtl] :host(.position-end){left:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		text: [{ type: Input }],
		position: [{ type: Input }],
		dotMode: [{ type: Input }, {
			type: HostBinding,
			args: ["class.dot-mode"]
		}],
		status: [{ type: Input }],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		top: [{
			type: HostBinding,
			args: ["class.position-top"]
		}],
		right: [{
			type: HostBinding,
			args: ["class.position-right"]
		}],
		bottom: [{
			type: HostBinding,
			args: ["class.position-bottom"]
		}],
		left: [{
			type: HostBinding,
			args: ["class.position-left"]
		}],
		start: [{
			type: HostBinding,
			args: ["class.position-start"]
		}],
		end: [{
			type: HostBinding,
			args: ["class.position-end"]
		}],
		center: [{
			type: HostBinding,
			args: ["class.position-center"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToggleStates;
(function(NbToggleStates) {
	NbToggleStates["Expanded"] = "expanded";
	NbToggleStates["Collapsed"] = "collapsed";
})(NbToggleStates || (NbToggleStates = {}));
var NbMenuItemComponent = class NbMenuItemComponent {
	constructor(menuService, directionService) {
		this.menuService = menuService;
		this.directionService = directionService;
		this.menuItem = null;
		this.hoverItem = new EventEmitter();
		this.toggleSubMenu = new EventEmitter();
		this.selectItem = new EventEmitter();
		this.itemClick = new EventEmitter();
		this.destroy$ = new Subject();
		this.changeDetectorRef = inject(ChangeDetectorRef);
	}
	ngDoCheck() {
		this.toggleState = this.menuItem.expanded ? NbToggleStates.Expanded : NbToggleStates.Collapsed;
	}
	ngAfterViewInit() {
		this.directionService.onDirectionChange().pipe(takeUntil(this.destroy$)).subscribe(() => this.changeDetectorRef.markForCheck());
		this.menuService.onSubmenuToggle().pipe(filter(({ item }) => item === this.menuItem), map(({ item }) => item.expanded), takeUntil(this.destroy$)).subscribe((isExpanded) => this.toggleState = isExpanded ? NbToggleStates.Expanded : NbToggleStates.Collapsed);
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	onToggleSubMenu(item) {
		this.toggleSubMenu.emit(item);
	}
	onHoverItem(item) {
		this.hoverItem.emit(item);
	}
	onSelectItem(item) {
		this.selectItem.emit(item);
	}
	onItemClick(item) {
		this.itemClick.emit(item);
	}
	getExpandStateIcon() {
		if (this.menuItem.expanded) return "chevron-down-outline";
		return this.directionService.isLtr() ? "chevron-left-outline" : "chevron-right-outline";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuItemComponent,
			deps: [{ token: NbMenuService }, { token: NbLayoutDirectionService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbMenuItemComponent,
			isStandalone: false,
			selector: "[nbMenuItem]",
			inputs: {
				menuItem: "menuItem",
				badge: "badge"
			},
			outputs: {
				hoverItem: "hoverItem",
				toggleSubMenu: "toggleSubMenu",
				selectItem: "selectItem",
				itemClick: "itemClick"
			},
			ngImport: i0,
			template: "<span *ngIf=\"menuItem.group\">\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  {{ menuItem.title }}\n</span>\n<a\n  *ngIf=\"menuItem.link && !menuItem.url && !menuItem.children && !menuItem.group\"\n  [routerLink]=\"menuItem.link\"\n  [queryParams]=\"menuItem.queryParams\"\n  [fragment]=\"menuItem.fragment\"\n  [queryParamsHandling]=\"menuItem.queryParamsHandling\"\n  [preserveFragment]=\"menuItem.preserveFragment\"\n  [skipLocationChange]=\"menuItem.skipLocationChange\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"onItemClick(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"menuItem.url && !menuItem.children && !menuItem.link && !menuItem.group\"\n  [attr.href]=\"menuItem.url\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"onSelectItem(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"!menuItem.children && !menuItem.link && !menuItem.url && !menuItem.group\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"$event.preventDefault(); onItemClick(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"menuItem.children\"\n  (click)=\"$event.preventDefault(); onToggleSubMenu(menuItem)\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.aria-expanded]=\"menuItem.expanded ?? false\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  href=\"#\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n  <nb-icon class=\"expand-state\" [icon]=\"getExpandStateIcon()\" pack=\"nebular-essentials\"></nb-icon>\n</a>\n<ul\n  *ngIf=\"menuItem.children\"\n  [class.collapsed]=\"!(menuItem.children && menuItem.expanded)\"\n  [class.expanded]=\"menuItem.expanded\"\n  [@toggle]=\"toggleState\"\n  class=\"menu-items\"\n>\n  <ng-container *ngFor=\"let item of menuItem.children\">\n    <li\n      nbMenuItem\n      *ngIf=\"!item.hidden\"\n      [menuItem]=\"item\"\n      [badge]=\"item.badge\"\n      [class.menu-group]=\"item.group\"\n      (hoverItem)=\"onHoverItem($event)\"\n      (toggleSubMenu)=\"onToggleSubMenu($event)\"\n      (selectItem)=\"onSelectItem($event)\"\n      (itemClick)=\"onItemClick($event)\"\n      class=\"menu-item\"\n    ></li>\n  </ng-container>\n</ul>\n\n<ng-template #badgeTemplate>\n  <nb-badge [text]=\"badge.text\" [dotMode]=\"badge.dotMode\" [status]=\"badge.status\"> </nb-badge>\n</ng-template>\n",
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "directive",
					type: i1$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbBadgeComponent,
					selector: "nb-badge",
					inputs: [
						"text",
						"position",
						"dotMode",
						"status"
					]
				},
				{
					kind: "component",
					type: NbMenuItemComponent,
					selector: "[nbMenuItem]",
					inputs: ["menuItem", "badge"],
					outputs: [
						"hoverItem",
						"toggleSubMenu",
						"selectItem",
						"itemClick"
					]
				}
			],
			animations: [trigger("toggle", [
				state(NbToggleStates.Collapsed, style({
					height: "0",
					margin: "0"
				})),
				state(NbToggleStates.Expanded, style({ height: "*" })),
				transition(`${NbToggleStates.Collapsed} <=> ${NbToggleStates.Expanded}`, animate(300))
			])]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMenuItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "[nbMenuItem]",
			animations: [trigger("toggle", [
				state(NbToggleStates.Collapsed, style({
					height: "0",
					margin: "0"
				})),
				state(NbToggleStates.Expanded, style({ height: "*" })),
				transition(`${NbToggleStates.Collapsed} <=> ${NbToggleStates.Expanded}`, animate(300))
			])],
			standalone: false,
			template: "<span *ngIf=\"menuItem.group\">\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  {{ menuItem.title }}\n</span>\n<a\n  *ngIf=\"menuItem.link && !menuItem.url && !menuItem.children && !menuItem.group\"\n  [routerLink]=\"menuItem.link\"\n  [queryParams]=\"menuItem.queryParams\"\n  [fragment]=\"menuItem.fragment\"\n  [queryParamsHandling]=\"menuItem.queryParamsHandling\"\n  [preserveFragment]=\"menuItem.preserveFragment\"\n  [skipLocationChange]=\"menuItem.skipLocationChange\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"onItemClick(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"menuItem.url && !menuItem.children && !menuItem.link && !menuItem.group\"\n  [attr.href]=\"menuItem.url\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"onSelectItem(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"!menuItem.children && !menuItem.link && !menuItem.url && !menuItem.group\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  (click)=\"$event.preventDefault(); onItemClick(menuItem)\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n</a>\n<a\n  *ngIf=\"menuItem.children\"\n  (click)=\"$event.preventDefault(); onToggleSubMenu(menuItem)\"\n  [attr.target]=\"menuItem.target\"\n  [attr.title]=\"menuItem.title\"\n  [attr.aria-expanded]=\"menuItem.expanded ?? false\"\n  [attr.role]=\"menuItem.ariaRole\"\n  [class.active]=\"menuItem.selected\"\n  (mouseenter)=\"onHoverItem(menuItem)\"\n  href=\"#\"\n>\n  <nb-icon class=\"menu-icon\" [config]=\"menuItem.icon\" *ngIf=\"menuItem.icon\"></nb-icon>\n  <span class=\"menu-title\">{{ menuItem.title }}</span>\n  <ng-container *ngIf=\"badge\" [ngTemplateOutlet]=\"badgeTemplate\"></ng-container>\n  <nb-icon class=\"expand-state\" [icon]=\"getExpandStateIcon()\" pack=\"nebular-essentials\"></nb-icon>\n</a>\n<ul\n  *ngIf=\"menuItem.children\"\n  [class.collapsed]=\"!(menuItem.children && menuItem.expanded)\"\n  [class.expanded]=\"menuItem.expanded\"\n  [@toggle]=\"toggleState\"\n  class=\"menu-items\"\n>\n  <ng-container *ngFor=\"let item of menuItem.children\">\n    <li\n      nbMenuItem\n      *ngIf=\"!item.hidden\"\n      [menuItem]=\"item\"\n      [badge]=\"item.badge\"\n      [class.menu-group]=\"item.group\"\n      (hoverItem)=\"onHoverItem($event)\"\n      (toggleSubMenu)=\"onToggleSubMenu($event)\"\n      (selectItem)=\"onSelectItem($event)\"\n      (itemClick)=\"onItemClick($event)\"\n      class=\"menu-item\"\n    ></li>\n  </ng-container>\n</ul>\n\n<ng-template #badgeTemplate>\n  <nb-badge [text]=\"badge.text\" [dotMode]=\"badge.dotMode\" [status]=\"badge.status\"> </nb-badge>\n</ng-template>\n"
		}]
	}],
	ctorParameters: () => [{ type: NbMenuService }, { type: NbLayoutDirectionService }],
	propDecorators: {
		menuItem: [{ type: Input }],
		badge: [{ type: Input }],
		hoverItem: [{ type: Output }],
		toggleSubMenu: [{ type: Output }],
		selectItem: [{ type: Output }],
		itemClick: [{ type: Output }]
	}
});
var NbMenuComponent = class NbMenuComponent {
	get autoCollapse() {
		return this._autoCollapse;
	}
	set autoCollapse(value) {
		this._autoCollapse = convertToBoolProperty(value);
	}
	constructor(window, platformId, menuInternalService, router) {
		this.window = window;
		this.platformId = platformId;
		this.menuInternalService = menuInternalService;
		this.router = router;
		this._autoCollapse = false;
		this.destroy$ = new Subject();
		this.changeDetectorRef = inject(ChangeDetectorRef);
	}
	ngOnInit() {
		this.menuInternalService.prepareItems(this.items);
		this.menuInternalService.onAddItem().pipe(filter((data) => this.compareTag(data.tag)), takeUntil(this.destroy$)).subscribe((data) => this.onAddItem(data));
		this.menuInternalService.onNavigateHome().pipe(filter((data) => this.compareTag(data.tag)), takeUntil(this.destroy$)).subscribe(() => this.navigateHome());
		this.menuInternalService.onGetSelectedItem().pipe(filter((data) => this.compareTag(data.tag)), takeUntil(this.destroy$)).subscribe((data) => {
			data.listener.next({
				tag: this.tag,
				item: this.getSelectedItem(this.items)
			});
		});
		this.menuInternalService.onCollapseAll().pipe(filter((data) => this.compareTag(data.tag)), takeUntil(this.destroy$)).subscribe(() => this.collapseAll());
		this.router.events.pipe(filter((event) => event instanceof NavigationEnd), takeUntil(this.destroy$)).subscribe(() => {
			this.menuInternalService.selectFromUrl(this.items, this.tag, this.autoCollapse);
		});
	}
	ngAfterViewInit() {
		setTimeout(() => this.menuInternalService.selectFromUrl(this.items, this.tag, this.autoCollapse));
	}
	onAddItem(data) {
		this.items.push(...data.items);
		this.menuInternalService.prepareItems(this.items);
		this.menuInternalService.selectFromUrl(this.items, this.tag, this.autoCollapse);
		this.changeDetectorRef.markForCheck();
	}
	onHoverItem(item) {
		this.menuInternalService.itemHover(item, this.tag);
	}
	onToggleSubMenu(item) {
		if (this.autoCollapse) this.menuInternalService.collapseAll(this.items, this.tag, item);
		item.expanded = !item.expanded;
		this.menuInternalService.submenuToggle(item, this.tag);
	}
	onSelectItem(item) {
		this.menuInternalService.selectItem(item, this.items, this.autoCollapse, this.tag);
	}
	onItemClick(item) {
		this.menuInternalService.itemClick(item, this.tag);
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	navigateHome() {
		const homeItem = this.getHomeItem(this.items);
		if (homeItem) {
			if (homeItem.link) {
				const extras = {
					queryParams: homeItem.queryParams,
					queryParamsHandling: homeItem.queryParamsHandling,
					fragment: homeItem.fragment,
					preserveFragment: homeItem.preserveFragment
				};
				this.router.navigate([homeItem.link], extras);
			}
			if (homeItem.url && isPlatformBrowser(this.platformId)) this.window.location.href = homeItem.url;
		}
	}
	collapseAll() {
		this.menuInternalService.collapseAll(this.items, this.tag);
	}
	getHomeItem(items) {
		for (const item of items) {
			if (item.home) return item;
			const homeItem = item.children && this.getHomeItem(item.children);
			if (homeItem) return homeItem;
		}
	}
	compareTag(tag) {
		return !tag || tag === this.tag;
	}
	getSelectedItem(items) {
		let selected = null;
		items.forEach((item) => {
			if (item.selected) selected = item;
			if (item.selected && item.children && item.children.length > 0) selected = this.getSelectedItem(item.children);
		});
		return selected;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuComponent,
			deps: [
				{ token: NB_WINDOW },
				{ token: PLATFORM_ID },
				{ token: NbMenuInternalService },
				{ token: i1$1.Router }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbMenuComponent,
			isStandalone: false,
			selector: "nb-menu",
			inputs: {
				tag: "tag",
				items: "items",
				autoCollapse: "autoCollapse"
			},
			ngImport: i0,
			template: `
    <ul class="menu-items">
      <ng-container *ngFor="let item of items">
        <li
          nbMenuItem
          *ngIf="!item.hidden"
          [menuItem]="item"
          [badge]="item.badge"
          [class.menu-group]="item.group"
          (hoverItem)="onHoverItem($event)"
          (toggleSubMenu)="onToggleSubMenu($event)"
          (selectItem)="onSelectItem($event)"
          (itemClick)="onItemClick($event)"
          class="menu-item"
        ></li>
      </ng-container>
    </ul>
  `,
			isInline: true,
			styles: [":host ::ng-deep{display:block}:host ::ng-deep .menu-items,:host ::ng-deep .menu-item>.menu-items{list-style-type:none;overflow:hidden}:host ::ng-deep .menu-item a{display:flex;text-decoration:none;align-items:center}:host ::ng-deep .menu-item a .menu-title{flex:1 0 auto;pointer-events:none}[dir=rtl] :host ::ng-deep .menu-item a .menu-title{text-align:right}:host ::ng-deep .menu-item nb-badge{position:static}:host ::ng-deep .menu-group span{display:flex}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: NbMenuItemComponent,
					selector: "[nbMenuItem]",
					inputs: ["menuItem", "badge"],
					outputs: [
						"hoverItem",
						"toggleSubMenu",
						"selectItem",
						"itemClick"
					]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-menu",
			template: `
    <ul class="menu-items">
      <ng-container *ngFor="let item of items">
        <li
          nbMenuItem
          *ngIf="!item.hidden"
          [menuItem]="item"
          [badge]="item.badge"
          [class.menu-group]="item.group"
          (hoverItem)="onHoverItem($event)"
          (toggleSubMenu)="onToggleSubMenu($event)"
          (selectItem)="onSelectItem($event)"
          (itemClick)="onItemClick($event)"
          class="menu-item"
        ></li>
      </ng-container>
    </ul>
  `,
			standalone: false,
			styles: [":host ::ng-deep{display:block}:host ::ng-deep .menu-items,:host ::ng-deep .menu-item>.menu-items{list-style-type:none;overflow:hidden}:host ::ng-deep .menu-item a{display:flex;text-decoration:none;align-items:center}:host ::ng-deep .menu-item a .menu-title{flex:1 0 auto;pointer-events:none}[dir=rtl] :host ::ng-deep .menu-item a .menu-title{text-align:right}:host ::ng-deep .menu-item nb-badge{position:static}:host ::ng-deep .menu-group span{display:flex}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{ type: NbMenuInternalService },
		{ type: i1$1.Router }
	],
	propDecorators: {
		tag: [{ type: Input }],
		items: [{ type: Input }],
		autoCollapse: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbBadgeModule = class NbBadgeModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBadgeModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBadgeModule,
			declarations: [NbBadgeComponent],
			exports: [NbBadgeComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBadgeModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBadgeModule,
	decorators: [{
		type: NgModule,
		args: [{
			exports: [NbBadgeComponent],
			declarations: [NbBadgeComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const nbMenuComponents = [NbMenuComponent, NbMenuItemComponent];
const NB_MENU_PROVIDERS = [NbMenuService, NbMenuInternalService];
var NbMenuModule = class NbMenuModule {
	static forRoot() {
		return {
			ngModule: NbMenuModule,
			providers: [...NB_MENU_PROVIDERS]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuModule,
			declarations: [NbMenuComponent, NbMenuItemComponent],
			imports: [
				NbSharedModule,
				NbIconModule,
				NbBadgeModule
			],
			exports: [NbMenuComponent, NbMenuItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMenuModule,
			imports: [
				NbSharedModule,
				NbIconModule,
				NbBadgeModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMenuModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbIconModule,
				NbBadgeModule
			],
			declarations: [...nbMenuComponents],
			exports: [...nbMenuComponents]
		}]
	}]
});
var NbMergeConfigsPipe = class NbMergeConfigsPipe {
	transform(...configs) {
		return Object.assign({}, ...configs);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMergeConfigsPipe,
			deps: [],
			target: i0.ɵɵFactoryTarget.Pipe
		});
	}
	static {
		this.ɵpipe = i0.ɵɵngDeclarePipe({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbMergeConfigsPipe,
			isStandalone: false,
			name: "nbMergeConfigs"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbMergeConfigsPipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "nbMergeConfigs",
			standalone: false
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRouteTabsetComponent = class NbRouteTabsetComponent {
	constructor() {
		this.fullWidthValue = false;
		this.activeLinkOptions = { exact: true };
		this.changeTab = new EventEmitter();
	}
	set fullWidth(val) {
		this.fullWidthValue = convertToBoolProperty(val);
	}
	selectTab(tab) {
		this.changeTab.emit(tab);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRouteTabsetComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRouteTabsetComponent,
			isStandalone: false,
			selector: "nb-route-tabset",
			inputs: {
				tabs: "tabs",
				activeLinkOptions: "activeLinkOptions",
				fullWidth: "fullWidth"
			},
			outputs: { changeTab: "changeTab" },
			host: { properties: { "class.full-width": "this.fullWidthValue" } },
			ngImport: i0,
			template: `
    <ul class="route-tabset">
      <ng-container *ngFor="let tab of tabs">
        <li
          *ngIf="tab.disabled; else enabled"
          [class.responsive]="tab.responsive"
          class="route-tab disabled"
          tabindex="-1"
        >
          <a tabindex="-1" class="tab-link">
            <nb-icon *ngIf="tab.icon" [config]="tab.icon"></nb-icon>
            <span *ngIf="tab.title" class="tab-text">{{ tab.title }}</span>
          </a>
        </li>

        <ng-template #enabled>
          <li
            routerLinkActive="active"
            [routerLinkActiveOptions]="activeLinkOptions | nbMergeConfigs: tab.activeLinkOptions"
            class="route-tab"
          >
            <a
              (click)="selectTab(tab)"
              [routerLink]="tab.route"
              [class.responsive]="tab.responsive"
              [queryParams]="tab.queryParams"
              [queryParamsHandling]="tab.queryParamsHandling"
              [fragment]="tab.fragment"
              [preserveFragment]="tab.preserveFragment"
              [skipLocationChange]="tab.skipLocationChange"
              [replaceUrl]="tab.replaceUrl"
              [state]="tab.state"
              class="tab-link"
            >
              <nb-icon *ngIf="tab.icon" [config]="tab.icon"></nb-icon>
              <span *ngIf="tab.title" class="tab-text">{{ tab.title }}</span>
            </a>
          </li>
        </ng-template>
      </ng-container>
    </ul>
    <router-outlet></router-outlet>
  `,
			isInline: true,
			styles: [".route-tabset{display:flex;flex-direction:row;list-style-type:none;margin:0;padding:0}.route-tabset .route-tab{margin-bottom:-1px;text-align:center;padding:0}.route-tabset .route-tab.active a:before{display:block}.route-tabset .route-tab a{position:relative;text-decoration:none;display:inline-block}.route-tabset .route-tab a:before{position:absolute;content:\"\";width:100%;border-radius:3px;bottom:-2px;left:0}.route-tabset .route-tab a nb-icon{vertical-align:middle}[dir=ltr] :host .tab-link nb-icon+span{margin-left:.5rem}[dir=rtl] :host .tab-link nb-icon+span{margin-right:.5rem}:host(.full-width) .route-tabset{justify-content:space-around}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i1$1.RouterOutlet,
					selector: "router-outlet",
					inputs: ["name", "routerOutletData"],
					outputs: [
						"activate",
						"deactivate",
						"attach",
						"detach"
					],
					exportAs: ["outlet"]
				},
				{
					kind: "directive",
					type: i1$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: i1$1.RouterLinkActive,
					selector: "[routerLinkActive]",
					inputs: [
						"routerLinkActiveOptions",
						"ariaCurrentWhenActive",
						"routerLinkActive"
					],
					outputs: ["isActiveChange"],
					exportAs: ["routerLinkActive"]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "pipe",
					type: NbMergeConfigsPipe,
					name: "nbMergeConfigs"
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRouteTabsetComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-route-tabset",
			template: `
    <ul class="route-tabset">
      <ng-container *ngFor="let tab of tabs">
        <li
          *ngIf="tab.disabled; else enabled"
          [class.responsive]="tab.responsive"
          class="route-tab disabled"
          tabindex="-1"
        >
          <a tabindex="-1" class="tab-link">
            <nb-icon *ngIf="tab.icon" [config]="tab.icon"></nb-icon>
            <span *ngIf="tab.title" class="tab-text">{{ tab.title }}</span>
          </a>
        </li>

        <ng-template #enabled>
          <li
            routerLinkActive="active"
            [routerLinkActiveOptions]="activeLinkOptions | nbMergeConfigs: tab.activeLinkOptions"
            class="route-tab"
          >
            <a
              (click)="selectTab(tab)"
              [routerLink]="tab.route"
              [class.responsive]="tab.responsive"
              [queryParams]="tab.queryParams"
              [queryParamsHandling]="tab.queryParamsHandling"
              [fragment]="tab.fragment"
              [preserveFragment]="tab.preserveFragment"
              [skipLocationChange]="tab.skipLocationChange"
              [replaceUrl]="tab.replaceUrl"
              [state]="tab.state"
              class="tab-link"
            >
              <nb-icon *ngIf="tab.icon" [config]="tab.icon"></nb-icon>
              <span *ngIf="tab.title" class="tab-text">{{ tab.title }}</span>
            </a>
          </li>
        </ng-template>
      </ng-container>
    </ul>
    <router-outlet></router-outlet>
  `,
			standalone: false,
			styles: [".route-tabset{display:flex;flex-direction:row;list-style-type:none;margin:0;padding:0}.route-tabset .route-tab{margin-bottom:-1px;text-align:center;padding:0}.route-tabset .route-tab.active a:before{display:block}.route-tabset .route-tab a{position:relative;text-decoration:none;display:inline-block}.route-tabset .route-tab a:before{position:absolute;content:\"\";width:100%;border-radius:3px;bottom:-2px;left:0}.route-tabset .route-tab a nb-icon{vertical-align:middle}[dir=ltr] :host .tab-link nb-icon+span{margin-left:.5rem}[dir=rtl] :host .tab-link nb-icon+span{margin-right:.5rem}:host(.full-width) .route-tabset{justify-content:space-around}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		fullWidthValue: [{
			type: HostBinding,
			args: ["class.full-width"]
		}],
		tabs: [{ type: Input }],
		activeLinkOptions: [{ type: Input }],
		fullWidth: [{ type: Input }],
		changeTab: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRouteTabsetModule = class NbRouteTabsetModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRouteTabsetModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRouteTabsetModule,
			declarations: [NbRouteTabsetComponent, NbMergeConfigsPipe],
			imports: [NbSharedModule, NbIconModule],
			exports: [NbRouteTabsetComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRouteTabsetModule,
			imports: [NbSharedModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRouteTabsetModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbIconModule],
			declarations: [NbRouteTabsetComponent, NbMergeConfigsPipe],
			exports: [NbRouteTabsetComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const getSidebarState$ = new Subject();
const getSidebarResponsiveState$ = new Subject();
var NbSidebarService = class NbSidebarService {
	constructor() {
		this.toggle$ = new Subject();
		this.expand$ = new Subject();
		this.collapse$ = new Subject();
		this.compact$ = new Subject();
	}
	onToggle() {
		return this.toggle$.pipe(share());
	}
	onExpand() {
		return this.expand$.pipe(share());
	}
	onCollapse() {
		return this.collapse$.pipe(share());
	}
	onCompact() {
		return this.compact$.pipe(share());
	}
	toggle(compact = false, tag) {
		this.toggle$.next({
			compact,
			tag
		});
	}
	expand(tag) {
		this.expand$.next({ tag });
	}
	collapse(tag) {
		this.collapse$.next({ tag });
	}
	compact(tag) {
		this.compact$.next({ tag });
	}
	getSidebarState(tag) {
		const observer = new ReplaySubject(1);
		getSidebarState$.next({
			observer,
			tag
		});
		return observer.pipe(publish(), refCount());
	}
	getSidebarResponsiveState(tag) {
		const observer = new ReplaySubject();
		getSidebarResponsiveState$.next({
			observer,
			tag
		});
		return observer.pipe(publish(), refCount());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSidebarService,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSidebarHeaderComponent = class NbSidebarHeaderComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarHeaderComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSidebarHeaderComponent,
			isStandalone: false,
			selector: "nb-sidebar-header",
			ngImport: i0,
			template: ` <ng-content></ng-content> `,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSidebarHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-sidebar-header",
			template: ` <ng-content></ng-content> `,
			standalone: false
		}]
	}]
});
var NbSidebarFooterComponent = class NbSidebarFooterComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarFooterComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSidebarFooterComponent,
			isStandalone: false,
			selector: "nb-sidebar-footer",
			ngImport: i0,
			template: ` <ng-content></ng-content> `,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSidebarFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-sidebar-footer",
			template: ` <ng-content></ng-content> `,
			standalone: false
		}]
	}]
});
var NbSidebarComponent = class NbSidebarComponent {
	get expanded() {
		return this.state === "expanded";
	}
	get collapsed() {
		return this.state === "collapsed";
	}
	get compacted() {
		return this.state === "compacted";
	}
	set right(val) {
		this.rightValue = convertToBoolProperty(val);
		this.leftValue = !this.rightValue;
		this.startValue = false;
		this.endValue = false;
	}
	set left(val) {
		this.leftValue = convertToBoolProperty(val);
		this.rightValue = !this.leftValue;
		this.startValue = false;
		this.endValue = false;
	}
	set start(val) {
		this.startValue = convertToBoolProperty(val);
		this.endValue = !this.startValue;
		this.leftValue = false;
		this.rightValue = false;
	}
	set end(val) {
		this.endValue = convertToBoolProperty(val);
		this.startValue = !this.endValue;
		this.leftValue = false;
		this.rightValue = false;
	}
	set fixed(val) {
		this.fixedValue = convertToBoolProperty(val);
	}
	set containerFixed(val) {
		this.containerFixedValue = convertToBoolProperty(val);
	}
	get state() {
		return this._state;
	}
	set state(value) {
		this._state = value;
	}
	get responsive() {
		return this._responsive;
	}
	set responsive(value) {
		if (this.responsive !== convertToBoolProperty(value)) {
			this._responsive = !this.responsive;
			this.responsiveValueChange$.next(this.responsive);
		}
	}
	constructor(sidebarService, themeService, element, cd) {
		this.sidebarService = sidebarService;
		this.themeService = themeService;
		this.element = element;
		this.cd = cd;
		this.responsiveValueChange$ = new Subject();
		this.responsiveState = "pc";
		this.destroy$ = new Subject();
		this.containerFixedValue = true;
		this.fixedValue = false;
		this.rightValue = false;
		this.leftValue = true;
		this.startValue = false;
		this.endValue = false;
		this._state = "expanded";
		this._responsive = false;
		this.compactedBreakpoints = [
			"xs",
			"is",
			"sm",
			"md",
			"lg"
		];
		this.collapsedBreakpoints = ["xs", "is"];
		this.stateChange = new EventEmitter();
		this.responsiveStateChange = new EventEmitter();
	}
	ngOnInit() {
		this.sidebarService.onToggle().pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(({ compact }) => this.toggle(compact));
		this.sidebarService.onExpand().pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(() => this.expand());
		this.sidebarService.onCollapse().pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(() => this.collapse());
		this.sidebarService.onCompact().pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(() => this.compact());
		getSidebarState$.pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(({ observer }) => observer.next(this.state));
		getSidebarResponsiveState$.pipe(filter(({ tag }) => !this.tag || this.tag === tag), takeUntil(this.destroy$)).subscribe(({ observer }) => observer.next(this.responsiveState));
		this.responsiveValueChange$.pipe(filter((responsive) => !responsive), takeUntil(this.destroy$)).subscribe(() => this.expand());
		this.subscribeToMediaQueryChange();
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	onClick(event) {
		const menu = this.element.nativeElement.querySelector("nb-menu");
		if (menu && menu.contains(event.target)) {
			const link = this.getMenuLink(event.target);
			if (link && link.nextElementSibling && link.nextElementSibling.classList.contains("menu-items")) this.sidebarService.expand(this.tag);
		}
	}
	collapse() {
		this.updateState("collapsed");
	}
	expand() {
		this.updateState("expanded");
	}
	compact() {
		this.updateState("compacted");
	}
	toggle(compact = false) {
		if (this.responsive) {
			if (this.responsiveState === "mobile") compact = false;
		}
		if (this.state === "compacted" || this.state === "collapsed") this.updateState("expanded");
		else this.updateState(compact ? "compacted" : "collapsed");
	}
	subscribeToMediaQueryChange() {
		combineLatest([this.responsiveValueChange$.pipe(startWith(this.responsive)), this.themeService.onMediaQueryChange()]).pipe(filter(([responsive]) => responsive), map(([, breakpoints]) => breakpoints), takeUntil(this.destroy$)).subscribe(([prev, current]) => {
			const isCollapsed = this.collapsedBreakpoints.includes(current.name);
			const isCompacted = this.compactedBreakpoints.includes(current.name);
			let newResponsiveState;
			if (isCompacted) {
				this.fixed = this.containerFixedValue;
				this.compact();
				newResponsiveState = "tablet";
			}
			if (isCollapsed) {
				this.fixed = true;
				this.collapse();
				newResponsiveState = "mobile";
			}
			if (!isCollapsed && !isCompacted && (!prev.width || prev.width < current.width)) {
				this.expand();
				this.fixed = false;
				newResponsiveState = "pc";
			}
			if (newResponsiveState && newResponsiveState !== this.responsiveState) {
				this.responsiveState = newResponsiveState;
				this.responsiveStateChange.emit(this.responsiveState);
				this.cd.markForCheck();
			}
		});
	}
	getMenuLink(element) {
		if (!element || element.tagName.toLowerCase() === "nb-menu") return;
		if (element.tagName.toLowerCase() === "a") return element;
		return this.getMenuLink(element.parentElement);
	}
	updateState(state) {
		if (this.state !== state) {
			this.state = state;
			this.stateChange.emit(this.state);
			this.cd.markForCheck();
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarComponent,
			deps: [
				{ token: NbSidebarService },
				{ token: NbThemeService },
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSidebarComponent,
			isStandalone: false,
			selector: "nb-sidebar",
			inputs: {
				right: "right",
				left: "left",
				start: "start",
				end: "end",
				fixed: "fixed",
				containerFixed: "containerFixed",
				state: "state",
				responsive: "responsive",
				tag: "tag",
				compactedBreakpoints: "compactedBreakpoints",
				collapsedBreakpoints: "collapsedBreakpoints"
			},
			outputs: {
				stateChange: "stateChange",
				responsiveStateChange: "responsiveStateChange"
			},
			host: { properties: {
				"class.fixed": "this.fixedValue",
				"class.right": "this.rightValue",
				"class.left": "this.leftValue",
				"class.start": "this.startValue",
				"class.end": "this.endValue",
				"class.expanded": "this.expanded",
				"class.collapsed": "this.collapsed",
				"class.compacted": "this.compacted"
			} },
			ngImport: i0,
			template: `
    <div class="main-container" [class.main-container-fixed]="containerFixedValue">
      <ng-content select="nb-sidebar-header"></ng-content>
      <div class="scrollable" (click)="onClick($event)">
        <ng-content></ng-content>
      </div>
      <ng-content select="nb-sidebar-footer"></ng-content>
    </div>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column;overflow:hidden;z-index:auto;order:0}:host .scrollable{overflow-y:auto;overflow-x:hidden;flex:1}:host .main-container{transform:translateZ(0);display:flex;flex-direction:column}:host .main-container-fixed{position:fixed}[dir=ltr] :host.right{order:4}[dir=rtl] :host.right{order:0}:host.right{margin-right:0;margin-left:auto}:host.end{order:4}[dir=ltr] :host.end{margin-right:0;margin-left:auto}[dir=rtl] :host.end{margin-left:0;margin-right:auto}:host.fixed{position:fixed;height:100%;z-index:999;top:0;bottom:0;left:0}:host.fixed.right{right:0}[dir=ltr] :host.fixed.start{left:0}[dir=rtl] :host.fixed.start{right:0}[dir=ltr] :host.fixed.end{right:0}[dir=rtl] :host.fixed.end{left:0}:host ::ng-deep nb-sidebar-footer{margin-top:auto;display:block}:host ::ng-deep nb-sidebar-header{display:block}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSidebarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-sidebar",
			template: `
    <div class="main-container" [class.main-container-fixed]="containerFixedValue">
      <ng-content select="nb-sidebar-header"></ng-content>
      <div class="scrollable" (click)="onClick($event)">
        <ng-content></ng-content>
      </div>
      <ng-content select="nb-sidebar-footer"></ng-content>
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column;overflow:hidden;z-index:auto;order:0}:host .scrollable{overflow-y:auto;overflow-x:hidden;flex:1}:host .main-container{transform:translateZ(0);display:flex;flex-direction:column}:host .main-container-fixed{position:fixed}[dir=ltr] :host.right{order:4}[dir=rtl] :host.right{order:0}:host.right{margin-right:0;margin-left:auto}:host.end{order:4}[dir=ltr] :host.end{margin-right:0;margin-left:auto}[dir=rtl] :host.end{margin-left:0;margin-right:auto}:host.fixed{position:fixed;height:100%;z-index:999;top:0;bottom:0;left:0}:host.fixed.right{right:0}[dir=ltr] :host.fixed.start{left:0}[dir=rtl] :host.fixed.start{right:0}[dir=ltr] :host.fixed.end{right:0}[dir=rtl] :host.fixed.end{left:0}:host ::ng-deep nb-sidebar-footer{margin-top:auto;display:block}:host ::ng-deep nb-sidebar-header{display:block}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbSidebarService },
		{ type: NbThemeService },
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: {
		fixedValue: [{
			type: HostBinding,
			args: ["class.fixed"]
		}],
		rightValue: [{
			type: HostBinding,
			args: ["class.right"]
		}],
		leftValue: [{
			type: HostBinding,
			args: ["class.left"]
		}],
		startValue: [{
			type: HostBinding,
			args: ["class.start"]
		}],
		endValue: [{
			type: HostBinding,
			args: ["class.end"]
		}],
		expanded: [{
			type: HostBinding,
			args: ["class.expanded"]
		}],
		collapsed: [{
			type: HostBinding,
			args: ["class.collapsed"]
		}],
		compacted: [{
			type: HostBinding,
			args: ["class.compacted"]
		}],
		right: [{ type: Input }],
		left: [{ type: Input }],
		start: [{ type: Input }],
		end: [{ type: Input }],
		fixed: [{ type: Input }],
		containerFixed: [{ type: Input }],
		state: [{ type: Input }],
		responsive: [{ type: Input }],
		tag: [{ type: Input }],
		compactedBreakpoints: [{ type: Input }],
		collapsedBreakpoints: [{ type: Input }],
		stateChange: [{ type: Output }],
		responsiveStateChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_SIDEBAR_COMPONENTS = [
	NbSidebarComponent,
	NbSidebarFooterComponent,
	NbSidebarHeaderComponent
];
const NB_SIDEBAR_PROVIDERS = [NbSidebarService];
var NbSidebarModule = class NbSidebarModule {
	static forRoot() {
		return {
			ngModule: NbSidebarModule,
			providers: [...NB_SIDEBAR_PROVIDERS]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarModule,
			declarations: [
				NbSidebarComponent,
				NbSidebarFooterComponent,
				NbSidebarHeaderComponent
			],
			imports: [NbSharedModule],
			exports: [
				NbSidebarComponent,
				NbSidebarFooterComponent,
				NbSidebarHeaderComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSidebarModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSidebarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: [...NB_SIDEBAR_COMPONENTS],
			exports: [...NB_SIDEBAR_COMPONENTS]
		}]
	}]
});
var NbTabContentDirective = class NbTabContentDirective {
	constructor(templateRef) {
		this.templateRef = templateRef;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabContentDirective,
			deps: [{ token: i0.TemplateRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTabContentDirective,
			isStandalone: false,
			selector: "[nbTabContent]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTabContentDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTabContent]",
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var NbTabTitleDirective = class NbTabTitleDirective {
	constructor(templateRef) {
		this.templateRef = templateRef;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabTitleDirective,
			deps: [{ token: i0.TemplateRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTabTitleDirective,
			isStandalone: false,
			selector: "[nbTabTitle]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTabTitleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTabTitle]",
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTabComponent = class NbTabComponent {
	constructor() {
		this.activeValue = false;
		this.responsiveValue = false;
		this.disabledValue = false;
		this.badgeStatus = "basic";
		this.init = false;
	}
	get badgeDot() {
		return this._badgeDot;
	}
	set badgeDot(val) {
		this._badgeDot = convertToBoolProperty(val);
	}
	get disabled() {
		return this.disabledValue;
	}
	set disabled(val) {
		this.disabledValue = convertToBoolProperty(val);
	}
	set responsive(val) {
		this.responsiveValue = convertToBoolProperty(val);
	}
	get responsive() {
		return this.responsiveValue;
	}
	get active() {
		return this.activeValue;
	}
	set active(val) {
		this.activeValue = convertToBoolProperty(val);
		if (this.activeValue) this.init = true;
	}
	set lazyLoad(val) {
		this.init = convertToBoolProperty(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTabComponent,
			isStandalone: false,
			selector: "nb-tab",
			inputs: {
				tabTitle: "tabTitle",
				tabId: "tabId",
				badgeDot: "badgeDot",
				tabIcon: "tabIcon",
				disabled: "disabled",
				responsive: "responsive",
				route: "route",
				active: "active",
				lazyLoad: "lazyLoad",
				badgeText: "badgeText",
				badgeStatus: "badgeStatus",
				badgePosition: "badgePosition"
			},
			host: { properties: {
				"class.disabled": "this.disabled",
				"class.content-active": "this.activeValue"
			} },
			queries: [{
				propertyName: "tabContentDirective",
				first: true,
				predicate: NbTabContentDirective,
				descendants: true
			}, {
				propertyName: "tabTitleDirective",
				first: true,
				predicate: NbTabTitleDirective,
				descendants: true
			}],
			ngImport: i0,
			template: `
    <ng-container
      *ngIf="tabContentDirective; else projectedContent"
      [ngTemplateOutlet]="tabContentDirective.templateRef"
    ></ng-container>

    <ng-template #projectedContent>
      <ng-content></ng-content>
    </ng-template>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "directive",
				type: i2.NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTabComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tab",
			template: `
    <ng-container
      *ngIf="tabContentDirective; else projectedContent"
      [ngTemplateOutlet]="tabContentDirective.templateRef"
    ></ng-container>

    <ng-template #projectedContent>
      <ng-content></ng-content>
    </ng-template>
  `,
			standalone: false
		}]
	}],
	propDecorators: {
		tabContentDirective: [{
			type: ContentChild,
			args: [NbTabContentDirective]
		}],
		tabTitleDirective: [{
			type: ContentChild,
			args: [NbTabTitleDirective]
		}],
		tabTitle: [{ type: Input }],
		tabId: [{ type: Input }],
		badgeDot: [{ type: Input }],
		tabIcon: [{ type: Input }],
		disabled: [{
			type: Input,
			args: ["disabled"]
		}, {
			type: HostBinding,
			args: ["class.disabled"]
		}],
		responsive: [{ type: Input }],
		route: [{ type: Input }],
		activeValue: [{
			type: HostBinding,
			args: ["class.content-active"]
		}],
		active: [{ type: Input }],
		lazyLoad: [{ type: Input }],
		badgeText: [{ type: Input }],
		badgeStatus: [{ type: Input }],
		badgePosition: [{ type: Input }]
	}
});
var NbTabsetComponent = class NbTabsetComponent {
	set fullWidth(val) {
		this.fullWidthValue = convertToBoolProperty(val);
	}
	constructor(route, changeDetectorRef) {
		this.route = route;
		this.changeDetectorRef = changeDetectorRef;
		this.fullWidthValue = false;
		this.changeTab = new EventEmitter();
		this.destroy$ = new Subject();
	}
	ngAfterContentInit() {
		this.route.params.pipe(map((params) => this.tabs.find((tab) => this.routeParam ? tab.route === params[this.routeParam] : tab.active)), delay(0), map((tab) => tab || this.tabs.first), filter((tab) => !!tab), takeUntil(this.destroy$)).subscribe((tabToSelect) => {
			this.selectTab(tabToSelect);
			this.changeDetectorRef.markForCheck();
		});
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	selectTab(selectedTab) {
		if (!selectedTab.disabled) {
			this.tabs.forEach((tab) => tab.active = tab === selectedTab);
			this.changeTab.emit(selectedTab);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabsetComponent,
			deps: [{ token: i1$1.ActivatedRoute }, { token: i0.ChangeDetectorRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTabsetComponent,
			isStandalone: false,
			selector: "nb-tabset",
			inputs: {
				fullWidth: "fullWidth",
				routeParam: "routeParam"
			},
			outputs: { changeTab: "changeTab" },
			host: { properties: { "class.full-width": "this.fullWidthValue" } },
			queries: [{
				propertyName: "tabs",
				predicate: NbTabComponent
			}],
			ngImport: i0,
			template: `
    <ul class="tabset">
      <li
        *ngFor="let tab of tabs"
        (click)="selectTab(tab)"
        (keyup.space)="selectTab(tab)"
        (keyup.enter)="selectTab(tab)"
        [class.responsive]="tab.responsive"
        [class.active]="tab.active"
        [class.disabled]="tab.disabled"
        [attr.tabindex]="tab.disabled ? -1 : 0"
        [attr.data-tab-id]="tab.tabId"
        class="tab"
      >
        <a href (click)="$event.preventDefault()" tabindex="-1" class="tab-link">
          <nb-icon *ngIf="tab.tabIcon" [config]="tab.tabIcon"></nb-icon>
          <ng-container
            *ngIf="tab.tabTitleDirective; else textTitleTemplate"
            [ngTemplateOutlet]="tab.tabTitleDirective.templateRef"
          ></ng-container>
          <ng-template #textTitleTemplate>
            <span class="tab-text">{{ tab.tabTitle }}</span>
          </ng-template>
        </a>
        <nb-badge
          *ngIf="tab.badgeText || tab.badgeDot"
          [text]="tab.badgeText"
          [dotMode]="tab.badgeDot"
          [status]="tab.badgeStatus"
          [position]="tab.badgePosition"
        >
        </nb-badge>
      </li>
    </ul>
    <ng-content select="nb-tab"></ng-content>
  `,
			isInline: true,
			styles: [":host{display:block}:host.full-width .tabset{justify-content:space-around}:host ::ng-deep nb-tab{flex:1;-ms-flex:1 1 auto;overflow:auto;display:none}:host ::ng-deep nb-tab.content-active{display:block}:host .tabset{display:flex;flex-direction:row;list-style-type:none;margin:0;padding:0}:host .tabset .tab{margin-bottom:-1px;text-align:center;position:relative}:host .tabset .tab.active a:before{display:block}:host .tabset .tab a{display:flex;position:relative;text-decoration:none}:host .tabset .tab a:before{position:absolute;content:\"\";width:100%;border-radius:3px;bottom:-2px;left:0}:host .tabset .tab a nb-icon{vertical-align:middle}[dir=ltr] :host .tabset .tab a nb-icon+span{margin-left:.5rem}[dir=rtl] :host .tabset .tab a nb-icon+span{margin-right:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "component",
					type: NbBadgeComponent,
					selector: "nb-badge",
					inputs: [
						"text",
						"position",
						"dotMode",
						"status"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTabsetComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tabset",
			template: `
    <ul class="tabset">
      <li
        *ngFor="let tab of tabs"
        (click)="selectTab(tab)"
        (keyup.space)="selectTab(tab)"
        (keyup.enter)="selectTab(tab)"
        [class.responsive]="tab.responsive"
        [class.active]="tab.active"
        [class.disabled]="tab.disabled"
        [attr.tabindex]="tab.disabled ? -1 : 0"
        [attr.data-tab-id]="tab.tabId"
        class="tab"
      >
        <a href (click)="$event.preventDefault()" tabindex="-1" class="tab-link">
          <nb-icon *ngIf="tab.tabIcon" [config]="tab.tabIcon"></nb-icon>
          <ng-container
            *ngIf="tab.tabTitleDirective; else textTitleTemplate"
            [ngTemplateOutlet]="tab.tabTitleDirective.templateRef"
          ></ng-container>
          <ng-template #textTitleTemplate>
            <span class="tab-text">{{ tab.tabTitle }}</span>
          </ng-template>
        </a>
        <nb-badge
          *ngIf="tab.badgeText || tab.badgeDot"
          [text]="tab.badgeText"
          [dotMode]="tab.badgeDot"
          [status]="tab.badgeStatus"
          [position]="tab.badgePosition"
        >
        </nb-badge>
      </li>
    </ul>
    <ng-content select="nb-tab"></ng-content>
  `,
			standalone: false,
			styles: [":host{display:block}:host.full-width .tabset{justify-content:space-around}:host ::ng-deep nb-tab{flex:1;-ms-flex:1 1 auto;overflow:auto;display:none}:host ::ng-deep nb-tab.content-active{display:block}:host .tabset{display:flex;flex-direction:row;list-style-type:none;margin:0;padding:0}:host .tabset .tab{margin-bottom:-1px;text-align:center;position:relative}:host .tabset .tab.active a:before{display:block}:host .tabset .tab a{display:flex;position:relative;text-decoration:none}:host .tabset .tab a:before{position:absolute;content:\"\";width:100%;border-radius:3px;bottom:-2px;left:0}:host .tabset .tab a nb-icon{vertical-align:middle}[dir=ltr] :host .tabset .tab a nb-icon+span{margin-left:.5rem}[dir=rtl] :host .tabset .tab a nb-icon+span{margin-right:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: i1$1.ActivatedRoute }, { type: i0.ChangeDetectorRef }],
	propDecorators: {
		tabs: [{
			type: ContentChildren,
			args: [NbTabComponent]
		}],
		fullWidthValue: [{
			type: HostBinding,
			args: ["class.full-width"]
		}],
		fullWidth: [{ type: Input }],
		routeParam: [{ type: Input }],
		changeTab: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_TABSET_COMPONENTS = [NbTabsetComponent, NbTabComponent];
const NB_TABSET_DIRECTIVES = [NbTabContentDirective, NbTabTitleDirective];
var NbTabsetModule = class NbTabsetModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabsetModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabsetModule,
			declarations: [
				NbTabsetComponent,
				NbTabComponent,
				NbTabContentDirective,
				NbTabTitleDirective
			],
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			],
			exports: [
				NbTabsetComponent,
				NbTabComponent,
				NbTabContentDirective,
				NbTabTitleDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTabsetModule,
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTabsetModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			],
			declarations: [...NB_TABSET_COMPONENTS, ...NB_TABSET_DIRECTIVES],
			exports: [...NB_TABSET_COMPONENTS, ...NB_TABSET_DIRECTIVES]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbUserComponent = class NbUserComponent {
	set picture(value) {
		this.imageBackgroundStyle = value ? this.domSanitizer.bypassSecurityTrustStyle(`url(${value})`) : null;
	}
	get showName() {
		return this._showName;
	}
	set showName(val) {
		this._showName = convertToBoolProperty(val);
	}
	get showTitle() {
		return this._showTitle;
	}
	set showTitle(val) {
		this._showTitle = convertToBoolProperty(val);
	}
	get showInitials() {
		return this._showInitials;
	}
	set showInitials(val) {
		this._showInitials = convertToBoolProperty(val);
	}
	get onlyPicture() {
		return !this.showName && !this.showTitle;
	}
	set onlyPicture(val) {
		this.showName = this.showTitle = !convertToBoolProperty(val);
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get rectangle() {
		return this.shape === "rectangle";
	}
	get semiRound() {
		return this.shape === "semi-round";
	}
	get round() {
		return this.shape === "round";
	}
	constructor(domSanitizer) {
		this.domSanitizer = domSanitizer;
		this.name = "Anonymous";
		this.size = "medium";
		this.shape = "round";
		this._showName = true;
		this._showTitle = true;
		this._showInitials = true;
		this.badgeStatus = "basic";
	}
	getInitials() {
		if (this.name) return this.name.split(" ").map((n) => n.charAt(0)).splice(0, 2).join("").toUpperCase();
		return "";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbUserComponent,
			deps: [{ token: i1$2.DomSanitizer }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbUserComponent,
			isStandalone: false,
			selector: "nb-user",
			inputs: {
				name: "name",
				title: "title",
				picture: "picture",
				color: "color",
				size: "size",
				shape: "shape",
				showName: "showName",
				showTitle: "showTitle",
				showInitials: "showInitials",
				onlyPicture: "onlyPicture",
				badgeText: "badgeText",
				badgeStatus: "badgeStatus",
				badgePosition: "badgePosition"
			},
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.shape-rectangle": "this.rectangle",
				"class.shape-semi-round": "this.semiRound",
				"class.shape-round": "this.round"
			} },
			ngImport: i0,
			template: "<div class=\"user-container\">\n  <div *ngIf=\"imageBackgroundStyle\" class=\"user-picture image\" [style.background-image]=\"imageBackgroundStyle\">\n    <nb-badge *ngIf=\"badgeText\" [text]=\"badgeText\" [status]=\"badgeStatus\" [position]=\"badgePosition\"></nb-badge>\n  </div>\n  <div *ngIf=\"!imageBackgroundStyle\" class=\"user-picture initials\" [style.background-color]=\"color\">\n    <ng-container *ngIf=\"showInitials\">\n      {{ getInitials() }}\n    </ng-container>\n    <nb-badge *ngIf=\"badgeText\" [text]=\"badgeText\" [status]=\"badgeStatus\" [position]=\"badgePosition\"></nb-badge>\n  </div>\n\n  <div class=\"info-container\">\n    <div *ngIf=\"showName && name\" class=\"user-name\">{{ name }}</div>\n    <div *ngIf=\"showTitle && title\" class=\"user-title\">{{ title }}</div>\n  </div>\n</div>\n",
			styles: [":host{display:flex}:host .user-container{position:relative;display:flex;align-items:center}:host .user-picture{position:relative;flex-shrink:0}:host .user-picture.image{background-size:cover;background-repeat:no-repeat}:host .user-picture.initials{display:flex;align-items:center;justify-content:center}[dir=rtl] :host .user-name,[dir=rtl] :host .user-title{text-align:right}[dir=ltr] :host .info-container{margin-left:.5rem}[dir=rtl] :host .info-container{margin-right:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbBadgeComponent,
				selector: "nb-badge",
				inputs: [
					"text",
					"position",
					"dotMode",
					"status"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbUserComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-user",
			standalone: false,
			template: "<div class=\"user-container\">\n  <div *ngIf=\"imageBackgroundStyle\" class=\"user-picture image\" [style.background-image]=\"imageBackgroundStyle\">\n    <nb-badge *ngIf=\"badgeText\" [text]=\"badgeText\" [status]=\"badgeStatus\" [position]=\"badgePosition\"></nb-badge>\n  </div>\n  <div *ngIf=\"!imageBackgroundStyle\" class=\"user-picture initials\" [style.background-color]=\"color\">\n    <ng-container *ngIf=\"showInitials\">\n      {{ getInitials() }}\n    </ng-container>\n    <nb-badge *ngIf=\"badgeText\" [text]=\"badgeText\" [status]=\"badgeStatus\" [position]=\"badgePosition\"></nb-badge>\n  </div>\n\n  <div class=\"info-container\">\n    <div *ngIf=\"showName && name\" class=\"user-name\">{{ name }}</div>\n    <div *ngIf=\"showTitle && title\" class=\"user-title\">{{ title }}</div>\n  </div>\n</div>\n",
			styles: [":host{display:flex}:host .user-container{position:relative;display:flex;align-items:center}:host .user-picture{position:relative;flex-shrink:0}:host .user-picture.image{background-size:cover;background-repeat:no-repeat}:host .user-picture.initials{display:flex;align-items:center;justify-content:center}[dir=rtl] :host .user-name,[dir=rtl] :host .user-title{text-align:right}[dir=ltr] :host .info-container{margin-left:.5rem}[dir=rtl] :host .info-container{margin-right:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: i1$2.DomSanitizer }],
	propDecorators: {
		name: [{ type: Input }],
		title: [{ type: Input }],
		picture: [{ type: Input }],
		color: [{ type: Input }],
		size: [{ type: Input }],
		shape: [{ type: Input }],
		showName: [{ type: Input }],
		showTitle: [{ type: Input }],
		showInitials: [{ type: Input }],
		onlyPicture: [{ type: Input }],
		badgeText: [{ type: Input }],
		badgeStatus: [{ type: Input }],
		badgePosition: [{ type: Input }],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		rectangle: [{
			type: HostBinding,
			args: ["class.shape-rectangle"]
		}],
		semiRound: [{
			type: HostBinding,
			args: ["class.shape-semi-round"]
		}],
		round: [{
			type: HostBinding,
			args: ["class.shape-round"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_USER_COMPONENTS = [NbUserComponent];
var NbUserModule = class NbUserModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbUserModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbUserModule,
			declarations: [NbUserComponent],
			imports: [NbSharedModule, NbBadgeModule],
			exports: [NbUserComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbUserModule,
			imports: [NbSharedModule, NbBadgeModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbUserModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbBadgeModule],
			declarations: [...NB_USER_COMPONENTS],
			exports: [...NB_USER_COMPONENTS]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbActionComponent = class NbActionComponent {
	constructor() {
		this.title = "";
		this._disabled = false;
		this.badgeStatus = "basic";
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get badgeDot() {
		return this._badgeDot;
	}
	set badgeDot(value) {
		this._badgeDot = convertToBoolProperty(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbActionComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbActionComponent,
			isStandalone: false,
			selector: "nb-action",
			inputs: {
				link: "link",
				href: "href",
				title: "title",
				icon: "icon",
				disabled: "disabled",
				badgeDot: "badgeDot",
				badgeText: "badgeText",
				badgeStatus: "badgeStatus",
				badgePosition: "badgePosition"
			},
			host: { properties: { "class.disabled": "this.disabled" } },
			ngImport: i0,
			template: `
    <ng-container *ngIf="icon; else projectedContent">
      <a class="icon-container"
         [routerLink]="link"
         [title]="title"
         *ngIf="link">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
      <a class="icon-container"
         [href]="href"
         [title]="title"
         *ngIf="href && !link">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
      <a class="icon-container"
         href="#"
         [title]="title"
         *ngIf="!href && !link"
         (click)="$event.preventDefault()">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
    </ng-container>

    <ng-template #projectedContent>
      <ng-content></ng-content>
      <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
    </ng-template>
    <ng-template #badgeTemplate>
      <nb-badge *ngIf="badgeText || badgeDot"
                [text]="badgeText"
                [dotMode]="badgeDot"
                [status]="badgeStatus"
                [position]="badgePosition">
      </nb-badge>
    </ng-template>
  `,
			isInline: true,
			styles: [":host{background:transparent;display:flex;align-items:center;position:relative}:host(.disabled){cursor:not-allowed}:host(.disabled) a,:host(.disabled) nb-icon{cursor:not-allowed}:host-context(nb-actions.full-width){justify-content:center;width:100%}a.icon-container{position:relative}a.icon-container:hover,a.icon-container:focus{text-decoration:none}nb-icon:hover{cursor:pointer}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "directive",
					type: i1$1.RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "component",
					type: NbBadgeComponent,
					selector: "nb-badge",
					inputs: [
						"text",
						"position",
						"dotMode",
						"status"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbActionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-action",
			template: `
    <ng-container *ngIf="icon; else projectedContent">
      <a class="icon-container"
         [routerLink]="link"
         [title]="title"
         *ngIf="link">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
      <a class="icon-container"
         [href]="href"
         [title]="title"
         *ngIf="href && !link">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
      <a class="icon-container"
         href="#"
         [title]="title"
         *ngIf="!href && !link"
         (click)="$event.preventDefault()">
        <nb-icon [config]="icon"></nb-icon>
        <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
      </a>
    </ng-container>

    <ng-template #projectedContent>
      <ng-content></ng-content>
      <ng-container [ngTemplateOutlet]="badgeTemplate"></ng-container>
    </ng-template>
    <ng-template #badgeTemplate>
      <nb-badge *ngIf="badgeText || badgeDot"
                [text]="badgeText"
                [dotMode]="badgeDot"
                [status]="badgeStatus"
                [position]="badgePosition">
      </nb-badge>
    </ng-template>
  `,
			standalone: false,
			styles: [":host{background:transparent;display:flex;align-items:center;position:relative}:host(.disabled){cursor:not-allowed}:host(.disabled) a,:host(.disabled) nb-icon{cursor:not-allowed}:host-context(nb-actions.full-width){justify-content:center;width:100%}a.icon-container{position:relative}a.icon-container:hover,a.icon-container:focus{text-decoration:none}nb-icon:hover{cursor:pointer}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		link: [{ type: Input }],
		href: [{ type: Input }],
		title: [{ type: Input }],
		icon: [{ type: Input }],
		disabled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.disabled"]
		}],
		badgeDot: [{ type: Input }],
		badgeText: [{ type: Input }],
		badgeStatus: [{ type: Input }],
		badgePosition: [{ type: Input }]
	}
});
var NbActionsComponent = class NbActionsComponent {
	constructor() {
		this._size = "small";
		this._fullWidth = false;
	}
	get size() {
		return this._size;
	}
	set size(value) {
		this._size = value;
	}
	get fullWidth() {
		return this._fullWidth;
	}
	set fullWidth(value) {
		this._fullWidth = convertToBoolProperty(value);
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbActionsComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbActionsComponent,
			isStandalone: false,
			selector: "nb-actions",
			inputs: {
				size: "size",
				fullWidth: "fullWidth"
			},
			host: { properties: {
				"class.full-width": "this.fullWidth",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant"
			} },
			ngImport: i0,
			template: `
    <ng-content select="nb-action"></ng-content>
  `,
			isInline: true,
			styles: [":host{display:flex;align-items:center}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbActionsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-actions",
			template: `
    <ng-content select="nb-action"></ng-content>
  `,
			standalone: false,
			styles: [":host{display:flex;align-items:center}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		size: [{ type: Input }],
		fullWidth: [{ type: Input }, {
			type: HostBinding,
			args: ["class.full-width"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_ACTIONS_COMPONENTS = [NbActionComponent, NbActionsComponent];
var NbActionsModule = class NbActionsModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbActionsModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbActionsModule,
			declarations: [NbActionComponent, NbActionsComponent],
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			],
			exports: [NbActionComponent, NbActionsComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbActionsModule,
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbActionsModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbBadgeModule,
				NbIconModule
			],
			declarations: [...NB_ACTIONS_COMPONENTS],
			exports: [...NB_ACTIONS_COMPONENTS]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSearchService = class NbSearchService {
	constructor() {
		this.searchSubmittings$ = new Subject();
		this.searchActivations$ = new Subject();
		this.searchDeactivations$ = new Subject();
		this.searchInput$ = new Subject();
	}
	activateSearch(searchType, tag) {
		this.searchActivations$.next({
			searchType,
			tag
		});
	}
	deactivateSearch(searchType, tag) {
		this.searchDeactivations$.next({
			searchType,
			tag
		});
	}
	submitSearch(term, tag) {
		this.searchSubmittings$.next({
			term,
			tag
		});
	}
	searchInput(term, tag) {
		this.searchInput$.next({
			term,
			tag
		});
	}
	onSearchActivate() {
		return this.searchActivations$.pipe(share());
	}
	onSearchDeactivate() {
		return this.searchDeactivations$.pipe(share());
	}
	onSearchSubmit() {
		return this.searchSubmittings$.pipe(share());
	}
	onSearchInput() {
		return this.searchInput$.pipe(share());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSearchService,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSearchFieldComponent = class NbSearchFieldComponent {
	constructor() {
		this.show = false;
		this.close = new EventEmitter();
		this.search = new EventEmitter();
		this.searchInput = new EventEmitter();
	}
	static {
		this.TYPE_MODAL_ZOOMIN = "modal-zoomin";
	}
	static {
		this.TYPE_ROTATE_LAYOUT = "rotate-layout";
	}
	static {
		this.TYPE_MODAL_MOVE = "modal-move";
	}
	static {
		this.TYPE_CURTAIN = "curtain";
	}
	static {
		this.TYPE_COLUMN_CURTAIN = "column-curtain";
	}
	static {
		this.TYPE_MODAL_DROP = "modal-drop";
	}
	static {
		this.TYPE_MODAL_HALF = "modal-half";
	}
	get showClass() {
		return this.show;
	}
	get modalZoomin() {
		return this.type === NbSearchFieldComponent.TYPE_MODAL_ZOOMIN;
	}
	get rotateLayout() {
		return this.type === NbSearchFieldComponent.TYPE_ROTATE_LAYOUT;
	}
	get modalMove() {
		return this.type === NbSearchFieldComponent.TYPE_MODAL_MOVE;
	}
	get curtain() {
		return this.type === NbSearchFieldComponent.TYPE_CURTAIN;
	}
	get columnCurtain() {
		return this.type === NbSearchFieldComponent.TYPE_COLUMN_CURTAIN;
	}
	get modalDrop() {
		return this.type === NbSearchFieldComponent.TYPE_MODAL_DROP;
	}
	get modalHalf() {
		return this.type === NbSearchFieldComponent.TYPE_MODAL_HALF;
	}
	ngOnChanges({ show }) {
		if (!show.isFirstChange() && show.currentValue === false && this.inputElement) this.inputElement.nativeElement.value = "";
		this.focusInput();
	}
	ngAfterViewInit() {
		this.focusInput();
	}
	emitClose() {
		this.close.emit();
	}
	submitSearch(term) {
		if (term) this.search.emit(term);
	}
	emitSearchInput(term) {
		this.searchInput.emit(term);
	}
	focusInput() {
		if (this.show && this.inputElement) this.inputElement.nativeElement.focus();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchFieldComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSearchFieldComponent,
			isStandalone: false,
			selector: "nb-search-field",
			inputs: {
				type: "type",
				placeholder: "placeholder",
				hint: "hint",
				show: "show"
			},
			outputs: {
				close: "close",
				search: "search",
				searchInput: "searchInput"
			},
			host: { properties: {
				"class.show": "this.showClass",
				"class.modal-zoomin": "this.modalZoomin",
				"class.rotate-layout": "this.rotateLayout",
				"class.modal-move": "this.modalMove",
				"class.curtain": "this.curtain",
				"class.column-curtain": "this.columnCurtain",
				"class.modal-drop": "this.modalDrop",
				"class.modal-half": "this.modalHalf"
			} },
			viewQueries: [{
				propertyName: "inputElement",
				first: true,
				predicate: ["searchInput"],
				descendants: true
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <div class="search" (keyup.esc)="emitClose()">
      <button (click)="emitClose()" nbButton ghost class="close-button">
        <nb-icon icon="close-outline" pack="nebular-essentials"></nb-icon>
      </button>
      <div class="form-wrapper">
        <form class="form" (keyup.enter)="submitSearch(searchInput.value)">
          <div class="form-content">
            <input class="search-input"
                   #searchInput
                   (input)="emitSearchInput(searchInput.value)"
                   autocomplete="off"
                   [attr.placeholder]="placeholder"
                   tabindex="-1"
                   (blur)="focusInput()"/>
          </div>
          <span class="info">{{ hint }}</span>
        </form>
      </div>
    </div>
  `,
			isInline: true,
			styles: [
				":host button{margin:0;padding:0;cursor:pointer;border:none;background:none}:host button:focus{box-shadow:none;outline:none}:host input{border-top:0;border-right:0;border-left:0;background:transparent;border-radius:0;line-height:1;display:inline-block;box-sizing:border-box;padding:.05rem 0;-webkit-appearance:none}:host input:focus{outline:none}:host input::placeholder{opacity:.3}:host span{font-size:90%;font-weight:700;display:block;width:75%;margin:0 auto;padding:.85rem 0;text-align:right}:host.modal-zoomin{display:block}:host.modal-zoomin .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;position:fixed;z-index:1050;top:0;left:0;width:100%;height:100vh;pointer-events:none;opacity:0;transition:opacity .5s}:host.modal-zoomin .search:before,:host.modal-zoomin .search:after{content:\"\";position:absolute;width:calc(100% + 15px);height:calc(100% + 15px);pointer-events:none}:host.modal-zoomin .search:before{top:0;left:0;border-right-width:0;border-bottom-width:0;transform:translate3d(-15px,-15px,0)}:host.modal-zoomin .search:after{right:0;bottom:0;border-top-width:0;border-left-width:0;transform:translate3d(15px,15px,0)}:host.modal-zoomin .search button{position:absolute;top:3rem}[dir=ltr] :host.modal-zoomin .search button{right:3rem}[dir=rtl] :host.modal-zoomin .search button{left:3rem}:host.modal-zoomin .search button{font-size:2.5rem}:host.modal-zoomin .search input{font-size:10vw;width:75%}:host.modal-zoomin .search button{opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-zoomin .search form{opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-zoomin.show .search{pointer-events:auto;opacity:1}:host.modal-zoomin.show .search:before,:host.modal-zoomin.show .search:after{transform:translateZ(0);transition:transform .5s}:host.modal-zoomin.show .search button{opacity:1;transform:scaleZ(1)}:host.modal-zoomin.show .search form{opacity:1;transform:scaleZ(1)}@media screen and (max-width:40rem){:host.modal-zoomin form{margin:5rem 0 1rem}:host.modal-zoomin span{text-align:left}}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.rotate-layout{position:fixed;overflow:hidden;width:100%}::ng-deep nb-layout.rotate-layout .scrollable-container{position:relative;z-index:10001;transition:transform .5s cubic-bezier(.2,1,.3,1)}::ng-deep nb-layout.rotate-layout.with-search .scrollable-container{transition:transform .5s cubic-bezier(.2,1,.3,1);transform-origin:50vw 50vh;transform:perspective(1000px) translate3d(0,50vh,0) rotateX(30deg);pointer-events:none}:host.rotate-layout{position:absolute;display:block;width:100vw;height:100vh;pointer-events:none;opacity:0;transition-property:opacity;transition-delay:.4s}:host.rotate-layout .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;z-index:1050;position:fixed;top:0;left:0;width:100%;height:50vh;pointer-events:none;opacity:0;transition:opacity .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search button{position:absolute;top:3rem}[dir=ltr] :host.rotate-layout .search button{right:3rem}[dir=rtl] :host.rotate-layout .search button{left:3rem}:host.rotate-layout .search button{font-size:2.5rem;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search form{margin:5rem 0;opacity:0;transform:scale3d(.7,.7,1);transition:opacity .5s,transform .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search input{font-size:7vw;width:75%}:host.rotate-layout.show{opacity:1;transition-delay:0s}:host.rotate-layout.show .search{pointer-events:auto;opacity:1}:host.rotate-layout.show .search button{opacity:1;transform:scaleZ(1)}:host.rotate-layout.show .search form{opacity:1;transform:scaleZ(1)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-move .layout{transition:transform .5s}::ng-deep nb-layout.modal-move.with-search .layout{transform:scale3d(.8,.8,1);pointer-events:none}:host.modal-move .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;position:fixed;z-index:1050;top:0;left:0;width:100%;height:100vh;pointer-events:none;opacity:0;transition:opacity .5s}:host.modal-move .search button{position:absolute;top:3rem}[dir=ltr] :host.modal-move .search button{right:3rem}[dir=rtl] :host.modal-move .search button{left:3rem}:host.modal-move .search button{font-size:2.5rem;opacity:0;transition:opacity .5s}:host.modal-move .search form{margin:5rem 0;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-move .search input{font-size:10vw;width:75%;transform:scale3d(0,1,1);transform-origin:0 50%;transition:transform .3s}:host.modal-move.show .search{pointer-events:auto;opacity:1}:host.modal-move.show .search button{opacity:1}:host.modal-move.show .search form{opacity:1;transform:scaleZ(1)}:host.modal-move.show .search input{transform:scaleZ(1);transition-duration:.5s}@media screen and (max-width:40rem){:host.modal-move span{text-align:left}}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				":host.curtain .search{position:fixed;z-index:1050;top:0;left:100%;overflow:hidden;height:100vh;width:100%;padding:3rem;pointer-events:none;transition:transform .3s;transition-delay:.4s;transition-timing-function:ease-out}:host.curtain .search:after{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;transition:transform .3s;transition-timing-function:ease-out}:host.curtain .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.curtain .search button{right:3rem}[dir=rtl] :host.curtain .search button{left:3rem}:host.curtain .search button{transition:opacity .1s;transition-delay:.3s}:host.curtain .search form{width:50%;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.curtain .search input{width:100%;font-size:6vw}:host.curtain.show .search{width:100%;pointer-events:auto;transform:translate3d(-100%,0,0);transition-delay:0s}:host.curtain.show .search:after{transform:translate3d(100%,0,0);transition-delay:.4s}:host.curtain.show .search button{opacity:1;transform:scaleZ(1)}:host.curtain.show .search form{opacity:1;transform:scaleZ(1)}@media screen and (max-width:40em){:host.curtain span{width:90%}:host.curtain input{font-size:2em;width:90%}}::ng-deep nb-layout.curtain .scrollable-container{position:relative;z-index:0}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.column-curtain.with-search .layout{pointer-events:none}:host.column-curtain{display:block;position:fixed;z-index:1050;top:0;left:50%;overflow:hidden;width:50%;height:100vh;pointer-events:none}:host.column-curtain:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;transform:scale3d(0,1,1);transform-origin:0 50%;transition:transform .3s;transition-timing-function:cubic-bezier(.86,0,.07,1)}:host.column-curtain .search{position:relative;padding:2.5rem 1.5rem 0;background:transparent}:host.column-curtain .search button{position:absolute;top:2rem}[dir=ltr] :host.column-curtain .search button{right:2rem}[dir=rtl] :host.column-curtain .search button{left:2rem}:host.column-curtain .search button{font-size:2.5rem;opacity:0;transition:opacity .5s}:host.column-curtain .search form{width:85%;transform:translate3d(-150%,0,0);transition:transform .3s}:host.column-curtain .search input{font-size:2.5rem;width:100%}:host.column-curtain .search span{font-size:85%}:host.column-curtain.show{pointer-events:auto}:host.column-curtain.show:before{transform:scaleZ(1)}:host.column-curtain.show .search form{transform:translateZ(0);transition-delay:.15s;transition-timing-function:cubic-bezier(.86,0,.07,1)}:host.column-curtain.show .search button{opacity:1;z-index:100}@media screen and (max-width:40rem){:host.column-curtain span{width:90%}:host.column-curtain input{font-size:2rem;width:90%}}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-drop .layout{position:relative;transition:transform .4s,opacity .4s;transition-timing-function:cubic-bezier(.4,0,.2,1)}::ng-deep nb-layout.modal-drop.with-search .layout{opacity:0;transform:scale3d(.9,.9,1);pointer-events:none}:host.modal-drop .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;z-index:1050;position:fixed;top:0;left:0;width:100%;height:100vh;background:none;pointer-events:none}:host.modal-drop .search:before{content:\"\";position:absolute;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .4s}:host.modal-drop .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.modal-drop .search button{right:3rem}[dir=rtl] :host.modal-drop .search button{left:3rem}:host.modal-drop .search button{display:block;opacity:0;transition:opacity .4s}:host.modal-drop .search form{position:relative;margin:5rem 0 2rem}:host.modal-drop .search input{font-size:6vw;width:60%;padding:.25rem;text-align:center;opacity:0;transition:opacity .4s}:host.modal-drop .search span{position:relative;z-index:9;display:block;width:60%;padding:.85rem 0;opacity:0;transform:translate3d(0,-50px,0);transition:opacity .4s,transform .4s}:host.modal-drop .search .form-content{position:relative;z-index:10;overflow:hidden;transform:translate3d(0,-50px,0);transition:transform .4s}:host.modal-drop .search .form-content:after{content:\"\";position:absolute;top:0;left:20%;width:60%;height:105%;opacity:0;transform-origin:50% 0}:host.modal-drop.show .search{pointer-events:auto}:host.modal-drop.show .search:before{opacity:1}:host.modal-drop.show .search button{opacity:1}:host.modal-drop.show .search .form-content{transform:translateZ(0);transition:none}:host.modal-drop.show .search .form-content:after{animation:scaleUpDown .8s cubic-bezier(.4,0,.2,1) forwards}:host.modal-drop.show .search input{opacity:1;transition:opacity 0s .4s}:host.modal-drop.show .search span{opacity:1;transform:translateZ(0);transition-delay:.4s;transition-timing-function:ease-out}@keyframes scaleUpDown{0%{opacity:1;transform:scale3d(1,0,1)}50%{transform:scaleZ(1);transform-origin:50% 0;transition-timing-function:ease-out}50.1%{transform-origin:50% 100%;transition-timing-function:ease-out}to{opacity:1;transform:scale3d(1,0,1);transform-origin:50% 100%;transition-timing-function:ease-out}}@media screen and (max-width:40rem){:host.modal-drop form{margin:2rem 0}:host.modal-drop input{width:100%;left:0}}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-half .layout{transition:transform .6s,opacity .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}::ng-deep nb-layout.modal-half.with-search .layout{transform:scale3d(.8,.8,1);pointer-events:none}:host.modal-half .search{text-align:center;position:fixed;z-index:1050;top:0;left:0;overflow:hidden;width:100%;height:100vh;background:none;pointer-events:none}:host.modal-half .search:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;opacity:0;transition:opacity .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.modal-half .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.modal-half .search button{right:3rem}[dir=rtl] :host.modal-half .search button{left:3rem}:host.modal-half .search button{display:block;z-index:100;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .6s,transform .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.modal-half .search .form-wrapper{position:absolute;display:flex;justify-content:center;align-items:center;width:100%;height:50%;transition:transform .6s;transition-timing-function:cubic-bezier(.2,1,.3,1);transform:translate3d(0,-100%,0)}:host.modal-half .search form{width:75%;margin:0 auto}:host.modal-half .search input{font-size:7vw;width:100%}:host.modal-half.show .search{pointer-events:auto}:host.modal-half.show .search:before{opacity:1}:host.modal-half.show .search button{opacity:1;transform:scaleZ(1)}:host.modal-half.show .search .form-wrapper{transform:translateZ(0)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"
			],
			dependencies: [
				{
					kind: "directive",
					type: i1.ɵNgNoValidate,
					selector: "form:not([ngNoForm]):not([ngNativeValidate])"
				},
				{
					kind: "directive",
					type: i1.NgControlStatusGroup,
					selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
				},
				{
					kind: "directive",
					type: i1.NgForm,
					selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
					inputs: ["ngFormOptions"],
					outputs: ["ngSubmit"],
					exportAs: ["ngForm"]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSearchFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-search-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div class="search" (keyup.esc)="emitClose()">
      <button (click)="emitClose()" nbButton ghost class="close-button">
        <nb-icon icon="close-outline" pack="nebular-essentials"></nb-icon>
      </button>
      <div class="form-wrapper">
        <form class="form" (keyup.enter)="submitSearch(searchInput.value)">
          <div class="form-content">
            <input class="search-input"
                   #searchInput
                   (input)="emitSearchInput(searchInput.value)"
                   autocomplete="off"
                   [attr.placeholder]="placeholder"
                   tabindex="-1"
                   (blur)="focusInput()"/>
          </div>
          <span class="info">{{ hint }}</span>
        </form>
      </div>
    </div>
  `,
			standalone: false,
			styles: [
				":host button{margin:0;padding:0;cursor:pointer;border:none;background:none}:host button:focus{box-shadow:none;outline:none}:host input{border-top:0;border-right:0;border-left:0;background:transparent;border-radius:0;line-height:1;display:inline-block;box-sizing:border-box;padding:.05rem 0;-webkit-appearance:none}:host input:focus{outline:none}:host input::placeholder{opacity:.3}:host span{font-size:90%;font-weight:700;display:block;width:75%;margin:0 auto;padding:.85rem 0;text-align:right}:host.modal-zoomin{display:block}:host.modal-zoomin .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;position:fixed;z-index:1050;top:0;left:0;width:100%;height:100vh;pointer-events:none;opacity:0;transition:opacity .5s}:host.modal-zoomin .search:before,:host.modal-zoomin .search:after{content:\"\";position:absolute;width:calc(100% + 15px);height:calc(100% + 15px);pointer-events:none}:host.modal-zoomin .search:before{top:0;left:0;border-right-width:0;border-bottom-width:0;transform:translate3d(-15px,-15px,0)}:host.modal-zoomin .search:after{right:0;bottom:0;border-top-width:0;border-left-width:0;transform:translate3d(15px,15px,0)}:host.modal-zoomin .search button{position:absolute;top:3rem}[dir=ltr] :host.modal-zoomin .search button{right:3rem}[dir=rtl] :host.modal-zoomin .search button{left:3rem}:host.modal-zoomin .search button{font-size:2.5rem}:host.modal-zoomin .search input{font-size:10vw;width:75%}:host.modal-zoomin .search button{opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-zoomin .search form{opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-zoomin.show .search{pointer-events:auto;opacity:1}:host.modal-zoomin.show .search:before,:host.modal-zoomin.show .search:after{transform:translateZ(0);transition:transform .5s}:host.modal-zoomin.show .search button{opacity:1;transform:scaleZ(1)}:host.modal-zoomin.show .search form{opacity:1;transform:scaleZ(1)}@media screen and (max-width:40rem){:host.modal-zoomin form{margin:5rem 0 1rem}:host.modal-zoomin span{text-align:left}}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.rotate-layout{position:fixed;overflow:hidden;width:100%}::ng-deep nb-layout.rotate-layout .scrollable-container{position:relative;z-index:10001;transition:transform .5s cubic-bezier(.2,1,.3,1)}::ng-deep nb-layout.rotate-layout.with-search .scrollable-container{transition:transform .5s cubic-bezier(.2,1,.3,1);transform-origin:50vw 50vh;transform:perspective(1000px) translate3d(0,50vh,0) rotateX(30deg);pointer-events:none}:host.rotate-layout{position:absolute;display:block;width:100vw;height:100vh;pointer-events:none;opacity:0;transition-property:opacity;transition-delay:.4s}:host.rotate-layout .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;z-index:1050;position:fixed;top:0;left:0;width:100%;height:50vh;pointer-events:none;opacity:0;transition:opacity .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search button{position:absolute;top:3rem}[dir=ltr] :host.rotate-layout .search button{right:3rem}[dir=rtl] :host.rotate-layout .search button{left:3rem}:host.rotate-layout .search button{font-size:2.5rem;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search form{margin:5rem 0;opacity:0;transform:scale3d(.7,.7,1);transition:opacity .5s,transform .5s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.rotate-layout .search input{font-size:7vw;width:75%}:host.rotate-layout.show{opacity:1;transition-delay:0s}:host.rotate-layout.show .search{pointer-events:auto;opacity:1}:host.rotate-layout.show .search button{opacity:1;transform:scaleZ(1)}:host.rotate-layout.show .search form{opacity:1;transform:scaleZ(1)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-move .layout{transition:transform .5s}::ng-deep nb-layout.modal-move.with-search .layout{transform:scale3d(.8,.8,1);pointer-events:none}:host.modal-move .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;position:fixed;z-index:1050;top:0;left:0;width:100%;height:100vh;pointer-events:none;opacity:0;transition:opacity .5s}:host.modal-move .search button{position:absolute;top:3rem}[dir=ltr] :host.modal-move .search button{right:3rem}[dir=rtl] :host.modal-move .search button{left:3rem}:host.modal-move .search button{font-size:2.5rem;opacity:0;transition:opacity .5s}:host.modal-move .search form{margin:5rem 0;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.modal-move .search input{font-size:10vw;width:75%;transform:scale3d(0,1,1);transform-origin:0 50%;transition:transform .3s}:host.modal-move.show .search{pointer-events:auto;opacity:1}:host.modal-move.show .search button{opacity:1}:host.modal-move.show .search form{opacity:1;transform:scaleZ(1)}:host.modal-move.show .search input{transform:scaleZ(1);transition-duration:.5s}@media screen and (max-width:40rem){:host.modal-move span{text-align:left}}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				":host.curtain .search{position:fixed;z-index:1050;top:0;left:100%;overflow:hidden;height:100vh;width:100%;padding:3rem;pointer-events:none;transition:transform .3s;transition-delay:.4s;transition-timing-function:ease-out}:host.curtain .search:after{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;transition:transform .3s;transition-timing-function:ease-out}:host.curtain .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.curtain .search button{right:3rem}[dir=rtl] :host.curtain .search button{left:3rem}:host.curtain .search button{transition:opacity .1s;transition-delay:.3s}:host.curtain .search form{width:50%;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .5s,transform .5s}:host.curtain .search input{width:100%;font-size:6vw}:host.curtain.show .search{width:100%;pointer-events:auto;transform:translate3d(-100%,0,0);transition-delay:0s}:host.curtain.show .search:after{transform:translate3d(100%,0,0);transition-delay:.4s}:host.curtain.show .search button{opacity:1;transform:scaleZ(1)}:host.curtain.show .search form{opacity:1;transform:scaleZ(1)}@media screen and (max-width:40em){:host.curtain span{width:90%}:host.curtain input{font-size:2em;width:90%}}::ng-deep nb-layout.curtain .scrollable-container{position:relative;z-index:0}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.column-curtain.with-search .layout{pointer-events:none}:host.column-curtain{display:block;position:fixed;z-index:1050;top:0;left:50%;overflow:hidden;width:50%;height:100vh;pointer-events:none}:host.column-curtain:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;transform:scale3d(0,1,1);transform-origin:0 50%;transition:transform .3s;transition-timing-function:cubic-bezier(.86,0,.07,1)}:host.column-curtain .search{position:relative;padding:2.5rem 1.5rem 0;background:transparent}:host.column-curtain .search button{position:absolute;top:2rem}[dir=ltr] :host.column-curtain .search button{right:2rem}[dir=rtl] :host.column-curtain .search button{left:2rem}:host.column-curtain .search button{font-size:2.5rem;opacity:0;transition:opacity .5s}:host.column-curtain .search form{width:85%;transform:translate3d(-150%,0,0);transition:transform .3s}:host.column-curtain .search input{font-size:2.5rem;width:100%}:host.column-curtain .search span{font-size:85%}:host.column-curtain.show{pointer-events:auto}:host.column-curtain.show:before{transform:scaleZ(1)}:host.column-curtain.show .search form{transform:translateZ(0);transition-delay:.15s;transition-timing-function:cubic-bezier(.86,0,.07,1)}:host.column-curtain.show .search button{opacity:1;z-index:100}@media screen and (max-width:40rem){:host.column-curtain span{width:90%}:host.column-curtain input{font-size:2rem;width:90%}}\n/**\n* @license\n* Copyright Akveo. All Rights Reserved.\n* Licensed under the MIT License. See License.txt in the project root for license information.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-drop .layout{position:relative;transition:transform .4s,opacity .4s;transition-timing-function:cubic-bezier(.4,0,.2,1)}::ng-deep nb-layout.modal-drop.with-search .layout{opacity:0;transform:scale3d(.9,.9,1);pointer-events:none}:host.modal-drop .search{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;z-index:1050;position:fixed;top:0;left:0;width:100%;height:100vh;background:none;pointer-events:none}:host.modal-drop .search:before{content:\"\";position:absolute;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .4s}:host.modal-drop .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.modal-drop .search button{right:3rem}[dir=rtl] :host.modal-drop .search button{left:3rem}:host.modal-drop .search button{display:block;opacity:0;transition:opacity .4s}:host.modal-drop .search form{position:relative;margin:5rem 0 2rem}:host.modal-drop .search input{font-size:6vw;width:60%;padding:.25rem;text-align:center;opacity:0;transition:opacity .4s}:host.modal-drop .search span{position:relative;z-index:9;display:block;width:60%;padding:.85rem 0;opacity:0;transform:translate3d(0,-50px,0);transition:opacity .4s,transform .4s}:host.modal-drop .search .form-content{position:relative;z-index:10;overflow:hidden;transform:translate3d(0,-50px,0);transition:transform .4s}:host.modal-drop .search .form-content:after{content:\"\";position:absolute;top:0;left:20%;width:60%;height:105%;opacity:0;transform-origin:50% 0}:host.modal-drop.show .search{pointer-events:auto}:host.modal-drop.show .search:before{opacity:1}:host.modal-drop.show .search button{opacity:1}:host.modal-drop.show .search .form-content{transform:translateZ(0);transition:none}:host.modal-drop.show .search .form-content:after{animation:scaleUpDown .8s cubic-bezier(.4,0,.2,1) forwards}:host.modal-drop.show .search input{opacity:1;transition:opacity 0s .4s}:host.modal-drop.show .search span{opacity:1;transform:translateZ(0);transition-delay:.4s;transition-timing-function:ease-out}@keyframes scaleUpDown{0%{opacity:1;transform:scale3d(1,0,1)}50%{transform:scaleZ(1);transform-origin:50% 0;transition-timing-function:ease-out}50.1%{transform-origin:50% 100%;transition-timing-function:ease-out}to{opacity:1;transform:scale3d(1,0,1);transform-origin:50% 100%;transition-timing-function:ease-out}}@media screen and (max-width:40rem){:host.modal-drop form{margin:2rem 0}:host.modal-drop input{width:100%;left:0}}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n",
				"::ng-deep nb-layout.modal-half .layout{transition:transform .6s,opacity .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}::ng-deep nb-layout.modal-half.with-search .layout{transform:scale3d(.8,.8,1);pointer-events:none}:host.modal-half .search{text-align:center;position:fixed;z-index:1050;top:0;left:0;overflow:hidden;width:100%;height:100vh;background:none;pointer-events:none}:host.modal-half .search:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;opacity:0;transition:opacity .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.modal-half .search button{font-size:2.5rem;position:absolute;top:3rem}[dir=ltr] :host.modal-half .search button{right:3rem}[dir=rtl] :host.modal-half .search button{left:3rem}:host.modal-half .search button{display:block;z-index:100;opacity:0;transform:scale3d(.8,.8,1);transition:opacity .6s,transform .6s;transition-timing-function:cubic-bezier(.2,1,.3,1)}:host.modal-half .search .form-wrapper{position:absolute;display:flex;justify-content:center;align-items:center;width:100%;height:50%;transition:transform .6s;transition-timing-function:cubic-bezier(.2,1,.3,1);transform:translate3d(0,-100%,0)}:host.modal-half .search form{width:75%;margin:0 auto}:host.modal-half .search input{font-size:7vw;width:100%}:host.modal-half.show .search{pointer-events:auto}:host.modal-half.show .search:before{opacity:1}:host.modal-half.show .search button{opacity:1;transform:scaleZ(1)}:host.modal-half.show .search .form-wrapper{transform:translateZ(0)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"
			]
		}]
	}],
	propDecorators: {
		type: [{ type: Input }],
		placeholder: [{ type: Input }],
		hint: [{ type: Input }],
		show: [{ type: Input }],
		close: [{ type: Output }],
		search: [{ type: Output }],
		searchInput: [{ type: Output }],
		inputElement: [{
			type: ViewChild,
			args: ["searchInput"]
		}],
		showClass: [{
			type: HostBinding,
			args: ["class.show"]
		}],
		modalZoomin: [{
			type: HostBinding,
			args: ["class.modal-zoomin"]
		}],
		rotateLayout: [{
			type: HostBinding,
			args: ["class.rotate-layout"]
		}],
		modalMove: [{
			type: HostBinding,
			args: ["class.modal-move"]
		}],
		curtain: [{
			type: HostBinding,
			args: ["class.curtain"]
		}],
		columnCurtain: [{
			type: HostBinding,
			args: ["class.column-curtain"]
		}],
		modalDrop: [{
			type: HostBinding,
			args: ["class.modal-drop"]
		}],
		modalHalf: [{
			type: HostBinding,
			args: ["class.modal-half"]
		}]
	}
});
var NbSearchComponent = class NbSearchComponent {
	constructor(searchService, themeService, router, overlayService, changeDetector) {
		this.searchService = searchService;
		this.themeService = themeService;
		this.router = router;
		this.overlayService = overlayService;
		this.changeDetector = changeDetector;
		this.destroy$ = new Subject();
		this.showSearchField = false;
		this.placeholder = "Search...";
		this.hint = "Hit enter to search";
	}
	ngOnInit() {
		this.router.events.pipe(filter((event) => event instanceof NavigationEnd), takeUntil(this.destroy$)).subscribe(() => this.hideSearch());
		this.searchService.onSearchActivate().pipe(filter((data) => !this.tag || data.tag === this.tag), takeUntil(this.destroy$)).subscribe(() => this.openSearch());
		this.searchService.onSearchDeactivate().pipe(filter((data) => !this.tag || data.tag === this.tag), takeUntil(this.destroy$)).subscribe(() => this.hideSearch());
	}
	ngOnDestroy() {
		if (this.overlayRef && this.overlayRef.hasAttached()) {
			this.removeLayoutClasses();
			this.overlayRef.detach();
		}
		this.destroy$.next();
		this.destroy$.complete();
	}
	openSearch() {
		if (!this.overlayRef) {
			this.overlayRef = this.overlayService.create();
			this.overlayRef.attach(this.searchFieldPortal);
		}
		this.themeService.appendLayoutClass(this.type);
		of(null).pipe(delay(0)).subscribe(() => {
			this.themeService.appendLayoutClass("with-search");
			this.showSearchField = true;
			this.changeDetector.detectChanges();
		});
	}
	hideSearch() {
		this.removeLayoutClasses();
		this.showSearchField = false;
		this.changeDetector.detectChanges();
		this.searchButton.nativeElement.focus();
	}
	search(term) {
		this.searchService.submitSearch(term, this.tag);
		this.hideSearch();
	}
	emitInput(term) {
		this.searchService.searchInput(term, this.tag);
	}
	emitActivate() {
		this.searchService.activateSearch(this.type, this.tag);
	}
	emitDeactivate() {
		this.searchService.deactivateSearch(this.type, this.tag);
	}
	removeLayoutClasses() {
		this.themeService.removeLayoutClass("with-search");
		of(null).pipe(delay(500)).subscribe(() => {
			this.themeService.removeLayoutClass(this.type);
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchComponent,
			deps: [
				{ token: NbSearchService },
				{ token: NbThemeService },
				{ token: i1$1.Router },
				{ token: NbOverlayService },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSearchComponent,
			isStandalone: false,
			selector: "nb-search",
			inputs: {
				tag: "tag",
				placeholder: "placeholder",
				hint: "hint",
				type: "type"
			},
			viewQueries: [{
				propertyName: "searchFieldPortal",
				first: true,
				predicate: NbPortalDirective,
				descendants: true
			}, {
				propertyName: "searchButton",
				first: true,
				predicate: ["searchButton"],
				descendants: true,
				read: ElementRef
			}],
			ngImport: i0,
			template: `
    <button #searchButton class="start-search" (click)="emitActivate()" nbButton ghost>
      <nb-icon icon="search-outline" pack="nebular-essentials"></nb-icon>
    </button>
    <nb-search-field
      *nbPortal
      [show]="showSearchField"
      [type]="type"
      [placeholder]="placeholder"
      [hint]="hint"
      (search)="search($event)"
      (searchInput)="emitInput($event)"
      (close)="emitDeactivate()">
    </nb-search-field>
  `,
			isInline: true,
			styles: [":host button{font-size:2rem;margin:0 auto;padding:0;cursor:pointer;border:none;background:none}:host button:focus{box-shadow:none;outline:none}::ng-deep nb-layout.with-search .scrollable-container{position:relative;z-index:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: NbPortalDirective,
					selector: "[nbPortal]"
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				},
				{
					kind: "component",
					type: NbSearchFieldComponent,
					selector: "nb-search-field",
					inputs: [
						"type",
						"placeholder",
						"hint",
						"show"
					],
					outputs: [
						"close",
						"search",
						"searchInput"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSearchComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-search",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button #searchButton class="start-search" (click)="emitActivate()" nbButton ghost>
      <nb-icon icon="search-outline" pack="nebular-essentials"></nb-icon>
    </button>
    <nb-search-field
      *nbPortal
      [show]="showSearchField"
      [type]="type"
      [placeholder]="placeholder"
      [hint]="hint"
      (search)="search($event)"
      (searchInput)="emitInput($event)"
      (close)="emitDeactivate()">
    </nb-search-field>
  `,
			standalone: false,
			styles: [":host button{font-size:2rem;margin:0 auto;padding:0;cursor:pointer;border:none;background:none}:host button:focus{box-shadow:none;outline:none}::ng-deep nb-layout.with-search .scrollable-container{position:relative;z-index:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbSearchService },
		{ type: NbThemeService },
		{ type: i1$1.Router },
		{ type: NbOverlayService },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: {
		tag: [{ type: Input }],
		placeholder: [{ type: Input }],
		hint: [{ type: Input }],
		type: [{ type: Input }],
		searchFieldPortal: [{
			type: ViewChild,
			args: [NbPortalDirective]
		}],
		searchButton: [{
			type: ViewChild,
			args: ["searchButton", { read: ElementRef }]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSearchModule = class NbSearchModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchModule,
			declarations: [NbSearchComponent, NbSearchFieldComponent],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule,
				NbButtonModule
			],
			exports: [NbSearchComponent, NbSearchFieldComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSearchModule,
			providers: [NbSearchService],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule,
				NbButtonModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSearchModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule,
				NbButtonModule
			],
			declarations: [NbSearchComponent, NbSearchFieldComponent],
			exports: [NbSearchComponent, NbSearchFieldComponent],
			providers: [NbSearchService]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCheckboxComponent = class NbCheckboxComponent {
	get checked() {
		return this._checked;
	}
	set checked(value) {
		this._checked = convertToBoolProperty(value);
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get indeterminate() {
		return this._indeterminate;
	}
	set indeterminate(value) {
		this._indeterminate = convertToBoolProperty(value);
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get info() {
		return this.status === "info";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(changeDetector, renderer, hostElement, zone, statusService) {
		this.changeDetector = changeDetector;
		this.renderer = renderer;
		this.hostElement = hostElement;
		this.zone = zone;
		this.statusService = statusService;
		this.onChange = () => {};
		this.onTouched = () => {};
		this._checked = false;
		this._disabled = false;
		this.status = "basic";
		this._indeterminate = false;
		this.checkedChange = new EventEmitter();
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostElement.nativeElement, "nb-transition");
		}));
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	writeValue(val) {
		this._checked = val;
		this.changeDetector.markForCheck();
	}
	setDisabledState(val) {
		this.disabled = convertToBoolProperty(val);
		this.changeDetector.markForCheck();
	}
	setTouched() {
		this.onTouched();
	}
	updateValueAndIndeterminate(event) {
		const input = event.target;
		this.checked = input.checked;
		this.checkedChange.emit(this.checked);
		this.onChange(this.checked);
		this.indeterminate = input.indeterminate;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCheckboxComponent,
			deps: [
				{ token: i0.ChangeDetectorRef },
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCheckboxComponent,
			isStandalone: false,
			selector: "nb-checkbox",
			inputs: {
				checked: "checked",
				disabled: "disabled",
				status: "status",
				indeterminate: "indeterminate"
			},
			outputs: { checkedChange: "checkedChange" },
			host: { properties: {
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-info": "this.info",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses"
			} },
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbCheckboxComponent),
				multi: true
			}],
			ngImport: i0,
			template: `
    <label class="label">
      <input type="checkbox" class="native-input visually-hidden"
             [disabled]="disabled"
             [checked]="checked"
             (change)="updateValueAndIndeterminate($event)"
             (blur)="setTouched()"
             (click)="$event.stopPropagation()"
             [indeterminate]="indeterminate">
      <span [class.indeterminate]="indeterminate" [class.checked]="checked" class="custom-checkbox">
        <nb-icon *ngIf="indeterminate" icon="minus-bold-outline" pack="nebular-essentials" class="custom-checkbox-icon"></nb-icon>
        <nb-icon *ngIf="checked && !indeterminate" icon="checkmark-bold-outline" pack="nebular-essentials" class="custom-checkbox-icon"></nb-icon>
      </span>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			isInline: true,
			styles: [":host .label{position:relative;display:inline-flex;align-items:center;margin:0;min-height:inherit}:host .custom-checkbox{flex-shrink:0}:host(.nb-transition) .custom-checkbox{transition-duration:.15s;transition-property:background-color,border,box-shadow;transition-timing-function:ease-in}:host(.nb-transition) .text{transition-duration:.15s;transition-property:color;transition-timing-function:ease-in}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCheckboxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-checkbox",
			template: `
    <label class="label">
      <input type="checkbox" class="native-input visually-hidden"
             [disabled]="disabled"
             [checked]="checked"
             (change)="updateValueAndIndeterminate($event)"
             (blur)="setTouched()"
             (click)="$event.stopPropagation()"
             [indeterminate]="indeterminate">
      <span [class.indeterminate]="indeterminate" [class.checked]="checked" class="custom-checkbox">
        <nb-icon *ngIf="indeterminate" icon="minus-bold-outline" pack="nebular-essentials" class="custom-checkbox-icon"></nb-icon>
        <nb-icon *ngIf="checked && !indeterminate" icon="checkmark-bold-outline" pack="nebular-essentials" class="custom-checkbox-icon"></nb-icon>
      </span>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbCheckboxComponent),
				multi: true
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host .label{position:relative;display:inline-flex;align-items:center;margin:0;min-height:inherit}:host .custom-checkbox{flex-shrink:0}:host(.nb-transition) .custom-checkbox{transition-duration:.15s;transition-property:background-color,border,box-shadow;transition-timing-function:ease-in}:host(.nb-transition) .text{transition-duration:.15s;transition-property:color;transition-timing-function:ease-in}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ChangeDetectorRef },
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		checked: [{ type: Input }],
		disabled: [{ type: Input }],
		status: [{ type: Input }],
		indeterminate: [{ type: Input }],
		checkedChange: [{ type: Output }],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbCheckboxModule = class NbCheckboxModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCheckboxModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCheckboxModule,
			declarations: [NbCheckboxComponent],
			imports: [NbSharedModule, NbIconModule],
			exports: [NbCheckboxComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCheckboxModule,
			imports: [NbSharedModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCheckboxModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbIconModule],
			declarations: [NbCheckboxComponent],
			exports: [NbCheckboxComponent]
		}]
	}]
});
var NbDynamicOverlay = class NbDynamicOverlay {
	get isAttached() {
		return this.ref && this.ref.hasAttached();
	}
	get isShown() {
		return this.isShown$.pipe(distinctUntilChanged());
	}
	constructor(overlay, zone, overlayContainer) {
		this.overlay = overlay;
		this.zone = zone;
		this.overlayContainer = overlayContainer;
		this.context = {};
		this.overlayConfig = {};
		this.disabled = false;
		this.positionStrategyChange$ = new Subject();
		this.isShown$ = new BehaviorSubject(false);
		this.destroy$ = new Subject();
		this.overlayDestroy$ = new Subject();
	}
	create(componentType, content, context, positionStrategy, overlayConfig = {}, disabled = false) {
		this.setContentAndContext(content, context);
		this.setComponent(componentType);
		this.setPositionStrategy(positionStrategy);
		this.setOverlayConfig(overlayConfig);
		this.setDisabled(disabled);
		return this;
	}
	setContent(content) {
		this.content = content;
		if (this.container) this.updateContext();
		this.updatePosition();
	}
	setContext(context) {
		this.context = context;
		if (this.container) this.updateContext();
		this.updatePosition();
	}
	setContentAndContext(content, context) {
		this.content = content;
		this.context = context;
		if (this.container) this.updateContext();
		this.updatePosition();
	}
	setComponent(componentType) {
		this.componentType = componentType;
		const wasAttached = this.isAttached;
		this.disposeOverlayRef();
		if (wasAttached) this.show();
	}
	setPositionStrategy(positionStrategy) {
		this.positionStrategyChange$.next();
		this.positionStrategy = positionStrategy;
		this.positionStrategy.positionChange.pipe(filter(() => !!this.container), takeUntil(merge(this.positionStrategyChange$, this.destroy$))).subscribe((position) => {
			this.lastAppliedPosition = position;
			patch(this.container, { position });
		});
		if (this.ref) this.ref.updatePositionStrategy(this.positionStrategy);
	}
	setOverlayConfig(overlayConfig) {
		this.overlayConfig = overlayConfig;
		const wasAttached = this.isAttached;
		this.disposeOverlayRef();
		if (wasAttached) this.show();
	}
	setDisabled(disabled) {
		if (disabled && this.isShown$.value) this.hide();
		this.disabled = disabled;
	}
	show() {
		if (this.disabled) return;
		if (!this.ref) this.createOverlay();
		this.renderContainer();
		if (!this.hasOverlayInContainer()) {
			this.disposeOverlayRef();
			return this.show();
		}
		this.isShown$.next(true);
	}
	hide() {
		if (!this.ref) return;
		this.ref.detach();
		this.container = null;
		this.isShown$.next(false);
	}
	toggle() {
		if (this.isAttached) this.hide();
		else this.show();
	}
	dispose() {
		this.destroy$.next();
		this.destroy$.complete();
		this.hide();
		this.disposeOverlayRef();
		this.isShown$.complete();
		this.positionStrategyChange$.complete();
		this.overlayDestroy$.complete();
	}
	getContainer() {
		return this.container;
	}
	createOverlay() {
		this.ref = this.overlay.create({
			positionStrategy: this.positionStrategy,
			scrollStrategy: this.overlay.scrollStrategies.reposition(),
			...this.overlayConfig
		});
		this.updatePositionWhenStable(this.ref);
	}
	renderContainer() {
		const containerContext = this.createContainerContext();
		if (!this.container) this.container = createContainer(this.ref, this.componentType, containerContext);
		this.container.instance.renderContent();
	}
	updateContext() {
		const containerContext = this.createContainerContext();
		Object.assign(this.container.instance, containerContext);
		this.container.instance.renderContent();
		this.container.changeDetectorRef.detectChanges();
	}
	createContainerContext() {
		return {
			content: this.content,
			context: this.context,
			position: this.lastAppliedPosition
		};
	}
	updatePositionWhenStable(overlay) {
		const overlayDestroy$ = this.overlayDestroy$.pipe(filter((destroyedOverlay) => destroyedOverlay === overlay));
		this.zone.onStable.pipe(take(1), takeUntil(merge(this.destroy$, overlayDestroy$))).subscribe(() => this.updatePosition());
	}
	updatePosition() {
		if (this.ref) this.ref.updatePosition();
	}
	hasOverlayInContainer() {
		return this.overlayContainer.getContainerElement().contains(this.ref.hostElement);
	}
	disposeOverlayRef() {
		if (this.ref) {
			this.ref.dispose();
			this.overlayDestroy$.next(this.ref);
			this.ref = null;
			this.container = null;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDynamicOverlay,
			deps: [
				{ token: NbOverlayService },
				{ token: i0.NgZone },
				{ token: NbOverlayContainer }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDynamicOverlay
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDynamicOverlay,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbOverlayService },
		{ type: i0.NgZone },
		{ type: NbOverlayContainer }
	]
});
var NbDynamicOverlayChange = class extends SimpleChange {
	constructor(previousValue, currentValue, firstChange = false) {
		super(previousValue, currentValue, firstChange);
	}
	isChanged() {
		return this.currentValue !== this.previousValue;
	}
};
var NbDynamicOverlayHandler = class NbDynamicOverlayHandler {
	constructor(positionBuilder, triggerStrategyBuilder, dynamicOverlayService, directionService) {
		this.positionBuilder = positionBuilder;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.dynamicOverlayService = dynamicOverlayService;
		this.directionService = directionService;
		this._context = {};
		this._trigger = NbTrigger.NOOP;
		this._disabled = false;
		this._position = NbPosition.TOP;
		this._adjustment = NbAdjustment.NOOP;
		this._offset = 15;
		this._overlayConfig = {};
		this.changes = {};
		this.destroy$ = new Subject();
	}
	host(host) {
		this.changes.host = new NbDynamicOverlayChange(this._host, host);
		this._host = host;
		return this;
	}
	trigger(trigger) {
		this.changes.trigger = new NbDynamicOverlayChange(this._trigger, trigger);
		this._trigger = trigger;
		return this;
	}
	disabled(disabled) {
		this.changes.disabled = new NbDynamicOverlayChange(this._disabled, disabled);
		this._disabled = disabled;
		return this;
	}
	position(position) {
		this.changes.position = new NbDynamicOverlayChange(this._position, position);
		this._position = position;
		return this;
	}
	adjustment(adjustment) {
		this.changes.adjustment = new NbDynamicOverlayChange(this._adjustment, adjustment);
		this._adjustment = adjustment;
		return this;
	}
	componentType(componentType) {
		this.changes.componentType = new NbDynamicOverlayChange(this._componentType, componentType);
		this._componentType = componentType;
		return this;
	}
	content(content) {
		this.changes.content = new NbDynamicOverlayChange(this._content, content);
		this._content = content;
		return this;
	}
	context(context) {
		this.changes.context = new NbDynamicOverlayChange(this._context, context);
		this._context = context;
		return this;
	}
	offset(offset) {
		this.changes.offset = new NbDynamicOverlayChange(this._offset, offset);
		this._offset = offset;
		return this;
	}
	overlayConfig(overlayConfig) {
		this.changes.overlayConfig = new NbDynamicOverlayChange(this._overlayConfig, overlayConfig);
		this._overlayConfig = overlayConfig;
		return this;
	}
	build() {
		if (!this._componentType || !this._host) throw Error(`NbDynamicOverlayHandler: at least 'componentType' and 'host' should be
      passed before building a dynamic overlay.`);
		this.dynamicOverlay = this.dynamicOverlayService.create(this._componentType, this._content, this._context, this.createPositionStrategy(), this._overlayConfig, this._disabled);
		this.connect();
		this.clearChanges();
		return this.dynamicOverlay;
	}
	rebuild() {
		if (!this.dynamicOverlay) return;
		if (this.isPositionStrategyUpdateRequired()) this.dynamicOverlay.setPositionStrategy(this.createPositionStrategy());
		if (this.isTriggerStrategyUpdateRequired()) this.connect();
		if (this.isContainerRerenderRequired()) this.dynamicOverlay.setContentAndContext(this._content, this._context);
		if (this.isComponentTypeUpdateRequired()) this.dynamicOverlay.setComponent(this._componentType);
		if (this.isOverlayConfigUpdateRequired()) this.dynamicOverlay.setOverlayConfig(this._overlayConfig);
		if (this.isDisabledUpdated()) this.dynamicOverlay.setDisabled(this._disabled);
		this.clearChanges();
		return this.dynamicOverlay;
	}
	connect() {
		if (!this.dynamicOverlay) throw new Error(`NbDynamicOverlayHandler: cannot connect to DynamicOverlay
      as it is not created yet. Call build() first`);
		this.disconnect();
		this.subscribeOnTriggers(this.dynamicOverlay);
		this.subscribeOnDirectionChange();
	}
	disconnect() {
		if (this.triggerStrategy) this.triggerStrategy.destroy();
	}
	destroy() {
		this.destroy$.next();
		this.destroy$.complete();
		this.disconnect();
		this.clearChanges();
		if (this.dynamicOverlay) this.dynamicOverlay.dispose();
	}
	createPositionStrategy() {
		return this.positionBuilder.connectedTo(this._host).position(this._position).adjustment(this._adjustment).offset(this._offset).direction(this.directionService.getDirection());
	}
	subscribeOnTriggers(dynamicOverlay) {
		this.triggerStrategy = this.triggerStrategyBuilder.trigger(this._trigger).host(this._host.nativeElement).container(() => dynamicOverlay.getContainer()).build();
		this.triggerStrategy.show$.subscribe(() => dynamicOverlay.show());
		this.triggerStrategy.hide$.subscribe(() => dynamicOverlay.hide());
	}
	subscribeOnDirectionChange() {
		this.directionService.onDirectionChange().pipe(skip(1), takeUntil(this.destroy$)).subscribe(() => {
			this.dynamicOverlay.setPositionStrategy(this.createPositionStrategy());
		});
	}
	isContainerRerenderRequired() {
		return this.isContentUpdated() || this.isContextUpdated() || this.isPositionStrategyUpdateRequired();
	}
	isPositionStrategyUpdateRequired() {
		return this.isAdjustmentUpdated() || this.isPositionUpdated() || this.isOffsetUpdated() || this.isHostUpdated();
	}
	isTriggerStrategyUpdateRequired() {
		return this.isTriggerUpdated() || this.isHostUpdated();
	}
	isComponentTypeUpdateRequired() {
		return this.isComponentTypeUpdated();
	}
	isOverlayConfigUpdateRequired() {
		return this.isOverlayConfigUpdated();
	}
	isComponentTypeUpdated() {
		return this.changes.componentType && this.changes.componentType.isChanged();
	}
	isContentUpdated() {
		return this.changes.content && this.changes.content.isChanged();
	}
	isContextUpdated() {
		return this.changes.context && this.changes.context.isChanged();
	}
	isAdjustmentUpdated() {
		return this.changes.adjustment && this.changes.adjustment.isChanged();
	}
	isPositionUpdated() {
		return this.changes.position && this.changes.position.isChanged();
	}
	isHostUpdated() {
		return this.changes.host && this.changes.host.isChanged();
	}
	isTriggerUpdated() {
		return this.changes.trigger && this.changes.trigger.isChanged();
	}
	isOffsetUpdated() {
		return this.changes.offset && this.changes.offset.isChanged();
	}
	isOverlayConfigUpdated() {
		return this.changes.overlayConfig && this.changes.overlayConfig.isChanged();
	}
	isDisabledUpdated() {
		return this.changes.disabled && this.changes.disabled.isChanged();
	}
	clearChanges() {
		this.changes = {};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDynamicOverlayHandler,
			deps: [
				{ token: NbPositionBuilderService },
				{ token: NbTriggerStrategyBuilderService },
				{ token: NbDynamicOverlay },
				{ token: NbLayoutDirectionService }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDynamicOverlayHandler
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDynamicOverlayHandler,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbPositionBuilderService },
		{ type: NbTriggerStrategyBuilderService },
		{ type: NbDynamicOverlay },
		{ type: NbLayoutDirectionService }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbPopoverComponent = class NbPopoverComponent extends NbPositionedContainerComponent {
	renderContent() {
		this.detachContent();
		this.attachContent();
	}
	detachContent() {
		this.overlayContainer.detach();
	}
	attachContent() {
		if (this.content instanceof TemplateRef) this.attachTemplate();
		else if (this.content instanceof Type) this.attachComponent();
		else this.attachString();
	}
	attachTemplate() {
		this.overlayContainer.attachTemplatePortal(new NbTemplatePortal(this.content, null, { $implicit: this.context }));
	}
	attachComponent() {
		const portal = new NbComponentPortal(this.content, null, null);
		this.overlayContainer.attachComponentPortal(portal, this.context).changeDetectorRef.detectChanges();
	}
	attachString() {
		this.overlayContainer.attachStringContent(this.content);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPopoverComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPopoverComponent,
			isStandalone: false,
			selector: "nb-popover",
			inputs: {
				content: "content",
				context: "context"
			},
			viewQueries: [{
				propertyName: "overlayContainer",
				first: true,
				predicate: NbOverlayContainerComponent,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: `
    <span class="arrow"></span>
    <nb-overlay-container></nb-overlay-container>
  `,
			isInline: true,
			styles: [":host .arrow{position:absolute;width:0;height:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "component",
				type: NbOverlayContainerComponent,
				selector: "nb-overlay-container"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPopoverComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-popover",
			template: `
    <span class="arrow"></span>
    <nb-overlay-container></nb-overlay-container>
  `,
			standalone: false,
			styles: [":host .arrow{position:absolute;width:0;height:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		overlayContainer: [{
			type: ViewChild,
			args: [NbOverlayContainerComponent]
		}],
		content: [{ type: Input }],
		context: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbPopoverDirective = class NbPopoverDirective {
	get adjustment() {
		return this._adjustment;
	}
	set adjustment(value) {
		this._adjustment = value;
	}
	get popoverClass() {
		return this._popoverClass;
	}
	set popoverClass(value) {
		if (value !== this.popoverClass) {
			this._popoverClass = value;
			this.overlayConfig = { panelClass: this.popoverClass };
		}
	}
	get isShown() {
		return !!(this.dynamicOverlay && this.dynamicOverlay.isAttached);
	}
	constructor(hostRef, dynamicOverlayHandler) {
		this.hostRef = hostRef;
		this.dynamicOverlayHandler = dynamicOverlayHandler;
		this.popoverComponent = NbPopoverComponent;
		this.destroy$ = new Subject();
		this.context = {};
		this.position = NbPosition.TOP;
		this._adjustment = NbAdjustment.CLOCKWISE;
		this.trigger = NbTrigger.CLICK;
		this.offset = 15;
		this.disabled = false;
		this._popoverClass = "";
		this.nbPopoverShowStateChange = new EventEmitter();
		this.overlayConfig = { panelClass: this.popoverClass };
	}
	ngOnInit() {
		this.dynamicOverlayHandler.host(this.hostRef).componentType(this.popoverComponent);
	}
	ngOnChanges() {
		this.rebuild();
	}
	ngAfterViewInit() {
		this.dynamicOverlay = this.configureDynamicOverlay().build();
		this.dynamicOverlay.isShown.pipe(skip(1), takeUntil(this.destroy$)).subscribe((isShown) => this.nbPopoverShowStateChange.emit({ isShown }));
	}
	rebuild() {
		this.dynamicOverlay = this.configureDynamicOverlay().rebuild();
	}
	show() {
		this.dynamicOverlay.show();
	}
	hide() {
		this.dynamicOverlay.hide();
	}
	toggle() {
		this.dynamicOverlay.toggle();
	}
	ngOnDestroy() {
		this.dynamicOverlayHandler.destroy();
		this.destroy$.next();
		this.destroy$.complete();
	}
	configureDynamicOverlay() {
		return this.dynamicOverlayHandler.position(this.position).trigger(this.trigger).disabled(this.disabled).offset(this.offset).adjustment(this.adjustment).content(this.content).context(this.context).overlayConfig(this.overlayConfig);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPopoverDirective,
			deps: [{ token: i0.ElementRef }, { token: NbDynamicOverlayHandler }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPopoverDirective,
			isStandalone: false,
			selector: "[nbPopover]",
			inputs: {
				content: ["nbPopover", "content"],
				context: ["nbPopoverContext", "context"],
				position: ["nbPopoverPlacement", "position"],
				adjustment: ["nbPopoverAdjustment", "adjustment"],
				trigger: ["nbPopoverTrigger", "trigger"],
				offset: ["nbPopoverOffset", "offset"],
				disabled: ["nbTooltipDisabled", "disabled"],
				popoverClass: ["nbPopoverClass", "popoverClass"]
			},
			outputs: { nbPopoverShowStateChange: "nbPopoverShowStateChange" },
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			exportAs: ["nbPopover"],
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPopoverDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbPopover]",
			exportAs: "nbPopover",
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, { type: NbDynamicOverlayHandler }],
	propDecorators: {
		content: [{
			type: Input,
			args: ["nbPopover"]
		}],
		context: [{
			type: Input,
			args: ["nbPopoverContext"]
		}],
		position: [{
			type: Input,
			args: ["nbPopoverPlacement"]
		}],
		adjustment: [{
			type: Input,
			args: ["nbPopoverAdjustment"]
		}],
		trigger: [{
			type: Input,
			args: ["nbPopoverTrigger"]
		}],
		offset: [{
			type: Input,
			args: ["nbPopoverOffset"]
		}],
		disabled: [{
			type: Input,
			args: ["nbTooltipDisabled"]
		}],
		popoverClass: [{
			type: Input,
			args: ["nbPopoverClass"]
		}],
		nbPopoverShowStateChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbPopoverModule = class NbPopoverModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPopoverModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPopoverModule,
			declarations: [NbPopoverDirective, NbPopoverComponent],
			imports: [NbOverlayModule],
			exports: [NbPopoverDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPopoverModule,
			imports: [NbOverlayModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPopoverModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbOverlayModule],
			declarations: [NbPopoverDirective, NbPopoverComponent],
			exports: [NbPopoverDirective]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbContextMenuComponent = class NbContextMenuComponent extends NbPositionedContainerComponent {
	constructor() {
		super(...arguments);
		this.items = [];
		this.context = { items: [] };
	}
	renderContent() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbContextMenuComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbContextMenuComponent,
			isStandalone: false,
			selector: "nb-context-menu",
			inputs: {
				items: "items",
				tag: "tag",
				context: "context"
			},
			usesInheritance: true,
			ngImport: i0,
			template: `
    <nb-menu class="context-menu" [items]="context.items" [tag]="context.tag"></nb-menu>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbMenuComponent,
				selector: "nb-menu",
				inputs: [
					"tag",
					"items",
					"autoCollapse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbContextMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-context-menu",
			template: `
    <nb-menu class="context-menu" [items]="context.items" [tag]="context.tag"></nb-menu>
  `,
			standalone: false
		}]
	}],
	propDecorators: {
		items: [{ type: Input }],
		tag: [{ type: Input }],
		context: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbContextMenuDirective = class NbContextMenuDirective {
	get position() {
		return this._position;
	}
	set position(value) {
		if (value !== this.position) {
			this._position = value;
			this.updateOverlayContext();
		}
	}
	get tag() {
		return this._tag;
	}
	set tag(value) {
		if (value !== this.tag) {
			this._tag = value;
			this.updateOverlayContext();
		}
	}
	get items() {
		return this._items;
	}
	set items(items) {
		this.validateItems(items);
		this._items = items;
		this.updateOverlayContext();
	}
	get contextMenuClass() {
		return this._contextMenuClass;
	}
	set contextMenuClass(value) {
		if (value !== this.contextMenuClass) {
			this._contextMenuClass = value;
			this.overlayConfig = { panelClass: this.contextMenuClass };
		}
	}
	constructor(hostRef, menuService, dynamicOverlayHandler) {
		this.hostRef = hostRef;
		this.menuService = menuService;
		this.dynamicOverlayHandler = dynamicOverlayHandler;
		this.contextMenuHost = true;
		this._position = NbPosition.BOTTOM;
		this.adjustment = NbAdjustment.CLOCKWISE;
		this.trigger = NbTrigger.CLICK;
		this._contextMenuClass = "";
		this.overlayConfig = { panelClass: this.contextMenuClass };
		this.overlayContext = {
			items: this.items,
			tag: this.tag,
			position: this.position
		};
		this.destroy$ = new Subject();
		this._items = [];
	}
	ngOnInit() {
		this.dynamicOverlayHandler.host(this.hostRef).componentType(NbContextMenuComponent);
	}
	ngOnChanges() {
		this.rebuild();
	}
	ngAfterViewInit() {
		this.dynamicOverlay = this.configureDynamicOverlay().build();
		this.subscribeOnItemClick();
	}
	rebuild() {
		this.dynamicOverlay = this.configureDynamicOverlay().rebuild();
	}
	show() {
		this.dynamicOverlay.show();
	}
	hide() {
		this.dynamicOverlay.hide();
	}
	toggle() {
		this.dynamicOverlay.toggle();
	}
	ngOnDestroy() {
		this.dynamicOverlayHandler.destroy();
		this.destroy$.next();
		this.destroy$.complete();
	}
	configureDynamicOverlay() {
		return this.dynamicOverlayHandler.position(this.position).trigger(this.trigger).adjustment(this.adjustment).context(this.overlayContext).overlayConfig(this.overlayConfig);
	}
	validateItems(items) {
		if (!items || !items.length) throw Error(`List of menu items expected, but given: ${items}`);
	}
	subscribeOnItemClick() {
		this.menuService.onItemClick().pipe(filter(({ tag }) => tag === this.tag && this.trigger !== NbTrigger.NOOP), takeUntil(this.destroy$)).subscribe(() => this.hide());
	}
	updateOverlayContext() {
		this.overlayContext = {
			items: this.items,
			position: this.position,
			tag: this.tag
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbContextMenuDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: NbMenuService },
				{ token: NbDynamicOverlayHandler }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbContextMenuDirective,
			isStandalone: false,
			selector: "[nbContextMenu]",
			inputs: {
				position: ["nbContextMenuPlacement", "position"],
				adjustment: ["nbContextMenuAdjustment", "adjustment"],
				tag: ["nbContextMenuTag", "tag"],
				items: ["nbContextMenu", "items"],
				trigger: ["nbContextMenuTrigger", "trigger"],
				contextMenuClass: ["nbContextMenuClass", "contextMenuClass"]
			},
			host: { properties: { "class.context-menu-host": "this.contextMenuHost" } },
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbContextMenuDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbContextMenu]",
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: NbMenuService },
		{ type: NbDynamicOverlayHandler }
	],
	propDecorators: {
		contextMenuHost: [{
			type: HostBinding,
			args: ["class.context-menu-host"]
		}],
		position: [{
			type: Input,
			args: ["nbContextMenuPlacement"]
		}],
		adjustment: [{
			type: Input,
			args: ["nbContextMenuAdjustment"]
		}],
		tag: [{
			type: Input,
			args: ["nbContextMenuTag"]
		}],
		items: [{
			type: Input,
			args: ["nbContextMenu"]
		}],
		trigger: [{
			type: Input,
			args: ["nbContextMenuTrigger"]
		}],
		contextMenuClass: [{
			type: Input,
			args: ["nbContextMenuClass"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbContextMenuModule = class NbContextMenuModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbContextMenuModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbContextMenuModule,
			declarations: [NbContextMenuDirective, NbContextMenuComponent],
			imports: [
				CommonModule,
				NbOverlayModule,
				NbMenuModule
			],
			exports: [NbContextMenuDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbContextMenuModule,
			imports: [
				CommonModule,
				NbOverlayModule,
				NbMenuModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbContextMenuModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				NbOverlayModule,
				NbMenuModule
			],
			exports: [NbContextMenuDirective],
			declarations: [NbContextMenuDirective, NbContextMenuComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbProgressBarComponent = class NbProgressBarComponent {
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get info() {
		return this.status === "info";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.value = 0;
		this.status = "basic";
		this.size = "medium";
		this.displayValue = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbProgressBarComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbProgressBarComponent,
			isStandalone: false,
			selector: "nb-progress-bar",
			inputs: {
				value: "value",
				status: "status",
				size: "size",
				displayValue: "displayValue"
			},
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-info": "this.info",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses"
			} },
			ngImport: i0,
			template: `
    <div class="progress-container">
      <div class="progress-value" [style.width.%]="value">
        <span *ngIf="displayValue">{{ value }}%</span>
        <ng-content></ng-content>
      </div>
    </div>
  `,
			isInline: true,
			styles: [":host{display:block}.progress-container{overflow:hidden}.progress-value{height:100%;text-align:center;overflow:hidden}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbProgressBarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-progress-bar",
			template: `
    <div class="progress-container">
      <div class="progress-value" [style.width.%]="value">
        <span *ngIf="displayValue">{{ value }}%</span>
        <ng-content></ng-content>
      </div>
    </div>
  `,
			standalone: false,
			styles: [":host{display:block}.progress-container{overflow:hidden}.progress-value{height:100%;text-align:center;overflow:hidden}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		value: [{ type: Input }],
		status: [{ type: Input }],
		size: [{ type: Input }],
		displayValue: [{ type: Input }],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbProgressBarModule = class NbProgressBarModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbProgressBarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbProgressBarModule,
			declarations: [NbProgressBarComponent],
			imports: [NbSharedModule],
			exports: [NbProgressBarComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbProgressBarModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbProgressBarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: [NbProgressBarComponent],
			exports: [NbProgressBarComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAlertComponent = class NbAlertComponent {
	get closable() {
		return this._closable;
	}
	set closable(value) {
		this._closable = convertToBoolProperty(value);
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.size = "";
		this.status = "basic";
		this.accent = "";
		this.outline = "";
		this._closable = false;
		this.close = new EventEmitter();
	}
	onClose() {
		this.close.emit();
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get info() {
		return this.status === "info";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get primaryAccent() {
		return this.accent === "primary";
	}
	get successAccent() {
		return this.accent === "success";
	}
	get infoAccent() {
		return this.accent === "info";
	}
	get warningAccent() {
		return this.accent === "warning";
	}
	get dangerAccent() {
		return this.accent === "danger";
	}
	get basicAccent() {
		return this.accent === "basic";
	}
	get controlAccent() {
		return this.accent === "control";
	}
	get primaryOutline() {
		return this.outline === "primary";
	}
	get successOutline() {
		return this.outline === "success";
	}
	get infoOutline() {
		return this.outline === "info";
	}
	get warningOutline() {
		return this.outline === "warning";
	}
	get dangerOutline() {
		return this.outline === "danger";
	}
	get basicOutline() {
		return this.outline === "basic";
	}
	get controlOutline() {
		return this.outline === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAlertComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAlertComponent,
			isStandalone: false,
			selector: "nb-alert",
			inputs: {
				size: "size",
				status: "status",
				accent: "accent",
				outline: "outline",
				closable: "closable"
			},
			outputs: { close: "close" },
			host: { properties: {
				"class.closable": "this.closable",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-info": "this.info",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.accent-primary": "this.primaryAccent",
				"class.accent-success": "this.successAccent",
				"class.accent-info": "this.infoAccent",
				"class.accent-warning": "this.warningAccent",
				"class.accent-danger": "this.dangerAccent",
				"class.accent-basic": "this.basicAccent",
				"class.accent-control": "this.controlAccent",
				"class.outline-primary": "this.primaryOutline",
				"class.outline-success": "this.successOutline",
				"class.outline-info": "this.infoOutline",
				"class.outline-warning": "this.warningOutline",
				"class.outline-danger": "this.dangerOutline",
				"class.outline-basic": "this.basicOutline",
				"class.outline-control": "this.controlOutline",
				"class": "this.additionalClasses"
			} },
			ngImport: i0,
			template: `
    <button *ngIf="closable" type="button" class="close" aria-label="Close" (click)="onClose()">
      <span aria-hidden="true">&times;</span>
    </button>
    <ng-content></ng-content>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column;position:relative}[dir=ltr] :host .close{right:0}[dir=rtl] :host .close{left:0}.close{position:absolute;top:0;color:inherit;background-color:transparent;border:0;appearance:none}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAlertComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-alert",
			template: `
    <button *ngIf="closable" type="button" class="close" aria-label="Close" (click)="onClose()">
      <span aria-hidden="true">&times;</span>
    </button>
    <ng-content></ng-content>
  `,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column;position:relative}[dir=ltr] :host .close{right:0}[dir=rtl] :host .close{left:0}.close{position:absolute;top:0;color:inherit;background-color:transparent;border:0;appearance:none}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		size: [{ type: Input }],
		status: [{ type: Input }],
		accent: [{ type: Input }],
		outline: [{ type: Input }],
		closable: [{ type: Input }, {
			type: HostBinding,
			args: ["class.closable"]
		}],
		close: [{ type: Output }],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		primaryAccent: [{
			type: HostBinding,
			args: ["class.accent-primary"]
		}],
		successAccent: [{
			type: HostBinding,
			args: ["class.accent-success"]
		}],
		infoAccent: [{
			type: HostBinding,
			args: ["class.accent-info"]
		}],
		warningAccent: [{
			type: HostBinding,
			args: ["class.accent-warning"]
		}],
		dangerAccent: [{
			type: HostBinding,
			args: ["class.accent-danger"]
		}],
		basicAccent: [{
			type: HostBinding,
			args: ["class.accent-basic"]
		}],
		controlAccent: [{
			type: HostBinding,
			args: ["class.accent-control"]
		}],
		primaryOutline: [{
			type: HostBinding,
			args: ["class.outline-primary"]
		}],
		successOutline: [{
			type: HostBinding,
			args: ["class.outline-success"]
		}],
		infoOutline: [{
			type: HostBinding,
			args: ["class.outline-info"]
		}],
		warningOutline: [{
			type: HostBinding,
			args: ["class.outline-warning"]
		}],
		dangerOutline: [{
			type: HostBinding,
			args: ["class.outline-danger"]
		}],
		basicOutline: [{
			type: HostBinding,
			args: ["class.outline-basic"]
		}],
		controlOutline: [{
			type: HostBinding,
			args: ["class.outline-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAlertModule = class NbAlertModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAlertModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAlertModule,
			declarations: [NbAlertComponent],
			imports: [NbSharedModule],
			exports: [NbAlertComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAlertModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAlertModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: [NbAlertComponent],
			exports: [NbAlertComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbFormFieldControl = class NbFormFieldControl {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldControl,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldControl
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFormFieldControl,
	decorators: [{ type: Injectable }]
});
var NbFormFieldControlConfig = class NbFormFieldControlConfig {
	constructor() {
		this.supportsPrefix = true;
		this.supportsSuffix = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldControlConfig,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldControlConfig
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFormFieldControlConfig,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbInputDirective = class NbInputDirective {
	get fullWidth() {
		return this._fullWidth;
	}
	set fullWidth(value) {
		this._fullWidth = convertToBoolProperty(value);
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(elementRef, focusMonitor, renderer, zone, statusService) {
		this.elementRef = elementRef;
		this.focusMonitor = focusMonitor;
		this.renderer = renderer;
		this.zone = zone;
		this.statusService = statusService;
		this.destroy$ = new Subject();
		this.fieldSize = "medium";
		this.status = "basic";
		this.shape = "rectangle";
		this._fullWidth = false;
		this.status$ = new BehaviorSubject(this.status);
		this.size$ = new BehaviorSubject(this.fieldSize);
		this.focused$ = new BehaviorSubject(false);
		this.disabled$ = new BehaviorSubject(false);
		this.fullWidth$ = new BehaviorSubject(this.fullWidth);
	}
	ngDoCheck() {
		const isDisabled = this.elementRef.nativeElement.disabled;
		if (isDisabled !== this.disabled$.value) this.disabled$.next(isDisabled);
	}
	ngOnChanges({ status, fieldSize, fullWidth }) {
		if (status) this.status$.next(this.status);
		if (fieldSize) this.size$.next(this.fieldSize);
		if (fullWidth) this.fullWidth$.next(this.fullWidth);
	}
	ngOnInit() {
		this.focusMonitor.monitor(this.elementRef).pipe(map((origin) => !!origin), finalize(() => this.focusMonitor.stopMonitoring(this.elementRef)), takeUntil(this.destroy$)).subscribe(this.focused$);
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.elementRef.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.destroy$.next();
	}
	get tiny() {
		return this.fieldSize === "tiny";
	}
	get small() {
		return this.fieldSize === "small";
	}
	get medium() {
		return this.fieldSize === "medium";
	}
	get large() {
		return this.fieldSize === "large";
	}
	get giant() {
		return this.fieldSize === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get rectangle() {
		return this.shape === "rectangle";
	}
	get semiRound() {
		return this.shape === "semi-round";
	}
	get round() {
		return this.shape === "round";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbInputDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: NbFocusMonitor },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbInputDirective,
			isStandalone: false,
			selector: "input[nbInput],textarea[nbInput]",
			inputs: {
				fieldSize: "fieldSize",
				status: "status",
				shape: "shape",
				fullWidth: "fullWidth"
			},
			host: { properties: {
				"class.input-full-width": "this.fullWidth",
				"class": "this.additionalClasses",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.shape-rectangle": "this.rectangle",
				"class.shape-semi-round": "this.semiRound",
				"class.shape-round": "this.round"
			} },
			providers: [{
				provide: NbFormFieldControl,
				useExisting: NbInputDirective
			}],
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[nbInput],textarea[nbInput]",
			providers: [{
				provide: NbFormFieldControl,
				useExisting: NbInputDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: NbFocusMonitor },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		fieldSize: [{ type: Input }],
		status: [{ type: Input }],
		shape: [{ type: Input }],
		fullWidth: [{ type: Input }, {
			type: HostBinding,
			args: ["class.input-full-width"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		rectangle: [{
			type: HostBinding,
			args: ["class.shape-rectangle"]
		}],
		semiRound: [{
			type: HostBinding,
			args: ["class.shape-semi-round"]
		}],
		round: [{
			type: HostBinding,
			args: ["class.shape-round"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatFormComponent = class NbChatFormComponent {
	constructor(cd, domSanitizer) {
		this.cd = cd;
		this.domSanitizer = domSanitizer;
		this.status = "basic";
		this.inputFocus = false;
		this.inputHover = false;
		this.droppedFiles = [];
		this.imgDropTypes = [
			"image/png",
			"image/jpeg",
			"image/gif"
		];
		this.message = "";
		this.messagePlaceholder = "Type a message";
		this.buttonTitle = "";
		this.buttonIcon = "paper-plane-outline";
		this.showButton = true;
		this.dropFiles = false;
		this.dropFilePlaceholder = "Drop file to send";
		this.send = new EventEmitter();
		this.onInputChange = new EventEmitter();
		this.fileOver = false;
	}
	onDrop(event) {
		if (this.dropFiles) {
			event.preventDefault();
			event.stopPropagation();
			this.fileOver = false;
			if (event.dataTransfer && event.dataTransfer.files) for (const file of event.dataTransfer.files) {
				const res = file;
				if (this.imgDropTypes.includes(file.type)) {
					const fr = new FileReader();
					fr.onload = (e) => {
						res.src = e.target.result;
						res.urlStyle = this.domSanitizer.bypassSecurityTrustStyle(`url(${res.src})`);
						this.cd.detectChanges();
					};
					fr.readAsDataURL(file);
				}
				this.droppedFiles.push(res);
			}
		}
	}
	removeFile(file) {
		const index = this.droppedFiles.indexOf(file);
		if (index >= 0) this.droppedFiles.splice(index, 1);
	}
	onDragOver(event) {
		event.preventDefault();
		event.stopPropagation();
		if (this.dropFiles) this.fileOver = true;
	}
	onDragLeave(event) {
		event.preventDefault();
		event.stopPropagation();
		if (this.dropFiles) this.fileOver = false;
	}
	sendMessage() {
		if (this.droppedFiles.length || String(this.message).trim().length) {
			this.send.emit({
				message: this.message,
				files: this.droppedFiles
			});
			this.message = "";
			this.droppedFiles = [];
		}
	}
	setStatus(status) {
		if (this.status !== status) {
			this.status = status;
			this.cd.detectChanges();
		}
	}
	getInputStatus() {
		if (this.fileOver) return this.getHighlightStatus();
		if (this.inputFocus || this.inputHover) return this.status;
		return "basic";
	}
	getButtonStatus() {
		return this.getHighlightStatus();
	}
	getHighlightStatus() {
		if (this.status === "basic" || this.status === "control") return "primary";
		return this.status;
	}
	onModelChange(value) {
		this.onInputChange.emit(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatFormComponent,
			deps: [{ token: i0.ChangeDetectorRef }, { token: i1$2.DomSanitizer }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatFormComponent,
			isStandalone: false,
			selector: "nb-chat-form",
			inputs: {
				message: "message",
				messagePlaceholder: "messagePlaceholder",
				buttonTitle: "buttonTitle",
				buttonIcon: "buttonIcon",
				showButton: "showButton",
				dropFiles: "dropFiles",
				dropFilePlaceholder: "dropFilePlaceholder"
			},
			outputs: {
				send: "send",
				onInputChange: "onInputChange"
			},
			host: {
				listeners: {
					"drop": "onDrop($event)",
					"dragover": "onDragOver($event)",
					"dragleave": "onDragLeave($event)"
				},
				properties: { "class.file-over": "this.fileOver" }
			},
			ngImport: i0,
			template: `
    <div class="dropped-files" *ngIf="droppedFiles?.length">
      <ng-container *ngFor="let file of droppedFiles">
        <div *ngIf="file.urlStyle" [style.background-image]="file.urlStyle">
          <span class="remove" (click)="removeFile(file)">&times;</span>
        </div>

        <div *ngIf="!file.urlStyle">
          <nb-icon icon="file-text-outline" pack="nebular-essentials"></nb-icon>
          <span class="remove" (click)="removeFile(file)">&times;</span>
        </div>
      </ng-container>
    </div>
    <div class="message-row">
      <input
        nbInput
        fullWidth
        [status]="getInputStatus()"
        (focus)="inputFocus = true"
        (blur)="inputFocus = false"
        (mouseenter)="inputHover = true"
        (mouseleave)="inputHover = false"
        [(ngModel)]="message"
        (ngModelChange)="onModelChange($event)"
        [class.with-button]="showButton"
        type="text"
        placeholder="{{ fileOver ? dropFilePlaceholder : messagePlaceholder }}"
        (keyup.enter)="sendMessage()"
      />
      <button
        nbButton
        [status]="getButtonStatus()"
        *ngIf="showButton"
        [class.with-icon]="!buttonTitle"
        (click)="sendMessage()"
        class="send-button"
      >
        <nb-icon *ngIf="!buttonTitle; else title" [icon]="buttonIcon" pack="nebular-essentials"></nb-icon>
        <ng-template #title>{{ buttonTitle }}</ng-template>
      </button>
    </div>
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.NgModel,
					selector: "[ngModel]:not([formControlName]):not([formControl])",
					inputs: [
						"name",
						"disabled",
						"ngModel",
						"ngModelOptions"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngModel"]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "directive",
					type: NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatFormComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-form",
			template: `
    <div class="dropped-files" *ngIf="droppedFiles?.length">
      <ng-container *ngFor="let file of droppedFiles">
        <div *ngIf="file.urlStyle" [style.background-image]="file.urlStyle">
          <span class="remove" (click)="removeFile(file)">&times;</span>
        </div>

        <div *ngIf="!file.urlStyle">
          <nb-icon icon="file-text-outline" pack="nebular-essentials"></nb-icon>
          <span class="remove" (click)="removeFile(file)">&times;</span>
        </div>
      </ng-container>
    </div>
    <div class="message-row">
      <input
        nbInput
        fullWidth
        [status]="getInputStatus()"
        (focus)="inputFocus = true"
        (blur)="inputFocus = false"
        (mouseenter)="inputHover = true"
        (mouseleave)="inputHover = false"
        [(ngModel)]="message"
        (ngModelChange)="onModelChange($event)"
        [class.with-button]="showButton"
        type="text"
        placeholder="{{ fileOver ? dropFilePlaceholder : messagePlaceholder }}"
        (keyup.enter)="sendMessage()"
      />
      <button
        nbButton
        [status]="getButtonStatus()"
        *ngIf="showButton"
        [class.with-icon]="!buttonTitle"
        (click)="sendMessage()"
        class="send-button"
      >
        <nb-icon *ngIf="!buttonTitle; else title" [icon]="buttonIcon" pack="nebular-essentials"></nb-icon>
        <ng-template #title>{{ buttonTitle }}</ng-template>
      </button>
    </div>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1$2.DomSanitizer }],
	propDecorators: {
		message: [{ type: Input }],
		messagePlaceholder: [{ type: Input }],
		buttonTitle: [{ type: Input }],
		buttonIcon: [{ type: Input }],
		showButton: [{ type: Input }],
		dropFiles: [{ type: Input }],
		dropFilePlaceholder: [{ type: Input }],
		send: [{ type: Output }],
		onInputChange: [{ type: Output }],
		fileOver: [{
			type: HostBinding,
			args: ["class.file-over"]
		}],
		onDrop: [{
			type: HostListener,
			args: ["drop", ["$event"]]
		}],
		onDragOver: [{
			type: HostListener,
			args: ["dragover", ["$event"]]
		}],
		onDragLeave: [{
			type: HostListener,
			args: ["dragleave", ["$event"]]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatCustomMessageService = class NbChatCustomMessageService {
	constructor() {
		this.customMessages = /* @__PURE__ */ new Map();
	}
	register(type, instance) {
		this.customMessages.set(type, instance);
	}
	unregister(type) {
		return this.customMessages.delete(type);
	}
	getInstance(type) {
		return this.customMessages.get(type);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatCustomMessageService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatCustomMessageService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatCustomMessageService,
	decorators: [{ type: Injectable }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatMessageTextComponent = class NbChatMessageTextComponent {
	constructor() {
		this.dateFormat = "shortTime";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatMessageTextComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatMessageTextComponent,
			isStandalone: false,
			selector: "nb-chat-message-text",
			inputs: {
				sender: "sender",
				message: "message",
				date: "date",
				dateFormat: "dateFormat"
			},
			ngImport: i0,
			template: `
    <p class="sender" *ngIf="sender || date">{{ sender }} <time>{{ date  | date: dateFormat }}</time></p>
    <p class="text" *ngIf="message">{{ message }}</p>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "pipe",
				type: i2.DatePipe,
				name: "date"
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatMessageTextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-message-text",
			template: `
    <p class="sender" *ngIf="sender || date">{{ sender }} <time>{{ date  | date: dateFormat }}</time></p>
    <p class="text" *ngIf="message">{{ message }}</p>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: {
		sender: [{ type: Input }],
		message: [{ type: Input }],
		date: [{ type: Input }],
		dateFormat: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatMessageFileComponent = class NbChatMessageFileComponent {
	set files(files) {
		this.readyFiles = (files || []).map((file) => {
			const isImage = this.isImage(file);
			return {
				...file,
				urlStyle: isImage && this.domSanitizer.bypassSecurityTrustStyle(`url(${file.url})`),
				isImage
			};
		});
		this.cd.detectChanges();
	}
	constructor(cd, domSanitizer) {
		this.cd = cd;
		this.domSanitizer = domSanitizer;
		this.dateFormat = "shortTime";
	}
	isImage(file) {
		const type = file.type;
		if (type) return [
			"image/png",
			"image/jpeg",
			"image/gif"
		].includes(type);
		return false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatMessageFileComponent,
			deps: [{ token: i0.ChangeDetectorRef }, { token: i1$2.DomSanitizer }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatMessageFileComponent,
			isStandalone: false,
			selector: "nb-chat-message-file",
			inputs: {
				message: "message",
				sender: "sender",
				date: "date",
				dateFormat: "dateFormat",
				files: "files"
			},
			ngImport: i0,
			template: `
    <nb-chat-message-text [sender]="sender" [date]="date" [dateFormat]="dateFormat" [message]="message">
      {{ message }}
    </nb-chat-message-text>

    <ng-container *ngIf="readyFiles?.length > 1">
      <div class="message-content-group">
        <a *ngFor="let file of readyFiles" [href]="file.url" target="_blank">
          <nb-icon [icon]="file.icon" *ngIf="!file.urlStyle && file.icon"></nb-icon>
          <div *ngIf="file.urlStyle" [style.background-image]="file.urlStyle"></div>
        </a>
      </div>
    </ng-container>

    <ng-container *ngIf="readyFiles?.length === 1">
      <a [href]="readyFiles[0].url" target="_blank">
        <nb-icon [icon]="readyFiles[0].icon" *ngIf="!readyFiles[0].urlStyle && readyFiles[0].icon"></nb-icon>
        <div *ngIf="readyFiles[0].urlStyle" [style.background-image]="readyFiles[0].urlStyle"></div>
      </a>
    </ng-container>
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbChatMessageTextComponent,
					selector: "nb-chat-message-text",
					inputs: [
						"sender",
						"message",
						"date",
						"dateFormat"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatMessageFileComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-message-file",
			template: `
    <nb-chat-message-text [sender]="sender" [date]="date" [dateFormat]="dateFormat" [message]="message">
      {{ message }}
    </nb-chat-message-text>

    <ng-container *ngIf="readyFiles?.length > 1">
      <div class="message-content-group">
        <a *ngFor="let file of readyFiles" [href]="file.url" target="_blank">
          <nb-icon [icon]="file.icon" *ngIf="!file.urlStyle && file.icon"></nb-icon>
          <div *ngIf="file.urlStyle" [style.background-image]="file.urlStyle"></div>
        </a>
      </div>
    </ng-container>

    <ng-container *ngIf="readyFiles?.length === 1">
      <a [href]="readyFiles[0].url" target="_blank">
        <nb-icon [icon]="readyFiles[0].icon" *ngIf="!readyFiles[0].urlStyle && readyFiles[0].icon"></nb-icon>
        <div *ngIf="readyFiles[0].urlStyle" [style.background-image]="readyFiles[0].urlStyle"></div>
      </a>
    </ng-container>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1$2.DomSanitizer }],
	propDecorators: {
		message: [{ type: Input }],
		sender: [{ type: Input }],
		date: [{ type: Input }],
		dateFormat: [{ type: Input }],
		files: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatMessageQuoteComponent = class NbChatMessageQuoteComponent {
	constructor() {
		this.dateFormat = "shortTime";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatMessageQuoteComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatMessageQuoteComponent,
			isStandalone: false,
			selector: "nb-chat-message-quote",
			inputs: {
				message: "message",
				sender: "sender",
				date: "date",
				dateFormat: "dateFormat",
				quote: "quote"
			},
			ngImport: i0,
			template: `
    <p class="sender" *ngIf="sender || date">{{ sender }} <time>{{ date | date: dateFormat }}</time></p>
    <p class="quote">
      {{ quote }}
    </p>
    <nb-chat-message-text [message]="message">
      {{ message }}
    </nb-chat-message-text>
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "component",
					type: NbChatMessageTextComponent,
					selector: "nb-chat-message-text",
					inputs: [
						"sender",
						"message",
						"date",
						"dateFormat"
					]
				},
				{
					kind: "pipe",
					type: i2.DatePipe,
					name: "date"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatMessageQuoteComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-message-quote",
			template: `
    <p class="sender" *ngIf="sender || date">{{ sender }} <time>{{ date | date: dateFormat }}</time></p>
    <p class="quote">
      {{ quote }}
    </p>
    <nb-chat-message-text [message]="message">
      {{ message }}
    </nb-chat-message-text>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: {
		message: [{ type: Input }],
		sender: [{ type: Input }],
		date: [{ type: Input }],
		dateFormat: [{ type: Input }],
		quote: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatOptions = class {};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatMessageMapComponent = class NbChatMessageMapComponent {
	get file() {
		return {
			url: `https://maps.googleapis.com/maps/api/staticmap?center=${this.latitude},${this.longitude}&zoom=12&size=400x400&key=${this.mapKey}`,
			type: "image/png",
			icon: "location"
		};
	}
	constructor(options) {
		this.dateFormat = "shortTime";
		this.mapKey = options.messageGoogleMapKey;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatMessageMapComponent,
			deps: [{ token: NbChatOptions }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatMessageMapComponent,
			isStandalone: false,
			selector: "nb-chat-message-map",
			inputs: {
				message: "message",
				sender: "sender",
				date: "date",
				dateFormat: "dateFormat",
				latitude: "latitude",
				longitude: "longitude"
			},
			ngImport: i0,
			template: `
    <nb-chat-message-file [files]="[file]" [message]="message" [sender]="sender" [date]="date"
     [dateFormat]="dateFormat"></nb-chat-message-file>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: NbChatMessageFileComponent,
				selector: "nb-chat-message-file",
				inputs: [
					"message",
					"sender",
					"date",
					"dateFormat",
					"files"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatMessageMapComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-message-map",
			template: `
    <nb-chat-message-file [files]="[file]" [message]="message" [sender]="sender" [date]="date"
     [dateFormat]="dateFormat"></nb-chat-message-file>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbChatOptions }],
	propDecorators: {
		message: [{ type: Input }],
		sender: [{ type: Input }],
		date: [{ type: Input }],
		dateFormat: [{ type: Input }],
		latitude: [{ type: Input }],
		longitude: [{ type: Input }]
	}
});
var NbChatAvatarComponent = class NbChatAvatarComponent {
	constructor() {
		this.avatarClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatAvatarComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatAvatarComponent,
			isStandalone: false,
			selector: "nb-chat-avatar",
			inputs: {
				initials: "initials",
				avatarStyle: "avatarStyle"
			},
			host: { properties: {
				"style.background-image": "this.avatarStyle",
				"class.avatar": "this.avatarClass"
			} },
			ngImport: i0,
			template: `
    <ng-container *ngIf="!avatarStyle">
      {{ initials }}
    </ng-container>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatAvatarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-avatar",
			template: `
    <ng-container *ngIf="!avatarStyle">
      {{ initials }}
    </ng-container>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: {
		initials: [{ type: Input }],
		avatarStyle: [{ type: Input }, {
			type: HostBinding,
			args: ["style.background-image"]
		}],
		avatarClass: [{
			type: HostBinding,
			args: ["class.avatar"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatMessageComponent = class NbChatMessageComponent {
	get _addReplyClass() {
		return this._areDefaultStylesEnabled() && this.reply;
	}
	get _addNotReplyClass() {
		return this._areDefaultStylesEnabled() && this.notReply;
	}
	get _addNoSpaceClass() {
		return this._areDefaultStylesEnabled() && !this.message;
	}
	get flyInOut() {
		return true;
	}
	get notReply() {
		return !this.reply;
	}
	get reply() {
		return this._reply;
	}
	set reply(value) {
		this._reply = convertToBoolProperty(value);
	}
	set avatar(value) {
		this.avatarStyle = value ? this.domSanitizer.bypassSecurityTrustStyle(`url(${value})`) : null;
	}
	constructor(domSanitizer, customMessageService) {
		this.domSanitizer = domSanitizer;
		this.customMessageService = customMessageService;
		this.builtInMessageTypes = [
			"text",
			"file",
			"map",
			"quote"
		];
		this._reply = false;
	}
	getInitials() {
		if (this.sender) return this.sender.split(" ").map((n) => n.charAt(0)).splice(0, 2).join("").toUpperCase();
		return "";
	}
	_isBuiltInMessageType() {
		return this.type == null || this.builtInMessageTypes.includes(this.type);
	}
	_getTemplate() {
		return this.getCustomMessage(this.type).templateRef;
	}
	_getTemplateContext() {
		return {
			$implicit: this.customMessageData,
			isReply: this.reply
		};
	}
	_areDefaultStylesEnabled() {
		return !this.getCustomMessage(this.type).noStyles;
	}
	getCustomMessage(type) {
		const customMessageDirective = this.customMessageService.getInstance(type);
		if (!customMessageDirective) throw new Error(`nb-chat: Can't find template for custom type '${type}'. Make sure you provide it in the chat component with *nbCustomMessage='${type}'.`);
		return customMessageDirective;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatMessageComponent,
			deps: [{ token: i1$2.DomSanitizer }, { token: NbChatCustomMessageService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatMessageComponent,
			isStandalone: false,
			selector: "nb-chat-message",
			inputs: {
				reply: "reply",
				message: "message",
				sender: "sender",
				date: "date",
				dateFormat: "dateFormat",
				files: "files",
				quote: "quote",
				latitude: "latitude",
				longitude: "longitude",
				avatar: "avatar",
				type: "type",
				customMessageData: "customMessageData"
			},
			host: { properties: {
				"@flyInOut": "this.flyInOut",
				"class.not-reply": "this.notReply",
				"class.reply": "this.reply"
			} },
			ngImport: i0,
			template: `
    <nb-chat-avatar *ngIf="notReply" [initials]="getInitials()" [avatarStyle]="avatarStyle"> </nb-chat-avatar>

    <div class="message">
      <ng-container [ngSwitch]="type" *ngIf="_isBuiltInMessageType(); else customTemplate">
        <nb-chat-message-file
          *ngSwitchCase="'file'"
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
          [files]="files"
        >
        </nb-chat-message-file>

        <nb-chat-message-quote
          *ngSwitchCase="'quote'"
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
          [quote]="quote"
        >
        </nb-chat-message-quote>

        <nb-chat-message-map
          *ngSwitchCase="'map'"
          [sender]="sender"
          [date]="date"
          [message]="message"
          [latitude]="latitude"
          [longitude]="longitude"
        >
        </nb-chat-message-map>

        <nb-chat-message-text
          *ngSwitchDefault
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
        >
        </nb-chat-message-text>
      </ng-container>
    </div>

    <ng-template #customTemplate>
      <nb-chat-message-text [sender]="sender" [date]="date" [dateFormat]="dateFormat" [message]="message">
      </nb-chat-message-text>
      <div
        [class.nb-custom-message]="_areDefaultStylesEnabled()"
        [class.nb-custom-message-no-space]="_addNoSpaceClass"
        [class.nb-custom-message-reply]="_addReplyClass"
        [class.nb-custom-message-not-reply]="_addNotReplyClass"
        [class.nb-custom-message-full-width]="!_areDefaultStylesEnabled()"
      >
        <ng-container [ngTemplateOutlet]="_getTemplate()" [ngTemplateOutletContext]="_getTemplateContext()">
        </ng-container>
      </div>
    </ng-template>
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "directive",
					type: i2.NgSwitch,
					selector: "[ngSwitch]",
					inputs: ["ngSwitch"]
				},
				{
					kind: "directive",
					type: i2.NgSwitchCase,
					selector: "[ngSwitchCase]",
					inputs: ["ngSwitchCase"]
				},
				{
					kind: "directive",
					type: i2.NgSwitchDefault,
					selector: "[ngSwitchDefault]"
				},
				{
					kind: "component",
					type: NbChatMessageTextComponent,
					selector: "nb-chat-message-text",
					inputs: [
						"sender",
						"message",
						"date",
						"dateFormat"
					]
				},
				{
					kind: "component",
					type: NbChatMessageFileComponent,
					selector: "nb-chat-message-file",
					inputs: [
						"message",
						"sender",
						"date",
						"dateFormat",
						"files"
					]
				},
				{
					kind: "component",
					type: NbChatMessageQuoteComponent,
					selector: "nb-chat-message-quote",
					inputs: [
						"message",
						"sender",
						"date",
						"dateFormat",
						"quote"
					]
				},
				{
					kind: "component",
					type: NbChatMessageMapComponent,
					selector: "nb-chat-message-map",
					inputs: [
						"message",
						"sender",
						"date",
						"dateFormat",
						"latitude",
						"longitude"
					]
				},
				{
					kind: "component",
					type: NbChatAvatarComponent,
					selector: "nb-chat-avatar",
					inputs: ["initials", "avatarStyle"]
				}
			],
			animations: [trigger("flyInOut", [
				state("in", style({ transform: "translateX(0)" })),
				transition("void => *", [style({ transform: "translateX(-100%)" }), animate(80)]),
				transition("* => void", [animate(80, style({ transform: "translateX(100%)" }))])
			])],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatMessageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat-message",
			template: `
    <nb-chat-avatar *ngIf="notReply" [initials]="getInitials()" [avatarStyle]="avatarStyle"> </nb-chat-avatar>

    <div class="message">
      <ng-container [ngSwitch]="type" *ngIf="_isBuiltInMessageType(); else customTemplate">
        <nb-chat-message-file
          *ngSwitchCase="'file'"
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
          [files]="files"
        >
        </nb-chat-message-file>

        <nb-chat-message-quote
          *ngSwitchCase="'quote'"
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
          [quote]="quote"
        >
        </nb-chat-message-quote>

        <nb-chat-message-map
          *ngSwitchCase="'map'"
          [sender]="sender"
          [date]="date"
          [message]="message"
          [latitude]="latitude"
          [longitude]="longitude"
        >
        </nb-chat-message-map>

        <nb-chat-message-text
          *ngSwitchDefault
          [sender]="sender"
          [date]="date"
          [dateFormat]="dateFormat"
          [message]="message"
        >
        </nb-chat-message-text>
      </ng-container>
    </div>

    <ng-template #customTemplate>
      <nb-chat-message-text [sender]="sender" [date]="date" [dateFormat]="dateFormat" [message]="message">
      </nb-chat-message-text>
      <div
        [class.nb-custom-message]="_areDefaultStylesEnabled()"
        [class.nb-custom-message-no-space]="_addNoSpaceClass"
        [class.nb-custom-message-reply]="_addReplyClass"
        [class.nb-custom-message-not-reply]="_addNotReplyClass"
        [class.nb-custom-message-full-width]="!_areDefaultStylesEnabled()"
      >
        <ng-container [ngTemplateOutlet]="_getTemplate()" [ngTemplateOutletContext]="_getTemplateContext()">
        </ng-container>
      </div>
    </ng-template>
  `,
			animations: [trigger("flyInOut", [
				state("in", style({ transform: "translateX(0)" })),
				transition("void => *", [style({ transform: "translateX(-100%)" }), animate(80)]),
				transition("* => void", [animate(80, style({ transform: "translateX(100%)" }))])
			])],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i1$2.DomSanitizer }, { type: NbChatCustomMessageService }],
	propDecorators: {
		flyInOut: [{
			type: HostBinding,
			args: ["@flyInOut"]
		}],
		notReply: [{
			type: HostBinding,
			args: ["class.not-reply"]
		}],
		reply: [{ type: Input }, {
			type: HostBinding,
			args: ["class.reply"]
		}],
		message: [{ type: Input }],
		sender: [{ type: Input }],
		date: [{ type: Input }],
		dateFormat: [{ type: Input }],
		files: [{ type: Input }],
		quote: [{ type: Input }],
		latitude: [{ type: Input }],
		longitude: [{ type: Input }],
		avatar: [{ type: Input }],
		type: [{ type: Input }],
		customMessageData: [{ type: Input }]
	}
});
var NbChatTitleDirective = class NbChatTitleDirective {
	constructor(templateRef) {
		this.templateRef = templateRef;
		this.context = {};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatTitleDirective,
			deps: [{ token: i0.TemplateRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatTitleDirective,
			isStandalone: false,
			selector: "[nbChatTitle]",
			inputs: { context: "context" },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatTitleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: `[nbChatTitle]`,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }],
	propDecorators: { context: [{ type: Input }] }
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbChatComponent = class NbChatComponent {
	get scrollBottom() {
		return this._scrollBottom;
	}
	set scrollBottom(value) {
		this._scrollBottom = convertToBoolProperty(value);
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.status = "basic";
		this.noMessagesPlaceholder = "No messages yet.";
		this._scrollBottom = true;
	}
	ngOnChanges(changes) {
		if ("status" in changes) this.updateFormStatus();
	}
	ngAfterContentInit() {
		this.updateFormStatus();
	}
	ngAfterViewInit() {
		this.messages.changes.subscribe((messages) => {
			this.messages = messages;
			this.updateView();
		});
		this.updateView();
	}
	updateView() {
		if (this.scrollBottom) this.scrollListBottom();
	}
	scrollListBottom() {
		this.scrollable.nativeElement.scrollTop = this.scrollable.nativeElement.scrollHeight;
	}
	updateFormStatus() {
		if (this.chatForm) this.chatForm.setStatus(this.status);
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get info() {
		return this.status === "info";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatComponent,
			isStandalone: false,
			selector: "nb-chat",
			inputs: {
				title: "title",
				size: "size",
				status: "status",
				noMessagesPlaceholder: "noMessagesPlaceholder",
				scrollBottom: "scrollBottom"
			},
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-info": "this.info",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses"
			} },
			providers: [NbChatCustomMessageService],
			queries: [
				{
					propertyName: "chatForm",
					first: true,
					predicate: NbChatFormComponent,
					descendants: true
				},
				{
					propertyName: "titleTemplate",
					first: true,
					predicate: NbChatTitleDirective,
					descendants: true
				},
				{
					propertyName: "messages",
					predicate: NbChatMessageComponent
				}
			],
			viewQueries: [{
				propertyName: "scrollable",
				first: true,
				predicate: ["scrollable"],
				descendants: true
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <div class="header">
      <ng-container
        *ngIf="titleTemplate; else textTitleTemplate"
        [ngTemplateOutlet]="titleTemplate.templateRef"
        [ngTemplateOutletContext]="{ $implicit: titleTemplate.context }"
      >
      </ng-container>
      <ng-template #textTitleTemplate>
        {{ title }}
      </ng-template>
    </div>

    <div class="scrollable" #scrollable>
      <div class="messages">
        <ng-content select="nb-chat-message"></ng-content>
        <p class="no-messages" *ngIf="!messages?.length">{{ noMessagesPlaceholder }}</p>
      </div>
    </div>
    <div class="form">
      <ng-content select="nb-chat-form"></ng-content>
    </div>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column;position:relative;height:100%}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "directive",
				type: i2.NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-chat",
			template: `
    <div class="header">
      <ng-container
        *ngIf="titleTemplate; else textTitleTemplate"
        [ngTemplateOutlet]="titleTemplate.templateRef"
        [ngTemplateOutletContext]="{ $implicit: titleTemplate.context }"
      >
      </ng-container>
      <ng-template #textTitleTemplate>
        {{ title }}
      </ng-template>
    </div>

    <div class="scrollable" #scrollable>
      <div class="messages">
        <ng-content select="nb-chat-message"></ng-content>
        <p class="no-messages" *ngIf="!messages?.length">{{ noMessagesPlaceholder }}</p>
      </div>
    </div>
    <div class="form">
      <ng-content select="nb-chat-form"></ng-content>
    </div>
  `,
			providers: [NbChatCustomMessageService],
			standalone: false,
			styles: [":host{display:flex;flex-direction:column;position:relative;height:100%}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		title: [{ type: Input }],
		size: [{ type: Input }],
		status: [{ type: Input }],
		noMessagesPlaceholder: [{ type: Input }],
		scrollBottom: [{ type: Input }],
		scrollable: [{
			type: ViewChild,
			args: ["scrollable"]
		}],
		messages: [{
			type: ContentChildren,
			args: [NbChatMessageComponent]
		}],
		chatForm: [{
			type: ContentChild,
			args: [NbChatFormComponent]
		}],
		titleTemplate: [{
			type: ContentChild,
			args: [NbChatTitleDirective]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_INPUT_COMPONENTS = [NbInputDirective];
var NbInputModule = class NbInputModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbInputModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbInputModule,
			declarations: [NbInputDirective],
			imports: [NbSharedModule],
			exports: [NbInputDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbInputModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbInputModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			declarations: NB_INPUT_COMPONENTS,
			exports: NB_INPUT_COMPONENTS
		}]
	}]
});
function throwCustomMessageTypeIsRequired() {
	throw new Error("[nbCustomMessage]: custom message type is required.");
}
var NbChatCustomMessageDirective = class NbChatCustomMessageDirective {
	get nbCustomMessage() {
		return this._type;
	}
	set nbCustomMessage(value) {
		this._type = value;
	}
	get type() {
		return this._type;
	}
	set nbCustomMessageNoStyles(value) {
		this._noStyles = convertToBoolProperty(value);
	}
	get nbCustomMessageNoStyles() {
		return this._noStyles;
	}
	get noStyles() {
		return this.nbCustomMessageNoStyles;
	}
	constructor(templateRef, customMessageService) {
		this.templateRef = templateRef;
		this.customMessageService = customMessageService;
		this._noStyles = false;
	}
	ngOnInit() {
		if (!this._type) throwCustomMessageTypeIsRequired();
		this.customMessageService.register(this.type, this);
	}
	ngOnDestroy() {
		this.customMessageService.unregister(this.type);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatCustomMessageDirective,
			deps: [{ token: i0.TemplateRef }, { token: NbChatCustomMessageService }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbChatCustomMessageDirective,
			isStandalone: false,
			selector: "[nbCustomMessage]",
			inputs: {
				nbCustomMessage: "nbCustomMessage",
				nbCustomMessageNoStyles: "nbCustomMessageNoStyles"
			},
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatCustomMessageDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: `[nbCustomMessage]`,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }, { type: NbChatCustomMessageService }],
	propDecorators: {
		nbCustomMessage: [{ type: Input }],
		nbCustomMessageNoStyles: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_CHAT_COMPONENTS = [
	NbChatComponent,
	NbChatMessageComponent,
	NbChatFormComponent,
	NbChatMessageTextComponent,
	NbChatMessageFileComponent,
	NbChatMessageQuoteComponent,
	NbChatMessageMapComponent,
	NbChatAvatarComponent
];
const NB_CHAT_DIRECTIVES = [NbChatCustomMessageDirective, NbChatTitleDirective];
var NbChatModule = class NbChatModule {
	static forRoot(options) {
		return {
			ngModule: NbChatModule,
			providers: [{
				provide: NbChatOptions,
				useValue: options || {}
			}]
		};
	}
	static forChild(options) {
		return {
			ngModule: NbChatModule,
			providers: [{
				provide: NbChatOptions,
				useValue: options || {}
			}]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatModule,
			declarations: [
				NbChatComponent,
				NbChatMessageComponent,
				NbChatFormComponent,
				NbChatMessageTextComponent,
				NbChatMessageFileComponent,
				NbChatMessageQuoteComponent,
				NbChatMessageMapComponent,
				NbChatAvatarComponent,
				NbChatCustomMessageDirective,
				NbChatTitleDirective
			],
			imports: [
				NbSharedModule,
				NbIconModule,
				NbInputModule,
				NbButtonModule
			],
			exports: [
				NbChatComponent,
				NbChatMessageComponent,
				NbChatFormComponent,
				NbChatMessageTextComponent,
				NbChatMessageFileComponent,
				NbChatMessageQuoteComponent,
				NbChatMessageMapComponent,
				NbChatAvatarComponent,
				NbChatCustomMessageDirective,
				NbChatTitleDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbChatModule,
			imports: [
				NbSharedModule,
				NbIconModule,
				NbInputModule,
				NbButtonModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbChatModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbIconModule,
				NbInputModule,
				NbButtonModule
			],
			declarations: [...NB_CHAT_COMPONENTS, ...NB_CHAT_DIRECTIVES],
			exports: [...NB_CHAT_COMPONENTS, ...NB_CHAT_DIRECTIVES]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSpinnerComponent = class NbSpinnerComponent {
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.message = "Loading...";
		this.size = "medium";
		this.status = "basic";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSpinnerComponent,
			isStandalone: false,
			selector: "nb-spinner",
			inputs: {
				message: "message",
				size: "size",
				status: "status"
			},
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses"
			} },
			ngImport: i0,
			template: `
    <span class="spin-circle"></span>
    <span class="message" *ngIf="message">{{ message }}</span>
  `,
			isInline: true,
			styles: [":host{opacity:1;position:absolute;border-radius:inherit;inset:0;overflow:hidden;z-index:9999;display:flex;justify-content:center;align-items:center;visibility:visible}:host .spin-circle{animation:spin .8s infinite linear;border-radius:50%;border-style:solid;border-width:.125em;width:1em;height:1em}:host .message{margin-left:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSpinnerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-spinner",
			template: `
    <span class="spin-circle"></span>
    <span class="message" *ngIf="message">{{ message }}</span>
  `,
			standalone: false,
			styles: [":host{opacity:1;position:absolute;border-radius:inherit;inset:0;overflow:hidden;z-index:9999;display:flex;justify-content:center;align-items:center;visibility:visible}:host .spin-circle{animation:spin .8s infinite linear;border-radius:50%;border-style:solid;border-width:.125em;width:1em;height:1em}:host .message{margin-left:.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		message: [{ type: Input }],
		size: [{ type: Input }],
		status: [{ type: Input }],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSpinnerDirective = class NbSpinnerDirective {
	set nbSpinner(val) {
		if (val) this.show();
		else this.hide();
	}
	constructor(directiveView, renderer, directiveElement) {
		this.directiveView = directiveView;
		this.renderer = renderer;
		this.directiveElement = directiveElement;
		this.spinnerStatus = "basic";
		this.spinnerSize = "medium";
		this.isSpinnerExist = false;
	}
	hide() {
		if (this.isSpinnerExist) {
			this.directiveView.remove();
			this.isSpinnerExist = false;
		}
	}
	show() {
		if (!this.isSpinnerExist) {
			this.spinner = this.directiveView.createComponent(NbSpinnerComponent);
			this.setInstanceInputs(this.spinner.instance);
			this.spinner.changeDetectorRef.detectChanges();
			this.renderer.appendChild(this.directiveElement.nativeElement, this.spinner.location.nativeElement);
			this.isSpinnerExist = true;
		}
	}
	setInstanceInputs(instance) {
		instance.message = this.spinnerMessage;
		typeof this.spinnerStatus !== "undefined" && (instance.status = this.spinnerStatus);
		typeof this.spinnerSize !== "undefined" && (instance.size = this.spinnerSize);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerDirective,
			deps: [
				{ token: i0.ViewContainerRef },
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSpinnerDirective,
			isStandalone: false,
			selector: "[nbSpinner]",
			inputs: {
				spinnerMessage: ["nbSpinnerMessage", "spinnerMessage"],
				spinnerStatus: ["nbSpinnerStatus", "spinnerStatus"],
				spinnerSize: ["nbSpinnerSize", "spinnerSize"],
				nbSpinner: "nbSpinner"
			},
			host: { properties: { "class.nb-spinner-container": "this.isSpinnerExist" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSpinnerDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbSpinner]",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ViewContainerRef },
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef }
	],
	propDecorators: {
		spinnerMessage: [{
			type: Input,
			args: ["nbSpinnerMessage"]
		}],
		spinnerStatus: [{
			type: Input,
			args: ["nbSpinnerStatus"]
		}],
		spinnerSize: [{
			type: Input,
			args: ["nbSpinnerSize"]
		}],
		nbSpinner: [{
			type: Input,
			args: ["nbSpinner"]
		}],
		isSpinnerExist: [{
			type: HostBinding,
			args: ["class.nb-spinner-container"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSpinnerModule = class NbSpinnerModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerModule,
			declarations: [NbSpinnerComponent, NbSpinnerDirective],
			imports: [NbSharedModule],
			exports: [NbSpinnerComponent, NbSpinnerDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSpinnerModule,
			imports: [NbSharedModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSpinnerModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule],
			exports: [NbSpinnerComponent, NbSpinnerDirective],
			declarations: [NbSpinnerComponent, NbSpinnerDirective]
		}]
	}]
});
const NB_STEPPER = new InjectionToken("Nebular Stepper Component");
var NbStepComponent = class NbStepComponent {
	get hidden() {
		return this._hidden;
	}
	set hidden(value) {
		this._hidden = convertToBoolProperty(value);
	}
	get isLabelTemplate() {
		return this.label instanceof TemplateRef;
	}
	get completed() {
		return this._completed || this.isCompleted;
	}
	set completed(value) {
		this._completed = convertToBoolProperty(value);
	}
	get isCompleted() {
		return this.stepControl ? this.stepControl.valid && this.interacted : this.interacted;
	}
	constructor(stepper) {
		this._hidden = false;
		this._completed = false;
		this.interacted = false;
		this.stepper = stepper;
	}
	select() {
		this.stepper.selected = this;
	}
	reset() {
		this.interacted = false;
		if (this.stepControl) this.stepControl.reset();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepComponent,
			deps: [{ token: NB_STEPPER }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbStepComponent,
			isStandalone: false,
			selector: "nb-step",
			inputs: {
				stepControl: "stepControl",
				label: "label",
				hidden: "hidden",
				completed: "completed"
			},
			viewQueries: [{
				propertyName: "content",
				first: true,
				predicate: TemplateRef,
				descendants: true,
				static: true
			}],
			ngImport: i0,
			template: `
    <ng-template>
      <ng-content></ng-content>
    </ng-template>
  `,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStepComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-step",
			template: `
    <ng-template>
      <ng-content></ng-content>
    </ng-template>
  `,
			standalone: false
		}]
	}],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_STEPPER]
		}]
	}],
	propDecorators: {
		content: [{
			type: ViewChild,
			args: [TemplateRef, { static: true }]
		}],
		stepControl: [{ type: Input }],
		label: [{ type: Input }],
		hidden: [{ type: Input }],
		completed: [{ type: Input }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbStepperComponent = class NbStepperComponent {
	constructor() {
		this._selectedIndex = 0;
		this._disableStepNavigation = false;
		this.orientation = "horizontal";
		this._linear = true;
		this.stepChange = new EventEmitter();
	}
	get selectedIndex() {
		return this._selectedIndex;
	}
	set selectedIndex(index) {
		if (!this.steps) {
			this._selectedIndex = index;
			return;
		}
		this.markCurrentStepInteracted();
		if (this.canBeSelected(index)) {
			const previouslySelectedIndex = this._selectedIndex;
			const previouslySelectedStep = this.selected;
			this._selectedIndex = index;
			this.stepChange.emit({
				index: this.selectedIndex,
				step: this.selected,
				previouslySelectedIndex,
				previouslySelectedStep
			});
		}
	}
	set disableStepNavigation(value) {
		this._disableStepNavigation = convertToBoolProperty(value);
	}
	get disableStepNavigation() {
		return this._disableStepNavigation;
	}
	get selected() {
		return this.steps ? this.steps.toArray()[this.selectedIndex] : void 0;
	}
	set selected(step) {
		if (!this.steps) return;
		this.selectedIndex = this.steps.toArray().indexOf(step);
	}
	set linear(value) {
		this._linear = convertToBoolProperty(value);
	}
	get linear() {
		return this._linear;
	}
	get vertical() {
		return this.orientation === "vertical";
	}
	get horizontal() {
		return this.orientation === "horizontal";
	}
	next() {
		this.selectedIndex = Math.min(this.selectedIndex + 1, this.steps.length - 1);
	}
	previous() {
		this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
	}
	changeStep(step) {
		if (!this.disableStepNavigation) step.select();
	}
	reset() {
		const previouslySelectedIndex = this.selectedIndex;
		const previouslySelectedStep = this.selected;
		this._selectedIndex = 0;
		this.steps.forEach((step) => step.reset());
		this.stepChange.emit({
			index: this.selectedIndex,
			step: this.selected,
			previouslySelectedIndex,
			previouslySelectedStep
		});
	}
	isStepSelected(step) {
		return this.selected === step;
	}
	getStepTemplate(step) {
		if (step.isLabelTemplate) return step.label;
		return null;
	}
	isStepValid(index) {
		return this.steps.toArray()[index].completed;
	}
	canBeSelected(indexToCheck) {
		if (!this.steps || this.steps.length === 0 || indexToCheck < 0 || indexToCheck >= this.steps.length || indexToCheck === this.selectedIndex) return false;
		if (indexToCheck <= this.selectedIndex || !this.linear) return true;
		let isAllStepsValid = true;
		for (let i = this.selectedIndex; i < indexToCheck; i++) if (!this.isStepValid(i)) {
			isAllStepsValid = false;
			break;
		}
		return isAllStepsValid;
	}
	markCurrentStepInteracted() {
		if (this.selected) this.selected.interacted = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbStepperComponent,
			isStandalone: false,
			selector: "nb-stepper",
			inputs: {
				selectedIndex: "selectedIndex",
				disableStepNavigation: "disableStepNavigation",
				selected: "selected",
				orientation: "orientation",
				linear: "linear"
			},
			outputs: { stepChange: "stepChange" },
			host: { properties: {
				"class.vertical": "this.vertical",
				"class.horizontal": "this.horizontal"
			} },
			providers: [{
				provide: NB_STEPPER,
				useExisting: NbStepperComponent
			}],
			queries: [{
				propertyName: "steps",
				predicate: NbStepComponent
			}],
			ngImport: i0,
			template: "<ng-template><ng-content select=\"nb-step\"></ng-content></ng-template>\n<div class=\"header\">\n  <ng-container *ngFor=\"let step of steps; let index = index; let first = first\">\n\n    <div *ngIf=\"!first && !step.hidden\"\n         [class.connector-past]=\"index <= selectedIndex\"\n         class=\"connector\"></div>\n\n    <div *ngIf=\"!step.hidden\" class=\"step\"\n         [class.selected]=\"isStepSelected(step)\"\n         [class.completed]=\"!isStepSelected(step) && step.completed\"\n         [class.noninteractive]=\"disableStepNavigation\"\n         (click)=\"changeStep(step)\">\n      <div class=\"label-index\">\n        <span *ngIf=\"!step.completed || isStepSelected(step)\">{{ index + 1 }}</span>\n        <nb-icon *ngIf=\"!isStepSelected(step) && step.completed\" icon=\"checkmark-outline\" pack=\"nebular-essentials\">\n        </nb-icon>\n      </div>\n      <div class=\"label\">\n        <ng-container *ngIf=\"step.isLabelTemplate\">\n          <ng-container *ngTemplateOutlet=\"getStepTemplate(step)\"></ng-container>\n        </ng-container>\n        <span *ngIf=\"!step.isLabelTemplate\">{{ step.label }}</span>\n      </div>\n    </div>\n  </ng-container>\n</div>\n<div class=\"step-content\">\n  <ng-container [ngTemplateOutlet]=\"selected?.content\"></ng-container>\n</div>\n",
			styles: [":host(.horizontal) .header .step{flex-direction:column}:host(.horizontal) .header .connector{height:2px}:host(.horizontal) .label-index{margin-bottom:10px}:host(.vertical){display:flex;height:100%}:host(.vertical) .header{flex-direction:column}:host(.vertical) .header .label{margin:0 10px}:host(.vertical) .header .connector{width:2px}.header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}.header .connector{flex:auto}.header .step{display:flex;align-items:center;cursor:pointer}.header .step.noninteractive{cursor:default}.header .label-index{display:flex;justify-content:center;align-items:center}.header .label{width:max-content}\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgForOf,
					selector: "[ngFor][ngForOf]",
					inputs: [
						"ngForOf",
						"ngForTrackBy",
						"ngForTemplate"
					]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStepperComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-stepper",
			providers: [{
				provide: NB_STEPPER,
				useExisting: NbStepperComponent
			}],
			standalone: false,
			template: "<ng-template><ng-content select=\"nb-step\"></ng-content></ng-template>\n<div class=\"header\">\n  <ng-container *ngFor=\"let step of steps; let index = index; let first = first\">\n\n    <div *ngIf=\"!first && !step.hidden\"\n         [class.connector-past]=\"index <= selectedIndex\"\n         class=\"connector\"></div>\n\n    <div *ngIf=\"!step.hidden\" class=\"step\"\n         [class.selected]=\"isStepSelected(step)\"\n         [class.completed]=\"!isStepSelected(step) && step.completed\"\n         [class.noninteractive]=\"disableStepNavigation\"\n         (click)=\"changeStep(step)\">\n      <div class=\"label-index\">\n        <span *ngIf=\"!step.completed || isStepSelected(step)\">{{ index + 1 }}</span>\n        <nb-icon *ngIf=\"!isStepSelected(step) && step.completed\" icon=\"checkmark-outline\" pack=\"nebular-essentials\">\n        </nb-icon>\n      </div>\n      <div class=\"label\">\n        <ng-container *ngIf=\"step.isLabelTemplate\">\n          <ng-container *ngTemplateOutlet=\"getStepTemplate(step)\"></ng-container>\n        </ng-container>\n        <span *ngIf=\"!step.isLabelTemplate\">{{ step.label }}</span>\n      </div>\n    </div>\n  </ng-container>\n</div>\n<div class=\"step-content\">\n  <ng-container [ngTemplateOutlet]=\"selected?.content\"></ng-container>\n</div>\n",
			styles: [":host(.horizontal) .header .step{flex-direction:column}:host(.horizontal) .header .connector{height:2px}:host(.horizontal) .label-index{margin-bottom:10px}:host(.vertical){display:flex;height:100%}:host(.vertical) .header{flex-direction:column}:host(.vertical) .header .label{margin:0 10px}:host(.vertical) .header .connector{width:2px}.header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}.header .connector{flex:auto}.header .step{display:flex;align-items:center;cursor:pointer}.header .step.noninteractive{cursor:default}.header .label-index{display:flex;justify-content:center;align-items:center}.header .label{width:max-content}\n"]
		}]
	}],
	propDecorators: {
		selectedIndex: [{ type: Input }],
		disableStepNavigation: [{ type: Input }],
		selected: [{ type: Input }],
		orientation: [{ type: Input }],
		linear: [{ type: Input }],
		stepChange: [{ type: Output }],
		vertical: [{
			type: HostBinding,
			args: ["class.vertical"]
		}],
		horizontal: [{
			type: HostBinding,
			args: ["class.horizontal"]
		}],
		steps: [{
			type: ContentChildren,
			args: [NbStepComponent]
		}]
	}
});
var NbStepperNextDirective = class NbStepperNextDirective {
	constructor(stepper) {
		this.stepper = stepper;
		this.type = "submit";
	}
	onClick() {
		this.stepper.next();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperNextDirective,
			deps: [{ token: NbStepperComponent }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbStepperNextDirective,
			isStandalone: false,
			selector: "button[nbStepperNext]",
			inputs: { type: "type" },
			host: {
				listeners: { "click": "onClick()" },
				properties: { "attr.type": "this.type" }
			},
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStepperNextDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[nbStepperNext]",
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbStepperComponent }],
	propDecorators: {
		type: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.type"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
var NbStepperPreviousDirective = class NbStepperPreviousDirective {
	constructor(stepper) {
		this.stepper = stepper;
		this.type = "button";
	}
	onClick() {
		this.stepper.previous();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperPreviousDirective,
			deps: [{ token: NbStepperComponent }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbStepperPreviousDirective,
			isStandalone: false,
			selector: "button[nbStepperPrevious]",
			inputs: { type: "type" },
			host: {
				listeners: { "click": "onClick()" },
				properties: { "attr.type": "this.type" }
			},
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStepperPreviousDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[nbStepperPrevious]",
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbStepperComponent }],
	propDecorators: {
		type: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.type"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbStepperModule = class NbStepperModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperModule,
			declarations: [
				NbStepperComponent,
				NbStepComponent,
				NbStepperNextDirective,
				NbStepperPreviousDirective
			],
			imports: [NbSharedModule, NbIconModule],
			exports: [
				NbStepperComponent,
				NbStepComponent,
				NbStepperNextDirective,
				NbStepperPreviousDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbStepperModule,
			imports: [NbSharedModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbStepperModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbIconModule],
			declarations: [
				NbStepperComponent,
				NbStepComponent,
				NbStepperNextDirective,
				NbStepperPreviousDirective
			],
			exports: [
				NbStepperComponent,
				NbStepComponent,
				NbStepperNextDirective,
				NbStepperPreviousDirective
			]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAccordionComponent = class NbAccordionComponent {
	constructor() {
		this.openCloseItems = new Subject();
		this.multiValue = false;
	}
	get multi() {
		return this.multiValue;
	}
	set multi(val) {
		this.multiValue = convertToBoolProperty(val);
	}
	openAll() {
		if (this.multi) this.openCloseItems.next(false);
	}
	closeAll() {
		this.openCloseItems.next(true);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAccordionComponent,
			isStandalone: false,
			selector: "nb-accordion",
			inputs: { multi: "multi" },
			ngImport: i0,
			template: `
    <ng-content select="nb-accordion-item"></ng-content>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAccordionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-accordion",
			template: `
    <ng-content select="nb-accordion-item"></ng-content>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: { multi: [{
		type: Input,
		args: ["multi"]
	}] }
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAccordionItemComponent = class NbAccordionItemComponent {
	get collapsed() {
		return this.collapsedValue;
	}
	set collapsed(val) {
		this.collapsedValue = convertToBoolProperty(val);
		this.collapsedChange.emit(this.collapsedValue);
		this.invalidate();
	}
	get expanded() {
		return !this.collapsed;
	}
	set expanded(val) {
		this.collapsedValue = !convertToBoolProperty(val);
	}
	get disabled() {
		return this.disabledValue;
	}
	set disabled(val) {
		this.disabledValue = convertToBoolProperty(val);
		this.invalidate();
	}
	constructor(accordion, cd) {
		this.accordion = accordion;
		this.cd = cd;
		this.collapsedChange = new EventEmitter();
		this.accordionItemInvalidate = new Subject();
		this.collapsedValue = true;
		this.disabledValue = false;
		this.destroy$ = new Subject();
	}
	toggle() {
		if (!this.disabled) {
			const willSet = !this.collapsed;
			if (!this.accordion.multi) this.accordion.openCloseItems.next(true);
			this.collapsed = willSet;
		}
	}
	open() {
		!this.disabled && (this.collapsed = false);
	}
	close() {
		!this.disabled && (this.collapsed = true);
	}
	ngOnInit() {
		this.accordion.openCloseItems.pipe(takeUntil(this.destroy$)).subscribe((collapsed) => {
			!this.disabled && (this.collapsed = collapsed);
		});
	}
	ngOnChanges(changes) {
		this.accordionItemInvalidate.next(true);
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
		this.accordionItemInvalidate.complete();
	}
	invalidate() {
		this.accordionItemInvalidate.next(true);
		this.cd.markForCheck();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionItemComponent,
			deps: [{
				token: NbAccordionComponent,
				host: true
			}, { token: i0.ChangeDetectorRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAccordionItemComponent,
			isStandalone: false,
			selector: "nb-accordion-item",
			inputs: {
				collapsed: "collapsed",
				expanded: "expanded",
				disabled: "disabled"
			},
			outputs: { collapsedChange: "collapsedChange" },
			host: { properties: {
				"class.collapsed": "this.collapsed",
				"class.expanded": "this.expanded",
				"class.disabled": "this.disabled"
			} },
			usesOnChanges: true,
			ngImport: i0,
			template: `
    <ng-content select="nb-accordion-item-header"></ng-content>
    <ng-content select="nb-accordion-item-body"></ng-content>
  `,
			isInline: true,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAccordionItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-accordion-item",
			template: `
    <ng-content select="nb-accordion-item-header"></ng-content>
    <ng-content select="nb-accordion-item-body"></ng-content>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;flex-direction:column}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{
		type: NbAccordionComponent,
		decorators: [{ type: Host }]
	}, { type: i0.ChangeDetectorRef }],
	propDecorators: {
		collapsed: [{
			type: Input,
			args: ["collapsed"]
		}, {
			type: HostBinding,
			args: ["class.collapsed"]
		}],
		expanded: [{
			type: Input,
			args: ["expanded"]
		}, {
			type: HostBinding,
			args: ["class.expanded"]
		}],
		disabled: [{
			type: Input,
			args: ["disabled"]
		}, {
			type: HostBinding,
			args: ["class.disabled"]
		}],
		collapsedChange: [{ type: Output }]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const accordionItemBodyTrigger = trigger("accordionItemBody", [
	state("collapsed", style({
		overflow: "hidden",
		visibility: "hidden",
		height: 0
	})),
	state("expanded", style({
		overflow: "hidden",
		visibility: "visible"
	})),
	transition("collapsed => expanded", animate("100ms ease-in")),
	transition("expanded => collapsed", animate("100ms ease-out"))
]);
var NbAccordionItemBodyComponent = class NbAccordionItemBodyComponent {
	constructor(accordionItem, cd) {
		this.accordionItem = accordionItem;
		this.cd = cd;
		this.destroy$ = new Subject();
	}
	get state() {
		return this.accordionItem.collapsed ? "collapsed" : "expanded";
	}
	ngOnInit() {
		this.accordionItem.accordionItemInvalidate.pipe(takeUntil(this.destroy$)).subscribe(() => this.cd.markForCheck());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionItemBodyComponent,
			deps: [{
				token: NbAccordionItemComponent,
				host: true
			}, { token: i0.ChangeDetectorRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAccordionItemBodyComponent,
			isStandalone: false,
			selector: "nb-accordion-item-body",
			ngImport: i0,
			template: `
    <div [@accordionItemBody]="{ value: state }">
      <div class="item-body">
        <ng-content></ng-content>
      </div>
    </div>
  `,
			isInline: true,
			animations: [accordionItemBodyTrigger],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAccordionItemBodyComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-accordion-item-body",
			template: `
    <div [@accordionItemBody]="{ value: state }">
      <div class="item-body">
        <ng-content></ng-content>
      </div>
    </div>
  `,
			animations: [accordionItemBodyTrigger],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [{
		type: NbAccordionItemComponent,
		decorators: [{ type: Host }]
	}, { type: i0.ChangeDetectorRef }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAccordionItemHeaderComponent = class NbAccordionItemHeaderComponent {
	get isCollapsed() {
		return this.accordionItem.collapsed;
	}
	get expanded() {
		return !this.accordionItem.collapsed;
	}
	get tabbable() {
		return this.accordionItem.disabled ? "-1" : "0";
	}
	get disabled() {
		return this.accordionItem.disabled;
	}
	toggle() {
		this.accordionItem.toggle();
	}
	get state() {
		if (this.isCollapsed) return "collapsed";
		return "expanded";
	}
	constructor(accordionItem, cd) {
		this.accordionItem = accordionItem;
		this.cd = cd;
		this.destroy$ = new Subject();
	}
	ngOnInit() {
		this.accordionItem.accordionItemInvalidate.pipe(takeUntil(this.destroy$)).subscribe(() => this.cd.markForCheck());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionItemHeaderComponent,
			deps: [{
				token: NbAccordionItemComponent,
				host: true
			}, { token: i0.ChangeDetectorRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAccordionItemHeaderComponent,
			isStandalone: false,
			selector: "nb-accordion-item-header",
			host: {
				listeners: {
					"click": "toggle()",
					"keydown.space": "toggle()",
					"keydown.enter": "toggle()"
				},
				properties: {
					"class.accordion-item-header-collapsed": "this.isCollapsed",
					"class.accordion-item-header-expanded": "this.expanded",
					"attr.aria-expanded": "this.expanded",
					"attr.tabindex": "this.tabbable",
					"attr.aria-disabled": "this.disabled"
				}
			},
			ngImport: i0,
			template: `
    <ng-content select="nb-accordion-item-title"></ng-content>
    <ng-content select="nb-accordion-item-description"></ng-content>
    <ng-content></ng-content>
    <nb-icon icon="chevron-down-outline"
             pack="nebular-essentials"
             [@expansionIndicator]="state"
             *ngIf="!disabled"
             class="expansion-indicator">
    </nb-icon>
  `,
			isInline: true,
			styles: [":host{display:flex;align-items:center;cursor:pointer}:host:focus{outline:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			animations: [trigger("expansionIndicator", [
				state("expanded", style({ transform: "rotate(180deg)" })),
				transition("collapsed => expanded", animate("100ms ease-in")),
				transition("expanded => collapsed", animate("100ms ease-out"))
			])],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAccordionItemHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-accordion-item-header",
			template: `
    <ng-content select="nb-accordion-item-title"></ng-content>
    <ng-content select="nb-accordion-item-description"></ng-content>
    <ng-content></ng-content>
    <nb-icon icon="chevron-down-outline"
             pack="nebular-essentials"
             [@expansionIndicator]="state"
             *ngIf="!disabled"
             class="expansion-indicator">
    </nb-icon>
  `,
			animations: [trigger("expansionIndicator", [
				state("expanded", style({ transform: "rotate(180deg)" })),
				transition("collapsed => expanded", animate("100ms ease-in")),
				transition("expanded => collapsed", animate("100ms ease-out"))
			])],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:flex;align-items:center;cursor:pointer}:host:focus{outline:0}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{
		type: NbAccordionItemComponent,
		decorators: [{ type: Host }]
	}, { type: i0.ChangeDetectorRef }],
	propDecorators: {
		isCollapsed: [{
			type: HostBinding,
			args: ["class.accordion-item-header-collapsed"]
		}],
		expanded: [{
			type: HostBinding,
			args: ["class.accordion-item-header-expanded"]
		}, {
			type: HostBinding,
			args: ["attr.aria-expanded"]
		}],
		tabbable: [{
			type: HostBinding,
			args: ["attr.tabindex"]
		}],
		disabled: [{
			type: HostBinding,
			args: ["attr.aria-disabled"]
		}],
		toggle: [
			{
				type: HostListener,
				args: ["click"]
			},
			{
				type: HostListener,
				args: ["keydown.space"]
			},
			{
				type: HostListener,
				args: ["keydown.enter"]
			}
		]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_ACCORDION_COMPONENTS = [
	NbAccordionComponent,
	NbAccordionItemComponent,
	NbAccordionItemHeaderComponent,
	NbAccordionItemBodyComponent
];
var NbAccordionModule = class NbAccordionModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionModule,
			declarations: [
				NbAccordionComponent,
				NbAccordionItemComponent,
				NbAccordionItemHeaderComponent,
				NbAccordionItemBodyComponent
			],
			imports: [CommonModule, NbIconModule],
			exports: [
				NbAccordionComponent,
				NbAccordionItemComponent,
				NbAccordionItemHeaderComponent,
				NbAccordionItemBodyComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAccordionModule,
			imports: [CommonModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAccordionModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule, NbIconModule],
			exports: [...NB_ACCORDION_COMPONENTS],
			declarations: [...NB_ACCORDION_COMPONENTS],
			providers: []
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_BUTTON_GROUP = new InjectionToken("NB_BUTTON_GROUP");
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbButtonToggleDirective = class NbButtonToggleDirective extends NbButton {
	get pressedChange$() {
		return this._pressedChange$.asObservable();
	}
	get pressed() {
		return this._pressed;
	}
	set pressed(value) {
		if (this.pressed !== convertToBoolProperty(value)) {
			this._pressed = !this.pressed;
			this.pressedChange.emit(this.pressed);
			this._pressedChange$.next({
				source: this,
				pressed: this.pressed
			});
		}
	}
	get basic() {
		return !this.pressed;
	}
	get primary() {
		return this.pressed && (this.status === "basic" || this.status === "primary");
	}
	get success() {
		return this.pressed && this.status === "success";
	}
	get info() {
		return this.pressed && this.status === "info";
	}
	get warning() {
		return this.pressed && this.status === "warning";
	}
	get danger() {
		return this.pressed && this.status === "danger";
	}
	get control() {
		return this.pressed && this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	onClick() {
		if (this.buttonGroup?.multiple || !this.pressed) this.pressed = !this.pressed;
	}
	constructor(renderer, hostElement, cd, zone, statusService, buttonGroup) {
		super(renderer, hostElement, cd, zone, statusService);
		this.renderer = renderer;
		this.hostElement = hostElement;
		this.cd = cd;
		this.zone = zone;
		this.statusService = statusService;
		this.buttonGroup = buttonGroup;
		this._pressedChange$ = new Subject();
		this.appearance = "filled";
		this._pressed = false;
		this.pressedChange = new EventEmitter();
	}
	_updatePressed(value) {
		this.pressed = value;
		this.cd.markForCheck();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonToggleDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.NgZone },
				{ token: NbStatusService },
				{
					token: NB_BUTTON_GROUP,
					optional: true
				}
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbButtonToggleDirective,
			isStandalone: false,
			selector: "button[nbButtonToggle]",
			inputs: {
				appearance: "appearance",
				value: "value",
				pressed: "pressed"
			},
			outputs: { pressedChange: "pressedChange" },
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"attr.aria-pressed": "this.pressed",
					"class.status-basic": "this.basic",
					"class.status-primary": "this.primary",
					"class.status-success": "this.success",
					"class.status-info": "this.info",
					"class.status-warning": "this.warning",
					"class.status-danger": "this.danger",
					"class.status-control": "this.control",
					"class": "this.additionalClasses"
				}
			},
			providers: [{
				provide: NbButton,
				useExisting: NbButtonToggleDirective
			}],
			exportAs: ["nbButtonToggle"],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButtonToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[nbButtonToggle]",
			providers: [{
				provide: NbButton,
				useExisting: NbButtonToggleDirective
			}],
			exportAs: "nbButtonToggle",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: NbStatusService },
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NB_BUTTON_GROUP]
			}]
		}
	],
	propDecorators: {
		appearance: [{ type: Input }],
		value: [{ type: Input }],
		pressed: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-pressed"]
		}],
		pressedChange: [{ type: Output }],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbButtonGroupComponent = class NbButtonGroupComponent {
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		if (this.disabled !== convertToBoolProperty(value)) this._disabled = !this.disabled;
	}
	get multiple() {
		return this._multiple;
	}
	set multiple(value) {
		this._multiple = convertToBoolProperty(value);
	}
	get filled() {
		return this.appearance === "filled";
	}
	set filled(value) {
		if (convertToBoolProperty(value)) this.appearance = "filled";
	}
	get outline() {
		return this.appearance === "outline";
	}
	set outline(value) {
		if (convertToBoolProperty(value)) this.appearance = "outline";
	}
	get ghost() {
		return this.appearance === "ghost";
	}
	set ghost(value) {
		if (convertToBoolProperty(value)) this.appearance = "ghost";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	constructor(cd, statusService) {
		this.cd = cd;
		this.statusService = statusService;
		this.lastEmittedValue = [];
		this.destroy$ = new Subject();
		this.buttonsChange$ = new Subject();
		this.size = "medium";
		this.status = "basic";
		this.shape = "rectangle";
		this.appearance = "filled";
		this._disabled = false;
		this._multiple = false;
		this.valueChange = new EventEmitter();
		this.role = "group";
	}
	ngOnChanges({ size, status, shape, multiple, filled, outline, ghost, disabled }) {
		if (size || status || shape || multiple || filled || outline || ghost || disabled) this.syncButtonsProperties(this.buttons?.toArray() || []);
	}
	ngAfterContentInit() {
		this.buttonsChange$.pipe(takeUntil(this.destroy$)).subscribe((buttons) => {
			this.listenButtonPressedState(buttons);
			this.syncButtonsProperties(buttons);
		});
		this.buttons.changes.pipe(switchMap((buttons) => from(Promise.resolve(buttons.toArray()))), takeUntil(this.destroy$)).subscribe(this.buttonsChange$);
		this.buttonsChange$.next(this.buttons.toArray());
	}
	listenButtonPressedState(buttons) {
		const toggleButtons = buttons.filter((button) => {
			return button instanceof NbButtonToggleDirective;
		});
		if (!toggleButtons.length) return;
		const buttonsPressedChange$ = toggleButtons.map((button) => button.pressedChange$);
		merge(...buttonsPressedChange$).pipe(filter(({ pressed }) => !this.multiple && pressed), takeUntil(merge(this.buttonsChange$, this.destroy$))).subscribe(({ source }) => {
			toggleButtons.filter((button) => button !== source).forEach((button) => button._updatePressed(false));
		});
		merge(...buttonsPressedChange$).pipe(startWith(""), debounceTime(0), takeUntil(merge(this.buttonsChange$, this.destroy$))).subscribe(() => this.emitCurrentValue(toggleButtons));
	}
	syncButtonsProperties(buttons) {
		buttons.forEach((button) => {
			button.updateProperties({
				appearance: this.appearance,
				size: this.size,
				status: this.status,
				shape: this.shape,
				disabled: this.disabled
			});
		});
	}
	emitCurrentValue(toggleButtons) {
		const pressedToggleValues = toggleButtons.filter((b) => b.pressed && typeof b.value !== "undefined").map((b) => b.value);
		if (pressedToggleValues.length === 0 && this.lastEmittedValue.length === 0) return;
		this.valueChange.emit(pressedToggleValues);
		this.lastEmittedValue = pressedToggleValues;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonGroupComponent,
			deps: [{ token: i0.ChangeDetectorRef }, { token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbButtonGroupComponent,
			isStandalone: false,
			selector: "nb-button-group",
			inputs: {
				size: "size",
				status: "status",
				shape: "shape",
				appearance: "appearance",
				disabled: "disabled",
				multiple: "multiple",
				filled: "filled",
				outline: "outline",
				ghost: "ghost"
			},
			outputs: { valueChange: "valueChange" },
			host: { properties: {
				"attr.role": "this.role",
				"class": "this.additionalClasses"
			} },
			providers: [{
				provide: NB_BUTTON_GROUP,
				useExisting: NbButtonGroupComponent
			}],
			queries: [{
				propertyName: "buttons",
				predicate: NbButton
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: ` <ng-content></ng-content> `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButtonGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-button-group",
			template: ` <ng-content></ng-content> `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NB_BUTTON_GROUP,
				useExisting: NbButtonGroupComponent
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: NbStatusService }],
	propDecorators: {
		buttons: [{
			type: ContentChildren,
			args: [NbButton]
		}],
		size: [{ type: Input }],
		status: [{ type: Input }],
		shape: [{ type: Input }],
		appearance: [{ type: Input }],
		disabled: [{ type: Input }],
		multiple: [{ type: Input }],
		filled: [{ type: Input }],
		outline: [{ type: Input }],
		ghost: [{ type: Input }],
		valueChange: [{ type: Output }],
		role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbButtonGroupModule = class NbButtonGroupModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonGroupModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonGroupModule,
			declarations: [NbButtonGroupComponent, NbButtonToggleDirective],
			exports: [NbButtonGroupComponent, NbButtonToggleDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbButtonGroupModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbButtonGroupModule,
	decorators: [{
		type: NgModule,
		args: [{
			declarations: [NbButtonGroupComponent, NbButtonToggleDirective],
			exports: [NbButtonGroupComponent, NbButtonToggleDirective]
		}]
	}]
});
var NbListPageTrackerDirective = class NbListPageTrackerDirective {
	constructor() {
		this.destroy$ = new Subject();
		this.startPage = 1;
		this.pageChange = new EventEmitter();
		this.observer = new IntersectionObserver((entries) => this.checkForPageChange(entries), { threshold: .5 });
	}
	ngAfterViewInit() {
		if (this.listItems && this.listItems.length) this.observeItems();
		this.listItems.changes.pipe(takeUntil(this.destroy$)).subscribe(() => this.observeItems());
	}
	ngOnDestroy() {
		this.observer.disconnect && this.observer.disconnect();
	}
	observeItems() {
		this.listItems.forEach((i) => this.observer.observe(i.nativeElement));
	}
	checkForPageChange(entries) {
		const mostVisiblePage = this.findMostVisiblePage(entries);
		if (mostVisiblePage && this.currentPage !== mostVisiblePage) {
			this.currentPage = mostVisiblePage;
			this.pageChange.emit(this.currentPage);
		}
	}
	findMostVisiblePage(entries) {
		const intersectionRatioByPage = /* @__PURE__ */ new Map();
		for (const entry of entries) {
			if (entry.intersectionRatio < .5) continue;
			const elementIndex = this.elementIndex(entry.target);
			if (elementIndex === -1) continue;
			const page = this.startPage + Math.floor(elementIndex / this.pageSize);
			let ratio = entry.intersectionRatio;
			if (intersectionRatioByPage.has(page)) ratio += intersectionRatioByPage.get(page);
			intersectionRatioByPage.set(page, ratio);
		}
		let maxRatio = 0;
		let mostVisiblePage;
		intersectionRatioByPage.forEach((ratio, page) => {
			if (ratio > maxRatio) {
				maxRatio = ratio;
				mostVisiblePage = page;
			}
		});
		return mostVisiblePage;
	}
	elementIndex(element) {
		return element.parentElement && element.parentElement.children ? Array.from(element.parentElement.children).indexOf(element) : -1;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListPageTrackerDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbListPageTrackerDirective,
			isStandalone: false,
			selector: "[nbListPageTracker]",
			inputs: {
				pageSize: "pageSize",
				startPage: "startPage"
			},
			outputs: { pageChange: "pageChange" },
			queries: [{
				propertyName: "listItems",
				predicate: NbListItemComponent,
				read: ElementRef
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbListPageTrackerDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbListPageTracker]",
			standalone: false
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		pageSize: [{ type: Input }],
		startPage: [{ type: Input }],
		pageChange: [{ type: Output }],
		listItems: [{
			type: ContentChildren,
			args: [NbListItemComponent, { read: ElementRef }]
		}]
	}
});
var NbScrollableContainerDimensions = class {};
var NbInfiniteListDirective = class NbInfiniteListDirective {
	get elementScroll() {
		return !this.windowScroll;
	}
	set throttleTime(value) {
		this.throttleTime$.next(value);
	}
	get throttleTime() {
		return this.throttleTime$.value;
	}
	set listenWindowScroll(value) {
		this.windowScroll = convertToBoolProperty(value);
	}
	onElementScroll() {
		if (this.elementScroll) this.elementScroll$.next();
	}
	constructor(elementRef, scrollService, dimensionsService) {
		this.elementRef = elementRef;
		this.scrollService = scrollService;
		this.dimensionsService = dimensionsService;
		this.destroy$ = new Subject();
		this.windowScroll = false;
		this.elementScroll$ = new Subject();
		this.windowScroll$ = this.scrollService.onScroll().pipe(filter(() => this.windowScroll));
		this.bottomThreshold$ = new Subject();
		this.topThreshold$ = new Subject();
		this.throttleTime$ = new BehaviorSubject(0);
		this.bottomThreshold = new EventEmitter(true);
		this.topThreshold = new EventEmitter(true);
	}
	ngAfterViewInit() {
		merge(this.windowScroll$, this.elementScroll$).pipe(switchMap(() => this.getContainerDimensions()), takeUntil(this.destroy$)).subscribe((dimensions) => this.checkPosition(dimensions));
		this.throttleTime$.pipe(switchMap(() => this.topThreshold$.pipe(throttle(() => interval(this.throttleTime)))), takeUntil(this.destroy$)).subscribe(() => {
			this.topThreshold.emit();
		});
		this.throttleTime$.pipe(switchMap(() => this.bottomThreshold$.pipe(throttle(() => interval(this.throttleTime)))), takeUntil(this.destroy$)).subscribe(() => {
			this.bottomThreshold.emit();
		});
		this.listItems.changes.pipe(switchMap(() => interval(50).pipe(filter(() => this.inSyncWithDom()), take(1), takeUntil(timer(1e3)))), switchMap(() => this.getContainerDimensions()), takeUntil(this.destroy$)).subscribe((dimensions) => this.checkPosition(dimensions));
		this.getContainerDimensions().subscribe((dimensions) => this.checkPosition(dimensions));
	}
	ngOnDestroy() {
		this.topThreshold$.complete();
		this.bottomThreshold$.complete();
		this.elementScroll$.complete();
		this.destroy$.next();
		this.destroy$.complete();
	}
	checkPosition({ scrollHeight, scrollTop, clientHeight }) {
		const initialCheck = this.lastScrollPosition == null;
		const manualCheck = this.lastScrollPosition === scrollTop;
		const scrollUp = scrollTop < this.lastScrollPosition;
		const scrollDown = scrollTop > this.lastScrollPosition;
		const distanceToBottom = scrollHeight - scrollTop - clientHeight;
		if ((initialCheck || manualCheck || scrollDown) && distanceToBottom <= this.threshold) this.bottomThreshold$.next();
		if ((initialCheck || scrollUp) && scrollTop <= this.threshold) this.topThreshold$.next();
		this.lastScrollPosition = scrollTop;
	}
	getContainerDimensions() {
		if (this.elementScroll) {
			const { scrollTop, scrollHeight, clientHeight } = this.elementRef.nativeElement;
			return of({
				scrollTop,
				scrollHeight,
				clientHeight
			});
		}
		return forkJoin([this.scrollService.getPosition(), this.dimensionsService.getDimensions()]).pipe(map(([scrollPosition, dimensions]) => ({
			scrollTop: scrollPosition.y,
			scrollHeight: dimensions.scrollHeight,
			clientHeight: dimensions.clientHeight
		})));
	}
	inSyncWithDom() {
		return this.elementRef.nativeElement.children.length === this.listItems.length;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbInfiniteListDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: NbLayoutScrollService },
				{ token: NbLayoutRulerService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbInfiniteListDirective,
			isStandalone: false,
			selector: "[nbInfiniteList]",
			inputs: {
				threshold: "threshold",
				throttleTime: "throttleTime",
				listenWindowScroll: "listenWindowScroll"
			},
			outputs: {
				bottomThreshold: "bottomThreshold",
				topThreshold: "topThreshold"
			},
			host: { listeners: { "scroll": "onElementScroll()" } },
			queries: [{
				propertyName: "listItems",
				predicate: NbListItemComponent
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbInfiniteListDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbInfiniteList]",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: NbLayoutScrollService },
		{ type: NbLayoutRulerService }
	],
	propDecorators: {
		threshold: [{ type: Input }],
		throttleTime: [{ type: Input }],
		listenWindowScroll: [{ type: Input }],
		bottomThreshold: [{ type: Output }],
		topThreshold: [{ type: Output }],
		onElementScroll: [{
			type: HostListener,
			args: ["scroll"]
		}],
		listItems: [{
			type: ContentChildren,
			args: [NbListItemComponent]
		}]
	}
});
const components = [
	NbListComponent,
	NbListItemComponent,
	NbListPageTrackerDirective,
	NbInfiniteListDirective
];
var NbListModule = class NbListModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListModule,
			declarations: [
				NbListComponent,
				NbListItemComponent,
				NbListPageTrackerDirective,
				NbInfiniteListDirective
			],
			exports: [
				NbListComponent,
				NbListItemComponent,
				NbListPageTrackerDirective,
				NbInfiniteListDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbListModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbListModule,
	decorators: [{
		type: NgModule,
		args: [{
			declarations: components,
			exports: components
		}]
	}]
});
var NbDirectionality = class NbDirectionality extends Directionality {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDirectionality,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDirectionality
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDirectionality,
	decorators: [{ type: Injectable }]
});
var NbBidiModule = class NbBidiModule extends BidiModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBidiModule,
			deps: null,
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBidiModule
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbBidiModule,
			providers: [{
				provide: NbDirectionality,
				useExisting: Directionality
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbBidiModule,
	decorators: [{
		type: NgModule,
		args: [{ providers: [{
			provide: NbDirectionality,
			useExisting: Directionality
		}] }]
	}]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license infornbion.
*/
var NbCellDefDirective = class NbCellDefDirective extends CdkCellDef {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCellDefDirective,
			isStandalone: false,
			selector: "[nbCellDef]",
			providers: [{
				provide: CdkCellDef,
				useExisting: NbCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbCellDef]",
			providers: [{
				provide: CdkCellDef,
				useExisting: NbCellDefDirective
			}],
			standalone: false
		}]
	}]
});
var NbHeaderCellDefDirective = class NbHeaderCellDefDirective extends CdkHeaderCellDef {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbHeaderCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbHeaderCellDefDirective,
			isStandalone: false,
			selector: "[nbHeaderCellDef]",
			providers: [{
				provide: CdkHeaderCellDef,
				useExisting: NbHeaderCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbHeaderCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbHeaderCellDef]",
			providers: [{
				provide: CdkHeaderCellDef,
				useExisting: NbHeaderCellDefDirective
			}],
			standalone: false
		}]
	}]
});
var NbFooterCellDefDirective = class NbFooterCellDefDirective extends CdkFooterCellDef {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFooterCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFooterCellDefDirective,
			isStandalone: false,
			selector: "[nbFooterCellDef]",
			providers: [{
				provide: CdkFooterCellDef,
				useExisting: NbFooterCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFooterCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbFooterCellDef]",
			providers: [{
				provide: CdkFooterCellDef,
				useExisting: NbFooterCellDefDirective
			}],
			standalone: false
		}]
	}]
});
const NB_SORT_HEADER_COLUMN_DEF = new InjectionToken("NB_SORT_HEADER_COLUMN_DEF");
var NbColumnDefDirective = class NbColumnDefDirective extends CdkColumnDef {
	constructor() {
		super(...arguments);
		this._hasStickyCellChanged = false;
		this._stickyCell = false;
	}
	get name() {
		return this._name;
	}
	set name(value) {
		this._setNameInput(value);
	}
	get sticky() {
		return this._stickyCell;
	}
	set sticky(value) {
		if (value !== this._stickyCell) {
			this._stickyCell = value;
			this._hasStickyCellChanged = true;
		}
	}
	get stickyEnd() {
		return this._stickyEnd;
	}
	set stickyEnd(value) {
		const prevValue = this._stickyEnd;
		this._stickyEnd = coerceBooleanProperty(value);
		this._hasStickyCellChanged = prevValue !== this._stickyEnd;
	}
	hasStickyChanged() {
		const hasStickyChanged = this._hasStickyCellChanged;
		this.resetStickyChanged();
		return hasStickyChanged;
	}
	resetStickyChanged() {
		this._hasStickyCellChanged = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbColumnDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbColumnDefDirective,
			isStandalone: false,
			selector: "[nbColumnDef]",
			inputs: {
				name: ["nbColumnDef", "name"],
				sticky: "sticky",
				stickyEnd: "stickyEnd"
			},
			providers: [{
				provide: CdkColumnDef,
				useExisting: NbColumnDefDirective
			}, {
				provide: NB_SORT_HEADER_COLUMN_DEF,
				useExisting: NbColumnDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbColumnDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbColumnDef]",
			providers: [{
				provide: CdkColumnDef,
				useExisting: NbColumnDefDirective
			}, {
				provide: NB_SORT_HEADER_COLUMN_DEF,
				useExisting: NbColumnDefDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		name: [{
			type: Input,
			args: ["nbColumnDef"]
		}],
		sticky: [{ type: Input }],
		stickyEnd: [{ type: Input }]
	}
});
var NbHeaderCellDirective = class NbHeaderCellDirective extends CdkHeaderCell {
	constructor(columnDef, elementRef) {
		super();
		elementRef.nativeElement.classList.add(`nb-column-${columnDef.cssClassFriendlyName}`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbHeaderCellDirective,
			deps: [{ token: NbColumnDefDirective }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbHeaderCellDirective,
			isStandalone: false,
			selector: "nb-header-cell, th[nbHeaderCell]",
			host: {
				attributes: { "role": "columnheader" },
				classAttribute: "nb-header-cell"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbHeaderCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "nb-header-cell, th[nbHeaderCell]",
			host: {
				class: "nb-header-cell",
				role: "columnheader"
			},
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnDefDirective }, { type: i0.ElementRef }]
});
var NbFooterCellDirective = class NbFooterCellDirective extends CdkFooterCell {
	constructor(columnDef, elementRef) {
		super();
		elementRef.nativeElement.classList.add(`nb-column-${columnDef.cssClassFriendlyName}`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFooterCellDirective,
			deps: [{ token: NbColumnDefDirective }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFooterCellDirective,
			isStandalone: false,
			selector: "nb-footer-cell, td[nbFooterCell]",
			host: {
				attributes: { "role": "gridcell" },
				classAttribute: "nb-footer-cell"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFooterCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "nb-footer-cell, td[nbFooterCell]",
			host: {
				class: "nb-footer-cell",
				role: "gridcell"
			},
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnDefDirective }, { type: i0.ElementRef }]
});
var NbCellDirective = class NbCellDirective extends CdkCell {
	constructor(columnDef, elementRef) {
		super();
		elementRef.nativeElement.classList.add(`nb-column-${columnDef.cssClassFriendlyName}`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCellDirective,
			deps: [{ token: NbColumnDefDirective }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCellDirective,
			isStandalone: false,
			selector: "nb-cell, td[nbCell]",
			host: {
				attributes: { "role": "gridcell" },
				classAttribute: "nb-cell"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "nb-cell, td[nbCell]",
			host: {
				class: "nb-cell",
				role: "gridcell"
			},
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnDefDirective }, { type: i0.ElementRef }]
});
var NbDataSource = class extends DataSource {};
var NbDataRowOutletDirective = class NbDataRowOutletDirective extends DataRowOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDataRowOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDataRowOutletDirective,
			isStandalone: false,
			selector: "[nbRowOutlet]",
			providers: [{
				provide: DataRowOutlet,
				useExisting: NbDataRowOutletDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDataRowOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbRowOutlet]",
			providers: [{
				provide: DataRowOutlet,
				useExisting: NbDataRowOutletDirective
			}],
			standalone: false
		}]
	}]
});
var NbHeaderRowOutletDirective = class NbHeaderRowOutletDirective extends HeaderRowOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbHeaderRowOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbHeaderRowOutletDirective,
			isStandalone: false,
			selector: "[nbHeaderRowOutlet]",
			providers: [{
				provide: HeaderRowOutlet,
				useExisting: NbHeaderRowOutletDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbHeaderRowOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbHeaderRowOutlet]",
			providers: [{
				provide: HeaderRowOutlet,
				useExisting: NbHeaderRowOutletDirective
			}],
			standalone: false
		}]
	}]
});
var NbFooterRowOutletDirective = class NbFooterRowOutletDirective extends FooterRowOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFooterRowOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFooterRowOutletDirective,
			isStandalone: false,
			selector: "[nbFooterRowOutlet]",
			providers: [{
				provide: FooterRowOutlet,
				useExisting: NbFooterRowOutletDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFooterRowOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbFooterRowOutlet]",
			providers: [{
				provide: FooterRowOutlet,
				useExisting: NbFooterRowOutletDirective
			}],
			standalone: false
		}]
	}]
});
var NbNoDataRowOutletDirective = class NbNoDataRowOutletDirective extends NoDataRowOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbNoDataRowOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbNoDataRowOutletDirective,
			isStandalone: false,
			selector: "[nbNoDataRowOutlet]",
			providers: [{
				provide: NoDataRowOutlet,
				useExisting: NbNoDataRowOutletDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbNoDataRowOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbNoDataRowOutlet]",
			providers: [{
				provide: NoDataRowOutlet,
				useExisting: NbNoDataRowOutletDirective
			}],
			standalone: false
		}]
	}]
});
var NbCellOutletDirective = class NbCellOutletDirective extends CdkCellOutlet {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbCellOutletDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbCellOutletDirective,
			isStandalone: false,
			selector: "[nbCellOutlet]",
			providers: [{
				provide: CdkCellOutlet,
				useExisting: NbCellOutletDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbCellOutletDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbCellOutlet]",
			providers: [{
				provide: CdkCellOutlet,
				useExisting: NbCellOutletDirective
			}],
			standalone: false
		}]
	}]
});
var NbHeaderRowDefDirective = class NbHeaderRowDefDirective extends CdkHeaderRowDef {
	constructor() {
		super(...arguments);
		this._hasStickyRowChanged = false;
		this._stickyRow = false;
	}
	get sticky() {
		return this._stickyRow;
	}
	set sticky(value) {
		if (value !== this._stickyRow) {
			this._stickyRow = value;
			this._hasStickyRowChanged = true;
		}
	}
	hasStickyChanged() {
		const hasStickyChanged = this._hasStickyRowChanged;
		this.resetStickyChanged();
		return hasStickyChanged;
	}
	resetStickyChanged() {
		this._hasStickyRowChanged = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbHeaderRowDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbHeaderRowDefDirective,
			isStandalone: false,
			selector: "[nbHeaderRowDef]",
			inputs: {
				columns: ["nbHeaderRowDef", "columns"],
				sticky: ["nbHeaderRowDefSticky", "sticky"]
			},
			providers: [{
				provide: CdkHeaderRowDef,
				useExisting: NbHeaderRowDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbHeaderRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbHeaderRowDef]",
			providers: [{
				provide: CdkHeaderRowDef,
				useExisting: NbHeaderRowDefDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		columns: [{
			type: Input,
			args: ["nbHeaderRowDef"]
		}],
		sticky: [{
			type: Input,
			args: ["nbHeaderRowDefSticky"]
		}]
	}
});
var NbFooterRowDefDirective = class NbFooterRowDefDirective extends CdkFooterRowDef {
	constructor() {
		super(...arguments);
		this._hasStickyRowChanged = false;
		this._stickyRow = false;
	}
	get sticky() {
		return this._stickyRow;
	}
	set sticky(value) {
		if (value !== this._stickyRow) {
			this._stickyRow = value;
			this._hasStickyRowChanged = true;
		}
	}
	hasStickyChanged() {
		const hasStickyChanged = this._hasStickyRowChanged;
		this.resetStickyChanged();
		return hasStickyChanged;
	}
	resetStickyChanged() {
		this._hasStickyRowChanged = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFooterRowDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFooterRowDefDirective,
			isStandalone: false,
			selector: "[nbFooterRowDef]",
			inputs: {
				columns: ["nbFooterRowDef", "columns"],
				sticky: ["nbFooterRowDefSticky", "sticky"]
			},
			providers: [{
				provide: CdkFooterRowDef,
				useExisting: NbFooterRowDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFooterRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbFooterRowDef]",
			providers: [{
				provide: CdkFooterRowDef,
				useExisting: NbFooterRowDefDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		columns: [{
			type: Input,
			args: ["nbFooterRowDef"]
		}],
		sticky: [{
			type: Input,
			args: ["nbFooterRowDefSticky"]
		}]
	}
});
var NbRowDefDirective = class NbRowDefDirective extends CdkRowDef {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRowDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRowDefDirective,
			isStandalone: false,
			selector: "[nbRowDef]",
			inputs: {
				columns: ["nbRowDefColumns", "columns"],
				when: ["nbRowDefWhen", "when"]
			},
			providers: [{
				provide: CdkRowDef,
				useExisting: NbRowDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbRowDef]",
			providers: [{
				provide: CdkRowDef,
				useExisting: NbRowDefDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		columns: [{
			type: Input,
			args: ["nbRowDefColumns"]
		}],
		when: [{
			type: Input,
			args: ["nbRowDefWhen"]
		}]
	}
});
var NbHeaderRowComponent = class NbHeaderRowComponent extends CdkHeaderRow {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbHeaderRowComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbHeaderRowComponent,
			isStandalone: false,
			selector: "nb-header-row, tr[nbHeaderRow]",
			host: {
				attributes: { "role": "row" },
				classAttribute: "nb-header-row"
			},
			providers: [{
				provide: CdkHeaderRow,
				useExisting: NbHeaderRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: ` <ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbHeaderRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-header-row, tr[nbHeaderRow]",
			template: ` <ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-header-row",
				role: "row"
			},
			providers: [{
				provide: CdkHeaderRow,
				useExisting: NbHeaderRowComponent
			}],
			standalone: false
		}]
	}]
});
var NbFooterRowComponent = class NbFooterRowComponent extends CdkFooterRow {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFooterRowComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFooterRowComponent,
			isStandalone: false,
			selector: "nb-footer-row, tr[nbFooterRow]",
			host: {
				attributes: { "role": "row" },
				classAttribute: "nb-footer-row"
			},
			providers: [{
				provide: CdkFooterRow,
				useExisting: NbFooterRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: ` <ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFooterRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-footer-row, tr[nbFooterRow]",
			template: ` <ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-footer-row",
				role: "row"
			},
			providers: [{
				provide: CdkFooterRow,
				useExisting: NbFooterRowComponent
			}],
			standalone: false
		}]
	}]
});
var NbRowComponent = class NbRowComponent extends CdkRow {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRowComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRowComponent,
			isStandalone: false,
			selector: "nb-row, tr[nbRow]",
			host: {
				attributes: { "role": "row" },
				classAttribute: "nb-row"
			},
			providers: [{
				provide: CdkRow,
				useExisting: NbRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: ` <ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-row, tr[nbRow]",
			template: ` <ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-row",
				role: "row"
			},
			providers: [{
				provide: CdkRow,
				useExisting: NbRowComponent
			}],
			standalone: false
		}]
	}]
});
const NB_TABLE_TEMPLATE = `
  <ng-container nbHeaderRowOutlet></ng-container>
  <ng-container nbRowOutlet></ng-container>
  <ng-container nbNoDataRowOutlet></ng-container>
  <ng-container nbFooterRowOutlet></ng-container>
`;
const NB_VIEW_REPEATER_STRATEGY = new InjectionToken("_VIEW_REPEATER_STRATEGY");
const NB_TABLE_PROVIDERS = [{
	provide: ViewportRuler$1,
	useExisting: NbViewportRulerAdapter
}];
var NbTable = class NbTable extends CdkTable {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTable,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTable,
			isStandalone: false,
			selector: "nb-table-not-implemented",
			providers: NB_TABLE_PROVIDERS,
			usesInheritance: true,
			ngImport: i0,
			template: ``,
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTable,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-table-not-implemented",
			template: ``,
			providers: NB_TABLE_PROVIDERS,
			standalone: false
		}]
	}]
});
const COMPONENTS$2 = [
	NbTable,
	NbHeaderCellDefDirective,
	NbHeaderRowDefDirective,
	NbColumnDefDirective,
	NbCellDefDirective,
	NbRowDefDirective,
	NbFooterCellDefDirective,
	NbFooterRowDefDirective,
	NbDataRowOutletDirective,
	NbHeaderRowOutletDirective,
	NbFooterRowOutletDirective,
	NbNoDataRowOutletDirective,
	NbCellOutletDirective,
	NbHeaderCellDirective,
	NbCellDirective,
	NbFooterCellDirective,
	NbHeaderRowComponent,
	NbRowComponent,
	NbFooterRowComponent
];
var NbTableModule = class NbTableModule extends CdkTableModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTableModule,
			deps: null,
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTableModule,
			declarations: [
				NbTable,
				NbHeaderCellDefDirective,
				NbHeaderRowDefDirective,
				NbColumnDefDirective,
				NbCellDefDirective,
				NbRowDefDirective,
				NbFooterCellDefDirective,
				NbFooterRowDefDirective,
				NbDataRowOutletDirective,
				NbHeaderRowOutletDirective,
				NbFooterRowOutletDirective,
				NbNoDataRowOutletDirective,
				NbCellOutletDirective,
				NbHeaderCellDirective,
				NbCellDirective,
				NbFooterCellDirective,
				NbHeaderRowComponent,
				NbRowComponent,
				NbFooterRowComponent
			],
			imports: [NbBidiModule],
			exports: [
				NbTable,
				NbHeaderCellDefDirective,
				NbHeaderRowDefDirective,
				NbColumnDefDirective,
				NbCellDefDirective,
				NbRowDefDirective,
				NbFooterCellDefDirective,
				NbFooterRowDefDirective,
				NbDataRowOutletDirective,
				NbHeaderRowOutletDirective,
				NbFooterRowOutletDirective,
				NbNoDataRowOutletDirective,
				NbCellOutletDirective,
				NbHeaderCellDirective,
				NbCellDirective,
				NbFooterCellDirective,
				NbHeaderRowComponent,
				NbRowComponent,
				NbFooterRowComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTableModule,
			imports: [NbBidiModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTableModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbBidiModule],
			declarations: [...COMPONENTS$2],
			exports: [...COMPONENTS$2]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_DIALOG_CONFIG = new InjectionToken("Default dialog options");
var NbDialogConfig = class {
	constructor(config) {
		this.hasBackdrop = true;
		this.backdropClass = "overlay-backdrop";
		this.dialogClass = "";
		this.closeOnBackdropClick = true;
		this.closeOnEsc = true;
		this.hasScroll = false;
		this.autoFocus = true;
		Object.assign(this, config);
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDialogRef = class {
	constructor(overlayRef) {
		this.overlayRef = overlayRef;
		this.onClose$ = new Subject();
		this.onClose = this.onClose$.asObservable();
		this.onBackdropClick = this.overlayRef.backdropClick();
	}
	close(res) {
		this.overlayRef.detach();
		this.overlayRef.dispose();
		this.onClose$.next(res);
		this.onClose$.complete();
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDialogContainerComponent = class NbDialogContainerComponent {
	constructor(config, elementRef, focusTrapFactory) {
		this.config = config;
		this.elementRef = elementRef;
		this.focusTrapFactory = focusTrapFactory;
	}
	ngOnInit() {
		if (this.config.autoFocus) {
			this.focusTrap = this.focusTrapFactory.create(this.elementRef.nativeElement);
			this.focusTrap.blurPreviouslyFocusedElement();
			this.focusTrap.focusInitialElement();
		}
	}
	ngOnDestroy() {
		if (this.config.autoFocus && this.focusTrap) this.focusTrap.restoreFocus();
	}
	attachComponentPortal(portal) {
		return this.portalOutlet.attachComponentPortal(portal);
	}
	attachTemplatePortal(portal) {
		return this.portalOutlet.attachTemplatePortal(portal);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogContainerComponent,
			deps: [
				{ token: NbDialogConfig },
				{ token: i0.ElementRef },
				{ token: NbFocusTrapFactoryService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbDialogContainerComponent,
			isStandalone: false,
			selector: "nb-dialog-container",
			viewQueries: [{
				propertyName: "portalOutlet",
				first: true,
				predicate: NbPortalOutletDirective,
				descendants: true,
				static: true
			}],
			ngImport: i0,
			template: "<ng-template nbPortalOutlet></ng-template>",
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbPortalOutletDirective,
				selector: "[nbPortalOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDialogContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-dialog-container",
			template: "<ng-template nbPortalOutlet></ng-template>",
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: NbDialogConfig },
		{ type: i0.ElementRef },
		{ type: NbFocusTrapFactoryService }
	],
	propDecorators: { portalOutlet: [{
		type: ViewChild,
		args: [NbPortalOutletDirective, { static: true }]
	}] }
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDialogService = class NbDialogService {
	constructor(document, globalConfig, positionBuilder, overlay, injector) {
		this.document = document;
		this.globalConfig = globalConfig;
		this.positionBuilder = positionBuilder;
		this.overlay = overlay;
		this.injector = injector;
	}
	open(content, userConfig = {}) {
		const config = new NbDialogConfig({
			...this.globalConfig,
			...userConfig
		});
		const overlayRef = this.createOverlay(config);
		const dialogRef = new NbDialogRef(overlayRef);
		const container = this.createContainer(config, overlayRef);
		this.createContent(config, content, container, dialogRef);
		this.registerCloseListeners(config, overlayRef, dialogRef);
		return dialogRef;
	}
	createOverlay(config) {
		const positionStrategy = this.createPositionStrategy();
		const scrollStrategy = this.createScrollStrategy(config.hasScroll);
		return this.overlay.create({
			positionStrategy,
			scrollStrategy,
			hasBackdrop: config.hasBackdrop,
			backdropClass: config.backdropClass,
			panelClass: config.dialogClass
		});
	}
	createPositionStrategy() {
		return this.positionBuilder.global().centerVertically().centerHorizontally();
	}
	createScrollStrategy(hasScroll) {
		if (hasScroll) return this.overlay.scrollStrategies.noop();
		else return this.overlay.scrollStrategies.block();
	}
	createContainer(config, overlayRef) {
		const containerPortal = new NbComponentPortal(NbDialogContainerComponent, null, Injector.create({
			parent: this.createInjector(config),
			providers: [{
				provide: NbDialogConfig,
				useValue: config
			}]
		}));
		return overlayRef.attach(containerPortal).instance;
	}
	createContent(config, content, container, dialogRef) {
		if (content instanceof TemplateRef) {
			const portal = this.createTemplatePortal(config, content, dialogRef);
			container.attachTemplatePortal(portal);
		} else {
			const portal = this.createComponentPortal(config, content, dialogRef);
			dialogRef.componentRef = container.attachComponentPortal(portal);
			if (config.context) Object.assign(dialogRef.componentRef.instance, { ...config.context });
		}
	}
	createTemplatePortal(config, content, dialogRef) {
		return new NbTemplatePortal(content, null, {
			$implicit: config.context,
			dialogRef
		});
	}
	createComponentPortal(config, content, dialogRef) {
		const injector = this.createInjector(config);
		const portalInjector = Injector.create({
			parent: injector,
			providers: [{
				provide: NbDialogRef,
				useValue: dialogRef
			}]
		});
		return new NbComponentPortal(content, config.viewContainerRef, portalInjector);
	}
	createInjector(config) {
		return config.viewContainerRef && config.viewContainerRef.injector || this.injector;
	}
	registerCloseListeners(config, overlayRef, dialogRef) {
		if (config.closeOnBackdropClick) overlayRef.backdropClick().subscribe(() => dialogRef.close());
		if (config.closeOnEsc) fromEvent(this.document, "keyup").pipe(filter((event) => event.keyCode === 27), takeUntil(dialogRef.onClose)).subscribe(() => dialogRef.close());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogService,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NB_DIALOG_CONFIG },
				{ token: NbPositionBuilderService },
				{ token: NbOverlayService },
				{ token: i0.Injector }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDialogService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DIALOG_CONFIG]
			}]
		},
		{ type: NbPositionBuilderService },
		{ type: NbOverlayService },
		{ type: i0.Injector }
	]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDialogModule = class NbDialogModule {
	static forRoot(dialogConfig = {}) {
		return {
			ngModule: NbDialogModule,
			providers: [NbDialogService, {
				provide: NB_DIALOG_CONFIG,
				useValue: dialogConfig
			}]
		};
	}
	static forChild(dialogConfig = {}) {
		return {
			ngModule: NbDialogModule,
			providers: [NbDialogService, {
				provide: NB_DIALOG_CONFIG,
				useValue: dialogConfig
			}]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogModule,
			declarations: [NbDialogContainerComponent],
			imports: [NbSharedModule, NbOverlayModule]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDialogModule,
			imports: [NbSharedModule, NbOverlayModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDialogModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [NbSharedModule, NbOverlayModule],
			declarations: [NbDialogContainerComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToastComponent = class NbToastComponent {
	get success() {
		return this.toast.config.status === "success";
	}
	get info() {
		return this.toast.config.status === "info";
	}
	get warning() {
		return this.toast.config.status === "warning";
	}
	get primary() {
		return this.toast.config.status === "primary";
	}
	get danger() {
		return this.toast.config.status === "danger";
	}
	get basic() {
		return this.toast.config.status === "basic";
	}
	get control() {
		return this.toast.config.status === "control";
	}
	get destroyByClick() {
		return this.toast.config.destroyByClick;
	}
	get hasIcon() {
		const { icon } = this.toast.config;
		if (typeof icon === "string") return true;
		return !!(icon && icon.icon);
	}
	get customIcon() {
		return !!this.icon;
	}
	get icon() {
		return this.toast.config.icon;
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.toast.config.status)) return [this.statusService.getStatusClass(this.toast.config.status)];
		return [];
	}
	onClick() {
		this.toastClick.emit();
	}
	constructor(renderer, elementRef, statusService) {
		this.renderer = renderer;
		this.elementRef = elementRef;
		this.statusService = statusService;
		this.destroy = new EventEmitter();
		this.toastClick = new EventEmitter();
	}
	ngOnInit() {
		if (this.toast.config.toastClass) this.renderer.addClass(this.elementRef.nativeElement, this.toast.config.toastClass);
	}
	ngOnDestroy() {
		this.destroy.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastComponent,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbToastComponent,
			isStandalone: false,
			selector: "nb-toast",
			inputs: { toast: "toast" },
			outputs: {
				destroy: "destroy",
				toastClick: "toastClick"
			},
			host: {
				listeners: { "click": "onClick()" },
				properties: {
					"class.status-success": "this.success",
					"class.status-info": "this.info",
					"class.status-warning": "this.warning",
					"class.status-primary": "this.primary",
					"class.status-danger": "this.danger",
					"class.status-basic": "this.basic",
					"class.status-control": "this.control",
					"class.destroy-by-click": "this.destroyByClick",
					"class.has-icon": "this.hasIcon",
					"class.custom-icon": "this.customIcon",
					"class": "this.additionalClasses"
				}
			},
			ngImport: i0,
			template: "<div class=\"icon-container\" *ngIf=\"hasIcon && icon\">\n  <nb-icon [config]=\"icon\"></nb-icon>\n</div>\n<div class=\"content-container\">\n  <span class=\"title subtitle\">{{ toast.title }}</span>\n  <div class=\"message\">{{ toast.message }}</div>\n</div>\n",
			styles: [":host{display:flex;align-items:center;width:25rem;margin:.5rem}:host .title{margin-right:.25rem}:host.default .content-container,:host:not(.has-icon) .content-container{display:flex;flex-direction:row}:host.destroy-by-click{cursor:pointer}:host nb-icon{font-size:2.5rem}:host svg{width:2.5rem;height:2.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToastComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-toast",
			standalone: false,
			template: "<div class=\"icon-container\" *ngIf=\"hasIcon && icon\">\n  <nb-icon [config]=\"icon\"></nb-icon>\n</div>\n<div class=\"content-container\">\n  <span class=\"title subtitle\">{{ toast.title }}</span>\n  <div class=\"message\">{{ toast.message }}</div>\n</div>\n",
			styles: [":host{display:flex;align-items:center;width:25rem;margin:.5rem}:host .title{margin-right:.25rem}:host.default .content-container,:host:not(.has-icon) .content-container{display:flex;flex-direction:row}:host.destroy-by-click{cursor:pointer}:host nb-icon{font-size:2.5rem}:host svg{width:2.5rem;height:2.5rem}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: NbStatusService }
	],
	propDecorators: {
		toast: [{ type: Input }],
		destroy: [{ type: Output }],
		toastClick: [{ type: Output }],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		destroyByClick: [{
			type: HostBinding,
			args: ["class.destroy-by-click"]
		}],
		hasIcon: [{
			type: HostBinding,
			args: ["class.has-icon"]
		}],
		customIcon: [{
			type: HostBinding,
			args: ["class.custom-icon"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		onClick: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const voidState = style({
	transform: "translateX({{ direction }}110%)",
	height: 0,
	marginLeft: "0",
	marginRight: "0",
	marginTop: "0",
	marginBottom: "0"
});
const defaultOptions = { params: { direction: "" } };
var NbToastrContainerComponent = class NbToastrContainerComponent {
	constructor(layoutDirection, positionHelper) {
		this.layoutDirection = layoutDirection;
		this.positionHelper = positionHelper;
		this.destroy$ = new Subject();
		this.content = [];
	}
	ngOnInit() {
		this.layoutDirection.onDirectionChange().pipe(takeUntil(this.destroy$)).subscribe(() => this.onDirectionChange());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	onDirectionChange() {
		const direction = this.positionHelper.isRightPosition(this.position) ? "" : "-";
		this.fadeIn = {
			value: "",
			params: { direction }
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrContainerComponent,
			deps: [{ token: NbLayoutDirectionService }, { token: NbPositionHelper }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbToastrContainerComponent,
			isStandalone: false,
			selector: "nb-toastr-container",
			inputs: {
				content: "content",
				context: "context",
				position: "position"
			},
			viewQueries: [{
				propertyName: "toasts",
				predicate: NbToastComponent,
				descendants: true
			}],
			ngImport: i0,
			template: `
    <nb-toast [@fadeIn]="fadeIn" *ngFor="let toast of content" [toast]="toast"></nb-toast>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgForOf,
				selector: "[ngFor][ngForOf]",
				inputs: [
					"ngForOf",
					"ngForTrackBy",
					"ngForTemplate"
				]
			}, {
				kind: "component",
				type: NbToastComponent,
				selector: "nb-toast",
				inputs: ["toast"],
				outputs: ["destroy", "toastClick"]
			}],
			animations: [trigger("fadeIn", [transition(":enter", [voidState, animate(100)], defaultOptions), transition(":leave", [animate(100, voidState)], defaultOptions)])]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToastrContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-toastr-container",
			template: `
    <nb-toast [@fadeIn]="fadeIn" *ngFor="let toast of content" [toast]="toast"></nb-toast>`,
			animations: [trigger("fadeIn", [transition(":enter", [voidState, animate(100)], defaultOptions), transition(":leave", [animate(100, voidState)], defaultOptions)])],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbLayoutDirectionService }, { type: NbPositionHelper }],
	propDecorators: {
		content: [{ type: Input }],
		context: [{ type: Input }],
		position: [{ type: Input }],
		toasts: [{
			type: ViewChildren,
			args: [NbToastComponent]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_TOASTR_CONFIG = new InjectionToken("Default toastr options");
var NbToastrConfig = class {
	constructor(config) {
		this.position = NbGlobalLogicalPosition.TOP_END;
		this.status = "basic";
		this.duration = 3e3;
		this.destroyByClick = true;
		this.preventDuplicates = false;
		this.duplicatesBehaviour = "previous";
		this.limit = null;
		this.toastClass = "";
		this.hasIcon = true;
		this.icon = "email";
		this.icons = {
			danger: "flash-outline",
			success: "checkmark-outline",
			info: "question-mark-outline",
			warning: "alert-triangle-outline",
			primary: "email-outline",
			control: "email-outline",
			basic: "email-outline"
		};
		this.patchIcon(config);
		Object.assign(this, config);
	}
	patchIcon(config) {
		if (!("icon" in config)) config.icon = {
			icon: this.icons[config.status] || this.icons.basic,
			pack: "nebular-essentials"
		};
	}
};
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToastRef = class {
	constructor(toastContainer, toast) {
		this.toastContainer = toastContainer;
		this.toast = toast;
	}
	close() {
		this.toastContainer.destroy(this.toast);
	}
	onClose() {
		return this.toastInstance.destroy.asObservable();
	}
	onClick() {
		return this.toastInstance.toastClick.asObservable();
	}
};
var NbToastContainer = class {
	get nativeElement() {
		return this.containerRef.location.nativeElement;
	}
	constructor(position, containerRef, positionHelper) {
		this.position = position;
		this.containerRef = containerRef;
		this.positionHelper = positionHelper;
		this.toasts = [];
		this.toastDuplicateCompareFunc = (t1, t2) => {
			return t1.message === t2.message && t1.title === t2.title && t1.config.status === t2.config.status;
		};
	}
	attach(toast) {
		if (toast.config.preventDuplicates && this.isDuplicate(toast)) return;
		this.removeToastIfLimitReached(toast);
		const toastComponent = this.attachToast(toast);
		if (toast.config.destroyByClick) this.subscribeOnClick(toastComponent, toast);
		if (toast.config.duration) this.setDestroyTimeout(toast);
		this.prevToast = toast;
		const toastRef = new NbToastRef(this, toast);
		toastRef.toastInstance = toastComponent;
		return toastRef;
	}
	destroy(toast) {
		if (this.prevToast === toast) this.prevToast = null;
		this.toasts = this.toasts.filter((t) => t !== toast);
		this.updateContainer();
	}
	isDuplicate(toast) {
		return toast.config.duplicatesBehaviour === "previous" ? this.isDuplicatePrevious(toast) : this.isDuplicateAmongAll(toast);
	}
	isDuplicatePrevious(toast) {
		return this.prevToast && this.toastDuplicateCompareFunc(this.prevToast, toast);
	}
	isDuplicateAmongAll(toast) {
		return this.toasts.some((t) => this.toastDuplicateCompareFunc(t, toast));
	}
	removeToastIfLimitReached(toast) {
		if (!toast.config.limit || this.toasts.length < toast.config.limit) return;
		if (this.positionHelper.isTopPosition(toast.config.position)) this.toasts.pop();
		else this.toasts.shift();
	}
	attachToast(toast) {
		if (this.positionHelper.isTopPosition(toast.config.position)) return this.attachToTop(toast);
		else return this.attachToBottom(toast);
	}
	attachToTop(toast) {
		this.toasts.unshift(toast);
		this.updateContainer();
		return this.containerRef.instance.toasts.first;
	}
	attachToBottom(toast) {
		this.toasts.push(toast);
		this.updateContainer();
		return this.containerRef.instance.toasts.last;
	}
	setDestroyTimeout(toast) {
		setTimeout(() => this.destroy(toast), toast.config.duration);
	}
	subscribeOnClick(toastComponent, toast) {
		toastComponent.toastClick.pipe(filter(() => toast.config.destroyByClick), takeUntil(toastComponent.destroy)).subscribe(() => this.destroy(toast));
	}
	updateContainer() {
		patch(this.containerRef, {
			content: this.toasts,
			position: this.position
		});
	}
};
var NbToastrContainerRegistry = class NbToastrContainerRegistry {
	constructor(overlay, positionBuilder, positionHelper, document) {
		this.overlay = overlay;
		this.positionBuilder = positionBuilder;
		this.positionHelper = positionHelper;
		this.document = document;
		this.overlays = /* @__PURE__ */ new Map();
	}
	get(position) {
		const logicalPosition = this.positionHelper.toLogicalPosition(position);
		const overlayWithContainer = this.overlays.get(logicalPosition);
		if (!overlayWithContainer || !this.existsInDom(overlayWithContainer.toastrContainer)) {
			if (overlayWithContainer) overlayWithContainer.overlayRef.dispose();
			this.instantiateContainer(logicalPosition);
		}
		return this.overlays.get(logicalPosition).toastrContainer;
	}
	instantiateContainer(position) {
		const toastrOverlayWithContainer = this.createContainer(position);
		this.overlays.set(position, toastrOverlayWithContainer);
	}
	createContainer(position) {
		const positionStrategy = this.positionBuilder.global().position(position);
		const ref = this.overlay.create({ positionStrategy });
		this.addClassToOverlayHost(ref);
		return {
			overlayRef: ref,
			toastrContainer: new NbToastContainer(position, ref.attach(new NbComponentPortal(NbToastrContainerComponent, null, null)), this.positionHelper)
		};
	}
	addClassToOverlayHost(overlayRef) {
		overlayRef.hostElement.classList.add("toastr-overlay-container");
	}
	existsInDom(toastContainer) {
		return this.document.body.contains(toastContainer.nativeElement);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrContainerRegistry,
			deps: [
				{ token: NbOverlayService },
				{ token: NbPositionBuilderService },
				{ token: NbPositionHelper },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrContainerRegistry
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToastrContainerRegistry,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbOverlayService },
		{ type: NbPositionBuilderService },
		{ type: NbPositionHelper },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	]
});
var NbToastrService = class NbToastrService {
	constructor(globalConfig, containerRegistry) {
		this.globalConfig = globalConfig;
		this.containerRegistry = containerRegistry;
	}
	show(message, title, userConfig) {
		const config = new NbToastrConfig({
			...this.globalConfig,
			...userConfig
		});
		const container = this.containerRegistry.get(config.position);
		const toast = {
			message,
			title,
			config
		};
		return container.attach(toast);
	}
	success(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "success"
		});
	}
	info(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "info"
		});
	}
	warning(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "warning"
		});
	}
	primary(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "primary"
		});
	}
	danger(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "danger"
		});
	}
	default(message, title, config) {
		return this.show(message, title, {
			...config,
			status: "basic"
		});
	}
	control(message, title, config) {
		return this.default(message, title, {
			...config,
			status: "control"
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrService,
			deps: [{ token: NB_TOASTR_CONFIG }, { token: NbToastrContainerRegistry }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToastrService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: NbToastrConfig,
		decorators: [{
			type: Inject,
			args: [NB_TOASTR_CONFIG]
		}]
	}, { type: NbToastrContainerRegistry }]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToastrModule = class NbToastrModule {
	static forRoot(toastrConfig = {}) {
		return {
			ngModule: NbToastrModule,
			providers: [
				NbToastrService,
				NbToastrContainerRegistry,
				{
					provide: NB_TOASTR_CONFIG,
					useValue: toastrConfig
				}
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrModule,
			declarations: [NbToastrContainerComponent, NbToastComponent],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToastrModule,
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToastrModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			],
			declarations: [NbToastrContainerComponent, NbToastComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToast = class {};
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTooltipComponent = class NbTooltipComponent {
	get binding() {
		return `${this.position} ${this.statusClass}`;
	}
	get show() {
		return true;
	}
	get statusClass() {
		if (this.context.status) return this.statusService.getStatusClass(this.context.status);
		return "";
	}
	constructor(statusService) {
		this.statusService = statusService;
		this.position = NbPosition.TOP;
		this.context = {};
	}
	renderContent() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTooltipComponent,
			deps: [{ token: NbStatusService }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTooltipComponent,
			isStandalone: false,
			selector: "nb-tooltip",
			inputs: {
				content: "content",
				position: "position",
				context: "context"
			},
			host: { properties: {
				"class": "this.binding",
				"@showTooltip": "this.show"
			} },
			ngImport: i0,
			template: `
    <span class="arrow"></span>
    <div class="content">
      <nb-icon *ngIf="context?.icon" [config]="context.icon"></nb-icon>
      <span *ngIf="content">{{ content }}</span>
    </div>
  `,
			isInline: true,
			styles: [":host{z-index:10000}:host .content{display:flex;align-items:center}:host.right .content{flex-direction:row-reverse}:host .arrow{position:absolute;width:0;height:0}:host nb-icon+span{margin-left:.5rem}:host.right nb-icon+span{margin-right:.5rem}:host .arrow{border-left:6px solid transparent;border-right:6px solid transparent}:host(.bottom) .arrow{top:-6px;left:calc(50% - 6px)}:host(.bottom-start) .arrow{top:-6px}[dir=ltr] :host(.bottom-start) .arrow{right:6px}[dir=rtl] :host(.bottom-start) .arrow{left:6px}:host(.bottom-end) .arrow{top:-6px}[dir=ltr] :host(.bottom-end) .arrow{left:6px}[dir=rtl] :host(.bottom-end) .arrow{right:6px}[dir=ltr] :host(.left) .arrow,[dir=ltr] :host(.start) .arrow{right:-8px;transform:rotate(90deg)}[dir=rtl] :host(.left) .arrow,[dir=rtl] :host(.start) .arrow{left:-8px;transform:rotate(270deg)}:host(.left) .arrow,:host(.start) .arrow{top:calc(50% - 2.4px)}:host(.start-top) .arrow{right:-8px;bottom:6px;transform:rotate(90deg)}:host(.start-bottom) .arrow{right:-8px;top:6px;transform:rotate(90deg)}:host(.top) .arrow{bottom:-6px;left:calc(50% - 6px);transform:rotate(180deg)}:host(.top-start) .arrow{bottom:-5px}[dir=ltr] :host(.top-start) .arrow{right:6px}[dir=rtl] :host(.top-start) .arrow{left:6px}:host(.top-start) .arrow{transform:rotate(180deg)}:host(.top-end) .arrow{bottom:-5px}[dir=ltr] :host(.top-end) .arrow{left:6px}[dir=rtl] :host(.top-end) .arrow{right:6px}:host(.top-end) .arrow{transform:rotate(180deg)}[dir=ltr] :host(.right) .arrow,[dir=ltr] :host(.end) .arrow{left:-8px;transform:rotate(270deg)}[dir=rtl] :host(.right) .arrow,[dir=rtl] :host(.end) .arrow{right:-8px;transform:rotate(90deg)}:host(.right) .arrow,:host(.end) .arrow{top:calc(50% - 2.4px)}:host(.end-top) .arrow{left:-8.4px;bottom:6px;transform:rotate(270deg)}:host(.end-bottom) .arrow{left:-8.4px;top:6px;transform:rotate(270deg)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			animations: [trigger("showTooltip", [
				state("in", style({ opacity: 1 })),
				transition("void => *", [style({ opacity: 0 }), animate(100)]),
				transition("* => void", [animate(100, style({ opacity: 0 }))])
			])]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTooltipComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tooltip",
			template: `
    <span class="arrow"></span>
    <div class="content">
      <nb-icon *ngIf="context?.icon" [config]="context.icon"></nb-icon>
      <span *ngIf="content">{{ content }}</span>
    </div>
  `,
			animations: [trigger("showTooltip", [
				state("in", style({ opacity: 1 })),
				transition("void => *", [style({ opacity: 0 }), animate(100)]),
				transition("* => void", [animate(100, style({ opacity: 0 }))])
			])],
			standalone: false,
			styles: [":host{z-index:10000}:host .content{display:flex;align-items:center}:host.right .content{flex-direction:row-reverse}:host .arrow{position:absolute;width:0;height:0}:host nb-icon+span{margin-left:.5rem}:host.right nb-icon+span{margin-right:.5rem}:host .arrow{border-left:6px solid transparent;border-right:6px solid transparent}:host(.bottom) .arrow{top:-6px;left:calc(50% - 6px)}:host(.bottom-start) .arrow{top:-6px}[dir=ltr] :host(.bottom-start) .arrow{right:6px}[dir=rtl] :host(.bottom-start) .arrow{left:6px}:host(.bottom-end) .arrow{top:-6px}[dir=ltr] :host(.bottom-end) .arrow{left:6px}[dir=rtl] :host(.bottom-end) .arrow{right:6px}[dir=ltr] :host(.left) .arrow,[dir=ltr] :host(.start) .arrow{right:-8px;transform:rotate(90deg)}[dir=rtl] :host(.left) .arrow,[dir=rtl] :host(.start) .arrow{left:-8px;transform:rotate(270deg)}:host(.left) .arrow,:host(.start) .arrow{top:calc(50% - 2.4px)}:host(.start-top) .arrow{right:-8px;bottom:6px;transform:rotate(90deg)}:host(.start-bottom) .arrow{right:-8px;top:6px;transform:rotate(90deg)}:host(.top) .arrow{bottom:-6px;left:calc(50% - 6px);transform:rotate(180deg)}:host(.top-start) .arrow{bottom:-5px}[dir=ltr] :host(.top-start) .arrow{right:6px}[dir=rtl] :host(.top-start) .arrow{left:6px}:host(.top-start) .arrow{transform:rotate(180deg)}:host(.top-end) .arrow{bottom:-5px}[dir=ltr] :host(.top-end) .arrow{left:6px}[dir=rtl] :host(.top-end) .arrow{right:6px}:host(.top-end) .arrow{transform:rotate(180deg)}[dir=ltr] :host(.right) .arrow,[dir=ltr] :host(.end) .arrow{left:-8px;transform:rotate(270deg)}[dir=rtl] :host(.right) .arrow,[dir=rtl] :host(.end) .arrow{right:-8px;transform:rotate(90deg)}:host(.right) .arrow,:host(.end) .arrow{top:calc(50% - 2.4px)}:host(.end-top) .arrow{left:-8.4px;bottom:6px;transform:rotate(270deg)}:host(.end-bottom) .arrow{left:-8.4px;top:6px;transform:rotate(270deg)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbStatusService }],
	propDecorators: {
		content: [{ type: Input }],
		position: [{ type: Input }],
		binding: [{
			type: HostBinding,
			args: ["class"]
		}],
		show: [{
			type: HostBinding,
			args: ["@showTooltip"]
		}],
		context: [{ type: Input }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTooltipDirective = class NbTooltipDirective {
	get adjustment() {
		return this._adjustment;
	}
	set adjustment(value) {
		this._adjustment = value;
	}
	get tooltipClass() {
		return this._tooltipClass;
	}
	set tooltipClass(value) {
		if (value !== this.tooltipClass) {
			this._tooltipClass = value;
			this.overlayConfig = { panelClass: this.tooltipClass };
		}
	}
	set icon(icon) {
		this.context = Object.assign(this.context, { icon });
	}
	set status(status) {
		this.context = Object.assign(this.context, { status });
	}
	get isShown() {
		return !!(this.dynamicOverlay && this.dynamicOverlay.isAttached);
	}
	constructor(hostRef, dynamicOverlayHandler) {
		this.hostRef = hostRef;
		this.dynamicOverlayHandler = dynamicOverlayHandler;
		this.destroy$ = new Subject();
		this.tooltipComponent = NbTooltipComponent;
		this.context = {};
		this.position = NbPosition.TOP;
		this._adjustment = NbAdjustment.CLOCKWISE;
		this._tooltipClass = "";
		this.trigger = NbTrigger.HINT;
		this.offset = 8;
		this.disabled = false;
		this.nbTooltipShowStateChange = new EventEmitter();
		this.overlayConfig = { panelClass: this.tooltipClass };
	}
	ngOnInit() {
		this.dynamicOverlayHandler.host(this.hostRef).componentType(this.tooltipComponent).offset(this.offset);
	}
	ngOnChanges() {
		this.rebuild();
	}
	ngAfterViewInit() {
		this.dynamicOverlay = this.configureDynamicOverlay().build();
		this.dynamicOverlay.isShown.pipe(skip(1), takeUntil(this.destroy$)).subscribe((isShown) => this.nbTooltipShowStateChange.emit({ isShown }));
	}
	rebuild() {
		this.dynamicOverlay = this.configureDynamicOverlay().rebuild();
	}
	show() {
		this.dynamicOverlay.show();
	}
	hide() {
		this.dynamicOverlay.hide();
	}
	toggle() {
		this.dynamicOverlay.toggle();
	}
	ngOnDestroy() {
		this.dynamicOverlayHandler.destroy();
		this.destroy$.next();
		this.destroy$.complete();
	}
	configureDynamicOverlay() {
		return this.dynamicOverlayHandler.position(this.position).trigger(this.trigger).disabled(this.disabled).adjustment(this.adjustment).content(this.content).context(this.context).overlayConfig(this.overlayConfig);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTooltipDirective,
			deps: [{ token: i0.ElementRef }, { token: NbDynamicOverlayHandler }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTooltipDirective,
			isStandalone: false,
			selector: "[nbTooltip]",
			inputs: {
				content: ["nbTooltip", "content"],
				position: ["nbTooltipPlacement", "position"],
				adjustment: ["nbTooltipAdjustment", "adjustment"],
				tooltipClass: ["nbTooltipClass", "tooltipClass"],
				icon: ["nbTooltipIcon", "icon"],
				status: ["nbTooltipStatus", "status"],
				trigger: ["nbTooltipTrigger", "trigger"],
				offset: ["nbTooltipOffset", "offset"],
				disabled: ["nbTooltipDisabled", "disabled"]
			},
			outputs: { nbTooltipShowStateChange: "nbTooltipShowStateChange" },
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			exportAs: ["nbTooltip"],
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTooltipDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTooltip]",
			exportAs: "nbTooltip",
			providers: [NbDynamicOverlayHandler, NbDynamicOverlay],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, { type: NbDynamicOverlayHandler }],
	propDecorators: {
		content: [{
			type: Input,
			args: ["nbTooltip"]
		}],
		position: [{
			type: Input,
			args: ["nbTooltipPlacement"]
		}],
		adjustment: [{
			type: Input,
			args: ["nbTooltipAdjustment"]
		}],
		tooltipClass: [{
			type: Input,
			args: ["nbTooltipClass"]
		}],
		icon: [{
			type: Input,
			args: ["nbTooltipIcon"]
		}],
		status: [{
			type: Input,
			args: ["nbTooltipStatus"]
		}],
		trigger: [{
			type: Input,
			args: ["nbTooltipTrigger"]
		}],
		offset: [{
			type: Input,
			args: ["nbTooltipOffset"]
		}],
		disabled: [{
			type: Input,
			args: ["nbTooltipDisabled"]
		}],
		nbTooltipShowStateChange: [{ type: Output }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTooltipModule = class NbTooltipModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTooltipModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTooltipModule,
			declarations: [NbTooltipComponent, NbTooltipDirective],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			],
			exports: [NbTooltipDirective]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTooltipModule,
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTooltipModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbIconModule
			],
			declarations: [NbTooltipComponent, NbTooltipDirective],
			exports: [NbTooltipDirective]
		}]
	}]
});
var keycodes_exports = /* @__PURE__ */ __exportAll({});
import * as import__angular_cdk_keycodes from "@angular/cdk/keycodes";
__reExport(keycodes_exports, import__angular_cdk_keycodes);
const NB_SELECT_INJECTION_TOKEN = new InjectionToken("NB_SELECT_INJECTION_TOKEN");
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
let lastOptionId = 0;
var NbOptionComponent = class NbOptionComponent {
	get disabled() {
		return this._disabled || this.disabledByGroup;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get click() {
		return this.click$.asObservable();
	}
	constructor(parent, elementRef, cd, zone, renderer) {
		this.elementRef = elementRef;
		this.cd = cd;
		this.zone = zone;
		this.renderer = renderer;
		this.disabledByGroup = false;
		this._disabled = false;
		this.selectionChange = new EventEmitter();
		this.click$ = new Subject();
		this.selected = false;
		this.alive = true;
		this.id = `nb-option-${lastOptionId++}`;
		this._active = false;
		this.parent = parent;
	}
	ngOnDestroy() {
		this.alive = false;
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.elementRef.nativeElement, "nb-transition");
		}));
	}
	get withCheckbox() {
		return this.multiple && this.value != null;
	}
	get content() {
		return this.elementRef.nativeElement.textContent;
	}
	get hidden() {
		return this.elementRef.nativeElement.hidden;
	}
	get multiple() {
		return this.parent ? this.parent.multiple : false;
	}
	get selectedClass() {
		return this.selected;
	}
	get disabledAttribute() {
		return this.disabled ? "" : null;
	}
	get tabindex() {
		return "-1";
	}
	get activeClass() {
		return this._active;
	}
	onClick(event) {
		this.click$.next(this);
		event.preventDefault();
	}
	select() {
		this.setSelection(true);
	}
	deselect() {
		this.setSelection(false);
	}
	setDisabledByGroupState(disabled) {
		if (this.disabledByGroup !== disabled && this.alive) {
			this.disabledByGroup = disabled;
			this.cd.markForCheck();
		}
	}
	setSelection(selected) {
		if (this.alive && this.selected !== selected) {
			this.selected = selected;
			this.selectionChange.emit(this);
			this.cd.markForCheck();
		}
	}
	focus() {
		this.elementRef.nativeElement.focus();
	}
	getLabel() {
		return this.content;
	}
	setActiveStyles() {
		this._active = true;
		this.cd.markForCheck();
	}
	setInactiveStyles() {
		this._active = false;
		this.cd.markForCheck();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionComponent,
			deps: [
				{
					token: NB_SELECT_INJECTION_TOKEN,
					optional: true
				},
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.NgZone },
				{ token: i0.Renderer2 }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbOptionComponent,
			isStandalone: false,
			selector: "nb-option",
			inputs: {
				value: "value",
				disabled: "disabled"
			},
			outputs: { selectionChange: "selectionChange" },
			host: {
				listeners: {
					"click": "onClick($event)",
					"keydown.space": "onClick($event)",
					"keydown.enter": "onClick($event)"
				},
				properties: {
					"attr.id": "this.id",
					"class.multiple": "this.multiple",
					"class.selected": "this.selectedClass",
					"attr.disabled": "this.disabledAttribute",
					"tabIndex": "this.tabindex",
					"class.active": "this.activeClass"
				}
			},
			ngImport: i0,
			template: `
    <nb-checkbox *ngIf="withCheckbox" [checked]="selected" [disabled]="disabled" aria-hidden="true"> </nb-checkbox>
    <ng-content></ng-content>
  `,
			isInline: true,
			styles: [":host{display:flex}:host[hidden]{display:none}:host:hover{cursor:pointer}:host nb-checkbox{display:flex;pointer-events:none}[dir=ltr] :host nb-checkbox{margin-right:.5rem}[dir=rtl] :host nb-checkbox{margin-left:.5rem}:host nb-checkbox ::ng-deep .label{padding:0}:host([disabled]){pointer-events:none}:host(.nb-transition){transition-duration:.15s;transition-property:background-color,color;transition-timing-function:ease-in}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbCheckboxComponent,
				selector: "nb-checkbox",
				inputs: [
					"checked",
					"disabled",
					"status",
					"indeterminate"
				],
				outputs: ["checkedChange"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOptionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-option",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <nb-checkbox *ngIf="withCheckbox" [checked]="selected" [disabled]="disabled" aria-hidden="true"> </nb-checkbox>
    <ng-content></ng-content>
  `,
			standalone: false,
			styles: [":host{display:flex}:host[hidden]{display:none}:host:hover{cursor:pointer}:host nb-checkbox{display:flex;pointer-events:none}[dir=ltr] :host nb-checkbox{margin-right:.5rem}[dir=rtl] :host nb-checkbox{margin-left:.5rem}:host nb-checkbox ::ng-deep .label{padding:0}:host([disabled]){pointer-events:none}:host(.nb-transition){transition-duration:.15s;transition-property:background-color,color;transition-timing-function:ease-in}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NB_SELECT_INJECTION_TOKEN]
			}]
		},
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: i0.Renderer2 }
	],
	propDecorators: {
		value: [{ type: Input }],
		disabled: [{ type: Input }],
		selectionChange: [{ type: Output }],
		id: [{
			type: HostBinding,
			args: ["attr.id"]
		}],
		multiple: [{
			type: HostBinding,
			args: ["class.multiple"]
		}],
		selectedClass: [{
			type: HostBinding,
			args: ["class.selected"]
		}],
		disabledAttribute: [{
			type: HostBinding,
			args: ["attr.disabled"]
		}],
		tabindex: [{
			type: HostBinding,
			args: ["tabIndex"]
		}],
		activeClass: [{
			type: HostBinding,
			args: ["class.active"]
		}],
		onClick: [
			{
				type: HostListener,
				args: ["click", ["$event"]]
			},
			{
				type: HostListener,
				args: ["keydown.space", ["$event"]]
			},
			{
				type: HostListener,
				args: ["keydown.enter", ["$event"]]
			}
		]
	}
});
var NbOptionListComponent = class NbOptionListComponent {
	constructor() {
		this.size = "medium";
	}
	get positionTop() {
		return this.position === NbPosition.TOP;
	}
	get positionBottom() {
		return this.position === NbPosition.BOTTOM;
	}
	get sizeTiny() {
		return this.size === "tiny";
	}
	get sizeSmall() {
		return this.size === "small";
	}
	get sizeMedium() {
		return this.size === "medium";
	}
	get sizeLarge() {
		return this.size === "large";
	}
	get sizeGiant() {
		return this.size === "giant";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionListComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbOptionListComponent,
			isStandalone: false,
			selector: "nb-option-list",
			inputs: {
				size: "size",
				position: "position"
			},
			host: { properties: {
				"class.position-top": "this.positionTop",
				"class.position-bottom": "this.positionBottom",
				"class.size-tiny": "this.sizeTiny",
				"class.size-small": "this.sizeSmall",
				"class.size-medium": "this.sizeMedium",
				"class.size-large": "this.sizeLarge",
				"class.size-giant": "this.sizeGiant"
			} },
			ngImport: i0,
			template: `
    <ul class="option-list">
      <ng-content></ng-content>
    </ul>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOptionListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-option-list",
			template: `
    <ul class="option-list">
      <ng-content></ng-content>
    </ul>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	propDecorators: {
		size: [{ type: Input }],
		position: [{ type: Input }],
		positionTop: [{
			type: HostBinding,
			args: ["class.position-top"]
		}],
		positionBottom: [{
			type: HostBinding,
			args: ["class.position-bottom"]
		}],
		sizeTiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		sizeSmall: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		sizeMedium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		sizeLarge: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		sizeGiant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSelectLabelComponent = class NbSelectLabelComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectLabelComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSelectLabelComponent,
			isStandalone: false,
			selector: "nb-select-label",
			ngImport: i0,
			template: "<ng-content></ng-content>",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSelectLabelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-select-label",
			template: "<ng-content></ng-content>",
			standalone: false
		}]
	}]
});
function nbSelectFormFieldControlConfigFactory() {
	const config = new NbFormFieldControlConfig();
	config.supportsSuffix = false;
	return config;
}
var NbSelectComponent = class NbSelectComponent {
	get optionsWidth() {
		return this._optionsWidth ?? this.hostWidth;
	}
	set optionsWidth(value) {
		this._optionsWidth = value;
	}
	get outline() {
		return this.appearance === "outline";
	}
	set outline(value) {
		if (convertToBoolProperty(value)) this.appearance = "outline";
	}
	get filled() {
		return this.appearance === "filled";
	}
	set filled(value) {
		if (convertToBoolProperty(value)) this.appearance = "filled";
	}
	get hero() {
		return this.appearance === "hero";
	}
	set hero(value) {
		if (convertToBoolProperty(value)) this.appearance = "hero";
	}
	get disabled() {
		return !!this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get fullWidth() {
		return this._fullWidth;
	}
	set fullWidth(value) {
		this._fullWidth = convertToBoolProperty(value);
	}
	get compareWith() {
		return this._compareWith;
	}
	set compareWith(fn) {
		if (typeof fn !== "function") return;
		this._compareWith = fn;
		if (this.selectionModel.length && this.canSelectValue()) this.setSelection(this.selected);
	}
	set selected(value) {
		this.writeValue(value);
	}
	get selected() {
		return this.multiple ? this.selectionModel.map((o) => o.value) : this.selectionModel[0].value;
	}
	get multiple() {
		return this._multiple;
	}
	set multiple(value) {
		this._multiple = convertToBoolProperty(value);
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	get isOpen() {
		return this.ref && this.ref.hasAttached();
	}
	constructor(document, overlay, hostRef, positionBuilder, triggerStrategyBuilder, cd, focusKeyManagerFactoryService, focusMonitor, renderer, zone, statusService) {
		this.document = document;
		this.overlay = overlay;
		this.hostRef = hostRef;
		this.positionBuilder = positionBuilder;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.cd = cd;
		this.focusKeyManagerFactoryService = focusKeyManagerFactoryService;
		this.focusMonitor = focusMonitor;
		this.renderer = renderer;
		this.zone = zone;
		this.statusService = statusService;
		this.size = "medium";
		this.status = "basic";
		this.shape = "rectangle";
		this.appearance = "outline";
		this._fullWidth = false;
		this.placeholder = "";
		this._compareWith = (v1, v2) => v1 === v2;
		this._multiple = false;
		this.optionsOverlayOffset = 8;
		this.scrollStrategy = "block";
		this.selectedChange = new EventEmitter();
		this.selectionModel = [];
		this.overlayPosition = "";
		this.alive = true;
		this.destroy$ = new Subject();
		this.onChange = () => {};
		this.onTouched = () => {};
		this.status$ = new BehaviorSubject(this.status);
		this.size$ = new BehaviorSubject(this.size);
		this.focused$ = new BehaviorSubject(false);
		this.disabled$ = new BehaviorSubject(this.disabled);
		this.fullWidth$ = new BehaviorSubject(this.fullWidth);
	}
	get isHidden() {
		return !this.isOpen;
	}
	get hostWidth() {
		return this.button.nativeElement.getBoundingClientRect().width;
	}
	get selectButtonClasses() {
		const classes = [];
		if (!this.selectionModel.length) classes.push("placeholder");
		if (!this.selectionModel.length && !this.placeholder) classes.push("empty");
		if (this.isOpen) classes.push(this.overlayPosition);
		return classes;
	}
	get selectionView() {
		if (this.selectionModel.length > 1) return this.selectionModel.map((option) => option.content).join(", ");
		return this.selectionModel[0].content;
	}
	ngOnChanges({ disabled, status, size, fullWidth }) {
		if (disabled) this.disabled$.next(disabled.currentValue);
		if (status) this.status$.next(status.currentValue);
		if (size) this.size$.next(size.currentValue);
		if (fullWidth) this.fullWidth$.next(this.fullWidth);
	}
	ngAfterContentInit() {
		this.options.changes.pipe(startWith(this.options), filter(() => this.queue != null && this.canSelectValue()), switchMap((options) => from(Promise.resolve(options))), takeUntil(this.destroy$)).subscribe(() => this.writeValue(this.queue));
	}
	ngAfterViewInit() {
		this.triggerStrategy = this.createTriggerStrategy();
		this.subscribeOnButtonFocus();
		this.subscribeOnTriggers();
		this.subscribeOnOptionClick();
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostRef.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.alive = false;
		this.destroy$.next();
		this.destroy$.complete();
		if (this.ref) this.ref.dispose();
		if (this.triggerStrategy) this.triggerStrategy.destroy();
	}
	show() {
		if (this.shouldShow()) {
			this.attachToOverlay();
			this.positionStrategy.positionChange.pipe(take(1), takeUntil(this.destroy$)).subscribe(() => {
				this.setActiveOption();
			});
			this.cd.markForCheck();
		}
	}
	hide() {
		if (this.isOpen) {
			this.ref.detach();
			this.cd.markForCheck();
		}
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled = isDisabled;
		this.cd.markForCheck();
	}
	writeValue(value) {
		if (!this.alive) return;
		if (this.canSelectValue()) {
			this.setSelection(value);
			if (this.selectionModel.length) this.queue = null;
		} else this.queue = value;
	}
	handleOptionClick(option) {
		this.queue = null;
		if (option.value == null) this.reset();
		else this.selectOption(option);
		this.cd.markForCheck();
	}
	reset() {
		this.selectionModel.forEach((option) => option.deselect());
		this.selectionModel = [];
		this.hide();
		this.button.nativeElement.focus();
		this.emitSelected(this.multiple ? [] : null);
	}
	selectOption(option) {
		if (this.multiple) this.handleMultipleSelect(option);
		else this.handleSingleSelect(option);
	}
	handleSingleSelect(option) {
		const selected = this.selectionModel.pop();
		if (selected && !this._compareWith(selected.value, option.value)) selected.deselect();
		this.selectionModel = [option];
		option.select();
		this.hide();
		this.button.nativeElement.focus();
		this.emitSelected(option.value);
	}
	handleMultipleSelect(option) {
		if (option.selected) {
			this.selectionModel = this.selectionModel.filter((s) => !this._compareWith(s.value, option.value));
			option.deselect();
		} else {
			this.selectionModel.push(option);
			option.select();
		}
		this.emitSelected(this.selectionModel.map((opt) => opt.value));
	}
	attachToOverlay() {
		if (!this.ref) {
			this.createOverlay();
			this.subscribeOnPositionChange();
			this.createKeyManager();
			this.subscribeOnOverlayKeys();
		}
		this.ref.attach(this.portal);
	}
	setActiveOption() {
		if (this.selectionModel.length) this.keyManager.setActiveItem(this.selectionModel[0]);
		else this.keyManager.setFirstItemActive();
	}
	createOverlay() {
		const scrollStrategy = this.createScrollStrategy();
		this.positionStrategy = this.createPositionStrategy();
		this.ref = this.overlay.create({
			positionStrategy: this.positionStrategy,
			scrollStrategy,
			panelClass: this.optionsPanelClass
		});
	}
	createKeyManager() {
		this.keyManager = this.focusKeyManagerFactoryService.create(this.options).withTypeAhead(200);
	}
	createPositionStrategy() {
		return this.positionBuilder.connectedTo(this.button).position(NbPosition.BOTTOM).offset(this.optionsOverlayOffset).adjustment(NbAdjustment.VERTICAL);
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies[this.scrollStrategy]();
	}
	createTriggerStrategy() {
		return this.triggerStrategyBuilder.trigger(NbTrigger.CLICK).host(this.hostRef.nativeElement).container(() => this.getContainer()).build();
	}
	subscribeOnTriggers() {
		this.triggerStrategy.show$.subscribe(() => this.show());
		this.triggerStrategy.hide$.pipe(filter(() => this.isOpen)).subscribe(($event) => {
			this.hide();
			if (!this.isClickedWithinComponent($event)) this.onTouched();
		});
	}
	subscribeOnPositionChange() {
		this.positionStrategy.positionChange.pipe(takeUntil(this.destroy$)).subscribe((position) => {
			this.overlayPosition = position;
			this.cd.detectChanges();
		});
	}
	subscribeOnOptionClick() {
		this.options.changes.pipe(startWith(this.options), switchMap((options) => {
			return merge(...options.map((option) => option.click));
		}), takeUntil(this.destroy$)).subscribe((clickedOption) => this.handleOptionClick(clickedOption));
	}
	subscribeOnOverlayKeys() {
		this.ref.keydownEvents().pipe(filter(() => this.isOpen), takeUntil(this.destroy$)).subscribe((event) => {
			if (event.keyCode === keycodes_exports.ESCAPE) {
				this.button.nativeElement.focus();
				this.hide();
			} else this.keyManager.onKeydown(event);
		});
		this.keyManager.tabOut.pipe(takeUntil(this.destroy$)).subscribe(() => {
			this.hide();
			this.onTouched();
		});
	}
	subscribeOnButtonFocus() {
		this.focusMonitor.monitor(this.button).pipe(map((origin) => !!origin), finalize(() => this.focusMonitor.stopMonitoring(this.button)), takeUntil(this.destroy$)).subscribe(this.focused$);
	}
	getContainer() {
		return this.ref && this.ref.hasAttached() && { location: { nativeElement: this.ref.overlayElement } };
	}
	emitSelected(selected) {
		this.onChange(selected);
		this.selectedChange.emit(selected);
	}
	setSelection(value) {
		const isResetValue = value == null;
		let safeValue = value;
		if (this.multiple) safeValue = value ?? [];
		const isArray = Array.isArray(safeValue);
		if (this.multiple && !isArray && !isResetValue) throw new Error("Can't assign single value if select is marked as multiple");
		if (!this.multiple && isArray) throw new Error("Can't assign array if select is not marked as multiple");
		const previouslySelectedOptions = this.selectionModel;
		this.selectionModel = [];
		if (this.multiple) safeValue.forEach((option) => this.selectValue(option));
		else this.selectValue(safeValue);
		previouslySelectedOptions.filter((option) => !this.selectionModel.includes(option)).forEach((option) => option.deselect());
		this.cd.markForCheck();
	}
	selectValue(value) {
		if (value == null) return;
		const corresponding = this.options.find((option) => this._compareWith(option.value, value));
		if (corresponding) {
			corresponding.select();
			this.selectionModel.push(corresponding);
		}
	}
	shouldShow() {
		return this.isHidden && this.options?.length > 0;
	}
	trySetTouched() {
		if (this.isHidden) this.onTouched();
	}
	isClickedWithinComponent($event) {
		return this.hostRef.nativeElement === $event.target || this.hostRef.nativeElement.contains($event.target);
	}
	canSelectValue() {
		return !!(this.options && this.options.length);
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get rectangle() {
		return this.shape === "rectangle";
	}
	get round() {
		return this.shape === "round";
	}
	get semiRound() {
		return this.shape === "semi-round";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectComponent,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbOverlayService },
				{ token: i0.ElementRef },
				{ token: NbPositionBuilderService },
				{ token: NbTriggerStrategyBuilderService },
				{ token: i0.ChangeDetectorRef },
				{ token: NbFocusKeyManagerFactoryService },
				{ token: NbFocusMonitor },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSelectComponent,
			isStandalone: false,
			selector: "nb-select",
			inputs: {
				size: "size",
				status: "status",
				shape: "shape",
				appearance: "appearance",
				optionsListClass: "optionsListClass",
				optionsPanelClass: "optionsPanelClass",
				optionsWidth: "optionsWidth",
				outline: "outline",
				filled: "filled",
				hero: "hero",
				disabled: "disabled",
				fullWidth: "fullWidth",
				placeholder: "placeholder",
				compareWith: "compareWith",
				selected: "selected",
				multiple: "multiple",
				optionsOverlayOffset: "optionsOverlayOffset",
				scrollStrategy: "scrollStrategy"
			},
			outputs: { selectedChange: "selectedChange" },
			host: { properties: {
				"class.appearance-outline": "this.outline",
				"class.appearance-filled": "this.filled",
				"class.appearance-hero": "this.hero",
				"class.full-width": "this.fullWidth",
				"class": "this.additionalClasses",
				"class.open": "this.isOpen",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.shape-rectangle": "this.rectangle",
				"class.shape-round": "this.round",
				"class.shape-semi-round": "this.semiRound"
			} },
			providers: [
				{
					provide: NG_VALUE_ACCESSOR,
					useExisting: forwardRef(() => NbSelectComponent),
					multi: true
				},
				{
					provide: NB_SELECT_INJECTION_TOKEN,
					useExisting: NbSelectComponent
				},
				{
					provide: NbFormFieldControl,
					useExisting: NbSelectComponent
				},
				{
					provide: NbFormFieldControlConfig,
					useFactory: nbSelectFormFieldControlConfigFactory
				}
			],
			queries: [{
				propertyName: "customLabel",
				first: true,
				predicate: NbSelectLabelComponent,
				descendants: true
			}, {
				propertyName: "options",
				predicate: NbOptionComponent,
				descendants: true
			}],
			viewQueries: [{
				propertyName: "portal",
				first: true,
				predicate: NbPortalDirective,
				descendants: true
			}, {
				propertyName: "button",
				first: true,
				predicate: ["selectButton"],
				descendants: true,
				read: ElementRef
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: "<button\n  [disabled]=\"disabled\"\n  [ngClass]=\"selectButtonClasses\"\n  (blur)=\"trySetTouched()\"\n  (keydown.arrowDown)=\"show()\"\n  (keydown.arrowUp)=\"show()\"\n  class=\"select-button\"\n  type=\"button\"\n  #selectButton\n>\n  <span (click)=\"disabled && $event.stopPropagation()\">\n    <ng-container *ngIf=\"selectionModel.length; else placeholderTemplate\">\n      <ng-container *ngIf=\"customLabel; else defaultSelectionTemplate\">\n        <ng-content select=\"nb-select-label\"></ng-content>\n      </ng-container>\n\n      <ng-template #defaultSelectionTemplate>{{ selectionView }}</ng-template>\n    </ng-container>\n\n    <ng-template #placeholderTemplate>{{ placeholder }}</ng-template>\n  </span>\n\n  <nb-icon\n    icon=\"chevron-down-outline\"\n    pack=\"nebular-essentials\"\n    (click)=\"disabled && $event.stopPropagation()\"\n    aria-hidden=\"true\"\n  >\n  </nb-icon>\n</button>\n\n<nb-option-list\n  *nbPortal\n  [size]=\"size\"\n  [position]=\"overlayPosition\"\n  [style.width.px]=\"optionsWidth\"\n  [ngClass]=\"optionsListClass\"\n>\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host{display:inline-block;max-width:100%}[dir=ltr] :host .select-button{text-align:left}[dir=ltr] :host .select-button nb-icon{right:.2em}[dir=rtl] :host .select-button{text-align:right}[dir=rtl] :host .select-button nb-icon{left:.2em}:host(.full-width){width:100%}:host(.nb-transition) .select-button{transition-duration:.15s;transition-property:background-color,border-color,border-radius,box-shadow,color;transition-timing-function:ease-in}.select-button{position:relative;width:100%;overflow:hidden;text-overflow:ellipsis;text-transform:none;white-space:nowrap}nb-icon{font-size:1.5em;position:absolute;top:50%;transform:translateY(-50%)}[dir=ltr] nb-icon{right:.5rem}[dir=rtl] nb-icon{left:.5rem}nb-icon{transition-duration:.15s;transition-property:transform;transition-timing-function:ease-in}:host(.open) nb-icon{transform:translateY(-50%) rotate(180deg)}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: NbPortalDirective,
					selector: "[nbPortal]"
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbOptionListComponent,
					selector: "nb-option-list",
					inputs: ["size", "position"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				{
					provide: NG_VALUE_ACCESSOR,
					useExisting: forwardRef(() => NbSelectComponent),
					multi: true
				},
				{
					provide: NB_SELECT_INJECTION_TOKEN,
					useExisting: NbSelectComponent
				},
				{
					provide: NbFormFieldControl,
					useExisting: NbSelectComponent
				},
				{
					provide: NbFormFieldControlConfig,
					useFactory: nbSelectFormFieldControlConfigFactory
				}
			],
			standalone: false,
			template: "<button\n  [disabled]=\"disabled\"\n  [ngClass]=\"selectButtonClasses\"\n  (blur)=\"trySetTouched()\"\n  (keydown.arrowDown)=\"show()\"\n  (keydown.arrowUp)=\"show()\"\n  class=\"select-button\"\n  type=\"button\"\n  #selectButton\n>\n  <span (click)=\"disabled && $event.stopPropagation()\">\n    <ng-container *ngIf=\"selectionModel.length; else placeholderTemplate\">\n      <ng-container *ngIf=\"customLabel; else defaultSelectionTemplate\">\n        <ng-content select=\"nb-select-label\"></ng-content>\n      </ng-container>\n\n      <ng-template #defaultSelectionTemplate>{{ selectionView }}</ng-template>\n    </ng-container>\n\n    <ng-template #placeholderTemplate>{{ placeholder }}</ng-template>\n  </span>\n\n  <nb-icon\n    icon=\"chevron-down-outline\"\n    pack=\"nebular-essentials\"\n    (click)=\"disabled && $event.stopPropagation()\"\n    aria-hidden=\"true\"\n  >\n  </nb-icon>\n</button>\n\n<nb-option-list\n  *nbPortal\n  [size]=\"size\"\n  [position]=\"overlayPosition\"\n  [style.width.px]=\"optionsWidth\"\n  [ngClass]=\"optionsListClass\"\n>\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host{display:inline-block;max-width:100%}[dir=ltr] :host .select-button{text-align:left}[dir=ltr] :host .select-button nb-icon{right:.2em}[dir=rtl] :host .select-button{text-align:right}[dir=rtl] :host .select-button nb-icon{left:.2em}:host(.full-width){width:100%}:host(.nb-transition) .select-button{transition-duration:.15s;transition-property:background-color,border-color,border-radius,box-shadow,color;transition-timing-function:ease-in}.select-button{position:relative;width:100%;overflow:hidden;text-overflow:ellipsis;text-transform:none;white-space:nowrap}nb-icon{font-size:1.5em;position:absolute;top:50%;transform:translateY(-50%)}[dir=ltr] nb-icon{right:.5rem}[dir=rtl] nb-icon{left:.5rem}nb-icon{transition-duration:.15s;transition-property:transform;transition-timing-function:ease-in}:host(.open) nb-icon{transform:translateY(-50%) rotate(180deg)}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbOverlayService },
		{ type: i0.ElementRef },
		{ type: NbPositionBuilderService },
		{ type: NbTriggerStrategyBuilderService },
		{ type: i0.ChangeDetectorRef },
		{ type: NbFocusKeyManagerFactoryService },
		{ type: NbFocusMonitor },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		size: [{ type: Input }],
		status: [{ type: Input }],
		shape: [{ type: Input }],
		appearance: [{ type: Input }],
		optionsListClass: [{ type: Input }],
		optionsPanelClass: [{ type: Input }],
		optionsWidth: [{ type: Input }],
		outline: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-outline"]
		}],
		filled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-filled"]
		}],
		hero: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-hero"]
		}],
		disabled: [{ type: Input }],
		fullWidth: [{ type: Input }, {
			type: HostBinding,
			args: ["class.full-width"]
		}],
		placeholder: [{ type: Input }],
		compareWith: [{ type: Input }],
		selected: [{ type: Input }],
		multiple: [{ type: Input }],
		optionsOverlayOffset: [{ type: Input }],
		scrollStrategy: [{ type: Input }],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		selectedChange: [{ type: Output }],
		options: [{
			type: ContentChildren,
			args: [NbOptionComponent, { descendants: true }]
		}],
		customLabel: [{
			type: ContentChild,
			args: [NbSelectLabelComponent]
		}],
		portal: [{
			type: ViewChild,
			args: [NbPortalDirective]
		}],
		button: [{
			type: ViewChild,
			args: ["selectButton", { read: ElementRef }]
		}],
		isOpen: [{
			type: HostBinding,
			args: ["class.open"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		rectangle: [{
			type: HostBinding,
			args: ["class.shape-rectangle"]
		}],
		round: [{
			type: HostBinding,
			args: ["class.shape-round"]
		}],
		semiRound: [{
			type: HostBinding,
			args: ["class.shape-semi-round"]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbOptionGroupComponent = class NbOptionGroupComponent {
	constructor() {
		this.destroy$ = new Subject();
		this._disabled = false;
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
		if (this.options) this.updateOptionsDisabledState();
	}
	get disabledAttribute() {
		return this.disabled ? "" : null;
	}
	ngAfterContentInit() {
		if (this.options.length) this.asyncUpdateOptionsDisabledState();
		this.options.changes.pipe(takeUntil(this.destroy$)).subscribe(() => this.asyncUpdateOptionsDisabledState());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	updateOptionsDisabledState() {
		this.options.forEach((option) => option.setDisabledByGroupState(this.disabled));
	}
	asyncUpdateOptionsDisabledState() {
		from(Promise.resolve()).pipe(takeUntil(this.destroy$)).subscribe(() => this.updateOptionsDisabledState());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionGroupComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbOptionGroupComponent,
			isStandalone: false,
			selector: "nb-option-group",
			inputs: {
				title: "title",
				disabled: "disabled"
			},
			host: { properties: { "attr.disabled": "this.disabledAttribute" } },
			queries: [{
				propertyName: "options",
				predicate: NbOptionComponent,
				descendants: true
			}],
			ngImport: i0,
			template: `
    <span class="option-group-title">{{ title }}</span>
    <ng-content select="nb-option, ng-container"></ng-content>
  `,
			isInline: true,
			styles: [":host{display:block}.option-group-title{display:block}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOptionGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-option-group",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <span class="option-group-title">{{ title }}</span>
    <ng-content select="nb-option, ng-container"></ng-content>
  `,
			standalone: false,
			styles: [":host{display:block}.option-group-title{display:block}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	propDecorators: {
		title: [{ type: Input }],
		disabled: [{ type: Input }],
		disabledAttribute: [{
			type: HostBinding,
			args: ["attr.disabled"]
		}],
		options: [{
			type: ContentChildren,
			args: [NbOptionComponent, { descendants: true }]
		}]
	}
});
const NB_OPTION_LIST_COMPONENTS = [
	NbOptionListComponent,
	NbOptionComponent,
	NbOptionGroupComponent
];
var NbOptionModule = class NbOptionModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionModule,
			declarations: [
				NbOptionListComponent,
				NbOptionComponent,
				NbOptionGroupComponent
			],
			imports: [CommonModule, NbCheckboxModule],
			exports: [
				NbOptionListComponent,
				NbOptionComponent,
				NbOptionGroupComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbOptionModule,
			imports: [CommonModule, NbCheckboxModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbOptionModule,
	decorators: [{
		type: NgModule,
		args: [{
			declarations: [...NB_OPTION_LIST_COMPONENTS],
			imports: [CommonModule, NbCheckboxModule],
			exports: [...NB_OPTION_LIST_COMPONENTS]
		}]
	}]
});
const NB_SELECT_COMPONENTS$1 = [NbSelectComponent, NbSelectLabelComponent];
var NbSelectModule = class NbSelectModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectModule,
			declarations: [NbSelectComponent, NbSelectLabelComponent],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule
			],
			exports: [
				NbSelectComponent,
				NbSelectLabelComponent,
				NbOptionModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectModule,
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule,
				NbOptionModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSelectModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule
			],
			exports: [...NB_SELECT_COMPONENTS$1, NbOptionModule],
			declarations: [...NB_SELECT_COMPONENTS$1]
		}]
	}]
});
var NbPrefixDirective = class NbPrefixDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbPrefixDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbPrefixDirective,
			isStandalone: false,
			selector: "[nbPrefix]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbPrefixDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbPrefix]",
			standalone: false
		}]
	}]
});
var NbSuffixDirective = class NbSuffixDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSuffixDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSuffixDirective,
			isStandalone: false,
			selector: "[nbSuffix]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSuffixDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbSuffix]",
			standalone: false
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
function throwFormControlElementNotFound() {
	throw new Error(`NbFormFieldComponent must contain [nbInput]`);
}
var NbFormFieldComponent = class NbFormFieldComponent {
	constructor(cd, zone, elementRef, renderer) {
		this.cd = cd;
		this.zone = zone;
		this.elementRef = elementRef;
		this.renderer = renderer;
		this.destroy$ = new Subject();
		this.formControlState$ = new ReplaySubject(1);
		this.prefixClasses$ = this.formControlState$.pipe(map((s) => this.getAddonClasses("prefix", s)));
		this.suffixClasses$ = this.formControlState$.pipe(map((s) => this.getAddonClasses("suffix", s)));
	}
	ngAfterContentChecked() {
		if (!this.formControl) throwFormControlElementNotFound();
	}
	ngAfterContentInit() {
		this.subscribeToFormControlStateChange();
		this.subscribeToAddonChange();
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.elementRef.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.destroy$.next();
	}
	shouldShowPrefix() {
		return this.getFormControlConfig().supportsPrefix && !!this.prefix.length;
	}
	shouldShowSuffix() {
		return this.getFormControlConfig().supportsSuffix && !!this.suffix.length;
	}
	subscribeToFormControlStateChange() {
		const { disabled$, focused$, size$, status$, fullWidth$ } = this.formControl;
		combineLatest([
			disabled$,
			focused$,
			size$,
			status$,
			fullWidth$
		]).pipe(map(([disabled, focused, size, status, fullWidth]) => ({
			disabled,
			focused,
			size,
			status,
			fullWidth
		})), distinctUntilChanged((oldState, state) => this.isStatesEqual(oldState, state)), tap(({ size, fullWidth }) => {
			const formFieldClasses = [`nb-form-field-size-${size}`];
			if (!fullWidth) formFieldClasses.push("nb-form-field-limited-width");
			this.formFieldClasses = formFieldClasses.join(" ");
		}), takeUntil(this.destroy$)).subscribe(this.formControlState$);
	}
	subscribeToAddonChange() {
		merge(this.prefix.changes, this.suffix.changes).pipe(takeUntil(this.destroy$)).subscribe(() => this.cd.markForCheck());
	}
	getAddonClasses(addon, state) {
		const classes = ["nb-form-field-addon", `nb-form-field-${addon}-${state.size}`];
		if (state.disabled) classes.push(`nb-form-field-addon-disabled`);
		else if (state.focused) classes.push(`nb-form-field-addon-${state.status}-highlight`);
		else classes.push(`nb-form-field-addon-${state.status}`);
		return classes;
	}
	getFormControlConfig() {
		return this.formControlConfig || new NbFormFieldControlConfig();
	}
	isStatesEqual(oldState, state) {
		return oldState.status === state.status && oldState.disabled === state.disabled && oldState.focused === state.focused && oldState.fullWidth === state.fullWidth && oldState.size === state.size;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldComponent,
			deps: [
				{ token: i0.ChangeDetectorRef },
				{ token: i0.NgZone },
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFormFieldComponent,
			isStandalone: false,
			selector: "nb-form-field",
			host: { properties: { "class": "this.formFieldClasses" } },
			queries: [
				{
					propertyName: "formControl",
					first: true,
					predicate: NbFormFieldControl,
					descendants: true
				},
				{
					propertyName: "formControlConfig",
					first: true,
					predicate: NbFormFieldControlConfig,
					descendants: true
				},
				{
					propertyName: "prefix",
					predicate: NbPrefixDirective,
					descendants: true
				},
				{
					propertyName: "suffix",
					predicate: NbSuffixDirective,
					descendants: true
				}
			],
			ngImport: i0,
			template: "<div *ngIf=\"shouldShowPrefix()\" [ngClass]=\"prefixClasses$ | async\">\n  <ng-content select=\"[nbPrefix]\"></ng-content>\n</div>\n\n<div class=\"nb-form-control-container\"\n     [class.nb-form-field-control-with-prefix]=\"shouldShowPrefix()\"\n     [class.nb-form-field-control-with-suffix]=\"shouldShowSuffix()\">\n  <ng-content></ng-content>\n</div>\n\n<div *ngIf=\"shouldShowSuffix()\" [ngClass]=\"suffixClasses$ | async\">\n  <ng-content select=\"[nbSuffix]\"></ng-content>\n</div>\n",
			styles: [":host{display:flex;align-items:center}:host[hidden]{display:none}.nb-form-control-container{width:100%}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "pipe",
					type: i2.AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFormFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-form-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<div *ngIf=\"shouldShowPrefix()\" [ngClass]=\"prefixClasses$ | async\">\n  <ng-content select=\"[nbPrefix]\"></ng-content>\n</div>\n\n<div class=\"nb-form-control-container\"\n     [class.nb-form-field-control-with-prefix]=\"shouldShowPrefix()\"\n     [class.nb-form-field-control-with-suffix]=\"shouldShowSuffix()\">\n  <ng-content></ng-content>\n</div>\n\n<div *ngIf=\"shouldShowSuffix()\" [ngClass]=\"suffixClasses$ | async\">\n  <ng-content select=\"[nbSuffix]\"></ng-content>\n</div>\n",
			styles: [":host{display:flex;align-items:center}:host[hidden]{display:none}.nb-form-control-container{width:100%}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 }
	],
	propDecorators: {
		prefix: [{
			type: ContentChildren,
			args: [NbPrefixDirective, { descendants: true }]
		}],
		suffix: [{
			type: ContentChildren,
			args: [NbSuffixDirective, { descendants: true }]
		}],
		formControl: [{
			type: ContentChild,
			args: [NbFormFieldControl, { static: false }]
		}],
		formControlConfig: [{
			type: ContentChild,
			args: [NbFormFieldControlConfig, { static: false }]
		}],
		formFieldClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSelectWithAutocompleteComponent = class NbSelectWithAutocompleteComponent {
	get optionsWidth() {
		return this._optionsWidth ?? this.hostWidth;
	}
	set optionsWidth(value) {
		this._optionsWidth = value;
	}
	get outline() {
		return this.appearance === "outline";
	}
	set outline(value) {
		if (convertToBoolProperty(value)) this.appearance = "outline";
	}
	get filled() {
		return this.appearance === "filled";
	}
	set filled(value) {
		if (convertToBoolProperty(value)) this.appearance = "filled";
	}
	get hero() {
		return this.appearance === "hero";
	}
	set hero(value) {
		if (convertToBoolProperty(value)) this.appearance = "hero";
	}
	get disabled() {
		return !!this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get fullWidth() {
		return this._fullWidth;
	}
	set fullWidth(value) {
		this._fullWidth = convertToBoolProperty(value);
	}
	get compareWith() {
		return this._compareWith;
	}
	set compareWith(fn) {
		if (typeof fn !== "function") return;
		this._compareWith = fn;
		if (this.selectionModel.length && this.canSelectValue()) this.setSelection(this.selected);
	}
	set selected(value) {
		this.writeValue(value);
	}
	get selected() {
		return this.multiple ? this.selectionModel.map((o) => o.value) : this.selectionModel[0].value;
	}
	get multiple() {
		return this._multiple;
	}
	set multiple(value) {
		this._multiple = convertToBoolProperty(value);
		this.updatePositionStrategy();
		this.updateCurrentKeyManager();
	}
	set withOptionsAutocomplete(value) {
		this._withOptionsAutocomplete = convertToBoolProperty(value);
		this.updatePositionStrategy();
		this.updateCurrentKeyManager();
		if (!value) this.resetAutocompleteInput();
	}
	get withOptionsAutocomplete() {
		return this._withOptionsAutocomplete;
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	get isOpen() {
		return this.ref && this.ref.hasAttached();
	}
	get isOptionsAutocompleteAllowed() {
		return this.withOptionsAutocomplete;
	}
	get isOptionsAutocompleteInputShown() {
		return this.isOptionsAutocompleteAllowed && this.isOpen;
	}
	constructor(document, overlay, hostRef, positionBuilder, triggerStrategyBuilder, cd, focusKeyManagerFactoryService, focusMonitor, renderer, zone, statusService, activeDescendantKeyManagerFactoryService) {
		this.document = document;
		this.overlay = overlay;
		this.hostRef = hostRef;
		this.positionBuilder = positionBuilder;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.cd = cd;
		this.focusKeyManagerFactoryService = focusKeyManagerFactoryService;
		this.focusMonitor = focusMonitor;
		this.renderer = renderer;
		this.zone = zone;
		this.statusService = statusService;
		this.activeDescendantKeyManagerFactoryService = activeDescendantKeyManagerFactoryService;
		this.size = "medium";
		this.status = "basic";
		this.shape = "rectangle";
		this.appearance = "outline";
		this._fullWidth = false;
		this.placeholder = "";
		this._compareWith = (v1, v2) => v1 === v2;
		this._multiple = false;
		this.optionsOverlayOffset = 8;
		this.scrollStrategy = "block";
		this._withOptionsAutocomplete = false;
		this.selectedChange = new EventEmitter();
		this.selectOpen = new EventEmitter();
		this.selectClose = new EventEmitter();
		this.optionsAutocompleteInputChange = new EventEmitter();
		this.selectionModel = [];
		this.positionStrategy$ = new BehaviorSubject(void 0);
		this.overlayPosition = "";
		this.alive = true;
		this.destroy$ = new Subject();
		this.onChange = () => {};
		this.onTouched = () => {};
		this.status$ = new BehaviorSubject(this.status);
		this.size$ = new BehaviorSubject(this.size);
		this.focused$ = new BehaviorSubject(false);
		this.disabled$ = new BehaviorSubject(this.disabled);
		this.fullWidth$ = new BehaviorSubject(this.fullWidth);
		this.lastShownButtonWidth = void 0;
	}
	get isHidden() {
		return !this.isOpen;
	}
	get hostWidth() {
		if (this.isOptionsAutocompleteInputShown) return this.optionsAutocompleteInput.nativeElement.getBoundingClientRect().width;
		return this.button.nativeElement.getBoundingClientRect().width;
	}
	get selectButtonClasses() {
		const classes = [];
		if (!this.selectionModel.length) classes.push("placeholder");
		if (!this.selectionModel.length && !this.placeholder) classes.push("empty");
		if (this.isOpen) classes.push(this.overlayPosition);
		return classes;
	}
	get selectionView() {
		if (this.isOptionsAutocompleteInputShown && this.multiple) return "";
		if (this.selectionModel.length > 1) return this.selectionModel.map((option) => option.content).join(", ");
		return this.selectionModel[0]?.content?.trim() ?? "";
	}
	ngOnChanges({ disabled, status, size, fullWidth }) {
		if (disabled) this.disabled$.next(disabled.currentValue);
		if (status) this.status$.next(status.currentValue);
		if (size) this.size$.next(size.currentValue);
		if (fullWidth) this.fullWidth$.next(this.fullWidth);
	}
	ngAfterContentInit() {
		this.options.changes.pipe(startWith(this.options), filter(() => this.queue != null && this.canSelectValue()), switchMap((options) => from(Promise.resolve(options))), takeUntil(this.destroy$)).subscribe(() => this.writeValue(this.queue));
	}
	ngAfterViewInit() {
		this.triggerStrategy = this.createTriggerStrategy();
		this.subscribeOnButtonFocus();
		this.subscribeOnTriggers();
		this.subscribeOnOptionClick();
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostRef.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.alive = false;
		this.destroy$.next();
		this.destroy$.complete();
		if (this.ref) this.ref.dispose();
		if (this.triggerStrategy) this.triggerStrategy.destroy();
	}
	onAutocompleteInputChange(event) {
		this.optionsAutocompleteInputChange.emit(event.target.value);
	}
	show() {
		if (this.shouldShow()) {
			this.lastShownButtonWidth = this.hostWidth;
			this.attachToOverlay();
			this.positionStrategy$.pipe(switchMap((positionStrategy) => positionStrategy.positionChange ?? EMPTY), take(1), takeUntil(this.destroy$)).subscribe(() => {
				if (this.isOptionsAutocompleteInputShown) this.optionsAutocompleteInput.nativeElement.focus();
				this.setActiveOption();
			});
			this.selectOpen.emit();
			this.cd.markForCheck();
		}
	}
	hide() {
		if (this.isOpen) {
			this.ref.detach();
			this.cd.markForCheck();
			this.selectClose.emit();
			this.resetAutocompleteInput();
		}
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled = isDisabled;
		this.cd.markForCheck();
	}
	writeValue(value) {
		if (!this.alive) return;
		if (this.canSelectValue()) {
			this.setSelection(value);
			if (this.selectionModel.length) this.queue = null;
		} else this.queue = value;
	}
	handleOptionClick(option) {
		this.queue = null;
		if (option.value == null) this.reset();
		else this.selectOption(option);
		this.cd.markForCheck();
	}
	reset() {
		this.selectionModel.forEach((option) => option.deselect());
		this.selectionModel = [];
		this.hide();
		this.focusButton();
		this.emitSelected(this.multiple ? [] : null);
	}
	selectOption(option) {
		if (this.multiple) this.handleMultipleSelect(option);
		else this.handleSingleSelect(option);
	}
	handleSingleSelect(option) {
		const selected = this.selectionModel.pop();
		if (selected && !this._compareWith(selected.value, option.value)) selected.deselect();
		this.selectionModel = [option];
		option.select();
		this.hide();
		this.focusButton();
		this.emitSelected(option.value);
	}
	handleMultipleSelect(option) {
		if (option.selected) {
			this.selectionModel = this.selectionModel.filter((s) => !this._compareWith(s.value, option.value));
			option.deselect();
		} else {
			this.selectionModel.push(option);
			option.select();
		}
		this.emitSelected(this.selectionModel.map((opt) => opt.value));
	}
	attachToOverlay() {
		if (!this.ref) {
			this.createOverlay();
			this.subscribeOnPositionChange();
			this.createKeyManager();
			this.subscribeOnOverlayKeys();
			this.subscribeOnOptionsAutocompleteChange();
		}
		this.ref.attach(this.portal);
	}
	setActiveOption() {
		if (this.selectionModel.length && !this.selectionModel[0].hidden) this.currentKeyManager?.setActiveItem(this.selectionModel[0]);
		else this.currentKeyManager?.setFirstItemActive();
	}
	createOverlay() {
		const scrollStrategy = this.createScrollStrategy();
		this.positionStrategy$.next(this.createPositionStrategy());
		this.ref = this.overlay.create({
			positionStrategy: this.positionStrategy$.value,
			scrollStrategy,
			panelClass: this.optionsPanelClass
		});
	}
	createKeyManager() {
		this.activeDescendantKeyManager = this.activeDescendantKeyManagerFactoryService.create(this.options).skipPredicate((option) => {
			return this.isOptionHidden(option);
		});
		this.focusKeyManager = this.focusKeyManagerFactoryService.create(this.options).withTypeAhead(200).skipPredicate((option) => {
			return this.isOptionHidden(option);
		});
		this.updateCurrentKeyManager();
	}
	updateCurrentKeyManager() {
		this.currentKeyManager?.setActiveItem(-1);
		if (this.isOptionsAutocompleteAllowed) this.currentKeyManager = this.activeDescendantKeyManager;
		else this.currentKeyManager = this.focusKeyManager;
		this.setActiveOption();
	}
	resetAutocompleteInput() {
		if (this.optionsAutocompleteInput?.nativeElement) {
			this.optionsAutocompleteInput.nativeElement.value = this.selectionView;
			this.optionsAutocompleteInputChange.emit("");
		}
	}
	createPositionStrategy() {
		const element = this.isOptionsAutocompleteAllowed ? this.optionsAutocompleteInput : this.button;
		return this.positionBuilder.connectedTo(element).position(NbPosition.BOTTOM).offset(this.optionsOverlayOffset).adjustment(NbAdjustment.VERTICAL);
	}
	updatePositionStrategy() {
		if (this.ref) {
			this.positionStrategy$.next(this.createPositionStrategy());
			this.ref.updatePositionStrategy(this.positionStrategy$.value);
			if (this.isOpen) this.ref.updatePosition();
		}
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies[this.scrollStrategy]();
	}
	createTriggerStrategy() {
		return this.triggerStrategyBuilder.trigger(NbTrigger.CLICK).host(this.hostRef.nativeElement).container(() => this.getContainer()).build();
	}
	subscribeOnTriggers() {
		this.triggerStrategy.show$.subscribe(() => this.show());
		this.triggerStrategy.hide$.pipe(filter(() => this.isOpen)).subscribe(($event) => {
			this.hide();
			if (!this.isClickedWithinComponent($event)) this.onTouched();
		});
	}
	subscribeOnPositionChange() {
		this.positionStrategy$.pipe(switchMap((positionStrategy) => positionStrategy.positionChange ?? EMPTY), takeUntil(this.destroy$)).subscribe((position) => {
			this.overlayPosition = position;
			this.cd.detectChanges();
		});
	}
	subscribeOnOptionClick() {
		this.options.changes.pipe(startWith(this.options), switchMap((options) => {
			return merge(...options.map((option) => option.click));
		}), takeUntil(this.destroy$)).subscribe((clickedOption) => this.handleOptionClick(clickedOption));
	}
	subscribeOnOverlayKeys() {
		this.ref.keydownEvents().pipe(filter(() => this.isOpen), takeUntil(this.destroy$)).subscribe((event) => {
			if (event.keyCode === keycodes_exports.ESCAPE) {
				this.hide();
				this.focusButton();
			} else if (event.keyCode === keycodes_exports.ENTER && this.isOptionsAutocompleteInputShown) {
				event.preventDefault();
				const activeItem = this.currentKeyManager.activeItem;
				if (activeItem) this.selectOption(activeItem);
			} else this.currentKeyManager.onKeydown(event);
		});
		merge(this.focusKeyManager.tabOut.pipe(filter(() => !this.isOptionsAutocompleteInputShown)), this.activeDescendantKeyManager.tabOut.pipe(filter(() => this.isOptionsAutocompleteInputShown))).pipe(takeUntil(this.destroy$)).subscribe(() => {
			this.hide();
			this.onTouched();
		});
	}
	subscribeOnOptionsAutocompleteChange() {
		this.optionsAutocompleteInputChange.pipe(observeOn(animationFrameScheduler), filter(() => this.isOptionsAutocompleteInputShown), takeUntil(this.destroy$)).subscribe(() => {
			if (this.isOptionHidden(this.currentKeyManager.activeItem)) this.currentKeyManager.setFirstItemActive();
		});
	}
	subscribeOnButtonFocus() {
		combineLatest([this.focusMonitor.monitor(this.button).pipe(map((origin) => !!origin), startWith(false), finalize(() => this.focusMonitor.stopMonitoring(this.button))), this.focusMonitor.monitor(this.optionsAutocompleteInput).pipe(map((origin) => !!origin), startWith(false), finalize(() => this.focusMonitor.stopMonitoring(this.button)))]).pipe(map(([buttonFocus, filterInputFocus]) => buttonFocus || filterInputFocus), takeUntil(this.destroy$)).subscribe(this.focused$);
	}
	getContainer() {
		return this.ref && this.ref.hasAttached() && { location: { nativeElement: this.ref.overlayElement } };
	}
	focusButton() {
		setTimeout(() => {
			this.button?.nativeElement?.focus();
		});
	}
	emitSelected(selected) {
		this.onChange(selected);
		this.selectedChange.emit(selected);
	}
	setSelection(value) {
		const isResetValue = value == null;
		let safeValue = value;
		if (this.multiple) safeValue = value ?? [];
		const isArray = Array.isArray(safeValue);
		if (this.multiple && !isArray && !isResetValue) throw new Error("Can't assign single value if select is marked as multiple");
		if (!this.multiple && isArray) throw new Error("Can't assign array if select is not marked as multiple");
		const previouslySelectedOptions = this.selectionModel;
		this.selectionModel = [];
		if (this.multiple) safeValue.forEach((option) => this.selectValue(option));
		else this.selectValue(safeValue);
		previouslySelectedOptions.filter((option) => !this.selectionModel.includes(option)).forEach((option) => option.deselect());
		this.cd.markForCheck();
	}
	selectValue(value) {
		if (value == null) return;
		const corresponding = this.options.find((option) => this._compareWith(option.value, value));
		if (corresponding) {
			corresponding.select();
			this.selectionModel.push(corresponding);
		}
	}
	shouldShow() {
		return this.isHidden && this.options?.length > 0;
	}
	trySetTouched() {
		if (this.isHidden) this.onTouched();
	}
	isClickedWithinComponent($event) {
		return this.hostRef.nativeElement === $event.target || this.hostRef.nativeElement.contains($event.target);
	}
	canSelectValue() {
		return !!(this.options && this.options.length);
	}
	isOptionHidden(option) {
		return option.hidden;
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get primary() {
		return this.status === "primary";
	}
	get info() {
		return this.status === "info";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get rectangle() {
		return this.shape === "rectangle";
	}
	get round() {
		return this.shape === "round";
	}
	get semiRound() {
		return this.shape === "semi-round";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectWithAutocompleteComponent,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbOverlayService },
				{ token: i0.ElementRef },
				{ token: NbPositionBuilderService },
				{ token: NbTriggerStrategyBuilderService },
				{ token: i0.ChangeDetectorRef },
				{ token: NbFocusKeyManagerFactoryService },
				{ token: NbFocusMonitor },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbStatusService },
				{ token: NbActiveDescendantKeyManagerFactoryService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSelectWithAutocompleteComponent,
			isStandalone: false,
			selector: "nb-select-with-autocomplete",
			inputs: {
				size: "size",
				status: "status",
				shape: "shape",
				appearance: "appearance",
				optionsListClass: "optionsListClass",
				optionsPanelClass: "optionsPanelClass",
				optionsWidth: "optionsWidth",
				outline: "outline",
				filled: "filled",
				hero: "hero",
				disabled: "disabled",
				fullWidth: "fullWidth",
				placeholder: "placeholder",
				compareWith: "compareWith",
				selected: "selected",
				multiple: "multiple",
				optionsOverlayOffset: "optionsOverlayOffset",
				scrollStrategy: "scrollStrategy",
				withOptionsAutocomplete: "withOptionsAutocomplete"
			},
			outputs: {
				selectedChange: "selectedChange",
				selectOpen: "selectOpen",
				selectClose: "selectClose",
				optionsAutocompleteInputChange: "optionsAutocompleteInputChange"
			},
			host: { properties: {
				"class.appearance-outline": "this.outline",
				"class.appearance-filled": "this.filled",
				"class.appearance-hero": "this.hero",
				"class.full-width": "this.fullWidth",
				"class": "this.additionalClasses",
				"class.open": "this.isOpen",
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant",
				"class.status-primary": "this.primary",
				"class.status-info": "this.info",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class.shape-rectangle": "this.rectangle",
				"class.shape-round": "this.round",
				"class.shape-semi-round": "this.semiRound"
			} },
			providers: [
				{
					provide: NG_VALUE_ACCESSOR,
					useExisting: forwardRef(() => NbSelectWithAutocompleteComponent),
					multi: true
				},
				{
					provide: NB_SELECT_INJECTION_TOKEN,
					useExisting: NbSelectWithAutocompleteComponent
				},
				{
					provide: NbFormFieldControl,
					useExisting: NbSelectWithAutocompleteComponent
				},
				{
					provide: NbFormFieldControlConfig,
					useFactory: nbSelectFormFieldControlConfigFactory
				}
			],
			queries: [{
				propertyName: "customLabel",
				first: true,
				predicate: NbSelectLabelComponent,
				descendants: true
			}, {
				propertyName: "options",
				predicate: NbOptionComponent,
				descendants: true
			}],
			viewQueries: [
				{
					propertyName: "portal",
					first: true,
					predicate: NbPortalDirective,
					descendants: true
				},
				{
					propertyName: "button",
					first: true,
					predicate: ["selectButton"],
					descendants: true,
					read: ElementRef
				},
				{
					propertyName: "optionsAutocompleteInput",
					first: true,
					predicate: ["optionsAutocompleteInput"],
					descendants: true,
					read: ElementRef
				}
			],
			usesOnChanges: true,
			ngImport: i0,
			template: "<button\n  [hidden]=\"isOptionsAutocompleteInputShown\"\n  [disabled]=\"disabled\"\n  [ngClass]=\"selectButtonClasses\"\n  (blur)=\"trySetTouched()\"\n  (keydown.arrowDown)=\"show()\"\n  (keydown.arrowUp)=\"show()\"\n  class=\"select-button\"\n  type=\"button\"\n  #selectButton\n>\n  <span (click)=\"disabled && $event.stopPropagation()\">\n    <ng-container *ngIf=\"selectionModel.length; else placeholderTemplate\">\n      <ng-container *ngIf=\"customLabel; else defaultSelectionTemplate\">\n        <ng-content select=\"nb-select-label\"></ng-content>\n      </ng-container>\n\n      <ng-template #defaultSelectionTemplate>{{ selectionView }}</ng-template>\n    </ng-container>\n\n    <ng-template #placeholderTemplate>{{ placeholder }}</ng-template>\n  </span>\n\n  <nb-icon\n    icon=\"chevron-down-outline\"\n    pack=\"nebular-essentials\"\n    (click)=\"disabled && $event.stopPropagation()\"\n    aria-hidden=\"true\"\n  >\n  </nb-icon>\n</button>\n\n<nb-form-field [hidden]=\"!isOptionsAutocompleteInputShown\">\n  <input\n    nbInput\n    fullWidth\n    [style.max-width.px]=\"lastShownButtonWidth\"\n    #optionsAutocompleteInput\n    [value]=\"selectionView\"\n    [placeholder]=\"placeholder\"\n    [status]=\"status\"\n    [shape]=\"shape\"\n    [fieldSize]=\"size\"\n    (blur)=\"trySetTouched()\"\n    (click)=\"$event.stopPropagation()\"\n    (dblclick)=\"$event.stopPropagation()\"\n    (input)=\"onAutocompleteInputChange($event)\"\n  />\n  <nb-icon nbSuffix icon=\"chevron-up-outline\" pack=\"nebular-essentials\" aria-hidden=\"true\"> </nb-icon>\n</nb-form-field>\n\n<nb-option-list\n  *nbPortal\n  [size]=\"size\"\n  [position]=\"overlayPosition\"\n  [style.width.px]=\"optionsWidth\"\n  [ngClass]=\"optionsListClass\"\n>\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host{display:inline-block;max-width:100%}[dir=ltr] :host .select-button{text-align:left}[dir=ltr] :host .select-button nb-icon{right:.2em}[dir=rtl] :host .select-button{text-align:right}[dir=rtl] :host .select-button nb-icon{left:.2em}:host(.full-width){width:100%}:host(.nb-transition) .select-button{transition-duration:.15s;transition-property:background-color,border-color,border-radius,box-shadow,color;transition-timing-function:ease-in}.select-button,nb-form-field{position:relative;width:100%;overflow:hidden;text-overflow:ellipsis;text-transform:none;white-space:nowrap}nb-icon:not([nbSuffix]){font-size:1.5em;position:absolute;top:50%;transform:translateY(-50%)}[dir=ltr] nb-icon:not([nbSuffix]){right:.5rem}[dir=rtl] nb-icon:not([nbSuffix]){left:.5rem}nb-icon:not([nbSuffix]){transition-duration:.15s;transition-property:transform;transition-timing-function:ease-in}:host(.open) nb-icon:not([nbSuffix]){transform:translateY(-50%) rotate(180deg)}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: NbPortalDirective,
					selector: "[nbPortal]"
				},
				{
					kind: "directive",
					type: NbInputDirective,
					selector: "input[nbInput],textarea[nbInput]",
					inputs: [
						"fieldSize",
						"status",
						"shape",
						"fullWidth"
					]
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbOptionListComponent,
					selector: "nb-option-list",
					inputs: ["size", "position"]
				},
				{
					kind: "component",
					type: NbFormFieldComponent,
					selector: "nb-form-field"
				},
				{
					kind: "directive",
					type: NbSuffixDirective,
					selector: "[nbSuffix]"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSelectWithAutocompleteComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-select-with-autocomplete",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				{
					provide: NG_VALUE_ACCESSOR,
					useExisting: forwardRef(() => NbSelectWithAutocompleteComponent),
					multi: true
				},
				{
					provide: NB_SELECT_INJECTION_TOKEN,
					useExisting: NbSelectWithAutocompleteComponent
				},
				{
					provide: NbFormFieldControl,
					useExisting: NbSelectWithAutocompleteComponent
				},
				{
					provide: NbFormFieldControlConfig,
					useFactory: nbSelectFormFieldControlConfigFactory
				}
			],
			standalone: false,
			template: "<button\n  [hidden]=\"isOptionsAutocompleteInputShown\"\n  [disabled]=\"disabled\"\n  [ngClass]=\"selectButtonClasses\"\n  (blur)=\"trySetTouched()\"\n  (keydown.arrowDown)=\"show()\"\n  (keydown.arrowUp)=\"show()\"\n  class=\"select-button\"\n  type=\"button\"\n  #selectButton\n>\n  <span (click)=\"disabled && $event.stopPropagation()\">\n    <ng-container *ngIf=\"selectionModel.length; else placeholderTemplate\">\n      <ng-container *ngIf=\"customLabel; else defaultSelectionTemplate\">\n        <ng-content select=\"nb-select-label\"></ng-content>\n      </ng-container>\n\n      <ng-template #defaultSelectionTemplate>{{ selectionView }}</ng-template>\n    </ng-container>\n\n    <ng-template #placeholderTemplate>{{ placeholder }}</ng-template>\n  </span>\n\n  <nb-icon\n    icon=\"chevron-down-outline\"\n    pack=\"nebular-essentials\"\n    (click)=\"disabled && $event.stopPropagation()\"\n    aria-hidden=\"true\"\n  >\n  </nb-icon>\n</button>\n\n<nb-form-field [hidden]=\"!isOptionsAutocompleteInputShown\">\n  <input\n    nbInput\n    fullWidth\n    [style.max-width.px]=\"lastShownButtonWidth\"\n    #optionsAutocompleteInput\n    [value]=\"selectionView\"\n    [placeholder]=\"placeholder\"\n    [status]=\"status\"\n    [shape]=\"shape\"\n    [fieldSize]=\"size\"\n    (blur)=\"trySetTouched()\"\n    (click)=\"$event.stopPropagation()\"\n    (dblclick)=\"$event.stopPropagation()\"\n    (input)=\"onAutocompleteInputChange($event)\"\n  />\n  <nb-icon nbSuffix icon=\"chevron-up-outline\" pack=\"nebular-essentials\" aria-hidden=\"true\"> </nb-icon>\n</nb-form-field>\n\n<nb-option-list\n  *nbPortal\n  [size]=\"size\"\n  [position]=\"overlayPosition\"\n  [style.width.px]=\"optionsWidth\"\n  [ngClass]=\"optionsListClass\"\n>\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host{display:inline-block;max-width:100%}[dir=ltr] :host .select-button{text-align:left}[dir=ltr] :host .select-button nb-icon{right:.2em}[dir=rtl] :host .select-button{text-align:right}[dir=rtl] :host .select-button nb-icon{left:.2em}:host(.full-width){width:100%}:host(.nb-transition) .select-button{transition-duration:.15s;transition-property:background-color,border-color,border-radius,box-shadow,color;transition-timing-function:ease-in}.select-button,nb-form-field{position:relative;width:100%;overflow:hidden;text-overflow:ellipsis;text-transform:none;white-space:nowrap}nb-icon:not([nbSuffix]){font-size:1.5em;position:absolute;top:50%;transform:translateY(-50%)}[dir=ltr] nb-icon:not([nbSuffix]){right:.5rem}[dir=rtl] nb-icon:not([nbSuffix]){left:.5rem}nb-icon:not([nbSuffix]){transition-duration:.15s;transition-property:transform;transition-timing-function:ease-in}:host(.open) nb-icon:not([nbSuffix]){transform:translateY(-50%) rotate(180deg)}\n/*!\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbOverlayService },
		{ type: i0.ElementRef },
		{ type: NbPositionBuilderService },
		{ type: NbTriggerStrategyBuilderService },
		{ type: i0.ChangeDetectorRef },
		{ type: NbFocusKeyManagerFactoryService },
		{ type: NbFocusMonitor },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbStatusService },
		{ type: NbActiveDescendantKeyManagerFactoryService }
	],
	propDecorators: {
		size: [{ type: Input }],
		status: [{ type: Input }],
		shape: [{ type: Input }],
		appearance: [{ type: Input }],
		optionsListClass: [{ type: Input }],
		optionsPanelClass: [{ type: Input }],
		optionsWidth: [{ type: Input }],
		outline: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-outline"]
		}],
		filled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-filled"]
		}],
		hero: [{ type: Input }, {
			type: HostBinding,
			args: ["class.appearance-hero"]
		}],
		disabled: [{ type: Input }],
		fullWidth: [{ type: Input }, {
			type: HostBinding,
			args: ["class.full-width"]
		}],
		placeholder: [{ type: Input }],
		compareWith: [{ type: Input }],
		selected: [{ type: Input }],
		multiple: [{ type: Input }],
		optionsOverlayOffset: [{ type: Input }],
		scrollStrategy: [{ type: Input }],
		withOptionsAutocomplete: [{ type: Input }],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		selectedChange: [{ type: Output }],
		selectOpen: [{ type: Output }],
		selectClose: [{ type: Output }],
		optionsAutocompleteInputChange: [{ type: Output }],
		options: [{
			type: ContentChildren,
			args: [NbOptionComponent, { descendants: true }]
		}],
		customLabel: [{
			type: ContentChild,
			args: [NbSelectLabelComponent]
		}],
		portal: [{
			type: ViewChild,
			args: [NbPortalDirective]
		}],
		button: [{
			type: ViewChild,
			args: ["selectButton", { read: ElementRef }]
		}],
		optionsAutocompleteInput: [{
			type: ViewChild,
			args: ["optionsAutocompleteInput", { read: ElementRef }]
		}],
		isOpen: [{
			type: HostBinding,
			args: ["class.open"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		rectangle: [{
			type: HostBinding,
			args: ["class.shape-rectangle"]
		}],
		round: [{
			type: HostBinding,
			args: ["class.shape-round"]
		}],
		semiRound: [{
			type: HostBinding,
			args: ["class.shape-semi-round"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const COMPONENTS$1 = [
	NbFormFieldComponent,
	NbPrefixDirective,
	NbSuffixDirective
];
var NbFormFieldModule = class NbFormFieldModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldModule,
			declarations: [
				NbFormFieldComponent,
				NbPrefixDirective,
				NbSuffixDirective
			],
			imports: [CommonModule],
			exports: [
				NbFormFieldComponent,
				NbPrefixDirective,
				NbSuffixDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFormFieldModule,
			imports: [CommonModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFormFieldModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule],
			declarations: [...COMPONENTS$1],
			exports: [...COMPONENTS$1]
		}]
	}]
});
const NB_SELECT_COMPONENTS = [NbSelectWithAutocompleteComponent];
var NbSelectWithAutocompleteModule = class NbSelectWithAutocompleteModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectWithAutocompleteModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectWithAutocompleteModule,
			declarations: [NbSelectWithAutocompleteComponent],
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule,
				NbFormFieldModule,
				NbSelectModule
			],
			exports: [
				NbSelectWithAutocompleteComponent,
				NbOptionModule,
				NbSelectModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSelectWithAutocompleteModule,
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule,
				NbFormFieldModule,
				NbSelectModule,
				NbOptionModule,
				NbSelectModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSelectWithAutocompleteModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbSharedModule,
				NbOverlayModule,
				NbButtonModule,
				NbInputModule,
				NbCardModule,
				NbIconModule,
				NbOptionModule,
				NbFormFieldModule,
				NbSelectModule
			],
			exports: [
				...NB_SELECT_COMPONENTS,
				NbOptionModule,
				NbSelectModule
			],
			declarations: [...NB_SELECT_COMPONENTS]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
let lastAutocompleteId = 0;
var NbAutocompleteComponent = class NbAutocompleteComponent {
	get overlayPosition() {
		return this._overlayPosition;
	}
	set overlayPosition(value) {
		this._overlayPosition = value;
		this.cd.detectChanges();
	}
	get hostWidth() {
		return this.hostRef.nativeElement.getBoundingClientRect().width;
	}
	get optionsWidth() {
		return this._optionsWidth ?? this.hostWidth;
	}
	set optionsWidth(value) {
		this._optionsWidth = value;
	}
	constructor(cd) {
		this.cd = cd;
		this.destroy$ = new Subject();
		this.id = `nb-autocomplete-${lastAutocompleteId++}`;
		this._overlayPosition = "";
		this.size = "medium";
		this.activeFirst = false;
		this.selectedChange = new EventEmitter();
	}
	ngAfterContentInit() {
		this.options.changes.pipe(takeUntil(this.destroy$)).subscribe(() => this.cd.detectChanges());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	setHost(hostRef) {
		this.hostRef = hostRef;
	}
	emitSelected(selected) {
		this.selectedChange.emit(selected);
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAutocompleteComponent,
			deps: [{ token: i0.ChangeDetectorRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAutocompleteComponent,
			isStandalone: false,
			selector: "nb-autocomplete",
			inputs: {
				handleDisplayFn: "handleDisplayFn",
				size: "size",
				activeFirst: "activeFirst",
				optionsListClass: "optionsListClass",
				optionsPanelClass: "optionsPanelClass",
				optionsWidth: "optionsWidth"
			},
			outputs: { selectedChange: "selectedChange" },
			host: { properties: {
				"class.size-tiny": "this.tiny",
				"class.size-small": "this.small",
				"class.size-medium": "this.medium",
				"class.size-large": "this.large",
				"class.size-giant": "this.giant"
			} },
			queries: [{
				propertyName: "options",
				predicate: NbOptionComponent,
				descendants: true
			}],
			viewQueries: [{
				propertyName: "portal",
				first: true,
				predicate: NbPortalDirective,
				descendants: true
			}],
			ngImport: i0,
			template: "<nb-option-list *nbPortal\n                [size]=\"size\"\n                [position]=\"overlayPosition\"\n                [style.width.px]=\"optionsWidth\"\n                role=\"listbox\"\n                [id]=\"id\"\n                [class.empty]=\"!options?.length\"\n                [ngClass]=\"optionsListClass\">\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host(:hover){cursor:pointer}nb-option-list.empty{border:none}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "directive",
					type: NbPortalDirective,
					selector: "[nbPortal]"
				},
				{
					kind: "component",
					type: NbOptionListComponent,
					selector: "nb-option-list",
					inputs: ["size", "position"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAutocompleteComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-autocomplete",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "<nb-option-list *nbPortal\n                [size]=\"size\"\n                [position]=\"overlayPosition\"\n                [style.width.px]=\"optionsWidth\"\n                role=\"listbox\"\n                [id]=\"id\"\n                [class.empty]=\"!options?.length\"\n                [ngClass]=\"optionsListClass\">\n  <ng-content select=\"nb-option, nb-option-group\"></ng-content>\n</nb-option-list>\n",
			styles: [":host(:hover){cursor:pointer}nb-option-list.empty{border:none}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [{ type: i0.ChangeDetectorRef }],
	propDecorators: {
		handleDisplayFn: [{ type: Input }],
		size: [{ type: Input }],
		activeFirst: [{ type: Input }],
		optionsListClass: [{ type: Input }],
		optionsPanelClass: [{ type: Input }],
		optionsWidth: [{ type: Input }],
		selectedChange: [{ type: Output }],
		options: [{
			type: ContentChildren,
			args: [NbOptionComponent, { descendants: true }]
		}],
		portal: [{
			type: ViewChild,
			args: [NbPortalDirective]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbAutocompleteDirective = class NbAutocompleteDirective {
	get isOpen() {
		return this.overlayRef && this.overlayRef.hasAttached();
	}
	get isClosed() {
		return !this.isOpen;
	}
	get autocomplete() {
		return this._autocomplete;
	}
	set autocomplete(autocomplete) {
		this._autocomplete = autocomplete;
	}
	get top() {
		return this.isOpen && this.autocomplete.options.length && this.autocomplete.overlayPosition === NbPosition.TOP;
	}
	get bottom() {
		return this.isOpen && this.autocomplete.options.length && this.autocomplete.overlayPosition === NbPosition.BOTTOM;
	}
	get ariaExpanded() {
		return this.isOpen && this.isOpen.toString();
	}
	get ariaOwns() {
		return this.isOpen ? this.autocomplete.id : null;
	}
	get ariaActiveDescendant() {
		return this.isOpen && this.keyManager.activeItem ? this.keyManager.activeItem.id : null;
	}
	constructor(hostRef, overlay, cd, triggerStrategyBuilder, positionBuilder, activeDescendantKeyManagerFactory, renderer) {
		this.hostRef = hostRef;
		this.overlay = overlay;
		this.cd = cd;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.positionBuilder = positionBuilder;
		this.activeDescendantKeyManagerFactory = activeDescendantKeyManagerFactory;
		this.renderer = renderer;
		this.destroy$ = new Subject();
		this._onChange = () => {};
		this._onTouched = () => {};
		this.overlayOffset = 8;
		this.scrollStrategy = "block";
		this.role = "combobox";
		this.ariaAutocomplete = "list";
		this.hasPopup = "true";
	}
	ngAfterViewInit() {
		this.triggerStrategy = this.createTriggerStrategy();
		this.subscribeOnTriggers();
	}
	ngOnDestroy() {
		if (this.triggerStrategy) this.triggerStrategy.destroy();
		if (this.positionStrategy) this.positionStrategy.dispose();
		if (this.overlayRef) this.overlayRef.dispose();
		this.destroy$.next();
		this.destroy$.complete();
	}
	handleInput() {
		const currentValue = this.hostRef.nativeElement.value;
		this._onChange(currentValue);
		this.setHostInputValue(this.getDisplayValue(currentValue));
		this.show();
	}
	handleKeydown() {
		this.show();
	}
	handleBlur() {
		this._onTouched();
	}
	show() {
		if (this.shouldShow()) {
			this.attachToOverlay();
			this.setActiveItem();
		}
	}
	hide() {
		if (this.isOpen) {
			this.overlayRef.detach();
			this.cd.markForCheck();
		}
	}
	writeValue(value) {
		this.handleInputValueUpdate(value);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(disabled) {
		this.renderer.setProperty(this.hostRef.nativeElement, "disabled", disabled);
	}
	subscribeOnOptionClick() {
		this.autocomplete.options.changes.pipe(tap(() => this.setActiveItem()), startWith(this.autocomplete.options), switchMap((options) => {
			return merge(...options.map((option) => option.click));
		}), takeUntil(this.destroy$)).subscribe((clickedOption) => this.handleInputValueUpdate(clickedOption.value, true));
	}
	subscribeOnPositionChange() {
		this.positionStrategy.positionChange.pipe(takeUntil(this.destroy$)).subscribe((position) => {
			this.autocomplete.overlayPosition = position;
			this.cd.detectChanges();
		});
	}
	getActiveItem() {
		return this.keyManager.activeItem;
	}
	setupAutocomplete() {
		this.autocomplete.setHost(this.customOverlayHost || this.hostRef);
	}
	getDisplayValue(value) {
		const displayFn = this.autocomplete.handleDisplayFn;
		return displayFn ? displayFn(value) : value;
	}
	getContainer() {
		return this.overlayRef && this.isOpen && { location: { nativeElement: this.overlayRef.overlayElement } };
	}
	handleInputValueUpdate(value, focusInput = false) {
		this.setHostInputValue(value ?? "");
		this._onChange(value);
		if (focusInput) this.hostRef.nativeElement.focus();
		this.autocomplete.emitSelected(value);
		this.hide();
	}
	subscribeOnTriggers() {
		this.triggerStrategy.show$.pipe(filter(() => this.isClosed)).subscribe(() => this.show());
		this.triggerStrategy.hide$.pipe(filter(() => this.isOpen)).subscribe(() => this.hide());
	}
	createTriggerStrategy() {
		return this.triggerStrategyBuilder.trigger(NbTrigger.FOCUS).host(this.hostRef.nativeElement).container(() => this.getContainer()).build();
	}
	createKeyManager() {
		this.keyManager = this.activeDescendantKeyManagerFactory.create(this.autocomplete.options);
	}
	setHostInputValue(value) {
		this.hostRef.nativeElement.value = this.getDisplayValue(value);
	}
	createPositionStrategy() {
		return this.positionBuilder.connectedTo(this.customOverlayHost || this.hostRef).position(NbPosition.BOTTOM).offset(this.overlayOffset).adjustment(NbAdjustment.VERTICAL);
	}
	subscribeOnOverlayKeys() {
		this.overlayRef.keydownEvents().pipe(takeUntil(this.destroy$)).subscribe((event) => {
			if (event.keyCode === keycodes_exports.ESCAPE && this.isOpen) {
				event.preventDefault();
				this.hostRef.nativeElement.focus();
				this.hide();
			} else if (event.keyCode === keycodes_exports.ENTER) {
				event.preventDefault();
				const activeItem = this.getActiveItem();
				if (!activeItem) return;
				this.handleInputValueUpdate(activeItem.value, true);
			} else this.keyManager.onKeydown(event);
		});
	}
	setActiveItem() {
		const mode = this.autocomplete.activeFirst ? NbKeyManagerActiveItemMode.FIRST_ACTIVE : NbKeyManagerActiveItemMode.RESET_ACTIVE;
		this.keyManager.setActiveItem(mode);
		this.cd.detectChanges();
	}
	attachToOverlay() {
		if (!this.overlayRef) {
			this.setupAutocomplete();
			this.initOverlay();
		}
		this.overlayRef.attach(this.autocomplete.portal);
	}
	createOverlay() {
		const scrollStrategy = this.createScrollStrategy();
		this.overlayRef = this.overlay.create({
			positionStrategy: this.positionStrategy,
			scrollStrategy,
			panelClass: this.autocomplete.optionsPanelClass
		});
	}
	initOverlay() {
		this.positionStrategy = this.createPositionStrategy();
		this.createKeyManager();
		this.subscribeOnPositionChange();
		this.subscribeOnOptionClick();
		this.checkOverlayVisibility();
		this.createOverlay();
		this.subscribeOnOverlayKeys();
	}
	checkOverlayVisibility() {
		this.autocomplete.options.changes.pipe(takeUntil(this.destroy$)).subscribe(() => {
			if (!this.autocomplete.options.length) this.hide();
		});
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies[this.scrollStrategy]();
	}
	shouldShow() {
		return this.isClosed;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAutocompleteDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: NbOverlayService },
				{ token: i0.ChangeDetectorRef },
				{ token: NbTriggerStrategyBuilderService },
				{ token: NbPositionBuilderService },
				{ token: NbActiveDescendantKeyManagerFactoryService },
				{ token: i0.Renderer2 }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbAutocompleteDirective,
			isStandalone: false,
			selector: "input[nbAutocomplete]",
			inputs: {
				autocomplete: ["nbAutocomplete", "autocomplete"],
				overlayOffset: "overlayOffset",
				scrollStrategy: "scrollStrategy",
				customOverlayHost: "customOverlayHost"
			},
			host: {
				listeners: {
					"input": "handleInput()",
					"keydown.arrowDown": "handleKeydown()",
					"keydown.arrowUp": "handleKeydown()",
					"blur": "handleBlur()"
				},
				properties: {
					"class.nb-autocomplete-position-top": "this.top",
					"class.nb-autocomplete-position-bottom": "this.bottom",
					"attr.role": "this.role",
					"attr.aria-autocomplete": "this.ariaAutocomplete",
					"attr.haspopup": "this.hasPopup",
					"attr.aria-expanded": "this.ariaExpanded",
					"attr.aria-owns": "this.ariaOwns",
					"attr.aria-activedescendant": "this.ariaActiveDescendant"
				}
			},
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbAutocompleteDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAutocompleteDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[nbAutocomplete]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbAutocompleteDirective),
				multi: true
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: NbOverlayService },
		{ type: i0.ChangeDetectorRef },
		{ type: NbTriggerStrategyBuilderService },
		{ type: NbPositionBuilderService },
		{ type: NbActiveDescendantKeyManagerFactoryService },
		{ type: i0.Renderer2 }
	],
	propDecorators: {
		autocomplete: [{
			type: Input,
			args: ["nbAutocomplete"]
		}],
		overlayOffset: [{ type: Input }],
		scrollStrategy: [{ type: Input }],
		customOverlayHost: [{ type: Input }],
		top: [{
			type: HostBinding,
			args: ["class.nb-autocomplete-position-top"]
		}],
		bottom: [{
			type: HostBinding,
			args: ["class.nb-autocomplete-position-bottom"]
		}],
		role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		ariaAutocomplete: [{
			type: HostBinding,
			args: ["attr.aria-autocomplete"]
		}],
		hasPopup: [{
			type: HostBinding,
			args: ["attr.haspopup"]
		}],
		ariaExpanded: [{
			type: HostBinding,
			args: ["attr.aria-expanded"]
		}],
		ariaOwns: [{
			type: HostBinding,
			args: ["attr.aria-owns"]
		}],
		ariaActiveDescendant: [{
			type: HostBinding,
			args: ["attr.aria-activedescendant"]
		}],
		handleInput: [{
			type: HostListener,
			args: ["input"]
		}],
		handleKeydown: [{
			type: HostListener,
			args: ["keydown.arrowDown"]
		}, {
			type: HostListener,
			args: ["keydown.arrowUp"]
		}],
		handleBlur: [{
			type: HostListener,
			args: ["blur"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_AUTOCOMPLETE_COMPONENTS = [NbAutocompleteComponent, NbAutocompleteDirective];
var NbAutocompleteModule = class NbAutocompleteModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAutocompleteModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAutocompleteModule,
			declarations: [NbAutocompleteComponent, NbAutocompleteDirective],
			imports: [
				CommonModule,
				FormsModule,
				NbOverlayModule,
				NbCardModule,
				NbOptionModule
			],
			exports: [
				NbAutocompleteComponent,
				NbAutocompleteDirective,
				NbOptionModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbAutocompleteModule,
			imports: [
				CommonModule,
				FormsModule,
				NbOverlayModule,
				NbCardModule,
				NbOptionModule,
				NbOptionModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbAutocompleteModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				FormsModule,
				NbOverlayModule,
				NbCardModule,
				NbOptionModule
			],
			exports: [...NB_AUTOCOMPLETE_COMPONENTS, NbOptionModule],
			declarations: [...NB_AUTOCOMPLETE_COMPONENTS]
		}]
	}]
});
var NbWindowState;
(function(NbWindowState) {
	NbWindowState["MINIMIZED"] = "minimized";
	NbWindowState["MAXIMIZED"] = "maximized";
	NbWindowState["FULL_SCREEN"] = "full-screen";
})(NbWindowState || (NbWindowState = {}));
const NB_WINDOW_DEFAULT_BUTTONS_CONFIG = {
	minimize: true,
	maximize: true,
	fullScreen: true,
	close: true
};
var NbWindowConfig = class {
	constructor(...configs) {
		this.title = "";
		this.titleTemplateContext = {};
		this.initialState = NbWindowState.FULL_SCREEN;
		this.hasBackdrop = true;
		this.closeOnBackdropClick = true;
		this.closeOnEsc = true;
		this.windowClass = "";
		this.context = {};
		this.viewContainerRef = null;
		this.buttons = {};
		Object.assign(this, ...configs);
		this.applyDefaultButtonConfig();
	}
	applyDefaultButtonConfig() {
		Object.assign(this, { buttons: {
			...NB_WINDOW_DEFAULT_BUTTONS_CONFIG,
			...this.buttons
		} });
	}
};
const NB_WINDOW_CONTENT = new InjectionToken("Nebular Window Content");
const NB_WINDOW_CONFIG = new InjectionToken("Nebular Window Config");
const NB_WINDOW_CONTEXT = new InjectionToken("Nebular Window Context");
var NbWindowRef = class {
	get state() {
		this.stateSignal();
		return this.stateValue;
	}
	set state(newState) {
		if (newState && this.state !== newState) {
			this.prevStateValue = this.state;
			this.stateValue = newState;
			this.stateSignal.set(newState);
			this.stateChange$.next({
				oldState: this.prevStateValue,
				newState
			});
		}
	}
	get stateChange() {
		return this.stateChange$.asObservable();
	}
	get onClose() {
		return this.closed$.asObservable();
	}
	constructor(config) {
		this.config = config;
		this.stateSignal = signal(void 0, ...ngDevMode ? [{ debugName: "stateSignal" }] : 		/* istanbul ignore next */ []);
		this.stateChange$ = new ReplaySubject(1);
		this._closed = false;
		this.closed$ = new Subject();
		this.state = config.initialState;
	}
	minimize() {
		this.state = NbWindowState.MINIMIZED;
	}
	maximize() {
		this.state = NbWindowState.MAXIMIZED;
	}
	fullScreen() {
		this.state = NbWindowState.FULL_SCREEN;
	}
	toPreviousState() {
		this.state = this.prevStateValue;
	}
	close(res) {
		if (this._closed) return;
		this._closed = true;
		this.componentRef.destroy();
		this.componentInstance = null;
		this.stateChange$.complete();
		this.closed$.next(res);
		this.closed$.complete();
	}
};
var NbWindowsContainerComponent = class NbWindowsContainerComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowsContainerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbWindowsContainerComponent,
			isStandalone: false,
			selector: "nb-windows-container",
			viewQueries: [{
				propertyName: "viewContainerRef",
				first: true,
				predicate: ["viewContainerRef"],
				descendants: true,
				read: ViewContainerRef,
				static: true
			}],
			ngImport: i0,
			template: `<ng-container #viewContainerRef></ng-container>`,
			isInline: true,
			styles: [":host{display:flex;align-items:flex-end;overflow-x:auto}:host ::ng-deep nb-window:not(.full-screen){margin:0 2rem}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbWindowsContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-windows-container",
			template: `<ng-container #viewContainerRef></ng-container>`,
			standalone: false,
			styles: [":host{display:flex;align-items:flex-end;overflow-x:auto}:host ::ng-deep nb-window:not(.full-screen){margin:0 2rem}\n"]
		}]
	}],
	propDecorators: { viewContainerRef: [{
		type: ViewChild,
		args: ["viewContainerRef", {
			read: ViewContainerRef,
			static: true
		}]
	}] }
});
var NbWindowComponent = class NbWindowComponent {
	get isFullScreen() {
		return this.windowRef.state === NbWindowState.FULL_SCREEN;
	}
	get maximized() {
		return this.windowRef.state === NbWindowState.MAXIMIZED;
	}
	get minimized() {
		return this.windowRef.state === NbWindowState.MINIMIZED;
	}
	get showMinimize() {
		return this.config.buttons.minimize;
	}
	get showMaximize() {
		return this.config.buttons.maximize;
	}
	get showFullScreen() {
		return this.config.buttons.fullScreen;
	}
	get showClose() {
		return this.config.buttons.close;
	}
	constructor(content, context, windowRef, config, focusTrapFactory, elementRef, renderer) {
		this.content = content;
		this.context = context;
		this.windowRef = windowRef;
		this.config = config;
		this.focusTrapFactory = focusTrapFactory;
		this.elementRef = elementRef;
		this.renderer = renderer;
	}
	ngOnInit() {
		this.focusTrap = this.focusTrapFactory.create(this.elementRef.nativeElement);
		this.focusTrap.blurPreviouslyFocusedElement();
		this.focusTrap.focusInitialElement();
		if (this.config.windowClass) this.renderer.addClass(this.elementRef.nativeElement, this.config.windowClass);
	}
	ngAfterViewChecked() {
		if (!this.overlayContainer || this.overlayContainer.isAttached) return;
		if (this.content instanceof TemplateRef) this.attachTemplate();
		else this.attachComponent();
	}
	ngOnDestroy() {
		if (this.focusTrap) this.focusTrap.restoreFocus();
		this.close();
	}
	minimize() {
		if (this.windowRef.state === NbWindowState.MINIMIZED) this.windowRef.toPreviousState();
		else this.windowRef.minimize();
	}
	maximize() {
		this.windowRef.maximize();
	}
	fullScreen() {
		this.windowRef.fullScreen();
	}
	maximizeOrFullScreen() {
		if (this.windowRef.state === NbWindowState.MINIMIZED && this.showMaximize) this.maximize();
		else this.fullScreen();
	}
	close() {
		this.windowRef.close();
	}
	attachTemplate() {
		this.overlayContainer.attachTemplatePortal(new NbTemplatePortal(this.content, null, this.context));
	}
	attachComponent() {
		const portal = new NbComponentPortal(this.content, null, null);
		const ref = this.overlayContainer.attachComponentPortal(portal, this.context);
		this.windowRef.componentInstance = ref.instance;
		ref.changeDetectorRef.detectChanges();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowComponent,
			deps: [
				{ token: NB_WINDOW_CONTENT },
				{ token: NB_WINDOW_CONTEXT },
				{ token: NbWindowRef },
				{ token: NbWindowConfig },
				{ token: NbFocusTrapFactoryService },
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbWindowComponent,
			isStandalone: false,
			selector: "nb-window",
			host: { properties: {
				"class.full-screen": "this.isFullScreen",
				"class.maximized": "this.maximized",
				"class.minimized": "this.minimized"
			} },
			viewQueries: [{
				propertyName: "overlayContainer",
				first: true,
				predicate: NbOverlayContainerComponent,
				descendants: true
			}],
			ngImport: i0,
			template: `
    <nb-card>
      <nb-card-header>
        <div *ngIf="config.titleTemplate; else textTitleTemplate" cdkFocusInitial tabindex="-1">
          <ng-container
            *ngTemplateOutlet="config.titleTemplate; context: { $implicit: config.titleTemplateContext }"
          ></ng-container>
        </div>

        <ng-template #textTitleTemplate>
          <div cdkFocusInitial class="title" tabindex="-1">{{ config.title }}</div>
        </ng-template>

        <div class="buttons">
          <ng-container *ngIf="showMinimize">
            <button nbButton ghost (click)="minimize()">
              <nb-icon icon="minus-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showMaximize">
            <button nbButton ghost *ngIf="isFullScreen" (click)="maximize()">
              <nb-icon icon="collapse-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showFullScreen">
            <button nbButton ghost *ngIf="minimized || maximized" (click)="maximizeOrFullScreen()">
              <nb-icon icon="expand-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showClose">
            <button nbButton ghost (click)="close()">
              <nb-icon icon="close-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>
        </div>
      </nb-card-header>
      <nb-card-body *ngIf="maximized || isFullScreen">
        <nb-overlay-container></nb-overlay-container>
      </nb-card-body>
    </nb-card>
  `,
			isInline: true,
			styles: [":host{flex:1 0 auto;min-width:20rem}:host nb-card{margin:0}:host nb-card-header{display:flex;justify-content:space-between;align-items:center;overflow:hidden}:host .title{flex:1 0 auto;margin-right:3rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host .buttons{width:9.5rem;display:flex;justify-content:flex-end}:host .buttons [nbButton]{flex:0 0 3rem}:host(.full-screen){position:fixed;top:50%;left:50%;transform:translate(-50%,-50%)}:host(.maximized) nb-card{border-bottom-left-radius:0;border-bottom-right-radius:0}:host(.minimized) nb-card{border-bottom-left-radius:0;border-bottom-right-radius:0;height:auto}:host(.minimized) nb-card nb-card-header{border-bottom:none}\n"],
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "component",
					type: NbOverlayContainerComponent,
					selector: "nb-overlay-container"
				},
				{
					kind: "component",
					type: NbCardComponent,
					selector: "nb-card",
					inputs: [
						"size",
						"status",
						"accent"
					]
				},
				{
					kind: "component",
					type: NbCardBodyComponent,
					selector: "nb-card-body"
				},
				{
					kind: "component",
					type: NbCardHeaderComponent,
					selector: "nb-card-header"
				},
				{
					kind: "component",
					type: NbIconComponent,
					selector: "nb-icon",
					inputs: [
						"icon",
						"pack",
						"options",
						"status",
						"config"
					]
				},
				{
					kind: "component",
					type: NbButtonComponent,
					selector: "button[nbButton],a[nbButton],input[type=\"button\"][nbButton],input[type=\"submit\"][nbButton]",
					inputs: ["hero"]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbWindowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-window",
			template: `
    <nb-card>
      <nb-card-header>
        <div *ngIf="config.titleTemplate; else textTitleTemplate" cdkFocusInitial tabindex="-1">
          <ng-container
            *ngTemplateOutlet="config.titleTemplate; context: { $implicit: config.titleTemplateContext }"
          ></ng-container>
        </div>

        <ng-template #textTitleTemplate>
          <div cdkFocusInitial class="title" tabindex="-1">{{ config.title }}</div>
        </ng-template>

        <div class="buttons">
          <ng-container *ngIf="showMinimize">
            <button nbButton ghost (click)="minimize()">
              <nb-icon icon="minus-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showMaximize">
            <button nbButton ghost *ngIf="isFullScreen" (click)="maximize()">
              <nb-icon icon="collapse-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showFullScreen">
            <button nbButton ghost *ngIf="minimized || maximized" (click)="maximizeOrFullScreen()">
              <nb-icon icon="expand-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>

          <ng-container *ngIf="showClose">
            <button nbButton ghost (click)="close()">
              <nb-icon icon="close-outline" pack="nebular-essentials"></nb-icon>
            </button>
          </ng-container>
        </div>
      </nb-card-header>
      <nb-card-body *ngIf="maximized || isFullScreen">
        <nb-overlay-container></nb-overlay-container>
      </nb-card-body>
    </nb-card>
  `,
			standalone: false,
			styles: [":host{flex:1 0 auto;min-width:20rem}:host nb-card{margin:0}:host nb-card-header{display:flex;justify-content:space-between;align-items:center;overflow:hidden}:host .title{flex:1 0 auto;margin-right:3rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host .buttons{width:9.5rem;display:flex;justify-content:flex-end}:host .buttons [nbButton]{flex:0 0 3rem}:host(.full-screen){position:fixed;top:50%;left:50%;transform:translate(-50%,-50%)}:host(.maximized) nb-card{border-bottom-left-radius:0;border-bottom-right-radius:0}:host(.minimized) nb-card{border-bottom-left-radius:0;border-bottom-right-radius:0;height:auto}:host(.minimized) nb-card nb-card-header{border-bottom:none}\n"]
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW_CONTENT]
			}]
		},
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW_CONTEXT]
			}]
		},
		{ type: NbWindowRef },
		{ type: NbWindowConfig },
		{ type: NbFocusTrapFactoryService },
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 }
	],
	propDecorators: {
		isFullScreen: [{
			type: HostBinding,
			args: ["class.full-screen"]
		}],
		maximized: [{
			type: HostBinding,
			args: ["class.maximized"]
		}],
		minimized: [{
			type: HostBinding,
			args: ["class.minimized"]
		}],
		overlayContainer: [{
			type: ViewChild,
			args: [NbOverlayContainerComponent]
		}]
	}
});
var NbWindowService = class NbWindowService {
	constructor(overlayService, overlayPositionBuilder, blockScrollStrategy, defaultWindowsConfig, document) {
		this.overlayService = overlayService;
		this.overlayPositionBuilder = overlayPositionBuilder;
		this.blockScrollStrategy = blockScrollStrategy;
		this.defaultWindowsConfig = defaultWindowsConfig;
		this.openWindows = [];
		this.document = document;
	}
	open(windowContent, windowConfig = {}) {
		if (this.shouldCreateWindowsContainer()) this.createWindowsContainer();
		const config = new NbWindowConfig(this.defaultWindowsConfig, windowConfig);
		const windowRef = new NbWindowRef(config);
		windowRef.componentRef = this.appendWindow(windowContent, config, windowRef);
		this.openWindows.push(windowRef);
		this.subscribeToEvents(windowRef);
		return windowRef;
	}
	shouldCreateWindowsContainer() {
		if (this.windowsContainerViewRef) {
			const containerEl = this.windowsContainerViewRef.element.nativeElement;
			return !this.document.body.contains(containerEl);
		}
		return true;
	}
	createWindowsContainer() {
		if (this.overlayRef) this.overlayRef.dispose();
		this.overlayRef = this.overlayService.create({
			scrollStrategy: this.overlayService.scrollStrategies.noop(),
			positionStrategy: this.overlayPositionBuilder.global().bottom().right(),
			hasBackdrop: true
		});
		const windowsContainerPortal = new NbComponentPortal(NbWindowsContainerComponent, null, null);
		const overlayRef = this.overlayRef.attach(windowsContainerPortal);
		this.windowsContainerViewRef = overlayRef.instance.viewContainerRef;
	}
	appendWindow(content, config, windowRef) {
		const context = content instanceof TemplateRef ? {
			$implicit: config.context,
			windowRef
		} : config.context;
		const providers = [
			{
				provide: NB_WINDOW_CONTENT,
				useValue: content
			},
			{
				provide: NB_WINDOW_CONTEXT,
				useValue: context
			},
			{
				provide: NbWindowConfig,
				useValue: config
			},
			{
				provide: NbWindowRef,
				useValue: windowRef
			}
		];
		const parentInjector = config.viewContainerRef ? config.viewContainerRef.injector : this.windowsContainerViewRef.injector;
		const injector = Injector.create({
			parent: parentInjector,
			providers
		});
		const ref = this.windowsContainerViewRef.createComponent(NbWindowComponent, {
			injector,
			index: this.windowsContainerViewRef.length
		});
		ref.changeDetectorRef.detectChanges();
		return ref;
	}
	subscribeToEvents(windowRef) {
		if (windowRef.config.closeOnBackdropClick) this.overlayRef.backdropClick().subscribe(() => windowRef.close());
		if (windowRef.config.closeOnEsc) this.overlayRef.keydownEvents().pipe(filter((event) => event.keyCode === 27)).subscribe(() => windowRef.close());
		windowRef.stateChange.subscribe(() => this.checkAndUpdateOverlay());
		windowRef.onClose.subscribe(() => {
			this.openWindows.splice(this.openWindows.indexOf(windowRef), 1);
			this.checkAndUpdateOverlay();
		});
	}
	checkAndUpdateOverlay() {
		const fullScreenWindows = this.openWindows.filter((w) => w.state === NbWindowState.FULL_SCREEN);
		if (fullScreenWindows.length > 0) this.blockScrollStrategy.enable();
		else this.blockScrollStrategy.disable();
		if (fullScreenWindows.some((w) => w.config.hasBackdrop)) this.overlayRef.backdropElement.removeAttribute("hidden");
		else this.overlayRef.backdropElement.setAttribute("hidden", "");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowService,
			deps: [
				{ token: NbOverlayService },
				{ token: NbOverlayPositionBuilder },
				{ token: NbBlockScrollStrategyAdapter },
				{ token: NB_WINDOW_CONFIG },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbWindowService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbOverlayService },
		{ type: NbOverlayPositionBuilder },
		{ type: NbBlockScrollStrategyAdapter },
		{
			type: NbWindowConfig,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW_CONFIG]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	]
});
var NbWindowModule = class NbWindowModule {
	static forRoot(defaultConfig) {
		return {
			ngModule: NbWindowModule,
			providers: [NbWindowService, {
				provide: NB_WINDOW_CONFIG,
				useValue: defaultConfig
			}]
		};
	}
	static forChild(defaultConfig) {
		return {
			ngModule: NbWindowModule,
			providers: [NbWindowService, {
				provide: NB_WINDOW_CONFIG,
				useValue: defaultConfig
			}]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowModule,
			declarations: [NbWindowsContainerComponent, NbWindowComponent],
			imports: [
				CommonModule,
				NbOverlayModule,
				NbCardModule,
				NbIconModule,
				NbButtonModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbWindowModule,
			imports: [
				CommonModule,
				NbOverlayModule,
				NbCardModule,
				NbIconModule,
				NbButtonModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbWindowModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				NbOverlayModule,
				NbCardModule,
				NbIconModule,
				NbButtonModule
			],
			declarations: [NbWindowsContainerComponent, NbWindowComponent]
		}]
	}]
});
var NbTimePickerDirective = class NbTimePickerDirective {
	get timepicker() {
		return this._timePickerComponent;
	}
	set timepicker(timePicker) {
		this._timePickerComponent = timePicker;
		this.pickerInputsChangedSubscription?.unsubscribe();
		this.pickerInputsChangedSubscription = this._timePickerComponent.timepickerFormatChange$.pipe(map(() => this._timePickerComponent.computedTimeFormat), startWith(this._timePickerComponent.computedTimeFormat), distinctUntilChanged(), pairwise(), takeUntil(this.destroy$)).subscribe(([prevFormat, nextFormat]) => {
			if (this.inputValue) {
				const date = this.dateService.parse(this.inputValue, prevFormat);
				this.writeValue(date);
			}
		});
	}
	get input() {
		return this.hostRef.nativeElement;
	}
	get isOpen() {
		return this.overlayRef && this.overlayRef.hasAttached();
	}
	get isClosed() {
		return !this.isOpen;
	}
	constructor(document, positionBuilder, hostRef, triggerStrategyBuilder, overlay, cd, calendarTimeModelService, dateService, renderer, placeholder) {
		this.document = document;
		this.positionBuilder = positionBuilder;
		this.hostRef = hostRef;
		this.triggerStrategyBuilder = triggerStrategyBuilder;
		this.overlay = overlay;
		this.cd = cd;
		this.calendarTimeModelService = calendarTimeModelService;
		this.dateService = dateService;
		this.renderer = renderer;
		this.placeholder = placeholder;
		this.overlayOffset = 8;
		this.destroy$ = new Subject();
		this.onChange = () => {};
		this.onTouched = () => {};
	}
	get inputValue() {
		return this.input.value;
	}
	set inputValue(value) {
		this.input.value = value;
	}
	ngAfterViewInit() {
		this.subscribeOnInputChange();
		if (!this.placeholder) this.renderer.setProperty(this.input, "placeholder", this.timepicker.computedTimeFormat);
		this.triggerStrategy = this.createTriggerStrategy();
		this.subscribeOnTriggers();
		this.subscribeToBlur();
	}
	show() {
		if (this.isClosed) this.attachToOverlay();
	}
	hide() {
		if (this.isOpen) {
			this.overlayRef.detach();
			this.cd.markForCheck();
		}
	}
	attachToOverlay() {
		if (!this.overlayRef) {
			this.setupTimepicker();
			this.initOverlay();
		}
		this.overlayRef.attach(this.timepicker.portal);
	}
	setupTimepicker() {
		if (this.dateService.getId() === "native" && isDevMode()) console.warn("Date.parse does not support parsing time with custom format. See details here https://akveo.github.io/nebular/docs/components/datepicker/overview#native-parse-issue");
		this.timepicker.setHost(this.hostRef);
		if (this.inputValue) {
			const val = this.dateService.getId() === "native" ? this.parseNativeDateString(this.inputValue) : this.inputValue;
			this.timepicker.date = this.dateService.parse(val, this.timepicker.computedTimeFormat);
		} else this.timepicker.date = this.calendarTimeModelService.getResetTime();
	}
	initOverlay() {
		this.positionStrategy = this.createPositionStrategy();
		this.subscribeOnApplyClick();
		this.createOverlay();
	}
	subscribeOnApplyClick() {
		this.timepicker.onSelectTime.pipe(takeUntil(this.destroy$)).subscribe((value) => {
			const time = this.dateService.format(value.time, this.timepicker.computedTimeFormat).toUpperCase();
			this.inputValue = time;
			this.timepicker.date = value.time;
			this.onChange(value.time);
			if (value.save) {
				this.lastInputValue = time;
				this.hide();
			}
		});
	}
	createOverlay() {
		const scrollStrategy = this.createScrollStrategy();
		this.overlayRef = this.overlay.create({
			positionStrategy: this.positionStrategy,
			scrollStrategy
		});
	}
	subscribeOnTriggers() {
		this.triggerStrategy.show$.pipe(filter(() => this.isClosed)).subscribe(() => this.show());
		this.triggerStrategy.hide$.pipe(filter(() => this.isOpen)).subscribe(() => {
			this.inputValue = this.lastInputValue || "";
			this.hide();
		});
	}
	createTriggerStrategy() {
		return this.triggerStrategyBuilder.trigger(NbTrigger.FOCUS).host(this.hostRef.nativeElement).container(() => this.getContainer()).build();
	}
	createPositionStrategy() {
		return this.positionBuilder.connectedTo(this.hostRef).position(NbPosition.BOTTOM).offset(this.overlayOffset).adjustment(NbAdjustment.COUNTERCLOCKWISE);
	}
	getContainer() {
		return this.overlayRef && this.isOpen && { location: { nativeElement: this.overlayRef.overlayElement } };
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.block();
	}
	subscribeOnInputChange() {
		fromEvent(this.input, "input").pipe(map(() => this.inputValue), takeUntil(this.destroy$)).subscribe((value) => this.handleInputChange(value));
	}
	subscribeToBlur() {
		merge(this.timepicker.blur, fromEvent(this.input, "blur").pipe(filter(() => !this.isOpen && this.document.activeElement !== this.input))).pipe(takeUntil(this.destroy$)).subscribe(() => this.onTouched());
	}
	handleInputChange(value) {
		if (this.dateService.getId() === "native") value = this.parseNativeDateString(value);
		if (this.dateService.isValidDateString(value, this.timepicker.computedTimeFormat)) {
			this.lastInputValue = value;
			const date = this.dateService.parse(value, this.timepicker.computedTimeFormat);
			this.onChange(date);
			this.timepicker.date = date;
		}
	}
	updateValue(value) {
		if (value) {
			this.timepicker.date = value;
			const timeString = this.dateService.format(value, this.timepicker.computedTimeFormat).toUpperCase();
			this.inputValue = timeString;
			this.lastInputValue = timeString;
		}
	}
	writeValue(value) {
		this.updateValue(value);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.input.disabled = isDisabled;
	}
	parseNativeDateString(value) {
		const date = this.dateService.today();
		return `${this.dateService.getYear(date)}-${this.calendarTimeModelService.paddToTwoSymbols(this.dateService.getMonth(date))}-${this.calendarTimeModelService.paddToTwoSymbols(this.dateService.getDate(date))} ${value}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimePickerDirective,
			deps: [
				{ token: NB_DOCUMENT },
				{ token: NbPositionBuilderService },
				{ token: i0.ElementRef },
				{ token: NbTriggerStrategyBuilderService },
				{ token: NbOverlayService },
				{ token: i0.ChangeDetectorRef },
				{ token: NbCalendarTimeModelService },
				{ token: NbDateService },
				{ token: i0.Renderer2 },
				{
					token: "placeholder",
					attribute: true
				}
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTimePickerDirective,
			isStandalone: false,
			selector: "input[nbTimepicker]",
			inputs: {
				timepicker: ["nbTimepicker", "timepicker"],
				overlayOffset: "overlayOffset"
			},
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbTimePickerDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTimePickerDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[nbTimepicker]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbTimePickerDirective),
				multi: true
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		},
		{ type: NbPositionBuilderService },
		{ type: i0.ElementRef },
		{ type: NbTriggerStrategyBuilderService },
		{ type: NbOverlayService },
		{ type: i0.ChangeDetectorRef },
		{ type: NbCalendarTimeModelService },
		{ type: NbDateService },
		{ type: i0.Renderer2 },
		{
			type: void 0,
			decorators: [{
				type: Attribute,
				args: ["placeholder"]
			}]
		}
	],
	propDecorators: {
		timepicker: [{
			type: Input,
			args: ["nbTimepicker"]
		}],
		overlayOffset: [{ type: Input }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTimepickerModule = class NbTimepickerModule {
	static forRoot(config = {}) {
		return {
			ngModule: NbTimepickerModule,
			providers: [{
				provide: NB_TIME_PICKER_CONFIG,
				useValue: config
			}]
		};
	}
	static forChild(config = {}) {
		return {
			ngModule: NbTimepickerModule,
			providers: [{
				provide: NB_TIME_PICKER_CONFIG,
				useValue: config
			}]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimepickerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimepickerModule,
			declarations: [
				NbTimePickerComponent,
				NbTimePickerCellComponent,
				NbTimePickerDirective
			],
			imports: [
				CommonModule,
				NbOverlayModule,
				NbListModule,
				NbCardModule,
				NbCalendarKitModule
			],
			exports: [
				NbTimePickerComponent,
				NbTimePickerCellComponent,
				NbTimePickerDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTimepickerModule,
			providers: [NbCalendarTimeModelService],
			imports: [
				CommonModule,
				NbOverlayModule,
				NbListModule,
				NbCardModule,
				NbCalendarKitModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTimepickerModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				NbOverlayModule,
				NbListModule,
				NbCardModule,
				NbCalendarKitModule
			],
			providers: [NbCalendarTimeModelService],
			exports: [
				NbTimePickerComponent,
				NbTimePickerCellComponent,
				NbTimePickerDirective
			],
			declarations: [
				NbTimePickerComponent,
				NbTimePickerCellComponent,
				NbTimePickerDirective
			]
		}]
	}]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDateAdapterService = class NbDateAdapterService extends NbDatepickerAdapter {
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.picker = NbDatepickerComponent;
	}
	parse(date, format) {
		return this.dateService.parse(date, format);
	}
	format(date, format) {
		return this.dateService.format(date, format);
	}
	isValid(date, format) {
		return this.dateService.isValidDateString(date, format);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDateAdapterService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDateAdapterService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDateAdapterService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
var NbRangeAdapterService = class NbRangeAdapterService extends NbDatepickerAdapter {
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.picker = NbRangepickerComponent;
	}
	parse(range, format) {
		const [start, end] = range.split("-").map((subDate) => subDate.trim());
		return {
			start: this.dateService.parse(start, format),
			end: this.dateService.parse(end, format)
		};
	}
	format(range, format) {
		if (!range) return "";
		const start = this.dateService.format(range.start, format);
		if (!this.dateService.isValidDateString(start, format)) return "";
		const end = this.dateService.format(range.end, format);
		if (this.dateService.isValidDateString(end, format)) return `${start} - ${end}`;
		else return start;
	}
	isValid(range, format) {
		const [start, end] = range.split("-").map((subDate) => subDate.trim());
		return this.dateService.isValidDateString(start, format) && this.dateService.isValidDateString(end, format);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRangeAdapterService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRangeAdapterService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRangeAdapterService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
var NbDateTimeAdapterService = class NbDateTimeAdapterService extends NbDatepickerAdapter {
	constructor(dateService) {
		super();
		this.dateService = dateService;
		this.picker = NbDateTimePickerComponent;
	}
	parse(date, format) {
		return this.dateService.parse(date, format);
	}
	format(date, format) {
		return this.dateService.format(date, format);
	}
	isValid(date, format) {
		return this.dateService.isValidDateString(date, format);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDateTimeAdapterService,
			deps: [{ token: NbDateService }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDateTimeAdapterService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDateTimeAdapterService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: NbDateService }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbDatepickerModule = class NbDatepickerModule {
	static forRoot() {
		return {
			ngModule: NbDatepickerModule,
			providers: [
				DatePipe,
				{
					provide: NB_DATE_ADAPTER,
					multi: true,
					useClass: NbDateAdapterService
				},
				{
					provide: NB_DATE_ADAPTER,
					multi: true,
					useClass: NbRangeAdapterService
				},
				{
					provide: NB_DATE_ADAPTER,
					multi: true,
					useClass: NbDateTimeAdapterService
				}
			]
		};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerModule,
			declarations: [
				NbDatepickerDirective,
				NbDatepickerContainerComponent,
				NbCalendarWithTimeComponent,
				NbDateTimePickerComponent,
				NbDatepickerComponent,
				NbRangepickerComponent,
				NbBasePickerComponent
			],
			imports: [
				NbOverlayModule,
				NbCalendarModule,
				NbCalendarRangeModule,
				NbCardModule,
				NbBaseCalendarModule,
				NbTimepickerModule,
				NbCalendarKitModule
			],
			exports: [
				NbDatepickerDirective,
				NbDatepickerComponent,
				NbRangepickerComponent,
				NbDateTimePickerComponent,
				NbCalendarWithTimeComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbDatepickerModule,
			imports: [
				NbOverlayModule,
				NbCalendarModule,
				NbCalendarRangeModule,
				NbCardModule,
				NbBaseCalendarModule,
				NbTimepickerModule,
				NbCalendarKitModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbDatepickerModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				NbOverlayModule,
				NbCalendarModule,
				NbCalendarRangeModule,
				NbCardModule,
				NbBaseCalendarModule,
				NbTimepickerModule,
				NbCalendarKitModule
			],
			exports: [
				NbDatepickerDirective,
				NbDatepickerComponent,
				NbRangepickerComponent,
				NbDateTimePickerComponent,
				NbCalendarWithTimeComponent
			],
			declarations: [
				NbDatepickerDirective,
				NbDatepickerContainerComponent,
				NbCalendarWithTimeComponent,
				NbDateTimePickerComponent,
				NbDatepickerComponent,
				NbRangepickerComponent,
				NbBasePickerComponent
			]
		}]
	}]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRadioComponent = class NbRadioComponent {
	get name() {
		return this._name;
	}
	set name(value) {
		if (this._name !== value) this._name = value;
	}
	get checked() {
		return this._checked;
	}
	set checked(value) {
		const boolValue = convertToBoolProperty(value);
		if (this._checked !== boolValue) this._checked = boolValue;
	}
	get value() {
		return this._value;
	}
	set value(value) {
		if (this._value !== value) this._value = value;
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(disabled) {
		const boolValue = convertToBoolProperty(disabled);
		if (this._disabled !== boolValue) this._disabled = boolValue;
	}
	constructor(cd, renderer, statusService) {
		this.cd = cd;
		this.renderer = renderer;
		this.statusService = statusService;
		this._checked = false;
		this._disabled = false;
		this.status = "basic";
		this.valueChange = new EventEmitter();
		this.blur = new EventEmitter();
	}
	get isPrimary() {
		return this.status === "primary";
	}
	get isSuccess() {
		return this.status === "success";
	}
	get isWarning() {
		return this.status === "warning";
	}
	get isDanger() {
		return this.status === "danger";
	}
	get isInfo() {
		return this.status === "info";
	}
	get isBasic() {
		return this.status === "basic";
	}
	get isControl() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	onChange(event) {
		event.stopPropagation();
		this.checked = true;
		this.valueChange.emit(this.value);
	}
	onClick(event) {
		event.stopPropagation();
	}
	_markForCheck() {
		this.cd.markForCheck();
	}
	_setName(name) {
		this.name = name;
		if (this.input) this.renderer.setProperty(this.input.nativeElement, "name", name);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRadioComponent,
			deps: [
				{ token: i0.ChangeDetectorRef },
				{ token: i0.Renderer2 },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRadioComponent,
			isStandalone: false,
			selector: "nb-radio",
			inputs: {
				name: "name",
				checked: "checked",
				value: "value",
				disabled: "disabled",
				status: "status"
			},
			outputs: {
				valueChange: "valueChange",
				blur: "blur"
			},
			host: { properties: {
				"class.status-primary": "this.isPrimary",
				"class.status-success": "this.isSuccess",
				"class.status-warning": "this.isWarning",
				"class.status-danger": "this.isDanger",
				"class.status-info": "this.isInfo",
				"class.status-basic": "this.isBasic",
				"class.status-control": "this.isControl",
				"class": "this.additionalClasses"
			} },
			viewQueries: [{
				propertyName: "input",
				first: true,
				predicate: ["input"],
				descendants: true,
				read: ElementRef
			}],
			ngImport: i0,
			template: `
    <label>
      <input
        #input
        type="radio"
        class="native-input visually-hidden"
        [name]="name"
        [value]="value"
        [checked]="checked"
        [disabled]="disabled"
        (change)="onChange($event)"
        (click)="onClick($event)">
      <span class="outer-circle"></span>
      <span class="inner-circle"></span>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			isInline: true,
			styles: [":host{display:block;position:relative}:host label{display:inline-flex;margin:0;min-height:inherit;padding:.375rem 0}[dir=ltr] :host label{padding-right:1.5rem}[dir=rtl] :host label{padding-left:1.5rem}:host label{align-items:center}:host .outer-circle,:host .inner-circle{border-radius:50%;position:absolute;top:50%}[dir=ltr] :host .outer-circle,[dir=ltr] :host .inner-circle{left:0}[dir=rtl] :host .outer-circle,[dir=rtl] :host .inner-circle{right:0}:host .outer-circle,:host .inner-circle{transform:translateY(-50%)}:host .inner-circle{transform:translateY(-50%) scale(.6)}[dir=ltr] :host .text{padding-left:.5rem}[dir=rtl] :host .text{padding-right:.5rem}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRadioComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-radio",
			template: `
    <label>
      <input
        #input
        type="radio"
        class="native-input visually-hidden"
        [name]="name"
        [value]="value"
        [checked]="checked"
        [disabled]="disabled"
        (change)="onChange($event)"
        (click)="onClick($event)">
      <span class="outer-circle"></span>
      <span class="inner-circle"></span>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:block;position:relative}:host label{display:inline-flex;margin:0;min-height:inherit;padding:.375rem 0}[dir=ltr] :host label{padding-right:1.5rem}[dir=rtl] :host label{padding-left:1.5rem}:host label{align-items:center}:host .outer-circle,:host .inner-circle{border-radius:50%;position:absolute;top:50%}[dir=ltr] :host .outer-circle,[dir=ltr] :host .inner-circle{left:0}[dir=rtl] :host .outer-circle,[dir=rtl] :host .inner-circle{right:0}:host .outer-circle,:host .inner-circle{transform:translateY(-50%)}:host .inner-circle{transform:translateY(-50%) scale(.6)}[dir=ltr] :host .text{padding-left:.5rem}[dir=rtl] :host .text{padding-right:.5rem}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ChangeDetectorRef },
		{ type: i0.Renderer2 },
		{ type: NbStatusService }
	],
	propDecorators: {
		name: [{ type: Input }],
		checked: [{ type: Input }],
		value: [{ type: Input }],
		disabled: [{ type: Input }],
		status: [{ type: Input }],
		valueChange: [{ type: Output }],
		blur: [{ type: Output }],
		input: [{
			type: ViewChild,
			args: ["input", { read: ElementRef }]
		}],
		isPrimary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		isSuccess: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		isWarning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		isDanger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		isInfo: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		isBasic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		isControl: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRadioGroupComponent = class NbRadioGroupComponent {
	get value() {
		return this._value;
	}
	set value(value) {
		this._value = value;
		this.updateValues();
	}
	get name() {
		return this._name;
	}
	set name(name) {
		this._name = name;
		this.updateNames();
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(disabled) {
		this._disabled = convertToBoolProperty(disabled);
		this.updateDisabled();
	}
	get status() {
		return this._status;
	}
	set status(value) {
		if (this._status !== value) {
			this._status = value;
			this.updateStatus();
		}
	}
	constructor(hostElement, platformId, document) {
		this.hostElement = hostElement;
		this.platformId = platformId;
		this.document = document;
		this.destroy$ = new Subject();
		this.onChange = (value) => {};
		this.onTouched = () => {};
		this._status = "basic";
		this.valueChange = new EventEmitter();
	}
	ngAfterContentInit() {
		this.updateNames();
		this.radios.changes.pipe(startWith(this.radios), switchMap((radios) => from(Promise.resolve(radios))), takeUntil(this.destroy$)).subscribe(() => this.updateAndSubscribeToRadios());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	writeValue(value) {
		this.value = value;
	}
	setDisabledState(isDisabled) {
		this.disabled = isDisabled;
	}
	updateAndSubscribeToRadios() {
		this.updateValueFromCheckedOption();
		this.updateNames();
		this.updateValues();
		this.updateDisabled();
		this.updateStatus();
		this.subscribeOnRadiosValueChange();
		this.subscribeOnRadiosBlur();
	}
	updateNames() {
		if (this.radios) this.radios.forEach((radio) => radio._setName(this.name));
	}
	updateValues() {
		this.updateAndMarkForCheckRadios((radio) => radio.checked = radio.value === this.value);
	}
	updateDisabled() {
		if (typeof this.disabled !== "undefined") this.updateAndMarkForCheckRadios((radio) => radio.disabled = this.disabled);
	}
	subscribeOnRadiosValueChange() {
		if (!this.radios || !this.radios.length) return;
		merge(...this.radios.map((radio) => radio.valueChange)).pipe(takeUntil(merge(this.radios.changes, this.destroy$))).subscribe((value) => {
			this.writeValue(value);
			this.propagateValue(value);
		});
	}
	propagateValue(value) {
		this.valueChange.emit(value);
		this.onChange(value);
	}
	subscribeOnRadiosBlur() {
		const hasNoRadios = !this.radios || !this.radios.length;
		if (!isPlatformBrowser(this.platformId) || hasNoRadios) return;
		const hostElement = this.hostElement.nativeElement;
		fromEvent(hostElement, "focusin").pipe(filter((event) => hostElement.contains(event.target)), switchMap(() => merge(fromEvent(this.document, "focusin"), fromEvent(this.document, "click"))), filter((event) => !hostElement.contains(event.target)), takeUntil(merge(this.radios.changes, this.destroy$))).subscribe(() => this.onTouched());
	}
	updateStatus() {
		this.updateAndMarkForCheckRadios((radio) => radio.status = this.status);
	}
	updateAndMarkForCheckRadios(updateFn) {
		if (this.radios) this.radios.forEach((radio) => {
			updateFn(radio);
			radio._markForCheck();
		});
	}
	updateValueFromCheckedOption() {
		const checkedRadio = this.radios.find((radio) => radio.checked);
		const isValueMissing = this.value === void 0 || this.value === null;
		if (checkedRadio && isValueMissing && checkedRadio.value !== this.value) this.value = checkedRadio.value;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRadioGroupComponent,
			deps: [
				{ token: i0.ElementRef },
				{ token: PLATFORM_ID },
				{ token: NB_DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbRadioGroupComponent,
			isStandalone: false,
			selector: "nb-radio-group",
			inputs: {
				value: "value",
				name: "name",
				disabled: "disabled",
				status: "status"
			},
			outputs: { valueChange: "valueChange" },
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbRadioGroupComponent),
				multi: true
			}],
			queries: [{
				propertyName: "radios",
				predicate: NbRadioComponent,
				descendants: true
			}],
			ngImport: i0,
			template: `
    <ng-content select="nb-radio"></ng-content>`,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRadioGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-radio-group",
			template: `
    <ng-content select="nb-radio"></ng-content>`,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbRadioGroupComponent),
				multi: true
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_DOCUMENT]
			}]
		}
	],
	propDecorators: {
		value: [{ type: Input }],
		name: [{ type: Input }],
		disabled: [{ type: Input }],
		status: [{ type: Input }],
		radios: [{
			type: ContentChildren,
			args: [NbRadioComponent, { descendants: true }]
		}],
		valueChange: [{ type: Output }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbRadioModule = class NbRadioModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRadioModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRadioModule,
			declarations: [NbRadioComponent, NbRadioGroupComponent],
			exports: [NbRadioComponent, NbRadioGroupComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbRadioModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbRadioModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [],
			exports: [NbRadioComponent, NbRadioGroupComponent],
			declarations: [NbRadioComponent, NbRadioGroupComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
let tagUniqueId = 0;
var NbTagComponent = class NbTagComponent {
	get destroy$() {
		return this._destroy$.asObservable();
	}
	get selected() {
		return this._selected;
	}
	set selected(value) {
		if (this.selected !== convertToBoolProperty(value)) {
			this._selected = !this.selected;
			this.selectedChange.emit({
				tag: this,
				selected: this.selected
			});
		}
	}
	get removable() {
		return this._removable;
	}
	set removable(value) {
		this._removable = convertToBoolProperty(value);
	}
	get filled() {
		return this.appearance === "filled";
	}
	set filled(value) {
		if (convertToBoolProperty(value)) this.appearance = "filled";
	}
	get outline() {
		return this.appearance === "outline";
	}
	set outline(value) {
		if (convertToBoolProperty(value)) this.appearance = "outline";
	}
	get basic() {
		return this.status === "basic";
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get info() {
		return this.status === "info";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get control() {
		return this.status === "control";
	}
	get tiny() {
		return this.size === "tiny";
	}
	get small() {
		return this.size === "small";
	}
	get medium() {
		return this.size === "medium";
	}
	get large() {
		return this.size === "large";
	}
	get giant() {
		return this.size === "giant";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	_remove() {
		if (this.removable) this.remove.emit(this);
	}
	constructor(_hostElement, cd, renderer, zone, statusService) {
		this._hostElement = _hostElement;
		this.cd = cd;
		this.renderer = renderer;
		this.zone = zone;
		this.statusService = statusService;
		this._destroy$ = new Subject();
		this._selected = false;
		this._removable = false;
		this.appearance = "filled";
		this.status = "basic";
		this.size = "medium";
		this.role = "option";
		this.remove = new EventEmitter();
		this.selectedChange = new EventEmitter();
		this._isActive = false;
		this._id = `nb-tag-${tagUniqueId++}`;
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this._hostElement.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this._destroy$.next(this);
	}
	_toggleSelection() {
		this.selected = !this.selected;
		this.cd.markForCheck();
	}
	setActiveStyles() {
		if (!this._isActive) {
			this._isActive = true;
			this.cd.markForCheck();
		}
	}
	setInactiveStyles() {
		if (this._isActive) {
			this._isActive = false;
			this.cd.markForCheck();
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagComponent,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTagComponent,
			isStandalone: false,
			selector: "nb-tag",
			inputs: {
				text: "text",
				selected: "selected",
				removable: "removable",
				appearance: "appearance",
				status: "status",
				size: "size",
				role: "role"
			},
			outputs: {
				remove: "remove",
				selectedChange: "selectedChange"
			},
			host: {
				listeners: {
					"keydown.delete": "_remove()",
					"keydown.backspace": "_remove()"
				},
				properties: {
					"class.selected": "this.selected",
					"attr.aria-selected": "this.selected",
					"attr.role": "this.role",
					"class.active": "this._isActive",
					"attr.id": "this._id",
					"class.appearance-filled": "this.filled",
					"class.appearance-outline": "this.outline",
					"class.status-basic": "this.basic",
					"class.status-primary": "this.primary",
					"class.status-success": "this.success",
					"class.status-info": "this.info",
					"class.status-warning": "this.warning",
					"class.status-danger": "this.danger",
					"class.status-control": "this.control",
					"class.size-tiny": "this.tiny",
					"class.size-small": "this.small",
					"class.size-medium": "this.medium",
					"class.size-large": "this.large",
					"class.size-giant": "this.giant",
					"class": "this.additionalClasses"
				}
			},
			exportAs: ["nbTag"],
			ngImport: i0,
			template: "{{ text }}\n<nb-icon *ngIf=\"removable\"\n         (click)=\"_remove()\"\n         class=\"nb-tag-remove size-{{size}}\"\n         icon=\"close-outline\"\n         pack=\"nebular-essentials\"\n         aria-hidden=\"true\">\n</nb-icon>\n",
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTagComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tag",
			exportAs: "nbTag",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			template: "{{ text }}\n<nb-icon *ngIf=\"removable\"\n         (click)=\"_remove()\"\n         class=\"nb-tag-remove size-{{size}}\"\n         icon=\"close-outline\"\n         pack=\"nebular-essentials\"\n         aria-hidden=\"true\">\n</nb-icon>\n"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		text: [{ type: Input }],
		selected: [
			{ type: Input },
			{
				type: HostBinding,
				args: ["class.selected"]
			},
			{
				type: HostBinding,
				args: ["attr.aria-selected"]
			}
		],
		removable: [{ type: Input }],
		appearance: [{ type: Input }],
		status: [{ type: Input }],
		size: [{ type: Input }],
		role: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.role"]
		}],
		remove: [{ type: Output }],
		selectedChange: [{ type: Output }],
		_isActive: [{
			type: HostBinding,
			args: ["class.active"]
		}],
		_id: [{
			type: HostBinding,
			args: ["attr.id"]
		}],
		filled: [{
			type: HostBinding,
			args: ["class.appearance-filled"]
		}],
		outline: [{
			type: HostBinding,
			args: ["class.appearance-outline"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		tiny: [{
			type: HostBinding,
			args: ["class.size-tiny"]
		}],
		small: [{
			type: HostBinding,
			args: ["class.size-small"]
		}],
		medium: [{
			type: HostBinding,
			args: ["class.size-medium"]
		}],
		large: [{
			type: HostBinding,
			args: ["class.size-large"]
		}],
		giant: [{
			type: HostBinding,
			args: ["class.size-giant"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		_remove: [{
			type: HostListener,
			args: ["keydown.delete"]
		}, {
			type: HostListener,
			args: ["keydown.backspace"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTagInputDirective = class NbTagInputDirective extends NbInputDirective {
	get _value() {
		return this._hostElement.nativeElement.value;
	}
	_onKeydown(event) {
		this.keyDown$.next(event);
	}
	constructor(_hostElement, focusMonitor, renderer, zone, statusService) {
		super(_hostElement, focusMonitor, renderer, zone, statusService);
		this._hostElement = _hostElement;
		this.focusMonitor = focusMonitor;
		this.renderer = renderer;
		this.zone = zone;
		this.statusService = statusService;
		this.keyDown$ = new Subject();
		this.separatorKeys = [keycodes_exports.ENTER];
		this.tagAdd = new EventEmitter();
		this.nbTagInputClass = true;
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this.keyDown$.pipe(filter(({ keyCode }) => this.isSeparatorKey(keyCode)), map(() => this._value), takeUntil(this.destroy$)).subscribe((value) => this.tagAdd.emit({
			value,
			input: this._hostElement
		}));
	}
	isSeparatorKey(keyCode) {
		return this.separatorKeys.includes(keyCode);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagInputDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: NbFocusMonitor },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTagInputDirective,
			isStandalone: false,
			selector: "input[nbTagInput]",
			inputs: { separatorKeys: "separatorKeys" },
			outputs: { tagAdd: "tagAdd" },
			host: {
				listeners: { "keydown": "_onKeydown($event)" },
				properties: { "class.nb-tag-input": "this.nbTagInputClass" }
			},
			providers: [{
				provide: NbFormFieldControl,
				useExisting: NbTagInputDirective
			}],
			exportAs: ["nbTagInput"],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTagInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[nbTagInput]",
			exportAs: "nbTagInput",
			providers: [{
				provide: NbFormFieldControl,
				useExisting: NbTagInputDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: NbFocusMonitor },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		separatorKeys: [{ type: Input }],
		tagAdd: [{ type: Output }],
		nbTagInputClass: [{
			type: HostBinding,
			args: ["class.nb-tag-input"]
		}],
		_onKeydown: [{
			type: HostListener,
			args: ["keydown", ["$event"]]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTagListComponent = class NbTagListComponent {
	get multiple() {
		return this._multiple;
	}
	set multiple(value) {
		this._multiple = convertToBoolProperty(value);
	}
	get _hasInput() {
		return !!this.tagInput;
	}
	get _isFocused() {
		return this.focused;
	}
	get _isFullWidth() {
		return !!this.tagInput?.fullWidth;
	}
	get _inputClasses() {
		if (this._hasInput) return [
			`shape-${this.tagInput.shape}`,
			`size-${this.tagInput.fieldSize}`,
			this.statusService.getStatusClass(this.tagInput.status)
		];
		return [`size-${this.size}`];
	}
	_onKeydown(event) {
		this.keyDown$.next(event);
	}
	_onClick({ target }) {
		const clickedTag = this.tags.find((tag) => tag._hostElement.nativeElement === target);
		if (clickedTag) this.tagClick$.next(clickedTag);
	}
	constructor(hostElement, cd, renderer, zone, focusMonitor, activeDescendantKeyManagerFactory, directionService, statusService) {
		this.hostElement = hostElement;
		this.cd = cd;
		this.renderer = renderer;
		this.zone = zone;
		this.focusMonitor = focusMonitor;
		this.activeDescendantKeyManagerFactory = activeDescendantKeyManagerFactory;
		this.directionService = directionService;
		this.statusService = statusService;
		this.destroy$ = new Subject();
		this.keyDown$ = new Subject();
		this.tagClick$ = new Subject();
		this.focused = false;
		this.size = "medium";
		this.tabIndex = 0;
		this.role = "listbox";
		this._multiple = false;
		this.activeTagId = null;
		this.tagRemove = new EventEmitter();
	}
	ngOnInit() {
		this.focusMonitor.monitor(this.hostElement, true).pipe(map((origin) => !!origin), finalize(() => this.focusMonitor.stopMonitoring(this.hostElement)), takeUntil(this.destroy$)).subscribe((isFocused) => this.onFocusChange(isFocused));
	}
	ngAfterContentInit() {
		this.initKeyManager();
		this.setAutocompleteCustomHost();
	}
	ngAfterViewInit() {
		this.listenToLayoutDirectionChange();
		this.listenListKeyDown();
		this.listenInputKeyDown();
		this.listenTagClick();
		this.listenTagRemove();
		this.listenTagDestroy();
		this.listenActiveTagChange();
		this.listenNoTags();
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostElement.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.destroy$.next();
	}
	initKeyManager() {
		this.keyManager = this.activeDescendantKeyManagerFactory.create(this.tags).withHorizontalOrientation(this.directionService.getDirection()).withWrap();
	}
	listenToLayoutDirectionChange() {
		this.directionService.onDirectionChange().pipe(takeUntil(this.destroy$)).subscribe((direction) => this.keyManager.withHorizontalOrientation(direction));
	}
	listenListKeyDown() {
		const tagListKeyDown$ = this.keyDown$.pipe(filter(({ target }) => target === this.hostElement.nativeElement));
		const activeTagKeyDown$ = tagListKeyDown$.pipe(filter(() => !!this.keyManager.activeItem));
		tagListKeyDown$.pipe(takeUntil(this.destroy$)).subscribe((event) => this.keyManager.onKeydown(event));
		activeTagKeyDown$.pipe(filter(({ keyCode }) => keyCode === keycodes_exports.SPACE), takeUntil(this.destroy$)).subscribe((event) => {
			this.toggleTag(this.keyManager.activeItem);
			event.preventDefault();
		});
		activeTagKeyDown$.pipe(filter(({ keyCode }) => this.isBackspaceOrDelete(keyCode)), map(() => this.keyManager.activeItem), takeUntil(this.destroy$)).subscribe((tagToRemove) => tagToRemove._remove());
	}
	listenInputKeyDown() {
		this.keyDown$.pipe(filter(({ target }) => target === this.tagInput?._hostElement.nativeElement)).pipe(filter(({ keyCode }) => {
			return this.tagInput._value === "" && this.isBackspaceOrDelete(keyCode) && this.tags.length > 0;
		}), takeUntil(this.destroy$)).subscribe(() => {
			this.hostElement.nativeElement.focus();
			this.keyManager.setLastItemActive();
			this.cd.markForCheck();
		});
	}
	listenTagClick() {
		this.tagClick$.pipe(takeUntil(this.destroy$)).subscribe((clickedTag) => {
			this.toggleTag(clickedTag);
			this.keyManager.setActiveItem(clickedTag);
		});
	}
	listenTagRemove() {
		this.tags.changes.pipe(startWith(this.tags), switchMap((tags) => merge(...tags.map((tag) => tag.remove))), takeUntil(this.destroy$)).subscribe((tagToRemove) => this.tagRemove.emit(tagToRemove));
	}
	listenTagDestroy() {
		this.tags.changes.pipe(startWith(this.tags), switchMap((tags) => merge(...tags.map((tag) => tag.destroy$))), filter((destroyedTag) => destroyedTag === this.keyManager.activeItem), map((destroyedTag) => destroyedTag === this.tags.last), takeUntil(this.destroy$)).subscribe((isLastTagDestroyed) => {
			if (isLastTagDestroyed) this.keyManager.setPreviousItemActive();
			else this.keyManager.setNextItemActive();
		});
	}
	listenNoTags() {
		this.tags.changes.pipe(startWith(this.tags), filter((tags) => tags.length === 0), takeUntil(this.destroy$)).subscribe(() => this.focusInputIfActive());
	}
	listenActiveTagChange() {
		this.keyManager.change.pipe(map(() => this.keyManager.activeItem?._id), takeUntil(this.destroy$)).subscribe((activeTagId) => {
			this.activeTagId = activeTagId;
			this.cd.markForCheck();
		});
	}
	onFocusChange(isFocused) {
		this.focused = isFocused;
		this.cd.markForCheck();
		if (!isFocused || this.tagInput?.focused$.value) {
			this.keyManager?.setActiveItem(-1);
			return;
		}
		if (this.tags.length === 0 && this._hasInput) this.focusInput();
		else this.keyManager.setFirstItemActive();
	}
	isBackspaceOrDelete(keyCode) {
		return keyCode === keycodes_exports.BACKSPACE || keyCode === keycodes_exports.DELETE;
	}
	setAutocompleteCustomHost() {
		if (this.autocompleteDirective) this.autocompleteDirective.customOverlayHost = this.hostElement;
	}
	toggleTag(tagToToggle) {
		tagToToggle._toggleSelection();
		if (tagToToggle.selected && !this.multiple) this.tags.forEach((tag) => {
			if (tag !== tagToToggle) tag.selected = false;
		});
	}
	focusInput() {
		if (this._hasInput) this.tagInput._hostElement.nativeElement.focus();
	}
	focusInputIfActive() {
		if (this._isFocused) this.focusInput();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagListComponent,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.ChangeDetectorRef },
				{ token: i0.Renderer2 },
				{ token: i0.NgZone },
				{ token: NbFocusMonitor },
				{ token: NbActiveDescendantKeyManagerFactoryService },
				{ token: NbLayoutDirectionService },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTagListComponent,
			isStandalone: false,
			selector: "nb-tag-list",
			inputs: {
				size: "size",
				tabIndex: "tabIndex",
				role: "role",
				multiple: "multiple"
			},
			outputs: { tagRemove: "tagRemove" },
			host: {
				listeners: {
					"keydown": "_onKeydown($event)",
					"click": "_onClick($event)"
				},
				properties: {
					"attr.tabindex": "this.tabIndex",
					"attr.role": "this.role",
					"attr.aria-multiselectable": "this.multiple",
					"attr.aria-activedescendant": "this.activeTagId",
					"class.nb-tag-list-with-input": "this._hasInput",
					"class.focus": "this._isFocused",
					"class.input-full-width": "this._isFullWidth",
					"class": "this._inputClasses"
				}
			},
			queries: [
				{
					propertyName: "tagInput",
					first: true,
					predicate: NbTagInputDirective,
					descendants: true
				},
				{
					propertyName: "autocompleteDirective",
					first: true,
					predicate: NbAutocompleteDirective,
					descendants: true
				},
				{
					propertyName: "tags",
					predicate: NbTagComponent
				}
			],
			exportAs: ["nbTagList"],
			ngImport: i0,
			template: `
    <div class="nb-tag-list-tags-wrapper">
      <ng-content select="nb-tag, input[nbTagInput]"></ng-content>
    </div>
  `,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTagListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tag-list",
			template: `
    <div class="nb-tag-list-tags-wrapper">
      <ng-content select="nb-tag, input[nbTagInput]"></ng-content>
    </div>
  `,
			exportAs: "nbTagList",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.Renderer2 },
		{ type: i0.NgZone },
		{ type: NbFocusMonitor },
		{ type: NbActiveDescendantKeyManagerFactoryService },
		{ type: NbLayoutDirectionService },
		{ type: NbStatusService }
	],
	propDecorators: {
		tags: [{
			type: ContentChildren,
			args: [NbTagComponent]
		}],
		tagInput: [{
			type: ContentChild,
			args: [NbTagInputDirective]
		}],
		autocompleteDirective: [{
			type: ContentChild,
			args: [NbAutocompleteDirective]
		}],
		size: [{ type: Input }],
		tabIndex: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.tabindex"]
		}],
		role: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.role"]
		}],
		multiple: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-multiselectable"]
		}],
		activeTagId: [{
			type: HostBinding,
			args: ["attr.aria-activedescendant"]
		}],
		tagRemove: [{ type: Output }],
		_hasInput: [{
			type: HostBinding,
			args: ["class.nb-tag-list-with-input"]
		}],
		_isFocused: [{
			type: HostBinding,
			args: ["class.focus"]
		}],
		_isFullWidth: [{
			type: HostBinding,
			args: ["class.input-full-width"]
		}],
		_inputClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		_onKeydown: [{
			type: HostListener,
			args: ["keydown", ["$event"]]
		}],
		_onClick: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTagModule = class NbTagModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagModule,
			declarations: [
				NbTagComponent,
				NbTagListComponent,
				NbTagInputDirective
			],
			imports: [CommonModule, NbIconModule],
			exports: [
				NbTagComponent,
				NbTagListComponent,
				NbTagInputDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTagModule,
			imports: [CommonModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTagModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule, NbIconModule],
			declarations: [
				NbTagComponent,
				NbTagListComponent,
				NbTagInputDirective
			],
			exports: [
				NbTagComponent,
				NbTagListComponent,
				NbTagInputDirective
			]
		}]
	}]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_DEFAULT_ROW_LEVEL = 0;
var NbTreeGridPresentationNode = class {
	constructor(data, children, expanded, level) {
		this.data = data;
		this.children = children;
		this.expanded = expanded;
		this.level = level;
	}
	hasChildren() {
		return !!this.children && !!this.children.length;
	}
};
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridFilterService = class NbTreeGridFilterService {
	filter(query, data) {
		if (!query) return data;
		return data.reduce((filtered, node) => {
			let filteredChildren;
			if (node.children) {
				filteredChildren = this.filter(query, node.children);
				node.children = filteredChildren;
			}
			node.expanded = false;
			if (filteredChildren && filteredChildren.length) {
				node.expanded = true;
				filtered.push(node);
			} else if (this.filterPredicate(node.data, query)) filtered.push(node);
			return filtered;
		}, []);
	}
	filterPredicate(data, searchQuery) {
		const preparedQuery = searchQuery.trim().toLocaleLowerCase();
		for (const val of Object.values(data)) if (`${val}`.trim().toLocaleLowerCase().includes(preparedQuery)) return true;
		return false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFilterService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFilterService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridFilterService,
	decorators: [{ type: Injectable }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbSortDirection;
(function(NbSortDirection) {
	NbSortDirection["ASCENDING"] = "asc";
	NbSortDirection["DESCENDING"] = "desc";
	NbSortDirection["NONE"] = "";
})(NbSortDirection || (NbSortDirection = {}));
const sortDirections = [
	NbSortDirection.ASCENDING,
	NbSortDirection.DESCENDING,
	NbSortDirection.NONE
];
var NbSortDirective = class NbSortDirective {
	constructor() {
		this.sort = new EventEmitter();
	}
	emitSort(sortRequest) {
		if (this.sortable && this.sortable.sort) this.sortable.sort(sortRequest);
		this.sort.emit(sortRequest);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSortDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSortDirective,
			isStandalone: false,
			selector: "[nbSort]",
			inputs: { sortable: ["nbSort", "sortable"] },
			outputs: { sort: "sort" },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSortDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbSort]",
			standalone: false
		}]
	}],
	propDecorators: {
		sortable: [{
			type: Input,
			args: ["nbSort"]
		}],
		sort: [{ type: Output }]
	}
});
var NbSortHeaderIconDirective = class NbSortHeaderIconDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSortHeaderIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSortHeaderIconDirective,
			isStandalone: false,
			selector: "[nbSortHeaderIcon]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSortHeaderIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbSortHeaderIcon]",
			standalone: false
		}]
	}]
});
var NbSortIconComponent = class NbSortIconComponent {
	constructor() {
		this.direction = NbSortDirection.NONE;
	}
	isAscending() {
		return this.direction === NbSortDirection.ASCENDING;
	}
	isDescending() {
		return this.direction === NbSortDirection.DESCENDING;
	}
	isDirectionSet() {
		return this.isAscending() || this.isDescending();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSortIconComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSortIconComponent,
			isStandalone: false,
			selector: "nb-sort-icon",
			inputs: { direction: "direction" },
			ngImport: i0,
			template: `
    <ng-container *ngIf="isDirectionSet()">
      <nb-icon *ngIf="isAscending()" icon="chevron-down-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
      <nb-icon *ngIf="isDescending()" icon="chevron-up-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
    </ng-container>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSortIconComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-sort-icon",
			template: `
    <ng-container *ngIf="isDirectionSet()">
      <nb-icon *ngIf="isAscending()" icon="chevron-down-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
      <nb-icon *ngIf="isDescending()" icon="chevron-up-outline" pack="nebular-essentials" aria-hidden="true"></nb-icon>
    </ng-container>
  `,
			standalone: false
		}]
	}],
	propDecorators: { direction: [{ type: Input }] }
});
var NbSortHeaderComponent = class NbSortHeaderComponent {
	set disabled(value) {
		this.disabledValue = convertToBoolProperty(value);
	}
	get disabled() {
		return this.disabledValue;
	}
	sortIfEnabled() {
		if (!this.disabled) this.sortData();
	}
	constructor(sort, columnDef) {
		this.sort = sort;
		this.columnDef = columnDef;
		this.disabledValue = false;
	}
	isAscending() {
		return this.direction === NbSortDirection.ASCENDING;
	}
	isDescending() {
		return this.direction === NbSortDirection.DESCENDING;
	}
	sortData() {
		const sortRequest = this.createSortRequest();
		this.sort.emitSort(sortRequest);
	}
	getIconContext() {
		return {
			$implicit: this.direction,
			isAscending: this.isAscending(),
			isDescending: this.isDescending(),
			isNone: !this.isAscending() && !this.isDescending()
		};
	}
	getDisabledAttributeValue() {
		return this.disabled ? "" : null;
	}
	createSortRequest() {
		this.direction = this.getNextDirection();
		return {
			direction: this.direction,
			column: this.columnDef.name
		};
	}
	getNextDirection() {
		const sortDirectionCycle = sortDirections;
		let nextDirectionIndex = sortDirectionCycle.indexOf(this.direction) + 1;
		if (nextDirectionIndex >= sortDirectionCycle.length) nextDirectionIndex = 0;
		return sortDirectionCycle[nextDirectionIndex];
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbSortHeaderComponent,
			deps: [{ token: NbSortDirective }, { token: NB_SORT_HEADER_COLUMN_DEF }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbSortHeaderComponent,
			isStandalone: false,
			selector: "[nbSortHeader]",
			inputs: {
				direction: ["nbSortHeader", "direction"],
				disabled: "disabled"
			},
			host: {
				listeners: { "click": "sortIfEnabled()" },
				properties: { "class.disabled": "this.disabled" }
			},
			queries: [{
				propertyName: "sortIcon",
				first: true,
				predicate: NbSortHeaderIconDirective,
				descendants: true,
				read: TemplateRef
			}],
			ngImport: i0,
			template: `
    <button
      class="nb-tree-grid-header-change-sort-button"
      type="button"
      [attr.disabled]="getDisabledAttributeValue()"
      (click)="sortData()">
      <ng-content></ng-content>
    </button>
    <nb-sort-icon *ngIf="!sortIcon; else customIcon" [direction]="direction"></nb-sort-icon>
    <ng-template #customIcon [ngTemplateOutlet]="sortIcon" [ngTemplateOutletContext]="getIconContext()"></ng-template>
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: i2.NgIf,
					selector: "[ngIf]",
					inputs: [
						"ngIf",
						"ngIfThen",
						"ngIfElse"
					]
				},
				{
					kind: "directive",
					type: i2.NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "component",
					type: NbSortIconComponent,
					selector: "nb-sort-icon",
					inputs: ["direction"]
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbSortHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "[nbSortHeader]",
			template: `
    <button
      class="nb-tree-grid-header-change-sort-button"
      type="button"
      [attr.disabled]="getDisabledAttributeValue()"
      (click)="sortData()">
      <ng-content></ng-content>
    </button>
    <nb-sort-icon *ngIf="!sortIcon; else customIcon" [direction]="direction"></nb-sort-icon>
    <ng-template #customIcon [ngTemplateOutlet]="sortIcon" [ngTemplateOutletContext]="getIconContext()"></ng-template>
  `,
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbSortDirective }, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_SORT_HEADER_COLUMN_DEF]
		}]
	}],
	propDecorators: {
		sortIcon: [{
			type: ContentChild,
			args: [NbSortHeaderIconDirective, { read: TemplateRef }]
		}],
		direction: [{
			type: Input,
			args: ["nbSortHeader"]
		}],
		disabled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.disabled"]
		}],
		sortIfEnabled: [{
			type: HostListener,
			args: ["click"]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridSortService = class NbTreeGridSortService {
	sort(request, data) {
		if (!request) return data;
		const sorted = data.sort((na, nb) => this.comparator(request, na, nb));
		for (const node of data) if (node.children) node.children = this.sort(request, node.children);
		return sorted;
	}
	comparator(request, na, nb) {
		const key = request.column;
		const dir = request.direction;
		const a = na.data[key];
		const b = nb.data[key];
		let res = 0;
		if (a > b) res = 1;
		if (a < b) res = -1;
		return dir === NbSortDirection.ASCENDING ? res : res * -1;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridSortService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridSortService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridSortService,
	decorators: [{ type: Injectable }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridService = class NbTreeGridService {
	expand(data, row, options = {}) {
		const node = this.find(data, row);
		node.expanded = true;
		if (options.deep && node.hasChildren()) node.children.forEach((n) => this.expand(data, n.data, options));
	}
	collapse(data, row, options = {}) {
		const node = this.find(data, row);
		node.expanded = false;
		if (options.deep && node.hasChildren()) node.children.forEach((n) => this.collapse(data, n.data, options));
	}
	toggle(data, row, options = {}) {
		if (this.find(data, row).expanded) this.collapse(data, row, options);
		else this.expand(data, row, options);
	}
	find(data, row) {
		const toCheck = [...data];
		for (const node of toCheck) {
			if (node.data === row) return node;
			if (node.hasChildren()) toCheck.push(...node.children);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridService,
	decorators: [{ type: Injectable }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridDataService = class NbTreeGridDataService {
	constructor() {
		this.defaultGetters = {
			dataGetter: (node) => node.data,
			childrenGetter: (d) => d.children || void 0,
			expandedGetter: (d) => !!d.expanded
		};
	}
	toPresentationNodes(nodes, customGetters, level = 0) {
		const getters = {
			...this.defaultGetters,
			...customGetters
		};
		return this.mapNodes(nodes, getters, level);
	}
	mapNodes(nodes, getters, level) {
		const { dataGetter, childrenGetter, expandedGetter } = getters;
		return nodes.map((node) => {
			const childrenNodes = childrenGetter(node);
			let children;
			if (childrenNodes) children = this.toPresentationNodes(childrenNodes, getters, level + 1);
			return new NbTreeGridPresentationNode(dataGetter(node), children, expandedGetter(node), level);
		});
	}
	flattenExpanded(nodes) {
		return nodes.reduce((res, node) => {
			res.push(node);
			if (node.expanded && node.hasChildren()) res.push(...this.flattenExpanded(node.children));
			return res;
		}, []);
	}
	copy(nodes) {
		return nodes.map((node) => {
			let children;
			if (node.hasChildren()) children = this.copy(node.children);
			return new NbTreeGridPresentationNode(node.data, children, node.expanded, node.level);
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridDataService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridDataService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridDataService,
	decorators: [{ type: Injectable }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridDataSource = class extends NbDataSource {
	constructor(sortService, filterService, treeGridService, treeGridDataService) {
		super();
		this.sortService = sortService;
		this.filterService = filterService;
		this.treeGridService = treeGridService;
		this.treeGridDataService = treeGridDataService;
		this.renderData = new BehaviorSubject([]);
		this.filterRequest = new BehaviorSubject("");
		this.sortRequest = new BehaviorSubject(null);
	}
	setData(data, customGetters) {
		let presentationData = [];
		if (data) presentationData = this.treeGridDataService.toPresentationNodes(data, customGetters);
		this.data = new BehaviorSubject(presentationData);
		this.updateChangeSubscription();
	}
	connect(collectionViewer) {
		return this.renderData;
	}
	disconnect(collectionViewer) {}
	expand(row) {
		this.treeGridService.expand(this.data.value, row);
		this.data.next(this.data.value);
	}
	collapse(row) {
		this.treeGridService.collapse(this.data.value, row);
		this.data.next(this.data.value);
	}
	toggle(row, options) {
		this.treeGridService.toggle(this.data.value, row, options);
		this.data.next(this.data.value);
	}
	toggleByIndex(dataIndex, options) {
		const node = this.renderData.value && this.renderData.value[dataIndex];
		if (node) this.toggle(node.data, options);
	}
	getLevel(rowIndex) {
		const row = this.renderData.value[rowIndex];
		return row ? row.level : 0;
	}
	sort(sortRequest) {
		this.sortRequest.next(sortRequest);
	}
	filter(searchQuery) {
		this.filterRequest.next(searchQuery);
	}
	updateChangeSubscription() {
		const dataStream = this.data;
		combineLatest([combineLatest([dataStream, this.filterRequest]).pipe(map(([data]) => this.treeGridDataService.copy(data)), map((data) => this.filterData(data))), this.sortRequest]).pipe(map(([data]) => this.sortData(data))).pipe(map((data) => this.treeGridDataService.flattenExpanded(data))).subscribe((data) => this.renderData.next(data));
	}
	filterData(data) {
		return this.filterService.filter(this.filterRequest.value, data);
	}
	sortData(data) {
		return this.sortService.sort(this.sortRequest.value, data);
	}
};
var NbTreeGridDataSourceBuilder = class NbTreeGridDataSourceBuilder {
	constructor(filterService, sortService, treeGridService, treeGridDataService) {
		this.filterService = filterService;
		this.sortService = sortService;
		this.treeGridService = treeGridService;
		this.treeGridDataService = treeGridDataService;
	}
	create(data, customGetters) {
		const dataSource = new NbTreeGridDataSource(this.sortService, this.filterService, this.treeGridService, this.treeGridDataService);
		dataSource.setData(data, customGetters);
		return dataSource;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridDataSourceBuilder,
			deps: [
				{ token: NbTreeGridFilterService },
				{ token: NbTreeGridSortService },
				{ token: NbTreeGridService },
				{ token: NbTreeGridDataService }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridDataSourceBuilder
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridDataSourceBuilder,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: NbTreeGridFilterService },
		{ type: NbTreeGridSortService },
		{ type: NbTreeGridService },
		{ type: NbTreeGridDataService }
	]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const NB_TREE_GRID = new InjectionToken("NB_TREE_GRID");
var NbColumnsService = class NbColumnsService {
	constructor(differs) {
		this.differs = differs;
		this.columnHide$ = new Subject();
		this.columnShow$ = new Subject();
	}
	setColumns(columns) {
		if (!this.changesDiffer) this.changesDiffer = this.differs.find(columns || []).create();
		if (this.changesDiffer.diff(columns)) {
			this.allColumns = Array.from(columns);
			this.visibleColumns = Array.from(columns);
		}
	}
	getVisibleColumns() {
		return this.visibleColumns;
	}
	hideColumn(column) {
		const toRemove = this.visibleColumns.indexOf(column);
		if (toRemove > -1) {
			this.visibleColumns.splice(toRemove, 1);
			this.columnHide$.next();
		}
	}
	showColumn(column) {
		if (this.visibleColumns.includes(column)) return;
		this.visibleColumns.splice(this.findInsertIndex(column), 0, column);
		this.columnShow$.next();
	}
	onColumnsChange() {
		return merge(this.columnShow$, this.columnHide$);
	}
	findInsertIndex(column) {
		const initialIndex = this.allColumns.indexOf(column);
		if (initialIndex === 0 || !this.visibleColumns.length) return 0;
		if (initialIndex === this.allColumns.length - 1) return this.visibleColumns.length;
		const leftSiblingIndex = initialIndex - 1;
		for (let i = leftSiblingIndex; i >= 0; i--) {
			const leftSibling = this.allColumns[i];
			const index = this.visibleColumns.indexOf(leftSibling);
			if (index !== -1) return index + 1;
		}
		const rightSiblingIndex = initialIndex + 1;
		for (let i = rightSiblingIndex; i < this.allColumns.length; i++) {
			const rightSibling = this.allColumns[i];
			const index = this.visibleColumns.indexOf(rightSibling);
			if (index !== -1) return index;
		}
		throw new Error(`Can't restore column position.`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbColumnsService,
			deps: [{ token: i0.IterableDiffers }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbColumnsService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbColumnsService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i0.IterableDiffers }]
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridComponent = class NbTreeGridComponent extends NbTable {
	constructor(dataSourceBuilder, platform, window) {
		super();
		this.dataSourceBuilder = dataSourceBuilder;
		this.window = window;
		this.destroy$ = new Subject();
		this.levelPadding = "";
		this.equalColumnsWidthValue = false;
		this.treeClass = true;
		this.platform = platform;
	}
	set source(data) {
		if (!data) return;
		if (data instanceof NbTreeGridDataSource) this._source = data;
		else this._source = this.dataSourceBuilder.create(data);
		this.dataSource = this._source;
	}
	set equalColumnsWidth(value) {
		this.equalColumnsWidthValue = convertToBoolProperty(value);
	}
	get equalColumnsWidth() {
		return this.equalColumnsWidthValue;
	}
	ngAfterViewInit() {
		this.checkDefsCount();
		const rowsChange$ = merge(this._contentRowDefs.changes, this._contentHeaderRowDefs.changes, this._contentFooterRowDefs.changes);
		rowsChange$.pipe(takeUntil(this.destroy$)).subscribe(() => this.checkDefsCount());
		if (this.platform.isBrowser) {
			this.updateVisibleColumns();
			const windowResize$ = fromEvent(this.window, "resize").pipe(debounceTime(50));
			merge(rowsChange$, this._contentColumnDefs.changes, windowResize$).pipe(takeUntil(this.destroy$)).subscribe(() => this.updateVisibleColumns());
		}
	}
	ngOnDestroy() {
		super.ngOnDestroy();
		this.destroy$.next();
		this.destroy$.complete();
	}
	toggleRow(row, options) {
		const context = this.getRowContext(row);
		this._source.toggle(context.$implicit.data, options);
	}
	toggleCellRow(cell) {
		const context = this.getCellContext(cell);
		this._source.toggle(context.$implicit.data);
	}
	getColumnWidth() {
		if (this.equalColumnsWidth) return `${100 / this.getColumnsCount()}%`;
		return "";
	}
	getCellLevel(cell, columnName) {
		if (this.isFirstColumn(columnName)) return this.getCellContext(cell).$implicit.level;
		return 0;
	}
	getRowContext(row) {
		return this.getContextByRowEl(row.elementRef.nativeElement);
	}
	getCellContext(cell) {
		return this.getContextByCellEl(cell.elementRef.nativeElement);
	}
	getContextByCellEl(cellEl) {
		return this.getContextByRowEl(cellEl.parentElement);
	}
	getContextByRowEl(rowEl) {
		const rowsContainer = this._rowOutlet.viewContainer;
		for (let i = 0; i < rowsContainer.length; i++) {
			const rowViewRef = rowsContainer.get(i);
			if (rowViewRef.rootNodes.includes(rowEl)) return rowViewRef.context;
		}
	}
	getColumns() {
		let rowDef;
		if (this._contentHeaderRowDefs.length) rowDef = this._contentHeaderRowDefs.first;
		else rowDef = this._contentRowDefs.first;
		return Array.from(rowDef.getVisibleColumns() || []);
	}
	getColumnsCount() {
		return this.getColumns().length;
	}
	isFirstColumn(columnName) {
		return this.getColumns()[0] === columnName;
	}
	checkDefsCount() {
		if (this._contentRowDefs.length > 1) throw new Error(`Found multiple row definitions`);
		if (this._contentHeaderRowDefs.length > 1) throw new Error(`Found multiple header row definitions`);
		if (this._contentFooterRowDefs.length > 1) throw new Error(`Found multiple footer row definitions`);
	}
	updateVisibleColumns() {
		const width = this.window.innerWidth;
		const columnDefs = this._contentColumnDefs;
		const columnsToHide = columnDefs.filter((col) => col.shouldHide(width)).map((col) => col.name);
		const columnsToShow = columnDefs.filter((col) => col.shouldShow(width)).map((col) => col.name);
		if (!columnsToHide.length && !columnsToShow.length) return;
		const rowDefs = [
			this._contentHeaderRowDefs.first,
			this._contentRowDefs.first,
			this._contentFooterRowDefs.first
		].filter((d) => !!d);
		for (const rowDef of rowDefs) {
			for (const column of columnsToHide) rowDef.hideColumn(column);
			for (const column of columnsToShow) rowDef.showColumn(column);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridComponent,
			deps: [
				{ token: NbTreeGridDataSourceBuilder },
				{ token: NbPlatform },
				{ token: NB_WINDOW }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridComponent,
			isStandalone: false,
			selector: "table[nbTreeGrid]",
			inputs: {
				source: ["nbTreeGrid", "source"],
				levelPadding: "levelPadding",
				equalColumnsWidth: "equalColumnsWidth"
			},
			host: { properties: { "class.nb-tree-grid": "this.treeClass" } },
			providers: [
				{
					provide: NB_TREE_GRID,
					useExisting: NbTreeGridComponent
				},
				{
					provide: CDK_TABLE,
					useExisting: NbTreeGridComponent
				},
				NbColumnsService,
				...NB_TABLE_PROVIDERS
			],
			usesInheritance: true,
			ngImport: i0,
			template: "\n  <ng-container nbHeaderRowOutlet></ng-container>\n  <ng-container nbRowOutlet></ng-container>\n  <ng-container nbNoDataRowOutlet></ng-container>\n  <ng-container nbFooterRowOutlet></ng-container>\n",
			isInline: true,
			styles: [":host{table-layout:fixed;border-spacing:0;border-collapse:collapse;width:100%;max-width:100%;overflow:auto}::ng-deep .nb-tree-grid-cell,::ng-deep .nb-tree-grid-header-cell,::ng-deep .nb-tree-grid-footer-cell{overflow:hidden}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [
				{
					kind: "directive",
					type: NbDataRowOutletDirective,
					selector: "[nbRowOutlet]"
				},
				{
					kind: "directive",
					type: NbHeaderRowOutletDirective,
					selector: "[nbHeaderRowOutlet]"
				},
				{
					kind: "directive",
					type: NbFooterRowOutletDirective,
					selector: "[nbFooterRowOutlet]"
				},
				{
					kind: "directive",
					type: NbNoDataRowOutletDirective,
					selector: "[nbNoDataRowOutlet]"
				}
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "table[nbTreeGrid]",
			template: NB_TABLE_TEMPLATE,
			providers: [
				{
					provide: NB_TREE_GRID,
					useExisting: NbTreeGridComponent
				},
				{
					provide: CDK_TABLE,
					useExisting: NbTreeGridComponent
				},
				NbColumnsService,
				...NB_TABLE_PROVIDERS
			],
			standalone: false,
			styles: [":host{table-layout:fixed;border-spacing:0;border-collapse:collapse;width:100%;max-width:100%;overflow:auto}::ng-deep .nb-tree-grid-cell,::ng-deep .nb-tree-grid-header-cell,::ng-deep .nb-tree-grid-footer-cell{overflow:hidden}\n/*\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: NbTreeGridDataSourceBuilder },
		{ type: NbPlatform },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW]
			}]
		}
	],
	propDecorators: {
		source: [{
			type: Input,
			args: ["nbTreeGrid"]
		}],
		levelPadding: [{ type: Input }],
		equalColumnsWidth: [{ type: Input }],
		treeClass: [{
			type: HostBinding,
			args: ["class.nb-tree-grid"]
		}]
	}
});
const NbCdkRowDef = CdkRowDef;
const NbCdkRow = CdkRow;
const NbCdkCellDef = CdkCellDef;
const NbCdkHeaderRowDef = CdkHeaderRowDef;
const NbCdkHeaderRow = CdkHeaderRow;
const NbCdkHeaderCellDef = CdkHeaderCellDef;
const NbCdkFooterRowDef = CdkFooterRowDef;
const NbCdkFooterRow = CdkFooterRow;
const NbCdkFooterCellDef = CdkFooterCellDef;
const NbCdkColumnDef = CdkColumnDef;
const NbCdkCell = CdkCell;
const NbCdkHeaderCell = CdkHeaderCell;
const NbCdkFooterCell = CdkFooterCell;
var NbTreeGridRowDefDirective = class NbTreeGridRowDefDirective extends NbRowDefDirective {
	constructor(columnsService) {
		super();
		this.columnsService = columnsService;
	}
	ngOnChanges(changes) {
		super.ngOnChanges(changes);
		if (changes["columns"]) this.updateColumns(this.columns);
	}
	updateColumns(columns) {
		this.columnsService.setColumns(columns);
	}
	getVisibleColumns() {
		return this.columnsService.getVisibleColumns();
	}
	hideColumn(column) {
		this.columnsService.hideColumn(column);
	}
	showColumn(column) {
		this.columnsService.showColumn(column);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridRowDefDirective,
			deps: [{ token: NbColumnsService }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridRowDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridRowDef]",
			inputs: { columns: ["nbTreeGridRowDefColumns", "columns"] },
			providers: [{
				provide: NbCdkRowDef,
				useExisting: NbTreeGridRowDefDirective
			}],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridRowDef]",
			providers: [{
				provide: NbCdkRowDef,
				useExisting: NbTreeGridRowDefDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnsService }],
	propDecorators: { columns: [{
		type: Input,
		args: ["nbTreeGridRowDefColumns"]
	}] }
});
var NbTreeGridHeaderRowDefDirective = class NbTreeGridHeaderRowDefDirective extends NbHeaderRowDefDirective {
	constructor(columnsService) {
		super();
		this.columnsService = columnsService;
	}
	ngOnChanges(changes) {
		super.ngOnChanges(changes);
		if (changes["columns"]) this.updateColumns(this.columns);
	}
	updateColumns(columns) {
		this.columnsService.setColumns(columns);
	}
	getVisibleColumns() {
		return this.columnsService.getVisibleColumns();
	}
	hideColumn(column) {
		this.columnsService.hideColumn(column);
	}
	showColumn(column) {
		this.columnsService.showColumn(column);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridHeaderRowDefDirective,
			deps: [{ token: NbColumnsService }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridHeaderRowDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridHeaderRowDef]",
			inputs: { columns: ["nbTreeGridHeaderRowDef", "columns"] },
			providers: [{
				provide: NbCdkHeaderRowDef,
				useExisting: NbTreeGridHeaderRowDefDirective
			}],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridHeaderRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridHeaderRowDef]",
			providers: [{
				provide: NbCdkHeaderRowDef,
				useExisting: NbTreeGridHeaderRowDefDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnsService }],
	propDecorators: { columns: [{
		type: Input,
		args: ["nbTreeGridHeaderRowDef"]
	}] }
});
var NbTreeGridFooterRowDefDirective = class NbTreeGridFooterRowDefDirective extends NbFooterRowDefDirective {
	constructor(columnsService) {
		super();
		this.columnsService = columnsService;
	}
	ngOnChanges(changes) {
		super.ngOnChanges(changes);
		if (changes["columns"]) this.updateColumns(this.columns);
	}
	updateColumns(columns) {
		this.columnsService.setColumns(columns);
	}
	getVisibleColumns() {
		return this.columnsService.getVisibleColumns();
	}
	hideColumn(column) {
		this.columnsService.hideColumn(column);
	}
	showColumn(column) {
		this.columnsService.showColumn(column);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFooterRowDefDirective,
			deps: [{ token: NbColumnsService }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridFooterRowDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridFooterRowDef]",
			inputs: { columns: ["nbTreeGridFooterRowDef", "columns"] },
			providers: [{
				provide: NbCdkFooterRowDef,
				useExisting: NbTreeGridFooterRowDefDirective
			}],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridFooterRowDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridFooterRowDef]",
			providers: [{
				provide: NbCdkFooterRowDef,
				useExisting: NbTreeGridFooterRowDefDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbColumnsService }],
	propDecorators: { columns: [{
		type: Input,
		args: ["nbTreeGridFooterRowDef"]
	}] }
});
var NbTreeGridCellDefDirective = class NbTreeGridCellDefDirective extends NbCellDefDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridCellDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridCellDef]",
			providers: [{
				provide: NbCdkCellDef,
				useExisting: NbTreeGridCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridCellDef]",
			providers: [{
				provide: NbCdkCellDef,
				useExisting: NbTreeGridCellDefDirective
			}],
			standalone: false
		}]
	}]
});
var NbTreeGridHeaderCellDefDirective = class NbTreeGridHeaderCellDefDirective extends NbHeaderCellDefDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridHeaderCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridHeaderCellDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridHeaderCellDef]",
			providers: [{
				provide: NbCdkHeaderCellDef,
				useExisting: NbTreeGridHeaderCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridHeaderCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridHeaderCellDef]",
			providers: [{
				provide: NbCdkHeaderCellDef,
				useExisting: NbTreeGridHeaderCellDefDirective
			}],
			standalone: false
		}]
	}]
});
var NbTreeGridFooterCellDefDirective = class NbTreeGridFooterCellDefDirective extends NbFooterCellDefDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFooterCellDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridFooterCellDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridFooterCellDef]",
			providers: [{
				provide: NbCdkFooterCellDef,
				useExisting: NbTreeGridFooterCellDefDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridFooterCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridFooterCellDef]",
			providers: [{
				provide: NbCdkFooterCellDef,
				useExisting: NbTreeGridFooterCellDefDirective
			}],
			standalone: false
		}]
	}]
});
const NB_ROW_DOUBLE_CLICK_DELAY = 200;
var NbTreeGridRowComponent = class NbTreeGridRowComponent extends NbRowComponent {
	toggleIfEnabledNode() {
		if (!this.clickToToggle) return;
		timer(200).pipe(take(1), takeUntil(this.doubleClick$)).subscribe(() => this.tree.toggleRow(this));
	}
	toggleIfEnabledNodeDeep() {
		if (!this.clickToToggle) return;
		this.doubleClick$.next();
		this.tree.toggleRow(this, { deep: true });
	}
	constructor(tree, elementRef) {
		super();
		this.elementRef = elementRef;
		this.doubleClick$ = new Subject();
		this.doubleClickDelay = 200;
		this.clickToToggle = true;
		this.tree = tree;
	}
	ngOnDestroy() {
		this.doubleClick$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridRowComponent,
			deps: [{ token: NB_TREE_GRID }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridRowComponent,
			isStandalone: false,
			selector: "tr[nbTreeGridRow]",
			inputs: {
				doubleClickDelay: "doubleClickDelay",
				clickToToggle: "clickToToggle"
			},
			host: {
				attributes: { "role": "row" },
				listeners: {
					"click": "toggleIfEnabledNode()",
					"dblclick": "toggleIfEnabledNodeDeep()"
				},
				classAttribute: "nb-tree-grid-row"
			},
			providers: [{
				provide: NbCdkRow,
				useExisting: NbTreeGridRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: `<ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "tr[nbTreeGridRow]",
			template: `<ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-tree-grid-row",
				role: "row"
			},
			providers: [{
				provide: NbCdkRow,
				useExisting: NbTreeGridRowComponent
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [NB_TREE_GRID]
		}]
	}, { type: i0.ElementRef }],
	propDecorators: {
		doubleClickDelay: [{ type: Input }],
		clickToToggle: [{ type: Input }],
		toggleIfEnabledNode: [{
			type: HostListener,
			args: ["click"]
		}],
		toggleIfEnabledNodeDeep: [{
			type: HostListener,
			args: ["dblclick"]
		}]
	}
});
var NbTreeGridHeaderRowComponent = class NbTreeGridHeaderRowComponent extends NbHeaderRowComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridHeaderRowComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridHeaderRowComponent,
			isStandalone: false,
			selector: "tr[nbTreeGridHeaderRow]",
			host: {
				attributes: { "role": "row" },
				classAttribute: "nb-tree-grid-header-row"
			},
			providers: [{
				provide: NbCdkHeaderRow,
				useExisting: NbTreeGridHeaderRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: ` <ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridHeaderRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "tr[nbTreeGridHeaderRow]",
			template: ` <ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-tree-grid-header-row",
				role: "row"
			},
			providers: [{
				provide: NbCdkHeaderRow,
				useExisting: NbTreeGridHeaderRowComponent
			}],
			standalone: false
		}]
	}]
});
var NbTreeGridFooterRowComponent = class NbTreeGridFooterRowComponent extends NbFooterRowComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFooterRowComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridFooterRowComponent,
			isStandalone: false,
			selector: "tr[nbTreeGridFooterRow]",
			host: {
				attributes: { "role": "row" },
				classAttribute: "nb-tree-grid-footer-row"
			},
			providers: [{
				provide: NbCdkFooterRow,
				useExisting: NbTreeGridFooterRowComponent
			}],
			usesInheritance: true,
			ngImport: i0,
			template: ` <ng-container nbCellOutlet></ng-container>`,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NbCellOutletDirective,
				selector: "[nbCellOutlet]"
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridFooterRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "tr[nbTreeGridFooterRow]",
			template: ` <ng-container nbCellOutlet></ng-container>`,
			host: {
				class: "nb-tree-grid-footer-row",
				role: "row"
			},
			providers: [{
				provide: NbCdkFooterRow,
				useExisting: NbTreeGridFooterRowComponent
			}],
			standalone: false
		}]
	}]
});
var NbTreeGridColumnDefDirective = class NbTreeGridColumnDefDirective extends NbColumnDefDirective {
	constructor() {
		super(...arguments);
		this.hideOnValue = null;
		this.showOnValue = null;
	}
	get name() {
		return this._name;
	}
	set name(value) {
		this._setNameInput(value);
	}
	get hideOn() {
		return this.hideOnValue;
	}
	set hideOn(value) {
		this.hideOnValue = !value && value !== 0 ? null : parseInt(value, 10);
	}
	get showOn() {
		return this.showOnValue;
	}
	set showOn(value) {
		this.showOnValue = !value && value !== 0 ? null : parseInt(value, 10);
	}
	ngOnChanges() {
		if (this.hideOn != null && this.showOn != null) throw new Error(`hideOn and showOn are mutually exclusive and can't be used simultaneously.`);
	}
	shouldHide(width) {
		return !this.shouldShow(width);
	}
	shouldShow(width) {
		if (this.hideOn == null && this.showOn == null) return true;
		if (this.hideOn != null) return width > this.hideOn;
		return width >= this.showOn;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridColumnDefDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridColumnDefDirective,
			isStandalone: false,
			selector: "[nbTreeGridColumnDef]",
			inputs: {
				name: ["nbTreeGridColumnDef", "name"],
				hideOn: "hideOn",
				showOn: "showOn"
			},
			providers: [{
				provide: NbCdkColumnDef,
				useExisting: NbTreeGridColumnDefDirective
			}, {
				provide: NB_SORT_HEADER_COLUMN_DEF,
				useExisting: NbTreeGridColumnDefDirective
			}],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridColumnDefDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridColumnDef]",
			providers: [{
				provide: NbCdkColumnDef,
				useExisting: NbTreeGridColumnDefDirective
			}, {
				provide: NB_SORT_HEADER_COLUMN_DEF,
				useExisting: NbTreeGridColumnDefDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		name: [{
			type: Input,
			args: ["nbTreeGridColumnDef"]
		}],
		hideOn: [{ type: Input }],
		showOn: [{ type: Input }]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridCellDirective = class NbTreeGridCellDirective extends NbCellDirective {
	get columnWidth() {
		this.latestWidth = this.tree.getColumnWidth();
		if (this.latestWidth) return this.latestWidth;
		return null;
	}
	get leftPadding() {
		if (this.directionService.isLtr()) return this.getStartPadding();
		return null;
	}
	get rightPadding() {
		if (this.directionService.isRtl()) return this.getStartPadding();
		return null;
	}
	constructor(columnDef, elementRef, tree, platformId, window, sanitizer, directionService, columnService, cd) {
		super(columnDef, elementRef);
		this.platformId = platformId;
		this.window = window;
		this.sanitizer = sanitizer;
		this.directionService = directionService;
		this.columnService = columnService;
		this.cd = cd;
		this.destroy$ = new Subject();
		this.initialLeftPadding = "";
		this.initialRightPadding = "";
		this.tree = tree;
		this.columnDef = columnDef;
		this.elementRef = elementRef;
	}
	ngOnInit() {
		if (isPlatformBrowser(this.platformId)) {
			const style = this.window.getComputedStyle(this.elementRef.nativeElement);
			this.initialLeftPadding = style.paddingLeft;
			this.initialRightPadding = style.paddingRight;
		}
		this.columnService.onColumnsChange().pipe(filter(() => this.latestWidth !== this.tree.getColumnWidth()), takeUntil(this.destroy$)).subscribe(() => this.cd.detectChanges());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	toggleRow() {
		this.tree.toggleCellRow(this);
	}
	get initialStartPadding() {
		return this.directionService.isLtr() ? this.initialLeftPadding : this.initialRightPadding;
	}
	getStartPadding() {
		const rowLevel = this.tree.getCellLevel(this, this.columnDef.name);
		if (rowLevel === 0) return null;
		const nestingLevel = rowLevel + 1;
		let padding = "";
		if (this.tree.levelPadding) padding = `calc(${this.tree.levelPadding} * ${nestingLevel})`;
		else if (this.initialStartPadding) padding = `calc(${this.initialStartPadding} * ${nestingLevel})`;
		if (!padding) return null;
		return this.sanitizer.bypassSecurityTrustStyle(padding);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridCellDirective,
			deps: [
				{ token: NbTreeGridColumnDefDirective },
				{ token: i0.ElementRef },
				{ token: NB_TREE_GRID },
				{ token: PLATFORM_ID },
				{ token: NB_WINDOW },
				{ token: i1$2.DomSanitizer },
				{ token: NbLayoutDirectionService },
				{ token: NbColumnsService },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridCellDirective,
			isStandalone: false,
			selector: "td[nbTreeGridCell]",
			host: {
				attributes: { "role": "gridcell" },
				properties: {
					"style.width": "this.columnWidth",
					"style.padding-left": "this.leftPadding",
					"style.padding-right": "this.rightPadding"
				},
				classAttribute: "nb-tree-grid-cell"
			},
			providers: [{
				provide: NbCdkCell,
				useExisting: NbTreeGridCellDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "td[nbTreeGridCell]",
			host: {
				"class": "nb-tree-grid-cell",
				"role": "gridcell"
			},
			providers: [{
				provide: NbCdkCell,
				useExisting: NbTreeGridCellDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: NbTreeGridColumnDefDirective },
		{ type: i0.ElementRef },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_TREE_GRID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_WINDOW]
			}]
		},
		{ type: i1$2.DomSanitizer },
		{ type: NbLayoutDirectionService },
		{ type: NbColumnsService },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: {
		columnWidth: [{
			type: HostBinding,
			args: ["style.width"]
		}],
		leftPadding: [{
			type: HostBinding,
			args: ["style.padding-left"]
		}],
		rightPadding: [{
			type: HostBinding,
			args: ["style.padding-right"]
		}]
	}
});
var NbTreeGridHeaderCellDirective = class NbTreeGridHeaderCellDirective extends NbHeaderCellDirective {
	get columnWidth() {
		this.latestWidth = this.tree.getColumnWidth();
		return this.latestWidth || null;
	}
	constructor(columnDef, elementRef, tree, columnService, cd) {
		super(columnDef, elementRef);
		this.columnService = columnService;
		this.cd = cd;
		this.destroy$ = new Subject();
		this.tree = tree;
	}
	ngOnInit() {
		this.columnService.onColumnsChange().pipe(filter(() => this.latestWidth !== this.tree.getColumnWidth()), takeUntil(this.destroy$)).subscribe(() => this.cd.detectChanges());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridHeaderCellDirective,
			deps: [
				{ token: NbTreeGridColumnDefDirective },
				{ token: i0.ElementRef },
				{ token: NB_TREE_GRID },
				{ token: NbColumnsService },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridHeaderCellDirective,
			isStandalone: false,
			selector: "th[nbTreeGridHeaderCell]",
			host: {
				attributes: { "role": "columnheader" },
				properties: { "style.width": "this.columnWidth" },
				classAttribute: "nb-tree-grid-header-cell"
			},
			providers: [{
				provide: NbCdkHeaderCell,
				useExisting: NbTreeGridHeaderCellDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridHeaderCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "th[nbTreeGridHeaderCell]",
			host: {
				"class": "nb-tree-grid-header-cell",
				"role": "columnheader"
			},
			providers: [{
				provide: NbCdkHeaderCell,
				useExisting: NbTreeGridHeaderCellDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: NbTreeGridColumnDefDirective },
		{ type: i0.ElementRef },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_TREE_GRID]
			}]
		},
		{ type: NbColumnsService },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: { columnWidth: [{
		type: HostBinding,
		args: ["style.width"]
	}] }
});
var NbTreeGridFooterCellDirective = class NbTreeGridFooterCellDirective extends NbFooterCellDirective {
	get columnWidth() {
		this.latestWidth = this.tree.getColumnWidth();
		return this.latestWidth || null;
	}
	constructor(columnDef, elementRef, tree, columnService, cd) {
		super(columnDef, elementRef);
		this.columnService = columnService;
		this.cd = cd;
		this.destroy$ = new Subject();
		this.tree = tree;
	}
	ngOnInit() {
		this.columnService.onColumnsChange().pipe(filter(() => this.latestWidth !== this.tree.getColumnWidth()), takeUntil(this.destroy$)).subscribe(() => this.cd.detectChanges());
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridFooterCellDirective,
			deps: [
				{ token: NbTreeGridColumnDefDirective },
				{ token: i0.ElementRef },
				{ token: NB_TREE_GRID },
				{ token: NbColumnsService },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridFooterCellDirective,
			isStandalone: false,
			selector: "td[nbTreeGridFooterCell]",
			host: {
				attributes: { "role": "gridcell" },
				properties: { "style.width": "this.columnWidth" },
				classAttribute: "nb-tree-grid-footer-cell"
			},
			providers: [{
				provide: NbCdkFooterCell,
				useExisting: NbTreeGridFooterCellDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridFooterCellDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "td[nbTreeGridFooterCell]",
			host: {
				"class": "nb-tree-grid-footer-cell",
				"role": "gridcell"
			},
			providers: [{
				provide: NbCdkFooterCell,
				useExisting: NbTreeGridFooterCellDirective
			}],
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: NbTreeGridColumnDefDirective },
		{ type: i0.ElementRef },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [NB_TREE_GRID]
			}]
		},
		{ type: NbColumnsService },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: { columnWidth: [{
		type: HostBinding,
		args: ["style.width"]
	}] }
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbFilterDirective = class NbFilterDirective {
	filter(filterRequest) {
		this.filterable.filter(filterRequest);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFilterDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFilterDirective,
			isStandalone: false,
			selector: "[nbFilter]",
			inputs: { filterable: ["nbFilter", "filterable"] },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFilterDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbFilter]",
			standalone: false
		}]
	}],
	propDecorators: { filterable: [{
		type: Input,
		args: ["nbFilter"]
	}] }
});
var NbFilterInputDirective = class NbFilterInputDirective extends NbFilterDirective {
	constructor() {
		super(...arguments);
		this.search$ = new Subject();
		this.destroy$ = new Subject();
		this.debounceTime = 200;
	}
	ngOnInit() {
		this.search$.pipe(debounceTime(this.debounceTime), takeUntil(this.destroy$)).subscribe((query) => {
			super.filter(query);
		});
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
		this.search$.complete();
	}
	filter(event) {
		this.search$.next(event.target.value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbFilterInputDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbFilterInputDirective,
			isStandalone: false,
			selector: "[nbFilterInput]",
			inputs: {
				filterable: ["nbFilterInput", "filterable"],
				debounceTime: "debounceTime"
			},
			host: { listeners: { "input": "filter($event)" } },
			providers: [{
				provide: NbFilterDirective,
				useExisting: NbFilterInputDirective
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbFilterInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbFilterInput]",
			providers: [{
				provide: NbFilterDirective,
				useExisting: NbFilterInputDirective
			}],
			standalone: false
		}]
	}],
	propDecorators: {
		filterable: [{
			type: Input,
			args: ["nbFilterInput"]
		}],
		debounceTime: [{ type: Input }],
		filter: [{
			type: HostListener,
			args: ["input", ["$event"]]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridRowToggleDirective = class NbTreeGridRowToggleDirective {
	toggleRow($event) {
		this.cell.toggleRow();
		$event.stopPropagation();
	}
	constructor(cell) {
		this.cell = cell;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridRowToggleDirective,
			deps: [{ token: NbTreeGridCellDirective }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridRowToggleDirective,
			isStandalone: false,
			selector: "[nbTreeGridRowToggle]",
			host: { listeners: { "click": "toggleRow($event)" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridRowToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[nbTreeGridRowToggle]",
			standalone: false
		}]
	}],
	ctorParameters: () => [{ type: NbTreeGridCellDirective }],
	propDecorators: { toggleRow: [{
		type: HostListener,
		args: ["click", ["$event"]]
	}] }
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbTreeGridRowToggleComponent = class NbTreeGridRowToggleComponent {
	set expanded(value) {
		this.expandedValue = value;
	}
	get expanded() {
		return this.expandedValue;
	}
	toggleRow($event) {
		this.cell.toggleRow();
		$event.stopPropagation();
	}
	constructor(cell) {
		this.cell = cell;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridRowToggleComponent,
			deps: [{ token: NbTreeGridCellDirective }],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbTreeGridRowToggleComponent,
			isStandalone: false,
			selector: "nb-tree-grid-row-toggle",
			inputs: { expanded: "expanded" },
			host: { listeners: { "click": "toggleRow($event)" } },
			ngImport: i0,
			template: `
    <button class="row-toggle-button" [attr.aria-label]="expanded ? 'collapse' : 'expand'">
      <nb-icon [icon]="expanded ? 'chevron-down-outline' : 'chevron-right-outline'"
               pack="nebular-essentials"
               aria-hidden="true">
      </nb-icon>
    </button>
  `,
			isInline: true,
			styles: ["button{background:transparent;border:none;padding:0}\n"],
			dependencies: [{
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridRowToggleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-tree-grid-row-toggle",
			template: `
    <button class="row-toggle-button" [attr.aria-label]="expanded ? 'collapse' : 'expand'">
      <nb-icon [icon]="expanded ? 'chevron-down-outline' : 'chevron-right-outline'"
               pack="nebular-essentials"
               aria-hidden="true">
      </nb-icon>
    </button>
  `,
			standalone: false,
			styles: ["button{background:transparent;border:none;padding:0}\n"]
		}]
	}],
	ctorParameters: () => [{ type: NbTreeGridCellDirective }],
	propDecorators: {
		expanded: [{ type: Input }],
		toggleRow: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	}
});
/*
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
const COMPONENTS = [
	NbTreeGridComponent,
	NbTreeGridRowDefDirective,
	NbTreeGridRowComponent,
	NbTreeGridCellDefDirective,
	NbTreeGridCellDirective,
	NbTreeGridHeaderRowDefDirective,
	NbTreeGridHeaderRowComponent,
	NbTreeGridHeaderCellDefDirective,
	NbTreeGridHeaderCellDirective,
	NbTreeGridFooterRowDefDirective,
	NbTreeGridFooterRowComponent,
	NbTreeGridFooterCellDefDirective,
	NbTreeGridFooterCellDirective,
	NbTreeGridColumnDefDirective,
	NbSortDirective,
	NbSortHeaderComponent,
	NbSortIconComponent,
	NbFilterDirective,
	NbFilterInputDirective,
	NbTreeGridRowToggleDirective,
	NbTreeGridRowToggleComponent,
	NbSortHeaderIconDirective
];
var NbTreeGridModule = class NbTreeGridModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridModule,
			declarations: [
				NbTreeGridComponent,
				NbTreeGridRowDefDirective,
				NbTreeGridRowComponent,
				NbTreeGridCellDefDirective,
				NbTreeGridCellDirective,
				NbTreeGridHeaderRowDefDirective,
				NbTreeGridHeaderRowComponent,
				NbTreeGridHeaderCellDefDirective,
				NbTreeGridHeaderCellDirective,
				NbTreeGridFooterRowDefDirective,
				NbTreeGridFooterRowComponent,
				NbTreeGridFooterCellDefDirective,
				NbTreeGridFooterCellDirective,
				NbTreeGridColumnDefDirective,
				NbSortDirective,
				NbSortHeaderComponent,
				NbSortIconComponent,
				NbFilterDirective,
				NbFilterInputDirective,
				NbTreeGridRowToggleDirective,
				NbTreeGridRowToggleComponent,
				NbSortHeaderIconDirective
			],
			imports: [
				CommonModule,
				NbTableModule,
				NbIconModule
			],
			exports: [
				NbTableModule,
				NbTreeGridComponent,
				NbTreeGridRowDefDirective,
				NbTreeGridRowComponent,
				NbTreeGridCellDefDirective,
				NbTreeGridCellDirective,
				NbTreeGridHeaderRowDefDirective,
				NbTreeGridHeaderRowComponent,
				NbTreeGridHeaderCellDefDirective,
				NbTreeGridHeaderCellDirective,
				NbTreeGridFooterRowDefDirective,
				NbTreeGridFooterRowComponent,
				NbTreeGridFooterCellDefDirective,
				NbTreeGridFooterCellDirective,
				NbTreeGridColumnDefDirective,
				NbSortDirective,
				NbSortHeaderComponent,
				NbSortIconComponent,
				NbFilterDirective,
				NbFilterInputDirective,
				NbTreeGridRowToggleDirective,
				NbTreeGridRowToggleComponent,
				NbSortHeaderIconDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbTreeGridModule,
			providers: [
				NbTreeGridSortService,
				NbTreeGridFilterService,
				NbTreeGridService,
				NbTreeGridDataService,
				NbTreeGridDataSourceBuilder
			],
			imports: [
				CommonModule,
				NbTableModule,
				NbIconModule,
				NbTableModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbTreeGridModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				NbTableModule,
				NbIconModule
			],
			declarations: [...COMPONENTS],
			exports: [NbTableModule, ...COMPONENTS],
			providers: [
				NbTreeGridSortService,
				NbTreeGridFilterService,
				NbTreeGridService,
				NbTreeGridDataService,
				NbTreeGridDataSourceBuilder
			]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToggleComponent = class NbToggleComponent {
	get checked() {
		return this._checked;
	}
	set checked(value) {
		this._checked = convertToBoolProperty(value);
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = convertToBoolProperty(value);
	}
	get primary() {
		return this.status === "primary";
	}
	get success() {
		return this.status === "success";
	}
	get warning() {
		return this.status === "warning";
	}
	get danger() {
		return this.status === "danger";
	}
	get info() {
		return this.status === "info";
	}
	get basic() {
		return this.status === "basic";
	}
	get control() {
		return this.status === "control";
	}
	get additionalClasses() {
		if (this.statusService.isCustomStatus(this.status)) return [this.statusService.getStatusClass(this.status)];
		return [];
	}
	get labelLeft() {
		return this.labelPosition === "left";
	}
	get labelRight() {
		return this.labelPosition === "right";
	}
	get labelStart() {
		return this.labelPosition === "start";
	}
	get labelEnd() {
		return this.labelPosition === "end";
	}
	constructor(changeDetector, layoutDirection, renderer, hostElement, zone, statusService) {
		this.changeDetector = changeDetector;
		this.layoutDirection = layoutDirection;
		this.renderer = renderer;
		this.hostElement = hostElement;
		this.zone = zone;
		this.statusService = statusService;
		this.onChange = () => {};
		this.onTouched = () => {};
		this.destroy$ = new Subject();
		this._checked = false;
		this._disabled = false;
		this.status = "basic";
		this.labelPosition = "end";
		this.checkedChange = new EventEmitter();
	}
	ngOnInit() {
		this.layoutDirection.onDirectionChange().pipe(takeUntil(this.destroy$)).subscribe(() => this.changeDetector.detectChanges());
	}
	ngAfterViewInit() {
		this.zone.runOutsideAngular(() => setTimeout(() => {
			this.renderer.addClass(this.hostElement.nativeElement, "nb-transition");
		}));
	}
	ngOnDestroy() {
		this.destroy$.next();
		this.destroy$.complete();
	}
	checkState() {
		if (this.checked) return this.layoutDirection.isLtr() ? "right" : "left";
		return this.layoutDirection.isLtr() ? "left" : "right";
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	writeValue(val) {
		this.checked = val;
		this.changeDetector.markForCheck();
	}
	setDisabledState(val) {
		this.disabled = convertToBoolProperty(val);
		this.changeDetector.markForCheck();
	}
	updateValue(event) {
		const input = event.target;
		this.checked = input.checked;
		this.checkedChange.emit(this.checked);
		this.onChange(this.checked);
	}
	onInputClick(event) {
		event.stopPropagation();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToggleComponent,
			deps: [
				{ token: i0.ChangeDetectorRef },
				{ token: NbLayoutDirectionService },
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: i0.NgZone },
				{ token: NbStatusService }
			],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.0",
			type: NbToggleComponent,
			isStandalone: false,
			selector: "nb-toggle",
			inputs: {
				checked: "checked",
				disabled: "disabled",
				status: "status",
				labelPosition: "labelPosition"
			},
			outputs: { checkedChange: "checkedChange" },
			host: { properties: {
				"class.status-primary": "this.primary",
				"class.status-success": "this.success",
				"class.status-warning": "this.warning",
				"class.status-danger": "this.danger",
				"class.status-info": "this.info",
				"class.status-basic": "this.basic",
				"class.status-control": "this.control",
				"class": "this.additionalClasses",
				"class.toggle-label-left": "this.labelLeft",
				"class.toggle-label-right": "this.labelRight",
				"class.toggle-label-start": "this.labelStart",
				"class.toggle-label-end": "this.labelEnd"
			} },
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbToggleComponent),
				multi: true
			}],
			ngImport: i0,
			template: `
    <label class="toggle-label">
      <input type="checkbox"
             class="native-input visually-hidden"
             role="switch"
             [attr.aria-checked]="checked"
             [disabled]="disabled"
             [checked]="checked"
             (change)="updateValue($event)"
             (blur)="onTouched()"
             (click)="onInputClick($event)">
      <div class="toggle" [class.checked]="checked">
        <span [@position]="checkState()" class="toggle-switcher">
          <nb-icon *ngIf="checked" icon="checkmark-bold-outline" pack="nebular-essentials"></nb-icon>
        </span>
      </div>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			isInline: true,
			styles: [":host{display:inline-flex;outline:none}:host(.toggle-label-left) .text:not(:empty){padding-right:.6875rem}[dir=ltr] :host(.toggle-label-left) .text:not(:empty){order:-1}[dir=rtl] :host(.toggle-label-left) .text:not(:empty){order:1}:host(.toggle-label-right) .text:not(:empty){padding-left:.6875rem}[dir=ltr] :host(.toggle-label-right) .text:not(:empty){order:1}[dir=rtl] :host(.toggle-label-right) .text:not(:empty){order:-1}:host(.toggle-label-start) .toggle-label{flex-direction:row-reverse}[dir=ltr] :host(.toggle-label-start) .toggle-label .text:not(:empty){padding-right:.6875rem}[dir=rtl] :host(.toggle-label-start) .toggle-label .text:not(:empty){padding-left:.6875rem}[dir=ltr] :host(.toggle-label-end) .text:not(:empty){padding-left:.6875rem}[dir=rtl] :host(.toggle-label-end) .text:not(:empty){padding-right:.6875rem}:host(.nb-transition) .toggle{transition-duration:.15s;transition-property:background-color,border,box-shadow;transition-timing-function:ease-in}.toggle-label{position:relative;display:inline-flex;align-items:center}.toggle{position:relative;display:inline-flex;box-sizing:content-box}.toggle-switcher{position:absolute;border-radius:50%;margin:1px}.toggle-switcher nb-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"],
			dependencies: [{
				kind: "directive",
				type: i2.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}, {
				kind: "component",
				type: NbIconComponent,
				selector: "nb-icon",
				inputs: [
					"icon",
					"pack",
					"options",
					"status",
					"config"
				]
			}],
			animations: [trigger("position", [
				state("right", style({
					right: 0,
					left: "*"
				})),
				state("left", style({
					left: 0,
					right: "*"
				})),
				transition(":enter", [animate(0)]),
				transition("right <=> left", [animate("0.15s")])
			])],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToggleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "nb-toggle",
			animations: [trigger("position", [
				state("right", style({
					right: 0,
					left: "*"
				})),
				state("left", style({
					left: 0,
					right: "*"
				})),
				transition(":enter", [animate(0)]),
				transition("right <=> left", [animate("0.15s")])
			])],
			template: `
    <label class="toggle-label">
      <input type="checkbox"
             class="native-input visually-hidden"
             role="switch"
             [attr.aria-checked]="checked"
             [disabled]="disabled"
             [checked]="checked"
             (change)="updateValue($event)"
             (blur)="onTouched()"
             (click)="onInputClick($event)">
      <div class="toggle" [class.checked]="checked">
        <span [@position]="checkState()" class="toggle-switcher">
          <nb-icon *ngIf="checked" icon="checkmark-bold-outline" pack="nebular-essentials"></nb-icon>
        </span>
      </div>
      <span class="text">
        <ng-content></ng-content>
      </span>
    </label>
  `,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NbToggleComponent),
				multi: true
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: false,
			styles: [":host{display:inline-flex;outline:none}:host(.toggle-label-left) .text:not(:empty){padding-right:.6875rem}[dir=ltr] :host(.toggle-label-left) .text:not(:empty){order:-1}[dir=rtl] :host(.toggle-label-left) .text:not(:empty){order:1}:host(.toggle-label-right) .text:not(:empty){padding-left:.6875rem}[dir=ltr] :host(.toggle-label-right) .text:not(:empty){order:1}[dir=rtl] :host(.toggle-label-right) .text:not(:empty){order:-1}:host(.toggle-label-start) .toggle-label{flex-direction:row-reverse}[dir=ltr] :host(.toggle-label-start) .toggle-label .text:not(:empty){padding-right:.6875rem}[dir=rtl] :host(.toggle-label-start) .toggle-label .text:not(:empty){padding-left:.6875rem}[dir=ltr] :host(.toggle-label-end) .text:not(:empty){padding-left:.6875rem}[dir=rtl] :host(.toggle-label-end) .text:not(:empty){padding-right:.6875rem}:host(.nb-transition) .toggle{transition-duration:.15s;transition-property:background-color,border,box-shadow;transition-timing-function:ease-in}.toggle-label{position:relative;display:inline-flex;align-items:center}.toggle{position:relative;display:inline-flex;box-sizing:content-box}.toggle-switcher{position:absolute;border-radius:50%;margin:1px}.toggle-switcher nb-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n"]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ChangeDetectorRef },
		{ type: NbLayoutDirectionService },
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: i0.NgZone },
		{ type: NbStatusService }
	],
	propDecorators: {
		checked: [{ type: Input }],
		disabled: [{ type: Input }],
		status: [{ type: Input }],
		labelPosition: [{ type: Input }],
		checkedChange: [{ type: Output }],
		primary: [{
			type: HostBinding,
			args: ["class.status-primary"]
		}],
		success: [{
			type: HostBinding,
			args: ["class.status-success"]
		}],
		warning: [{
			type: HostBinding,
			args: ["class.status-warning"]
		}],
		danger: [{
			type: HostBinding,
			args: ["class.status-danger"]
		}],
		info: [{
			type: HostBinding,
			args: ["class.status-info"]
		}],
		basic: [{
			type: HostBinding,
			args: ["class.status-basic"]
		}],
		control: [{
			type: HostBinding,
			args: ["class.status-control"]
		}],
		additionalClasses: [{
			type: HostBinding,
			args: ["class"]
		}],
		labelLeft: [{
			type: HostBinding,
			args: ["class.toggle-label-left"]
		}],
		labelRight: [{
			type: HostBinding,
			args: ["class.toggle-label-right"]
		}],
		labelStart: [{
			type: HostBinding,
			args: ["class.toggle-label-start"]
		}],
		labelEnd: [{
			type: HostBinding,
			args: ["class.toggle-label-end"]
		}]
	}
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
var NbToggleModule = class NbToggleModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToggleModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToggleModule,
			declarations: [NbToggleComponent],
			imports: [CommonModule, NbIconModule],
			exports: [NbToggleComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.0",
			ngImport: i0,
			type: NbToggleModule,
			imports: [CommonModule, NbIconModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NbToggleModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule, NbIconModule],
			declarations: [NbToggleComponent],
			exports: [NbToggleComponent]
		}]
	}]
});
/**
* @license
* Copyright Akveo. All Rights Reserved.
* Licensed under the MIT License. See License.txt in the project root for license information.
*/
export { BUILT_IN_THEMES, CORPORATE_THEME, COSMIC_THEME, DARK_THEME, DEFAULT_MEDIA_BREAKPOINTS, DEFAULT_THEME, MONTHS_IN_COLUMN, MONTHS_IN_VIEW, NB_BUILT_IN_JS_THEMES, NB_BUTTON_GROUP, NB_DATE_ADAPTER, NB_DATE_SERVICE_OPTIONS, NB_DEFAULT_ROW_LEVEL, NB_DEFAULT_TIMEPICKER_LOCALIZATION_CONFIG, NB_DIALOG_CONFIG, NB_DOCUMENT, NB_JS_THEMES, NB_LAYOUT_DIRECTION, NB_MEDIA_BREAKPOINTS, NB_ROW_DOUBLE_CLICK_DELAY, NB_SELECT_INJECTION_TOKEN, NB_SORT_HEADER_COLUMN_DEF, NB_STEPPER, NB_TABLE_PROVIDERS, NB_TABLE_TEMPLATE, NB_THEME_OPTIONS, NB_TIME_PICKER_CONFIG, NB_TOASTR_CONFIG, NB_TREE_GRID, NB_VIEW_REPEATER_STRATEGY, NB_WINDOW, NB_WINDOW_CONFIG, NB_WINDOW_CONTENT, NB_WINDOW_CONTEXT, NB_WINDOW_DEFAULT_BUTTONS_CONFIG, NbA11yModule, NbAccordionComponent, NbAccordionItemBodyComponent, NbAccordionItemComponent, NbAccordionItemHeaderComponent, NbAccordionModule, NbActionComponent, NbActionsComponent, NbActionsModule, NbAdjustableConnectedPositionStrategy, NbAdjustment, NbAlertComponent, NbAlertModule, NbAutocompleteComponent, NbAutocompleteDirective, NbAutocompleteModule, NbBadgeComponent, NbBadgeModule, NbBaseCalendarComponent, NbBaseCalendarModule, NbBaseCalendarRangeCell, NbBasePicker, NbBasePickerComponent, NbBidiModule, NbBlockScrollStrategyAdapter, NbButton, NbButtonComponent, NbButtonGroupComponent, NbButtonGroupModule, NbButtonModule, NbButtonToggleDirective, NbCalendarActionsComponent, NbCalendarComponent, NbCalendarDayCellComponent, NbCalendarDayPickerComponent, NbCalendarDaysNamesComponent, NbCalendarKitModule, NbCalendarModule, NbCalendarMonthCellComponent, NbCalendarMonthModelService, NbCalendarMonthPickerComponent, NbCalendarPageableNavigationComponent, NbCalendarPickerComponent, NbCalendarPickerRowComponent, NbCalendarRangeComponent, NbCalendarRangeDayCellComponent, NbCalendarRangeModule, NbCalendarRangeMonthCellComponent, NbCalendarRangeYearCellComponent, NbCalendarSize, NbCalendarTimeModelService, NbCalendarViewMode, NbCalendarViewModeComponent, NbCalendarWeekNumberComponent, NbCalendarWithTimeComponent, NbCalendarYearCellComponent, NbCalendarYearModelService, NbCalendarYearPickerComponent, NbCardBackComponent, NbCardBodyComponent, NbCardComponent, NbCardFooterComponent, NbCardFrontComponent, NbCardHeaderComponent, NbCardModule, NbCdkAdapterModule, NbCdkMappingModule, NbCellDefDirective, NbCellDirective, NbCellOutletDirective, NbChatAvatarComponent, NbChatComponent, NbChatCustomMessageDirective, NbChatCustomMessageService, NbChatFormComponent, NbChatMessageComponent, NbChatMessageFileComponent, NbChatMessageMapComponent, NbChatMessageQuoteComponent, NbChatMessageTextComponent, NbChatModule, NbChatOptions, NbChatTitleDirective, NbCheckboxComponent, NbCheckboxModule, NbClickTriggerStrategy, NbColorHelper, NbColumnDefDirective, NbColumnsService, NbComponentPortal, NbContextMenuComponent, NbContextMenuDirective, NbContextMenuModule, NbDataRowOutletDirective, NbDataSource, NbDateAdapterService, NbDateService, NbDateTimeAdapterService, NbDateTimePickerComponent, NbDatepicker, NbDatepickerAdapter, NbDatepickerComponent, NbDatepickerContainerComponent, NbDatepickerDirective, NbDatepickerModule, NbDialogConfig, NbDialogContainerComponent, NbDialogModule, NbDialogRef, NbDialogService, NbDirectionality, NbDynamicOverlay, NbDynamicOverlayChange, NbDynamicOverlayHandler, NbFilterDirective, NbFilterInputDirective, NbFlexibleConnectedPositionStrategy, NbFlipCardComponent, NbFocusKeyManager, NbFocusKeyManagerFactoryService, NbFocusMonitor, NbFocusTrap, NbFocusTrapFactoryService, NbFocusTriggerStrategy, NbFontIcon, NbFooterCellDefDirective, NbFooterCellDirective, NbFooterRowComponent, NbFooterRowDefDirective, NbFooterRowOutletDirective, NbFormFieldComponent, NbFormFieldControl, NbFormFieldControlConfig, NbFormFieldModule, NbGlobalLogicalPosition, NbGlobalPhysicalPosition, NbGlobalPositionStrategy, NbHeaderCellDefDirective, NbHeaderCellDirective, NbHeaderRowComponent, NbHeaderRowDefDirective, NbHeaderRowOutletDirective, NbHintTriggerStrategy, NbHoverTriggerStrategy, NbIconComponent, NbIconDefinition, NbIconLibraries, NbIconModule, NbIconPackType, NbInfiniteListDirective, NbInputDirective, NbInputModule, NbJSThemesRegistry, NbLayoutColumnComponent, NbLayoutComponent, NbLayoutDirection, NbLayoutDirectionService, NbLayoutFooterComponent, NbLayoutHeaderComponent, NbLayoutModule, NbLayoutRulerService, NbLayoutScrollService, NbListComponent, NbListItemComponent, NbListModule, NbListPageTrackerDirective, NbLtrDirective, NbMediaBreakpointsService, NbMenuComponent, NbMenuItem, NbMenuItemComponent, NbMenuModule, NbMenuService, NbNativeDateService, NbNoDataRowOutletDirective, NbNoopTriggerStrategy, NbOptionComponent, NbOptionGroupComponent, NbOptionListComponent, NbOptionModule, NbOverlay, NbOverlayContainer, NbOverlayContainerAdapter, NbOverlayContainerComponent, NbOverlayModule, NbOverlayPositionBuilder, NbOverlayService, NbPlatform, NbPopoverComponent, NbPopoverDirective, NbPopoverModule, NbPortalDirective, NbPortalOutletDirective, NbPosition, NbPositionBuilderService, NbPositionHelper, NbPositionedContainerComponent, NbPrefixDirective, NbProgressBarComponent, NbProgressBarModule, NbRadioComponent, NbRadioGroupComponent, NbRadioModule, NbRangeAdapterService, NbRangepickerComponent, NbRestoreScrollTopHelper, NbRevealCardComponent, NbRouteTabsetComponent, NbRouteTabsetModule, NbRowComponent, NbRowDefDirective, NbRtlDirective, NbScrollDispatcherAdapter, NbScrollStrategyOptions, NbScrollableContainerDimensions, NbSearchComponent, NbSearchFieldComponent, NbSearchModule, NbSearchService, NbSelectComponent, NbSelectLabelComponent, NbSelectModule, NbSelectWithAutocompleteComponent, NbSelectWithAutocompleteModule, NbSidebarComponent, NbSidebarFooterComponent, NbSidebarHeaderComponent, NbSidebarModule, NbSidebarService, NbSortDirection, NbSortDirective, NbSortHeaderComponent, NbSortHeaderIconDirective, NbSortIconComponent, NbSpinnerComponent, NbSpinnerDirective, NbSpinnerModule, NbSpinnerService, NbStatusService, NbStepComponent, NbStepperComponent, NbStepperModule, NbStepperNextDirective, NbStepperPreviousDirective, NbSuffixDirective, NbSvgIcon, NbTabComponent, NbTabContentDirective, NbTabTitleDirective, NbTable, NbTableModule, NbTabsetComponent, NbTabsetModule, NbTagComponent, NbTagInputDirective, NbTagListComponent, NbTagModule, NbTemplatePortal, NbThemeModule, NbThemeService, NbTimePickerCellComponent, NbTimePickerComponent, NbTimePickerDirective, NbTimepickerModule, NbToast, NbToastComponent, NbToastContainer, NbToastRef, NbToastrConfig, NbToastrContainerComponent, NbToastrContainerRegistry, NbToastrModule, NbToastrService, NbToggleComponent, NbToggleModule, NbToggleStates, NbTooltipComponent, NbTooltipDirective, NbTooltipModule, NbTreeGridCellDefDirective, NbTreeGridCellDirective, NbTreeGridColumnDefDirective, NbTreeGridComponent, NbTreeGridDataService, NbTreeGridDataSource, NbTreeGridDataSourceBuilder, NbTreeGridFilterService, NbTreeGridFooterCellDefDirective, NbTreeGridFooterCellDirective, NbTreeGridFooterRowComponent, NbTreeGridFooterRowDefDirective, NbTreeGridHeaderCellDefDirective, NbTreeGridHeaderCellDirective, NbTreeGridHeaderRowComponent, NbTreeGridHeaderRowDefDirective, NbTreeGridModule, NbTreeGridPresentationNode, NbTreeGridRowComponent, NbTreeGridRowDefDirective, NbTreeGridRowToggleComponent, NbTreeGridRowToggleDirective, NbTreeGridService, NbTreeGridSortService, NbTrigger, NbTriggerStrategyBase, NbTriggerStrategyBuilderService, NbUserComponent, NbUserModule, NbViewportRulerAdapter, NbWindowComponent, NbWindowConfig, NbWindowModule, NbWindowRef, NbWindowService, NbWindowState, NbWindowsContainerComponent, createContainer, nbSelectFormFieldControlConfigFactory, patch, windowFactory };

//# sourceMappingURL=nebular-theme.mjs.map